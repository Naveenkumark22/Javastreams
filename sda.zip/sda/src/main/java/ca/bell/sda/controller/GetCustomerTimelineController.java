package ca.bell.sda.controller;

import java.time.Instant;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import ca.bell.sda.constant.log.LogKey;
import ca.bell.sda.constant.status.StatusTypes;
import ca.bell.sda.model.Request;
import ca.bell.sda.model.Response;
import ca.bell.sda.process.RequestProcessor;
import ca.bell.sda.service.GetCustomerTimeLineService;
@RestController
public class GetCustomerTimelineController extends SDAController {
	
	@Autowired
	private RequestProcessor processor;
	
	@Autowired
	private GetCustomerTimeLineService service;
	
	@PostMapping("/sbm/GetCustomerTimeline")
	public Response getCustomerTimeline(@RequestBody Map<String, Object> requestMap) throws Exception {
		Response response = new Response(StatusTypes.REQUEST_SUCCESS);
			try {	  
			  Request request = new Request("sbm", "GetCustomerTimeline");
			  request.logTime(LogKey.REQ_START); 
			  request.log(LogKey.TIMESTAMP,Instant.now().toString());
			  request.log(LogKey.REQ_GRP_ID,request.getReqId());
			  request.log(LogKey.REQ_MAP, requestMap);			  			  
			  request.log(LogKey.QUERY_BUILD_START, System.currentTimeMillis());
			  String eomFlag=requestMap.getOrDefault("sourceSystem", "").toString();
			  requestMap.remove("brand");
			  requestMap.remove("sourceSystem");			  
			  processor.processRequest(requestMap, request, response);
			  if (response.getStatus().getCode() == StatusTypes.REQUEST_SUCCESS.getCode())
			  {   
				  response.setData(service.getCustomerTimeline(request, response,requestMap,eomFlag.trim()));
				  request.log(LogKey.REQ_RESPONSE, response.getData());
			  }
			  checkRequestLog(request); 
			}
			catch(Exception ex)
			{
				response.setStatus(StatusTypes.REQUEST_NOT_FOUND);
				ex.printStackTrace();
				return response;
			}
			 
		 return response; 
	}
}
