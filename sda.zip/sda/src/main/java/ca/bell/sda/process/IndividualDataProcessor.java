package ca.bell.sda.process;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ca.bell.sda.config.AttributesConfig;
import ca.bell.sda.constant.query.ElasticKey;
import ca.bell.sda.model.Request;
import ca.bell.sda.model.elk.response.ResponseData;

@Component
public class IndividualDataProcessor extends ElasticDataProcessor implements DataProcessor {

	@Autowired
	private AttributesConfig attributesConfig;

	private static final String SEARCH_FLAG = "searchFlag";
	private static final String GET_MC_FLAG = "GetMCFlag";
	private static final String SORT = "sort";
	private static final String DESC = "desc";
	private static final String ROLE = "role";
	private static final String MASTER_PROFILE = "masterProfile";
	private static final String RELATED_PARTY_ACCOUNT = "relatedPartyAccount";
	private static final String RELATED_ID = "relatedId";
	private static final String CONTACT_SOURCE_SYSTEM = "contactSourceSystem";
	private static final String SSC = "SSC";
	private static final String GM_NM1_CONTACT = "GM-NM1_CONTACT";
	private static final String ID = "id";
	private static final String CONTACT_TYPE = "contactType";
	private static final String AUTHORIZATION_LEVEL = "authorizationLevel";
	private static final String PRIMARY_CONTACT = "primaryContact";

	@SuppressWarnings("unchecked")
	@Override
	public <T> ResponseData processData(Request request, T data) {
		ResponseData resData = new ResponseData();
		Map<String, Object> dataMap = (Map<String, Object>) data;
		int total = getTotalValue(dataMap);
		resData.setTotal(total);
		if (total > 0) {
			Map<String, Object> profile;
			List<Map<String, Object>> profilesMap = getProfileMapList(dataMap);
			List<Map<String, Object>> profileList = new ArrayList<>();
			if (profilesMap != null) {
				for (Map<String, Object> profMap : profilesMap) {
					profile = new HashMap<>();
					Map<String, Object> sourceMap = (Map<String, Object>) profMap.get("_source");
					Set<String> keySet = null;
					if (request.getRequestMap().containsKey(SEARCH_FLAG)
							&& request.getRequestMap().get(SEARCH_FLAG).toString().equalsIgnoreCase("true")) {
						keySet = attributesConfig.getDataAttributes().get(request.getReqId()).get(MASTER_PROFILE)
								.getKeys();
						if (sourceMap != null && !sourceMap.isEmpty())
							transformSearchContact(request, sourceMap, profile);
					} else {
						keySet = attributesConfig.getDataAttributes().get(request.getReqId()).get("profile").getKeys();
						processDataMap(sourceMap, profile, keySet);
						if (request.getRequestMap().containsKey(GET_MC_FLAG)
								&& request.getRequestMap().get(GET_MC_FLAG).toString().equalsIgnoreCase("true")) {
							transformMasterContact(request, sourceMap, profile);
						}
					}
					if (profile.size() > 0)
						profileList.add(profile);
				}
				if (request.getRequestMap().containsKey(SORT)) {
					if (request.getRequestMap().get(SORT).toString().contains("-"))
						sorting(DESC, ROLE, profileList);
					else
						sorting("asc", ROLE, profileList);
				}
				resData.setProfiles(profileList);
			}
		}
		return resData;
	}

	@SuppressWarnings("unchecked")
	private void transformSearchContact(Request request, Map<String, Object> sourceMap, Map<String, Object> profile) {
		Set<String> keySet = attributesConfig.getDataAttributes().get(request.getReqId()).get(MASTER_PROFILE).getKeys();
		processDataMap(sourceMap, profile, keySet);

		if (profile.get(RELATED_PARTY_ACCOUNT) != null) {
			List<Map<String, Object>> relatedParty = (List<Map<String, Object>>) profile.get(RELATED_PARTY_ACCOUNT);
			String role = null;
			for (Map<String, Object> relatedPartyMap : relatedParty) {

				if (relatedPartyMap.size() > 0 && relatedPartyMap.get(RELATED_ID)!=null&& relatedPartyMap.get(RELATED_ID).toString()
						.equalsIgnoreCase((String) request.getRequestMap().get(RELATED_ID))) {
					if (relatedPartyMap.get(CONTACT_SOURCE_SYSTEM) != null
							&& relatedPartyMap.get(CONTACT_SOURCE_SYSTEM).toString().equalsIgnoreCase(SSC))
						role = relatedPartyMap.get(CONTACT_TYPE).toString();
					if (relatedPartyMap.get(PRIMARY_CONTACT) != null)
						profile.put(PRIMARY_CONTACT, relatedPartyMap.get(PRIMARY_CONTACT));
					profile.put(ROLE, relatedPartyMap.get(CONTACT_TYPE));
					profile.put(ID, relatedPartyMap.get(ID));
				}
			}
			if (role != null)
				profile.put(ROLE, role);
			profile.remove(RELATED_PARTY_ACCOUNT);
		}

	}

	@SuppressWarnings("unchecked")
	private void transformMasterContact(Request request, Map<String, Object> sourceMap, Map<String, Object> profile) {
		if (sourceMap.containsKey(ID)) {
			Map<String, Object> engPartyMap = new HashMap<>();
			engPartyMap.put(ID, sourceMap.get(ID));
			profile.put("engagedParty", engPartyMap);
		}
		if (sourceMap.containsKey(RELATED_PARTY_ACCOUNT) && sourceMap.get(RELATED_PARTY_ACCOUNT) != null) {

			List<Map<String, Object>> relPartyList = (List<Map<String, Object>>) sourceMap.get(RELATED_PARTY_ACCOUNT);
			List<Map<String, Object>> relPartyProfileList = null;
			List<Map<String, Object>> relPartyFilterList = relPartyList.stream()
					.filter(m1 -> (m1.containsKey(ID)
							&& m1.get(ID).toString().equalsIgnoreCase((String) request.getRequestMap().get(ID))))
					.collect(Collectors.toList());
			if (relPartyFilterList != null) {
				relPartyProfileList = relPartyFilterList.stream()
						.filter(rel -> rel.get(CONTACT_SOURCE_SYSTEM).toString().equalsIgnoreCase(SSC))
						.collect(Collectors.toList());
				if (relPartyProfileList.isEmpty()) {
					relPartyProfileList = relPartyFilterList.stream()
							.filter(rel -> rel.get(CONTACT_SOURCE_SYSTEM).toString().equalsIgnoreCase(GM_NM1_CONTACT))
							.collect(Collectors.toList());
					if (relPartyProfileList.isEmpty() && !relPartyFilterList.isEmpty())
						relPartyProfileList.add(relPartyFilterList.get(0) != null ? relPartyFilterList.get(0) : null);
				}

			}
			if (relPartyProfileList != null && !relPartyProfileList.isEmpty()) {
				Map<String, Object> relMap = relPartyProfileList.get(0);
				if(relMap!=null&&relMap.size()>0)
				{
				profile.put(ID, relMap.get(ID));
				relMap.remove(ID);
				profile.put(AUTHORIZATION_LEVEL, relMap.get(AUTHORIZATION_LEVEL));
				relMap.remove(AUTHORIZATION_LEVEL);
				profile.put(CONTACT_TYPE, relMap.get(CONTACT_TYPE));
				relMap.remove(CONTACT_TYPE);
				if (relMap.get(PRIMARY_CONTACT) != null)
					profile.put(PRIMARY_CONTACT, relMap.get(PRIMARY_CONTACT));
				relMap.remove(PRIMARY_CONTACT);
				profile.put(RELATED_PARTY_ACCOUNT, new ArrayList<Map<String, Object>>( Arrays.asList(relMap)));
				profile.remove("relatedEntity");
				profile.remove("sourceSystem");
				}
			}

		}
	}

	@SuppressWarnings("unchecked")
	public void processSuspectData(Map<String, Map<String, Object>> individualProfileMap, Object suspectData) {
		if (suspectData != null) {
			Map<String, Object> suspectMap = (Map<String, Object>) suspectData;
			int total = getTotalValue(suspectMap);
			if (total > 0) {
				List<Map<String, Object>> profilesList = getProfileMapList(suspectMap);
				profilesList.forEach(profile -> {
					Map<String, String> srcMap = (Map<String, String>) profile.get(ElasticKey.SOURCE);
					String fromGK = srcMap.get("fromContactGK");
					String suspectGK = srcMap.get("suspectContactGK");
					if (fromGK != null && individualProfileMap.containsKey(fromGK)) {
						individualProfileMap.get(fromGK).put("hasSuspect", "yes");
					}
					if (suspectGK != null && individualProfileMap.containsKey(suspectGK)) {
						individualProfileMap.get(suspectGK).put("hasSuspect", "yes");
					}
				});
			}
		}
	}

	void sorting(String orderStr, String sortStr, List<Map<String, Object>> profileList) {
		Collections.sort(profileList, (m1, m2) -> ((String) m1.get(sortStr)).compareTo((String) m2.get(sortStr)));
		if (orderStr.equalsIgnoreCase(DESC))
			Collections.reverse(profileList);

	}

}
