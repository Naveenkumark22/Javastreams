package ca.bell.sda.process;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.stereotype.Component;

import ca.bell.sda.constant.query.ElasticKey;

@Component
public abstract class ElasticDataProcessor {
	
	public String getStringOrNull(Object value) {
		if(value!=null) {
			return value.toString();
		}else {
			return null;
		}
	}

	public void setValue(Map<String, Object> sourceMap, Map<String, Object> targetMap, String srcKey,
			String targetKey) {
		setValue(sourceMap, targetMap, srcKey, targetKey, false);
	}

	public void setValue(Map<String, Object> sourceMap, Map<String, Object> targetMap, String srcKey, String targetKey,
			boolean nullable) {
		if (sourceMap.containsKey(srcKey)) {
			if (nullable) {
				targetMap.put(targetKey, sourceMap.get(srcKey));
			} else if (sourceMap.get(srcKey) != null) {
				targetMap.put(targetKey, sourceMap.get(srcKey));
			}
		}
	}

	public void setValueWithDefault(Map<String, Object> sourceMap, Map<String, Object> targetMap, String srcKey,
			String targetKey, Object defaultValue) {
		setValueWithDefault(sourceMap, targetMap, srcKey, targetKey, false);
	}

	public void setValueWithDefault(Map<String, Object> sourceMap, Map<String, Object> targetMap, String srcKey,
			String targetKey, Object defaultValue, boolean nullable) {
		if (sourceMap.containsKey(srcKey)) {
			if (nullable) {
				targetMap.put(targetKey, sourceMap.get(srcKey));
			} else if (sourceMap.get(srcKey) != null) {
				targetMap.put(targetKey, sourceMap.get(srcKey));
			} else { // Value for srcKey is null assign default value
				if (defaultValue != null) {
					targetMap.put(targetKey, defaultValue);
				}
			}
		} else { // Assign default value
			if (defaultValue != null) {
				targetMap.put(targetKey, defaultValue);
			}
		}
	}

	public void processDataMap(Map<String, Object> sourceMap, Map<String, Object> targetMap,
			Map<String, String> keyPairs) {
		processDataMap(sourceMap, targetMap, keyPairs, false);
	}

	public void processDataMap(Map<String, Object> sourceMap, Map<String, Object> targetMap,
			Map<String, String> keyPairs, boolean nullable) {
		Set<String> keySet = keyPairs.keySet();
		for (String srcKey : keySet) {
			String targetKey = keyPairs.get(srcKey);
			setValue(sourceMap, targetMap, srcKey, targetKey, nullable);
		}
	}

	public void processDataMap(Map<String, Object> sourceMap, Map<String, Object> targetMap, Set<String> keys) {
		processDataMap(sourceMap, targetMap, keys, false);
	}

	public void processDataMap(Map<String, Object> sourceMap, Map<String, Object> targetMap, Set<String> keys,
			boolean nullable) {
		for (String srcKey : keys) {
			setValue(sourceMap, targetMap, srcKey, srcKey, nullable);
		}
	}

	public void processDataMapWithDefault(Map<String, Object> sourceMap, Map<String, Object> targetMap,
			Map<String, String> keyPairs, Map<String, Object> defaultValueMap) {
		processDataMapWithDefault(sourceMap, targetMap, keyPairs, defaultValueMap, false);
	}

	public void processDataMapWithDefault(Map<String, Object> sourceMap, Map<String, Object> targetMap,
			Map<String, String> keyPairs, Map<String, Object> defaultValueMap, boolean nullable) {
		Set<String> keySet = keyPairs.keySet();
		for (String srcKey : keySet) {
			String targetKey = keyPairs.get(srcKey);
			setValueWithDefault(sourceMap, targetMap, srcKey, targetKey, defaultValueMap.getOrDefault(srcKey,null), nullable);
		}
	}

	@SuppressWarnings("unchecked")
	public Map<String, Object> getProfHitsMap(Map<String, Object> data) {
		Map<String, Object> hitsMap = (Map<String, Object>) data.get(ElasticKey.HITS);
		return hitsMap;
	}

	@SuppressWarnings("unchecked")
	public List<Map<String, Object>> getProfileMapList(Map<String, Object> data) {
		int total = getTotalValue(data);
		if (total > 0) {
			return (List<Map<String, Object>>) getProfHitsMap(data).get(ElasticKey.HITS);
		}
		return null;
	}

	public int getTotalValue(Map<String, Object> data) {
		Object totalObj = getProfHitsMap(data).get(ElasticKey.TOTAL);
		int total = 0;
		if (totalObj != null) {
			total = getTotal(totalObj);
		}
		return total;
	}

	@SuppressWarnings("unchecked")
	public List<Map<String, Object>> getBucketsList(String aggsId, Map<String, Object> data) {
		Map<String, Object> aggrs = (Map<String, Object>) data.get(ElasticKey.AGGREGATIONS);
		Map<String, Object> aggsMap = (Map<String, Object>) aggrs.get(aggsId);
		return (List<Map<String, Object>>) aggsMap.get(ElasticKey.BUCKETS);
	}

	@SuppressWarnings("unchecked")
	private int getTotal(Object totalObj) {
		if (totalObj.getClass() == int.class || totalObj.getClass() == String.class
				|| totalObj.getClass() == Integer.class) { // ELK 6.x.x
			return Integer.valueOf(totalObj.toString());
		} else { // ELK 7.x.x
			Map<String, Object> totalMap = (Map<String, Object>) totalObj;
			return (int) totalMap.get("value");
		}
	}

	@SuppressWarnings("unchecked")
	public Object changeTotalValue(Map<String, Object> data, int value) {
		Object totalObj = getProfHitsMap(data).get(ElasticKey.TOTAL);
		if (totalObj != null) {
			if (totalObj.getClass() == int.class || totalObj.getClass() == String.class) { // ELK 6.x.x
				return value;
			} else { // ELK 7.x.x
				Map<String, Object> totalMap = (Map<String, Object>) totalObj;
				totalMap.put("value", value);
				return totalMap;
			}
		}
		return null;
	}

	public double getMaxScore(Map<String, Object> data) {
		Map<String, Object> profHitsMap = getProfHitsMap(data);
		return (double) profHitsMap.get(ElasticKey.MAX_SCORE);
	}

	public void addDataToList(Map<String, List<Map<String, Object>>> targetData, String key,
			Map<String, Object> srcData) {
		if (srcData != null) {
			List<Map<String, Object>> dataList;
			if (targetData.containsKey(key)) {
				dataList = targetData.get(key);
			} else {
				dataList = new ArrayList<>();
				targetData.put(key, dataList);
			}
			dataList.add(srcData);
		}
	}

	public void createDataListPlaceholder(Map<String, List<Map<String, Object>>> targetData, String key) {
		List<Map<String, Object>> dataList = new ArrayList<>();
		if (!targetData.containsKey(key)) {
			targetData.put(key, dataList);
		}
	}

	public void addNameValueMap(List<Map<String, Object>> targetList, String name, Object value) {
		if (value != null) {
			targetList.add(createNameValueMap(name, value));
		}
	}

	/**
	 * Name value for characteristic map
	 * 
	 * @param name  - characteristic.name
	 * @param value - characteristic.value
	 * @return
	 */

	public Map<String, Object> createNameValueMap(String name, Object value) {
		Map<String, Object> dataMap = new HashMap<>();
		dataMap.put("name", name);
		dataMap.put("value", value);
		return dataMap;
	}

	/**
	 * 
	 * @param name  - characteristic.name
	 * @param value - characteristic.value
	 * @param lang  - characteristic.langdescriptor
	 * @return
	 */
	public Map<String, Object> createRegionlisationMap(String name, Object value, String langDescp, String lang) {
		Map<String, Object> map = createNameValueMap(name, value);
		map.put(langDescp, lang);
		return map;
	}

	/**
	 * Characteristic Map with Regionalisation
	 * 
	 * @param name         - characteristic.name
	 * @param value        - characteristic.value
	 * @param regionalName - characteristic.regionalisation
	 * @param regionalObj  - characteristic.regionalisation.{...}
	 * @return
	 */
	public Map<String, Object> createNameValueMapWithRegional(String name, Object value, String regionalName,
			Object... regionalObj) {
		Map<String, Object> nameValueMap = createNameValueMap(name, value);
		nameValueMap.put(regionalName, regionalObj);
		return nameValueMap;
	}

	@SuppressWarnings("unchecked")
	public Map<String, Object> findDataMap(String key, String value, Object srcObj) {
		return findDataMap(key, value, (List<Map<String, Object>>) srcObj);
	}

	public Map<String, Object> findDataMap(String key, String value, List<Map<String, Object>> srcMapList) {
		if (srcMapList != null) {
			for (Map<String, Object> srcMap : srcMapList) {
				if (srcMap.containsKey(key)) {
					if (srcMap.get(key).toString().equalsIgnoreCase(value)) {
						return srcMap;
					}
				}
			}
		}
		return null;
	}

	@SuppressWarnings("unchecked")
	public Map<String, Object> iterateAndGetMap(String[] pathArr, Map<String, Object> srcMap) {
		Map<String, Object> map = srcMap;
		for (int i = 0; i < pathArr.length; i++) {
			if (map.containsKey(pathArr[i])) {
				map = (Map<String, Object>) map.get(pathArr[i]);
			} else {
				return null;
			}
		}
		return map;
	}

	@SuppressWarnings("unchecked")
	public Object iterateAndGetList(String[] pathArr, Map<String, Object> srcMap) {
		Map<String, Object> map = srcMap;
		for (int i = 0; i < pathArr.length; i++) {
			if (map.containsKey(pathArr[i])) {
				if (i == pathArr.length - 1) {
					return map.get(pathArr[i]);
				} else {
					map = (Map<String, Object>) map.get(pathArr[i]);
				}
			} else {
				return null;
			}

		}
		return null;
	}

}
