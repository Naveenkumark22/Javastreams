/**
 * 
 */
package ca.bell.sda.model.whitespace.ml;

/**
 * @author Kamalanathan Ranganathan
 *
 */
public class AdditionalQueryCall {

	private int index;

	private boolean isAddrNull = false;

	private String qry;

	private String endpoint;

	private String url;

	private String filterpath;

	/**
	 * @param index
	 * @param isAddrNull
	 * @param qry
	 * @param endpoint
	 * @param url
	 * @param filterpath
	 */
	public AdditionalQueryCall(int index, boolean isAddrNull, String qry, String endpoint, String url, String filterpath) {

		this.index = index;

		this.isAddrNull = isAddrNull;

		this.qry = qry;

		this.endpoint = endpoint;

		this.url = url;

		this.filterpath = filterpath;
	}

	public int getIndex() {
		return index;
	}

	public void setIndex(int index) {
		this.index = index;
	}

	public boolean isAddrNull() {
		return isAddrNull;
	}

	public void setAddrNull(boolean isAddrNull) {
		this.isAddrNull = isAddrNull;
	}

	public String getQry() {
		return qry;
	}

	public void setQry(String qry) {
		this.qry = qry;
	}

	public String getEndpoint() {
		return endpoint;
	}

	public void setEndpoint(String endpoint) {
		this.endpoint = endpoint;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getFilterpath() {
		return filterpath;
	}

	public void setFilterpath(String filterpath) {
		this.filterpath = filterpath;
	}

}
