package ca.bell.sda.model;

import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class CustomerTimeline {
	
	private String id;
	private List<Map<String,Object>> events;
	
	public CustomerTimeline(String id, List<Map<String, Object>> eventDataList) {
		this.id=id;
		this.events=eventDataList;
	}
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public List<Map<String, Object>> getEvents() {
		return events;
	}
	public void setEvents(List<Map<String, Object>> events) {
		this.events = events;
	}
	@Override
	public String toString() {
		return "CustomerTimeline [id=" + id + ", events=" + events + "]";
	}
	
	
}
