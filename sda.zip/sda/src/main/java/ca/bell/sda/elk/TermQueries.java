package ca.bell.sda.elk;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;

@Component
public class TermQueries {

	public static Map<String, Object> getTermQuery(String attrb, Object value, String boostVal) {
		Map<String, Object> rootMap = new HashMap<>();
		Map<String, Object> term = new HashMap<>();
		Map<String, Object> termQuery = new HashMap<>();

		termQuery.put("value", value);
		termQuery.put("boost", boostVal);
		term.put(attrb, termQuery);
		rootMap.put("term", term);

		return rootMap;
	}

	public static Map<String, Object> getNestedTermQuery(String attrb, String path, Object value, String boolCondition,
			String boostVal) {
		Map<String, Object> rootMap = new HashMap<>();
		Map<String, Object> nested = new HashMap<>();
		Map<String, Object> query = new HashMap<>();
		Map<String, List<Object>> bool = new HashMap<>();
		List<Object> objList = new ArrayList<>();
		Map<String, Object> term = new HashMap<>();
		Map<String, Object> attrbMap = new HashMap<>();
		Map<String, Object> termQuery = new HashMap<>();

		termQuery.put("value", value);
		termQuery.put("boost", boostVal);
		attrbMap.put(attrb, termQuery);
		term.put("term", attrbMap);
		objList.add(term);
		bool.put(boolCondition, objList);
		query.put("bool", bool);
		nested.put("path", path);
		nested.put("query", query);
		rootMap.put("nested", nested);

		return rootMap;
	}

}
