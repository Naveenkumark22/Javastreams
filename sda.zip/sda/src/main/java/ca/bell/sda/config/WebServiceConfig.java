package ca.bell.sda.config;

import java.util.Map;

import org.springframework.stereotype.Component;

import ca.bell.sda.model.config.Endpoint;

@Component
public class WebServiceConfig {
	private String codecsMaxInMemory;
	private Map<String, Endpoint> endPoints;

	public String getCodecsMaxInMemory() {
		return codecsMaxInMemory;
	}

	public void setCodecsMaxInMemory(String codecsMaxInMemory) {
		this.codecsMaxInMemory = codecsMaxInMemory;
	}

	public Map<String, Endpoint> getEndPoints() {
		return endPoints;
	}

	public void setEndPoints(Map<String, Endpoint> endPoints) {
		this.endPoints = endPoints;
	}

}
