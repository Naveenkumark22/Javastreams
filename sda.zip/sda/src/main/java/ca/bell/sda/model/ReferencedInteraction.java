package ca.bell.sda.model;

import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
@JsonInclude(Include.NON_NULL)
public class ReferencedInteraction {
	
	private List<Map<String,List<Map<String,Object>>>> interactionItem;
    private Object interactionType;
    private List<Characteristic> characteristic ;
    private Object interactionStatus;
    			
	public List<Map<String, List<Map<String, Object>>>> getInteractionItem() {
		return interactionItem;
	}
	public void setInteractionItem(List<Map<String, List<Map<String, Object>>>> interactionItem) {
		this.interactionItem = interactionItem;
	}
	public Object getInteractionType() {
		return interactionType;
	}
	public void setInteractionType(Object interactionType) {
		this.interactionType = interactionType;
	}
	public List<Characteristic> getCharacteristic() {
		return characteristic;
	}
	public void setCharacteristic(List<Characteristic> characteristic) {
		this.characteristic = characteristic;
	}
	public Object getInteractionStatus() {
		return interactionStatus;
	}
	public void setInteractionStatus(Object interactionStatus) {
		this.interactionStatus = interactionStatus;
	}
	    
}
