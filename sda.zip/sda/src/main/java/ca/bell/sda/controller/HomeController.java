/**
 * 
 */
package ca.bell.sda.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import ca.bell.sda.external.OrgNameStandardization;

/**
 * @author Jagan Boopathi
 *
 */

@RestController
public class HomeController extends SDAController {

	@Autowired
	OrgNameStandardization orgName;

	/**
	 * API's Default link.
	 * 
	 * @return API Details
	 */
	@RequestMapping(value = "/", produces = MediaType.APPLICATION_JSON_VALUE)
	public String home() {
		return "API's Home";
	}

	@RequestMapping(value = "/about", produces = MediaType.APPLICATION_JSON_VALUE)
	public Map<String, Object> getAbout() {

		Map<String, Object> objMap = new HashMap<>();
		objMap.put("PROP", System.getProperties());
		objMap.put("ENV", System.getenv());

		Map<String, Object> mem = new HashMap<>();
		mem.put("HOSTNAME", System.getenv().get("HOSTNAME"));
		mem.put("TOTAL_MEM", (Runtime.getRuntime().totalMemory() / 1024 / 1024) + " MB");
		mem.put("MAX_MEM", (Runtime.getRuntime().maxMemory() / 1024 / 1024) + " MB");
		mem.put("USED_MEM",
				((Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory()) / 1024 / 1024) + " MB");
		mem.put("FREE_MEM", (Runtime.getRuntime().freeMemory() / 1024 / 1024) + " MB");
		objMap.put("MEM", mem);

		return objMap;
	}

}
