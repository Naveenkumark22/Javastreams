package ca.bell.sda.external;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamConstants;
import javax.xml.stream.XMLStreamReader;

import org.apache.commons.text.StringEscapeUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;

import ca.bell.sda.config.AppConfig;
import ca.bell.sda.constant.log.LogKey;
import ca.bell.sda.model.Request;
import ca.bell.sda.model.config.Endpoint;
import ca.bell.sda.util.Freemaker;
import ca.bell.sda.util.WebService;

@Component
public class OrgNameStandardization {

	@Autowired
	private WebService webService;

	private WebClient wc;
	
	@Autowired
	private AppConfig appConfig;
	
	private static final String STD_MDM_NAME = "bbm-nameStand";
	private static final String STD_MDM_NAME_PROD = "bbm-nameStand-prod";
	
	@Autowired
	private Freemaker freemaker;



	//private final String url = "http://cwypla-4060.bell.corp.bce.ca:9443/MDMWSProvider/MDMService";
	private String url = "";

	private String reqtemplate = "<?xml version=\"1.0\" encoding=\"utf-8\"?>"
			+ "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" "
			+ "xmlns:soap=\"http://MDMQSService.MDMQS.isd.ibm.com/soapoverhttp/\">"
			+ "<soapenv:Header/><soapenv:Body><soap:standardizeOrgName><arg1>"
			+ "<organizationname>{{input}}</organizationname></arg1>"
			+ "</soap:standardizeOrgName></soapenv:Body></soapenv:Envelope>";
	
	private final String[] nameKeyArr = { "primaryname_mnname", "namesuffix_mnname" };

	private Set<String> nameKeys = new TreeSet<String>(String.CASE_INSENSITIVE_ORDER);

	public OrgNameStandardization() {
		super();
		nameKeys.addAll(Arrays.asList(nameKeyArr));
	}
	
	
	public String getStandardizedName(Request request, String orgName) throws Exception {
		request.logTime(LogKey.NAME_STD_START);
		String env = appConfig.getAcitveEnv();
		if(env!=null&&env.equalsIgnoreCase("prod"))
			url = getAsURL(STD_MDM_NAME_PROD);
		else
			url = getAsURL(STD_MDM_NAME);
		if (orgName != null && !"".equals(orgName.trim())) {
			try {
				String nameStd = standardizeName(getResXMLStr(getNameReqXML(orgName)));
				request.logTime(LogKey.NAME_STD_END);
				return nameStd;
			} catch (Exception e) {
				request.log(LogKey.REQ_LOG_EX_MSG, getClass().getName() + e.getMessage());
				request.log(LogKey.REQ_LOG_EX, e);
				request.logTime(LogKey.NAME_STD_END);
			}
		}
		return null;
	}
	
	private String standardizeName(String resXMLStr) throws JsonMappingException, JsonProcessingException {
		 XmlMapper xmlMapper = new XmlMapper();

         // Parse SOAP response XML into a JsonNode
         JsonNode jsonNode = xmlMapper.readTree(resXMLStr);

         // Access elements in the JSON representation of the XML
         JsonNode orgNameJsonNode= jsonNode.at("/Body/MaintainOrgNameStandardizationResponse/StandardizeOrganizationNameBObj/OrgName");
         return orgNameJsonNode!=null?orgNameJsonNode.textValue():null;
	}


	private String getAsURL(String configName) throws Exception {

		
		Endpoint endPoint = appConfig.getAppProps().getServers().getWebService().getEndPoints().get(configName);

		if (endPoint != null)
			url = endPoint.getHost() + endPoint.getUrl();

		return url;

	}
	
	private String getNameReqXML(String orgName) throws Exception {

		Map<String, Object> name = new HashMap<>();
		orgName = StringEscapeUtils.escapeXml11(orgName);
		name.put("orgName", orgName);

		String str = freemaker.generateByTemplate("STD_MDM_Name_Standardization", name);
		return str;

	}

	/*public String getStandardizedName(Request request, String orgName) {
		request.logTime(LogKey.NAME_STD_START);
		if (orgName != null && orgName.trim() != "") {
			try {
				String nameStd = standardizeName(readXML(getResXMLStr(getReqXML(orgName))));
				request.logTime(LogKey.NAME_STD_END);
				return nameStd;
			} catch (Exception e) {
				request.log(LogKey.REQ_LOG_EX_MSG, getClass().getName() + e.getMessage());
				request.log(LogKey.REQ_LOG_EX, e);
				request.logTime(LogKey.NAME_STD_END);
			}
		}
		return null;
	}*/

	private String getReqXML(String orgName) {
		orgName = StringEscapeUtils.escapeXml11(orgName);
		String reqXml = reqtemplate.replace("{{input}}", orgName);
		return reqXml;
	}

	private String getResXMLStr(String reqXML) throws Exception {
		if (wc == null) {
			wc = webService.getWebClient_Default();
		}
		try {
			return wc.post().uri(url).contentType(MediaType.TEXT_XML).header("SOAPAction", "").bodyValue(reqXML)
					.retrieve().bodyToMono(String.class).block();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	

	private Map<String, String> readXML(String resXMLStr) throws Exception {
		if (resXMLStr != null && resXMLStr.trim() != "") {
			Map<String, String> nameMap = new HashMap<>();
			InputStream inpStream = new ByteArrayInputStream(resXMLStr.getBytes());
			XMLInputFactory xmlFac = XMLInputFactory.newDefaultFactory();

			XMLStreamReader xmlReader = xmlFac.createXMLStreamReader(inpStream);
			while (xmlReader.hasNext()) {
				xmlReader.next();
				if (xmlReader.getEventType() == XMLStreamConstants.START_ELEMENT) {
					if (nameKeys.contains(xmlReader.getName().toString())) {
						String nodeName = xmlReader.getName().toString();
						int attrbCnt = xmlReader.getAttributeCount();
						boolean nil = false;
						for (int i = 0; i < attrbCnt; i++) {
							if (xmlReader.getAttributeLocalName(i).equalsIgnoreCase("nil")) {
								nil = Boolean.getBoolean(xmlReader.getAttributeValue(i));
							}
						}
						if (!nil) {
							xmlReader.next();
							if (xmlReader.getEventType() == XMLStreamConstants.CHARACTERS) {
								nameMap.put(nodeName, xmlReader.getText());
							}
						}
					}
					if (nameMap.size() == nameKeys.size()) {
						break;
					}
				}
			}
			return nameMap;
		} else {
			return null;
		}
	}

	private String standardizeName(Map<String, String> nameMap) {
		if (nameMap != null && !nameMap.isEmpty()) {
			String standName = "";
			for (String nameKey : nameKeyArr) {
				String name = nameMap.get(nameKey);
				if (name != null) {
					standName += nameMap.get(nameKey) + " ";
				}
			}
			return standName.trim();
		} else {
			return null;
		}
	}
}
