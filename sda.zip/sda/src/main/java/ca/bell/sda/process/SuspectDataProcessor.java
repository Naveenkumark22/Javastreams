package ca.bell.sda.process;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.stereotype.Component;

import ca.bell.sda.constant.query.ElasticKey;
import ca.bell.sda.model.Request;
import ca.bell.sda.model.elk.response.ResponseData;
import ca.bell.sda.model.service.ContactSuspectDetail;

@Component
public class SuspectDataProcessor extends ElasticDataProcessor implements DataProcessor {

	private static final String FROM_CONTACT = "fromContactGK";
	private static final String SUSPECT_CONTACT = "suspectContactGK";
	private static final String SCORE = "score";
	private static final String SUSPECT = "suspect";

	@Override
	public <T> ResponseData processData(Request request, T data) {
		return null;
	}

	@SuppressWarnings("unchecked")
	public void processSuspectProfile(Request request, ContactSuspectDetail csDetail, Object elkData) {
		Map<String, Object> dataMap = (Map<String, Object>) elkData;
		List<Map<String, Object>> profileMapList = getProfileMapList(dataMap);
		if (profileMapList != null) {
			Map<String, Map<String, Object>> suspectProfileMap = organizeSuspectProfile(profileMapList);
			Map<String, Set<String>> linkedContactSet = csDetail.getLinkedContactSet();
			csDetail.getRequestContactList().forEach(contact -> {
				if (suspectProfileMap.containsKey(contact)) {
					csDetail.getProfileMap().get(contact).putAll(suspectProfileMap.get(contact));
					Set<String> suspectContactSet = linkedContactSet.get(contact);
					suspectContactSet.forEach(susepctContact -> {
						Map<String, Object> suspectProfile = suspectProfileMap.get(susepctContact);
						if (suspectProfile != null) {
							if(csDetail.getSuspectScore().get(contact + "_" + susepctContact)==null)
								suspectProfile.put(SCORE, "");
							csDetail.getSuspectList().get(contact).add(suspectProfile);
						}
					});
					csDetail.getProfileList().add(csDetail.getProfileMap().get(contact));
				}
			});
		}
	}

	@SuppressWarnings("unchecked")
	private Map<String, Map<String, Object>> organizeSuspectProfile(List<Map<String, Object>> profileMapList) {
		Map<String, Map<String, Object>> suspectProfileMap = new HashMap<>();
		profileMapList.forEach(profileMap -> {
			Map<String, Object> srcMap = (Map<String, Object>) profileMap.get(ElasticKey.SOURCE);
			String contact = srcMap.remove("id").toString();
			srcMap.put("contactGK", contact);
			suspectProfileMap.put(contact, srcMap);
		});
		return suspectProfileMap;
	}

	@SuppressWarnings("unchecked")
	public void processSuspectData(Request request, ContactSuspectDetail csDetail, Object elkData) {
		Map<String, Object> resDataMap = (Map<String, Object>) elkData;
		List<String> contactsList = csDetail.getRequestContactList();
		if (resDataMap.containsKey(ElasticKey.RESPONSES)) {
			List<Map<String, Object>> dataList = (List<Map<String, Object>>) resDataMap.get(ElasticKey.RESPONSES);
			for (int i = 0; i < dataList.size(); i++) {
				collectSuspect(csDetail, contactsList.get(i), dataList.get(i));
			}
		}
	}

	@SuppressWarnings("unchecked")
	private void collectSuspect(ContactSuspectDetail csDetail, String requestContact, Map<String, Object> dataMap) {
		List<Map<String, Object>> profileMapList = getProfileMapList(dataMap);
		if (profileMapList != null) {
			createPlaceHolder(csDetail, requestContact);
			csDetail.getContactSet().add(requestContact);
			profileMapList.forEach(profileMap -> {
				Map<String, Object> srcMap = (Map<String, Object>) profileMap.get(ElasticKey.SOURCE);
				String fromContact = srcMap.get(FROM_CONTACT).toString();
				String suspectContact = srcMap.get(SUSPECT_CONTACT).toString();
				String fromToSuspectKey = requestContact;
				if (requestContact.equals(fromContact)) {
					fromToSuspectKey += "_" + suspectContact;
					csDetail.getLinkedContactSet().get(requestContact).add(suspectContact);
					csDetail.getContactSet().add(suspectContact);
				} else {
					fromToSuspectKey += "_" + fromContact;
					csDetail.getLinkedContactSet().get(requestContact).add(fromContact);
					csDetail.getContactSet().add(fromContact);
				}
				if(srcMap.get(SCORE)!=null)
					csDetail.getSuspectScore().put(fromToSuspectKey, srcMap.get(SCORE).toString());
			});
		}
	}

	private void createPlaceHolder(ContactSuspectDetail csDetail, String requestContact) {
		Set<String> linkedContactSet = new HashSet<>();
		csDetail.getLinkedContactSet().put(requestContact, linkedContactSet);

		List<Map<String, Object>> suspectList = new ArrayList<>();
		csDetail.getSuspectList().put(requestContact, suspectList);

		Map<String, Object> profileMap = new HashMap<>();
		profileMap.put(SUSPECT, suspectList);
		csDetail.getProfileMap().put(requestContact, profileMap);
	}

}
