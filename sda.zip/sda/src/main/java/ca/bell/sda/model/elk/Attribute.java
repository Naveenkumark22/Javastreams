package ca.bell.sda.model.elk;

import ca.bell.sda.model.config.AttributeProperties;

public class Attribute {

	private String id;
	private Object value;
	private String type;
	private AttributeProperties properties;

	public Attribute() {

	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Attribute(Object value) {
		this.value = value;
	}

	public Object getValue() {
		return value;
	}

	public void setValue(Object value) {
		this.value = value;
	}

	public AttributeProperties getProperties() {
		return properties;
	}

	public void setProperties(AttributeProperties properties) {
		this.properties = properties;
		this.id = properties.getId();
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

}
