package ca.bell.sda.process.whitespace;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import ca.bell.sda.config.AttributesConfig;
import ca.bell.sda.model.Request;
import ca.bell.sda.model.whitespace.RequestInputDetail;
import ca.bell.sda.process.ElasticDataProcessor;

@Component
public class standardizationProcessor extends ElasticDataProcessor {
	
	@Autowired
	private AttributesConfig attributesConfig;

	@SuppressWarnings("unchecked")
	public Map<String, Object> processData(Request request, Object data, RequestInputDetail requestInputDetail) {

		Map<String, Object> dataMap = (Map<String, Object>) data;
		int total = getTotalValue(dataMap);
		List<Object> orgName = null;
		Map<String, Object> profile = null;
		if (total > 0) {
			List<Map<String, Object>> profilesMap = getProfileMapList(dataMap);
			orgName=new ArrayList<>();
			profile = new HashMap<>();
			for (Map<String, Object> profMap : profilesMap) {				
				Map<String, Object> sourceMap = (Map<String, Object>) profMap.get("_source");
				Set<String> keySet = attributesConfig.getDataAttributes().get(request.getReqId()).get("profile")
						.getKeys();
				processDataMap(sourceMap, profile, keySet);
				orgName.add(profile.get("stdOrgName"));
			}
			if(!orgName.isEmpty()) {
			Map<String, Object> name = new HashMap<>();
			name.put("names", orgName);
			profile.putAll(name);
			}						
		}
		return profile;				
	}
}
