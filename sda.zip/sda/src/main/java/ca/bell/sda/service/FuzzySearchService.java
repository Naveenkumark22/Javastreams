package ca.bell.sda.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ca.bell.sda.config.AppConfig;
import ca.bell.sda.constant.log.LogKey;
import ca.bell.sda.constant.webclient.StreamSource;
import ca.bell.sda.dao.SearchDAO;
import ca.bell.sda.elk.QueryBuilder;
import ca.bell.sda.model.Request;
import ca.bell.sda.model.elk.Attribute;
import ca.bell.sda.model.elk.SearchQuery;
import ca.bell.sda.process.OrgDataProcessor;

@Service
public class FuzzySearchService extends CPMService {

	@Autowired
	private AppConfig appConfig;

	@Autowired
	private SearchDAO searchDAO;

	@Autowired
	private OrgDataProcessor orgDP;
	
	@Autowired
	private QueryBuilder queryBuilder;

	private final String accountSearchId = "bellExternalReference-externalId";
	private final String gkKey = "goldenKey";
	private final String srcSystemKey = "nameType";

	private enum RequestType {
		ACCOUNT_SEARCH_COMBINED, ACCOUNT_SEARCH, ID, OTHERS
	}

	public Object doSearch(Request request, Map<String, Object> requestMap) {
		RequestType requestType = checkRequestType(request);
		String[] indexes = appConfig.getIndexNames(request.getReqId());
		String url = null;
		switch (requestType) {
		case ACCOUNT_SEARCH:
			url = String.join(",", indexes[0],indexes[1]);
			break;
		case ACCOUNT_SEARCH_COMBINED:
			url = indexes[0];
			break;
		default:
			url = indexes[0];
			break;
		}
		SearchQuery searchQuery = getSearchQuery(request);
		if(isSliverKeyFlag(requestMap))
		{
			searchQuery.getSourceFilter().addAll(appConfig.getAttributesConfig().getDataAttributes()
					.get(request.getReqId()).get("silverKey").getKeys());
			if(requestType.equals(RequestType.ACCOUNT_SEARCH))
				url = String.join(",", indexes);
		}
		else
		{
			List<Attribute> attrbQueryList = request.getQueryAttrbList();
			Set<String> skList=new TreeSet<String>();
			skList.add("SK External");
			skList.add("SK Internal");
			attrbQueryList.add(getAttrb(request, "organizationTypeKey", skList));
			searchQuery.setQuery(queryBuilder.createSearchQuery(attrbQueryList,request.getFilterAttrbList()));
			}
		request.logTime(LogKey.QUERY_BUILD_END);
		Object data = null;
		try {
			request.log(LogKey.QUERY, searchQuery);
			request.logTime(LogKey.ELK_START);
			data = searchDAO.querySource(request.getReqId(), StreamSource.INDEX, searchQuery, url,
					request.getQueryConfig().getFilterPath());
			if (data!=null&&requestType == RequestType.ACCOUNT_SEARCH) {
				request.logTime(LogKey.DATA_CONV_START);
				processAccountData(request, data, indexes[0],requestMap);
				request.logTime(LogKey.DATA_CONV_END);
			}
			addSuccessLog(request);
		} catch (Exception e) {
			e.printStackTrace();
			request.log(LogKey.REQ_LOG_EX_MSG, getClass().getName() + e.getMessage());
			addExceptionLog(request,e);
		}
		request.logTime(LogKey.ELK_END);
		return data;
	}

	private boolean isSliverKeyFlag(Map<String, Object> requestMap) {
		if(requestMap!=null&&requestMap.containsKey("silverKeyFlag")&&requestMap.get("silverKeyFlag").toString().equalsIgnoreCase("true"))
			return true;
		return false;
	}

	@SuppressWarnings("unchecked")
	private void processAccountData(Request request, Object data, String gkIndex, Map<String, Object> requestMap) throws Exception {
		Map<String, Object> dataMap = (Map<String, Object>) data;
		int total = orgDP.getTotalValue(dataMap);
		if (total > 0) {
			if (total == 1) { // If it is BA/SA account, it'll exist only in Account Detail index.
				Map<String, Object> profMap = orgDP.getProfileMapList(dataMap).get(0);
				Map<String, Object> sourceMap = (Map<String, Object>) profMap.get("_source");
				Object gkIdObj = sourceMap.get(gkKey);
				if (sourceMap.get(gkKey) != null) {
					profMap.put("_source", getGKDoc(request, gkIdObj, gkIndex,sourceMap,requestMap));
				}
				else if(isSliverKeyFlag(requestMap)&&sourceMap.get("linkedKey")!=null)
				{
					profMap.put("_source", getGKDoc(request, sourceMap.get("linkedKey"), gkIndex,sourceMap,requestMap));
				}
				else {
					sourceMap.remove(gkKey);
				}
			} else { // If it is CA account, it'll exist in both GK and account Details
						// index.
				removeDuplicateData(dataMap,requestMap);
			}
		}
	}

	@SuppressWarnings("unchecked")
	private void removeDuplicateData(Map<String, Object> dataMap, Map<String, Object> requestMap) {

		List<Map<String, Object>> profilesList = orgDP.getProfileMapList(dataMap);
		Map<String, Object> newProfile;
		Map<String, Map<String, Object>> uniqueProfiles = new HashMap<>();
		for (Map<String, Object> profileMap : profilesList) {
			Map<String, Object> sourceMap = (Map<String, Object>) profileMap.get("_source");
			newProfile = new HashMap<>();
			newProfile.put("_score", profileMap.get("_score"));

			String profileId = null;
			String srcSystem = (String) sourceMap.get(srcSystemKey);
			if ("CPM".equalsIgnoreCase(srcSystem)) { // GK profile
				profileId = (String) sourceMap.get("id");
				newProfile.put("_source", sourceMap);
				uniqueProfiles.put(profileId, newProfile);
			} else { // Account Profile
				profileId = (String) sourceMap.get("id") + srcSystem;
				if (sourceMap.containsKey(gkKey)) { // Profile from Granular Account index
					if (sourceMap.get(gkKey) != null) { // Account profile linked to GK
						profileId = (String) sourceMap.get(gkKey);
					}
				}

				if (!uniqueProfiles.containsKey(profileId)) { // Profile is not yet encounter in loop
					if (sourceMap.containsKey(gkKey)) { // Profile found in Account index
						sourceMap.remove(gkKey);
					}
					newProfile.put("_source", sourceMap);
					uniqueProfiles.put(profileId, newProfile);
				} else { // Profile is encountered in loop
					if (!sourceMap.containsKey(gkKey)) { // Profile found in GK index
						newProfile.put("_source", sourceMap);
						uniqueProfiles.put(profileId, newProfile);
					}
				}
			}
		}
		
		profilesList.clear();
		for (String profileIdKey : uniqueProfiles.keySet()) {
			Map<String,Object> sourceMap=(Map<String, Object>) uniqueProfiles.get(profileIdKey).get("_source");
			if(isSliverKeyFlag(requestMap)&&sourceMap!=null&&sourceMap.get("linkedKey")!=null)
			{
				
			// since we have loaded SK merged accounts in Macro index, we need to remove those accounts and expose its related GK/SK accounts
			}else
			{
				sourceMap.remove("linkedKey");
				profilesList.add(uniqueProfiles.get(profileIdKey));
			}
		}

		Object totalObj = orgDP.changeTotalValue(dataMap, profilesList.size());
		orgDP.getProfHitsMap(dataMap).put("total", totalObj);

	}

	@SuppressWarnings("unchecked")
	private Object getGKDoc(Request request, Object gkIdObj, String gkIndex, Map<String, Object> accountMap, Map<String, Object> requestMap) throws Exception {
		List<Attribute> queryAttrbList = new ArrayList<>();
		Attribute attrb = getAttrb(request, "id", gkIdObj);
		queryAttrbList.add(attrb);
		request.setQueryAttrbList(queryAttrbList);
		SearchQuery searchQuery = getSearchQuery(request);
		Object data = searchDAO.querySource(request.getReqId(), StreamSource.INDEX, searchQuery, gkIndex,
				request.getQueryConfig().getFilterPath());
		Map<String, Object> dataMap = (Map<String, Object>) data;
		int total = orgDP.getTotalValue(dataMap);
		if (total > 0) {
			Map<String, Object> profMap = orgDP.getProfileMapList(dataMap).get(0);
			Map<String, Object> sourceMap = (Map<String, Object>) profMap.get("_source");
			if(isSliverKeyFlag(requestMap)&&accountMap.get("accountType").toString().equalsIgnoreCase("externalId"))
			{
				Map<String,Object> bellExtRefMap=new HashMap<String,Object>();
				bellExtRefMap.put("externalId", accountMap.get("id"));
				bellExtRefMap.put("sourceSystemId", accountMap.get("sourceSystem"));
				bellExtRefMap.put("externalReferenceType", "externalId");
				List<Map<String,Object>> gkbellExternalMap=(List<Map<String, Object>>) sourceMap.get("bellExternalReference");
				if(gkbellExternalMap==null)
				{
					gkbellExternalMap=new ArrayList<Map<String,Object>>();
				}
				gkbellExternalMap.add(bellExtRefMap);
				sourceMap.put("bellExternalReference", gkbellExternalMap);
			}
			return sourceMap;
		}
		return null;
	}

	private RequestType checkRequestType(Request request) {
		List<Attribute> attrbList = request.getQueryAttrbList();
		boolean combinedSearch = (attrbList.size() > 1 ? true : false);
		boolean accountSearch = false;
		for (Attribute attrb : attrbList) {
			accountSearch = attrb.getId().equalsIgnoreCase(accountSearchId);
			if (accountSearch) {
				break;
			}
		}

		if (accountSearch) {
			if (combinedSearch) {
				return RequestType.ACCOUNT_SEARCH_COMBINED;
			} else {
				return RequestType.ACCOUNT_SEARCH;
			}
		}

		return RequestType.OTHERS;
	}

}
