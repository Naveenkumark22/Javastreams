package ca.bell.sda.process;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import ca.bell.sda.config.AttributesConfig;
import ca.bell.sda.model.Request;
import ca.bell.sda.model.elk.response.ResponseData;

@Component
public class GetCustomerManagementProcessor extends ElasticDataProcessor implements DataProcessor {

	@Autowired
	private AttributesConfig attributesConfig;
	
	private static final String BI_360="bi360_customer";

	@SuppressWarnings("unchecked")
	@Override
	public <T> ResponseData processData(Request request, T data) {
		ResponseData res = new ResponseData();
		Map<String, Object> dataMap = (Map<String, Object>) data;
		int total = getTotalValue(dataMap);
		List<Map<String, Object>> profileList = null;
		Map<String, Object> profile;
		Map<String, Object> tarProfile;
		Map<String, Object> parentAcct;
		if (total > 0) {
			profile = new HashMap<>();
			tarProfile=new HashMap<>();
			parentAcct=new HashMap<>();
			List<Map<String, Object>> profilesMap = getProfileMapList(dataMap);
			profileList = new ArrayList<>();
			Map<String, Object> sourceProfile = new HashMap<>();
			boolean flag=false;
			for (Map<String, Object> profMap : profilesMap) {
				Map<String, Object> sourceMap = (Map<String, Object>) profMap.get("_source");
				  if(sourceMap.containsKey(BI_360)) {					  
					  sourceProfile.putAll((Map<? extends String, ? extends Object>) sourceMap.get(BI_360));
					 }else {
					  Map<String, String> keySet = attributesConfig.getDataAttributes().get(request.getReqId()).get("eomusers")
								.getKeyPairs();
					  processDataMap(sourceMap, profile, keySet);
					 }
				  if(!flag) {
					  flag=true;
					  parentAcct.put("parent_acct", sourceMap.get("parent_acct"));
				  }
			}
			sourceProfile.putAll(profile);			
			tarProfile.put(BI_360, sourceProfile);
			tarProfile.putAll(parentAcct);
			profileList.add(tarProfile);			
		}		
		res.setProfiles(profileList);
		return res;
	}
	
	public String processEomId(Object data) {
		String eomId=null;
		Map<String, Object> dataMap = (Map<String, Object>) data;
		int total = getTotalValue(dataMap);

		if (total > 0) {
			Map<String, Object> profile;
			List<Map<String, Object>> profilesMap = getProfileMapList(dataMap);
			for (Map<String, Object> profMap : profilesMap) {
				profile = new HashMap<>();
				Map<String, Object> sourceMap = (Map<String, Object>) profMap.get("_source");
				eomId=(String) sourceMap.get("id");
			}
		}
		return eomId;
	}
}
