package ca.bell.sda.process;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import ca.bell.sda.config.AttributesConfig;
import ca.bell.sda.config.ElasticQueryConfig;
import ca.bell.sda.constant.log.LogKey;
import ca.bell.sda.constant.node.NodeType;
import ca.bell.sda.constant.node.NodeValueType;
import ca.bell.sda.constant.query.QueryConfig;
import ca.bell.sda.constant.query.SourceFilterSet;
import ca.bell.sda.constant.status.StatusTypes;
import ca.bell.sda.constant.value.ValueConversion;
import ca.bell.sda.constant.value.ValueConversionType;
import ca.bell.sda.model.Request;
import ca.bell.sda.model.Response;
import ca.bell.sda.model.Status;
import ca.bell.sda.model.config.AttributeProperties;
import ca.bell.sda.model.elk.Attribute;
import ca.bell.sda.util.Utility;
import ca.bell.sda.validator.AttributeValidator;

@Component
public class RequestProcessor {

	@Autowired
	private AttributesConfig attributesConfig;

	@Autowired
	private ElasticQueryConfig elasticQueryConfig;

	@Autowired
	AttrbValueConvertors attrbValueConvtrs;

	public void processRequest(Map<String, Object> requestMap, Request request, Response response) {
		Map<String, AttributeProperties> attrbProperties = attributesConfig.getProperties().get(request.getReqId());
		request.setRequestMap(requestMap);
		for (Object obj : requestMap.keySet()) {
			if (response.getStatus().getCode() == StatusTypes.REQUEST_SUCCESS.getCode()) {
				String param = (String) obj;
				Object objValue = requestMap.get(param);
				if (objValue == null) { // Check for null value
					response.setStatus(StatusTypes.NULL_VALUE_ATTRIBUTE);
					return;
				}
				AttributeProperties attrbProp = attrbProperties.get(param);
				if (attrbProp == null || !attrbProp.isEnabled()) { // If attribute is not available or not enabled
					response.setStatus(StatusTypes.appendErrorMessage(StatusTypes.INVALID_ATTRIBUTE_NAME, param));
					return;
				}
				if (attrbProp.getNodeType() == NodeType.QUERY) { // Query attribute to search
					processQuery(request, response, param, objValue);
				} else if (attrbProp.getNodeType() == NodeType.QUERY_CONFIG) { // Query Config attribute
					processQueryConfig(request, response, param, objValue);
				} else if (attrbProp.getNodeType() == NodeType.QUERY_FILTER) { // Query filter attribute
					processQueryFilter(request, response, param, objValue);
				} else if (attrbProp.getNodeType() == NodeType.SOURCE_FILTER) { // Query source attribute
					processSourceFilter(request, response, param, objValue);
				} else if (attrbProp.getNodeType() == NodeType.NODE_VALUE_TYPE) { // Node Value Type
					processNodeValueType(request, response, param, objValue);
				} else if (attrbProp.getNodeType() == NodeType.REQUEST_CONFIG) { // Request Config attribute
					processReqConfig(request, response, param, objValue);
				}
			}
		}
		if (response.getStatus().getCode() == StatusTypes.REQUEST_SUCCESS.getCode()
				&& request.getQueryAttrbList().isEmpty()) {
			response.setStatus(StatusTypes.INVALID_REQUEST);
		}
		if (request.getSourceFilter() == null || request.getSourceFilter().isEmpty()) {
			// Generate Default Source filter set
			generateSourceFilter(request, response, null);
		}
		if (request.getQueryConfig() == null) {
			processQueryConfig(request, response, null, null);
		} else {
			validateOffsetLimit(request, response);
		}
	}

	@SuppressWarnings("unchecked")
	private void processQuery(Request request, Response response, String param, Object value) {

		Map<String, AttributeProperties> attrbProps = attributesConfig.getProperties().get(request.getReqId());
		AttributeProperties attrbProp = attrbProps.get(param);
		Attribute attrb = null;
		Status status = null;
		if (response.getStatus().getCode() == StatusTypes.REQUEST_SUCCESS.getCode()) {
			if (attrbProp.getValueType() == NodeValueType.STRING) { // Key-Pair value
				String valueStr = ((String) value).trim();
				attrb = checkMultiType(attrbProp, valueStr);
				status = validateAttribute(attrb);
				valueConversion(request, attrb);
			} else if (attrbProp.getValueType() == NodeValueType.OBJECT) { // JSON Object
				attrb = checkMultiType(attrbProp, value);
				status = validateAttribute(attrb);
				response.setStatus(status);
				if (status.getCode() == StatusTypes.REQUEST_SUCCESS.getCode()) {
					Map<String, Object> kpValue = (HashMap<String, Object>) value;
					Set<String> keySet = kpValue.keySet();
					for (String key : keySet) {
						String childNode = param + "-" + key;
						AttributeProperties childAttrb = attrbProps.get(childNode);
						if (childAttrb != null) {
							if (childAttrb.getNodeType() == NodeType.QUERY) {
								processQuery(request, response, childNode, kpValue.get(key));
							} else if (childAttrb.getNodeType() == NodeType.QUERY_FILTER) {
								processQueryFilter(request, response, childNode, kpValue.get(key));
							}
						}
					}
				}
			} else if (attrbProp.getValueType() == NodeValueType.ARRAY) { // Array of value
				if (value.getClass() != ArrayList.class) {
					status = StatusTypes.appendErrorMessage(StatusTypes.INVALID_VALUE, param);
					response.setStatus(status);
					return;
				} else {
					status = StatusTypes.REQUEST_SUCCESS;
				}
				List<String> valueArr = (ArrayList<String>) value;
				attrb = new Attribute();
				attrb.setProperties(attrbProp);
				for (String valueStr : valueArr) {
					if (status.getCode() == StatusTypes.REQUEST_SUCCESS.getCode()) {
						// attrb = checkMultiType(attrbProp, valueStr); // Multiple type is not
						// applicable as of now
						attrb.setValue(valueStr);
						status = validateAttribute(attrb);
					} else {
						break;
					}
				}
				attrb.setValue(valueArr);
				valueConversion(request, attrb);
			}
		}
	}

	private void processQueryFilter(Request request, Response response, String param, Object value) {
		AttributeProperties attrbProp = attributesConfig.getProperties().get(request.getReqId()).get(param);
		Attribute attrb = null;
		if (response.getStatus().getCode() == StatusTypes.REQUEST_SUCCESS.getCode()) {
			if (attrbProp.getValueType() == NodeValueType.STRING) { // Key-Pair value
				String strValue = ((String) value).toLowerCase().trim();
				attrb = new Attribute(strValue);
				attrb.setProperties(attrbProp);
				response.setStatus(validateAttribute(attrb));
				request.getFilterAttrbList().add(attrb);
			}
		}
	}

	@SuppressWarnings("unchecked")
	private void processSourceFilter(Request request, Response response, String param, Object value) {
		AttributeProperties attrbProp = attributesConfig.getProperties().get(request.getReqId()).get(param);
		if (attrbProp.getValueType() == NodeValueType.ARRAY) { // Array of value
			Set<String> srcSet = new TreeSet<String>(String.CASE_INSENSITIVE_ORDER);
			srcSet.addAll((ArrayList<String>) value);
			String grpId = request.getReqId();
			response.setStatus(validateSourceFilter(grpId, srcSet));
			generateSourceFilter(request, response, srcSet);

		}
	}

	private void processQueryConfig(Request request, Response response, String param, Object value) {
		if (request.getQueryConfig() == null) {
			request.setQueryConfig(elasticQueryConfig.clone());
		}
		if (param != null) {
			ElasticQueryConfig queryConfig = request.getQueryConfig();
			Attribute attrb = new Attribute(value);
			attrb.setProperties(attributesConfig.getProperties().get(request.getReqId()).get(param));
			Status status = validateAttribute(attrb);
			if (status == StatusTypes.REQUEST_SUCCESS) {
				String valurStr = String.valueOf(value).trim();
				if (param.equalsIgnoreCase(QueryConfig.SIZE)) {
					queryConfig.setSize(valurStr);
				}
				if (param.equalsIgnoreCase(QueryConfig.FROM)) {
					queryConfig.setFrom(valurStr);
				}
				if (param.equalsIgnoreCase(QueryConfig.MIN_SCORE)) {
					queryConfig.setMinScore(valurStr);
				}
				if (param.equalsIgnoreCase(QueryConfig.FILTER_PATH)) {
					queryConfig.setFilterPath(valurStr);
				}
			} else {
				response.setStatus(status);
			}
		}
	}

	private void processNodeValueType(Request request, Response response, String param, Object value) {
		AttributeProperties attrbProp = attributesConfig.getProperties().get(request.getReqId()).get(param);
		Attribute attrb = null;
		if (response.getStatus().getCode() == StatusTypes.REQUEST_SUCCESS.getCode()) {
			if (attrbProp.getValueType() == NodeValueType.STRING) { // Key-Pair value
				String strValue = ((String) value).toLowerCase().trim();
				attrb = new Attribute(strValue);
				attrb.setProperties(attrbProp);
				response.setStatus(validateAttribute(attrb));
				request.getNodeValueTypes().put(param, attrb);
			}
		}
	}

	private void processReqConfig(Request request, Response response, String param, Object value) {
		AttributeProperties attrbProp = attributesConfig.getProperties().get(request.getReqId()).get(param);
		Attribute attrb = null;
		Status status = null;
		if (response.getStatus().getCode() == StatusTypes.REQUEST_SUCCESS.getCode()) {
			String valueStr = ((String) value).trim();
			attrb = new Attribute(valueStr);
			attrb.setProperties(attrbProp);
			status = validateAttribute(attrb);
			if (status.getCode() == StatusTypes.REQUEST_SUCCESS.getCode()) {
				request.getReqConfigAttrb().put(param, attrb);
			} else {
				response.setStatus(status);
			}
		}
	}

	private Attribute checkMultiType(AttributeProperties attrbProp, Object value) {
		Attribute attrb = new Attribute(value);
		attrb.setProperties(attrbProp);
		if (attrbProp.isMultiType()) { // Check attribute has multiple type
			String methodToCheck = attrbProp.getCheckType();
			String type = null;
			if (value.getClass() == String.class) {
				type = (String) Utility.executeStaticMethod(AttributeValidator.class, methodToCheck, (String) value);
			} else {
				type = (String) Utility.executeStaticMethod(AttributeValidator.class, methodToCheck, value);
			}
			attrb.setType(type);
		}
		return attrb;
	}

	private Status validateSourceFilter(String grpId, Set<String> srcSet) {
		Set<String> deniedSrc = attributesConfig.getSourceDeniedSet(grpId);
		if (!Collections.disjoint(srcSet, deniedSrc)) {
			return StatusTypes.DENIED_FILTER;
		}
		if (srcSet.contains(SourceFilterSet.COMPLETE)) {
			if (srcSet.size() > 1) {
				return StatusTypes.INVALID_FILTER;
			}
		}
		return StatusTypes.REQUEST_SUCCESS;
	}

	private void generateSourceFilter(Request request, Response response, Set<String> srcSet) {
		if (response.getStatus().getCode() == StatusTypes.REQUEST_SUCCESS.getCode()) {
			Set<String> sourceFilterSet = new TreeSet<String>((String.CASE_INSENSITIVE_ORDER));
			String grpId = request.getReqId();
			sourceFilterSet.addAll(generateSourceFilterSet(grpId, attributesConfig.getSourceDefaultSet(grpId)));
			if (srcSet != null) {
				if (srcSet.contains(SourceFilterSet.COMPLETE)) { // Complete Profile
					sourceFilterSet
							.addAll(generateSourceFilterSet(grpId, attributesConfig.getSourceCompleteSet(grpId)));
				} else {
					sourceFilterSet.addAll(generateSourceFilterSet(grpId, srcSet));
				}
			}
			request.setSourceFilter(sourceFilterSet);
			request.getLog().put(LogKey.SOURCE_FILTER, sourceFilterSet);
		}
	}

	private Set<String> generateSourceFilterSet(String grpId, Set<String> srcSet) {
		Set<String> sourceFilter = new TreeSet<String>((String.CASE_INSENSITIVE_ORDER));
		Map<String, Set<String>> entityMap = attributesConfig.getEntityMap().get(grpId);
		for (String src : srcSet) {
			if (entityMap.get("root").contains(src)) { // If source is root attribute
				sourceFilter.add(src);
			} else { // If Source is nested attribute
				Set<String> srcs = entityMap.get(src);
				if (srcs != null) {
					sourceFilter.addAll(srcs);
				}
			}
		}
		return sourceFilter;
	}

	private Status validateAttribute(Attribute attrb) {
		Map<String, String> validationMethodMap = attributesConfig.getValidationRuleMap();
		String[] validationRules = attrb.getProperties().getValidationRules();
		if (validationRules != null && validationRules.length > 0) {
			for (String validationRule : validationRules) {
				String validationMethod = validationMethodMap.get(validationRule);
				if (!(boolean) Utility.executeStaticMethod(AttributeValidator.class, validationMethod, attrb)) {
					Map<String, String> errorStatusMap = attributesConfig.getErrorStatus();
					String errorStatus = errorStatusMap.get(validationRule);
					Status status = StatusTypes.getElkErrorStatus(errorStatus);
					return StatusTypes.appendErrorMessage(status, attrb.getProperties().getName());
				}
			}
		}
		return StatusTypes.REQUEST_SUCCESS;
	}

	private void valueConversion(Request request, Attribute attrb) {
		AttributeProperties attrbProp = attrb.getProperties();
		int valueConv = attrbProp.getValueConversion();
		List<Attribute> attrbList = new ArrayList<>();
		if (valueConv == ValueConversion.RAW) { // As as it is
			attrbList.add(attrb);
			request.logInput(attrb.getValue());
		} else if (valueConv == ValueConversion.CONVERTED_VALUE || valueConv == ValueConversion.RAW_N_CONVERTED) {
			String rawValue = (String) attrb.getValue();
			String convtValue = null;
			Attribute convtAttrb = new Attribute();
			convtAttrb.setProperties(attrbProp);

			// Use converted value
			if (attrbProp.getConversionType() == ValueConversionType.VALUE_MAP) { // Convert value using Map

			} else if (attrbProp.getConversionType() == ValueConversionType.METHOD) { // Convert value using Method
				convtValue = (String) Utility.executeInstanceMethod(AttrbValueConvertors.class, attrbValueConvtrs,
						attrbProp.getConversionMethod(), request, rawValue);
				convtAttrb.setValue(convtValue);
				if (convtValue != null) {
					convtAttrb = checkMultiType(attrbProp, convtValue);
				}
			}
			if (valueConv == ValueConversion.RAW_N_CONVERTED) { // Use Raw & Converted value
				attrbList.add(attrb);
				request.logInput(attrb.getValue());
				if (convtValue != null && !rawValue.equalsIgnoreCase(convtValue)) {
					attrbList.add(convtAttrb);
					request.logInput(convtAttrb.getValue());
				}
			} else { // Use Converted value only
				attrbList.add(convtAttrb);
				request.logInput(convtAttrb.getValue());
			}
		}
		request.getQueryAttrbList().addAll(attrbList);
	}

	private void validateOffsetLimit(Request request, Response response) {
		ElasticQueryConfig queryConfig = request.getQueryConfig();
		int size = Integer.valueOf(queryConfig.getSize());
		int from = Integer.valueOf(queryConfig.getFrom());
		if ((size + from) > 10000) {
			response.setStatus(StatusTypes.INVALID_OFFSET_LIMIT);
		}
	}
}
