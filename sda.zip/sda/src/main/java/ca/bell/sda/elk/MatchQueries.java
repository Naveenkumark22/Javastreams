package ca.bell.sda.elk;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.stereotype.Component;

@Component
public class MatchQueries {

	public static Map<String, Object> getExactMatch(String attrb, Object value) {
		Map<String, Object> rootMap = new HashMap<>();
		Map<String, Object> match = new HashMap<>();

		match.put(attrb, value);
		rootMap.put("match_phrase", match);

		return rootMap;
	}

	public static Map<String, Object> getExactMatch_Nested(String attrb, Object value, String path,
			String boolCondition) {
		Map<String, Object> rootMap = new HashMap<>();
		Map<String, Object> nested = new HashMap<>();
		Map<String, Object> match = getExactMatch(attrb, value);
		Map<String, Object> query = BoolCondition.getBoolCondition(boolCondition, match);

		nested.put("path", path);
		nested.put("query", query);

		rootMap.put("nested", nested);

		return rootMap;
	}

	public static Map<String, Object> getFuzzyMultiMatch(String[] attrbs, Object value, String fuzzyType,
			String boostVal) {
		Map<String, Object> rootMap = new HashMap<>();
		Map<String, Object> multiMatch = new HashMap<>();

		multiMatch.put("fields", attrbs);
		multiMatch.put("query", value);
//		multiMatch.put("type", "most_fields");
		multiMatch.put("boost", boostVal);
		multiMatch.put("fuzziness", fuzzyType);

		rootMap.put("multi_match", multiMatch);

		return rootMap;
	}

	public static Map<String, Object> getFuzzyMatch_Nested(String[] attrbs, Object value, String fuzzyType, String path,
			String boolCondition, String boostVal) {
		Map<String, Object> rootMap = new HashMap<>();
		Map<String, Object> nested = new HashMap<>();
		Map<String, Object> multiMatch = getFuzzyMultiMatch(attrbs, value, fuzzyType, boostVal);
		Map<String, Object> query = BoolCondition.getBoolCondition(boolCondition, multiMatch);

		nested.put("path", path);
		nested.put("query", query);

		rootMap.put("nested", nested);

		return rootMap;
	}

	public static List<Object> getFuzzyMatch_Mixed(String[] rootAttrbs, Map<String, String[]> nestedAttrbs,
			String value, String fuzzyType, String boolCondition, String boostVal) {
		Map<String, Object> nonNestedAttrb = getFuzzyMultiMatch(rootAttrbs, value, fuzzyType, boostVal);

		List<Object> queryList = new ArrayList<>();
		queryList.add(nonNestedAttrb);

		Set<String> nestedSet = nestedAttrbs.keySet();
		for (String nestedPath : nestedSet) {
			queryList.add(getFuzzyMatch_Nested(nestedAttrbs.get(nestedPath), value, fuzzyType, nestedPath,
					boolCondition, boostVal));
		}

		return queryList;
	}

	public static List<Object> getExactMatch_Mixed(String[] rootAttrbs, Map<String, String[]> nestedAttrbs,
			String value, String fuzzyType, String boolCondition) {
		List<Object> queryList = new ArrayList<>();

		for (String rootAttrbStr : rootAttrbs) {
			queryList.add(getExactMatch(rootAttrbStr, value));
		}

		Set<String> nestedSet = nestedAttrbs.keySet();
		for (String nestedPath : nestedSet) {

			String[] nestedFields = nestedAttrbs.get(nestedPath);
			for (String attrb : nestedFields) {
				queryList.add(getExactMatch_Nested(attrb, value, nestedPath, boolCondition));
			}
		}

		return queryList;
	}

	public static Map<String, Object> getMatchDefault(String attrb, Object value, String boolCondition,
			String boostVal) {
		Map<String, Object> rootMap = new HashMap<>();
		Map<String, Object> attrbMap = new HashMap<>();
		Map<String, Object> attrbQuery = new HashMap<>();

		attrbQuery.put("query", value);
		attrbQuery.put("boost", boostVal);

		attrbMap.put(attrb, attrbQuery);
		rootMap.put("match", attrbMap);

		return rootMap;
	}

	public static Map<String, Object> getMatchAdvanced(String attrb, Object value, String boolCondition,
			String boostVal, String analyzer, String operator) {
		Map<String, Object> rootMap = new HashMap<>();
		Map<String, Object> attrbMap = new HashMap<>();
		Map<String, Object> attrbQuery = new HashMap<>();

		attrbQuery.put("query", value);
		attrbQuery.put("boost", boostVal);
		attrbQuery.put("fuzziness", 0);
		attrbQuery.put("operator", operator);
		attrbQuery.put("auto_generate_synonyms_phrase_query", "false");
		attrbQuery.put("fuzzy_transpositions", "false");
		if (analyzer != null) {
			attrbQuery.put("analyzer", analyzer);
		}

		attrbMap.put(attrb, attrbQuery);
		rootMap.put("match", attrbMap);

		return rootMap;
	}

	public static Map<String, Object> getMatchDefault_Nested(String attrb, Object value, String path,
			String boolCondition, String boostVal) {
		Map<String, Object> rootMap = new HashMap<>();
		Map<String, Object> nested = new HashMap<>();
		Map<String, Object> query = new HashMap<>();
		Map<String, Object> bool = new HashMap<>();
		List<Object> objList = new ArrayList<>();
		objList.add(getMatchDefault(attrb, value, boolCondition, boostVal));

		bool.put(boolCondition, objList);
		query.put("bool", bool);
		nested.put("path", path);
		nested.put("query", query);
		rootMap.put("nested", nested);

		return rootMap;
	}

	public static Map<String, Object> getMatchAdvanced_Nested(String attrb, Object value, String path,
			String boolCondition, String boostVal, String analyzer, String operator) {
		Map<String, Object> rootMap = new HashMap<>();
		Map<String, Object> nested = new HashMap<>();
		Map<String, Object> query = new HashMap<>();
		Map<String, Object> bool = new HashMap<>();
		List<Object> objList = new ArrayList<>();
		objList.add(getMatchAdvanced(attrb, value, boolCondition, boostVal, analyzer, operator));

		bool.put(boolCondition, objList);
		query.put("bool", bool);
		nested.put("path", path);
		nested.put("query", query);
		rootMap.put("nested", nested);

		return rootMap;
	}

}
