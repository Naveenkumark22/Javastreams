/**
 *
 */
package ca.bell.sda.model.whitespace;

/**
 * @author Kamalanathan Ranganathan
 */
public class STDAddress {

	// Standardized Address
	private String addresslineone_formatted = "";

	private String addresslinetwo_formatted = "";

	private String addresslinethree_formatted = "";

	private String residencenumber_formatted = "";

	private String cityname_formatted = "";

	private String stateabbreviation_formatted = "";

	private String fullpostalcode_formatted = "";

	private String streetnumber_formatted = "";

	private String streetname_formatted = "";

	private String streetsuffix_formatted = "";

	private String postdirectional_formatted = "";

	private String predirectional_formatted = "";

	private String countryname_formatted = "";

	private String latitude = "";

	private String longitude = "";

	private String addresssource = "";

	private String matchType = "";

	private String onelineAddress_formatted = "";

	public STDAddress() {

	}

	public String getAddresslineone_formatted() {

		return addresslineone_formatted;
	}

	public void setAddresslineone_formatted(String addresslineone_formatted) {

		this.addresslineone_formatted = addresslineone_formatted;
	}

	public String getAddresslinetwo_formatted() {

		return addresslinetwo_formatted;
	}

	public void setAddresslinetwo_formatted(String addresslinetwo_formatted) {

		this.addresslinetwo_formatted = addresslinetwo_formatted;
	}

	public String getAddresslinethree_formatted() {

		return addresslinethree_formatted;
	}

	public void setAddresslinethree_formatted(String addresslinethree_formatted) {

		this.addresslinethree_formatted = addresslinethree_formatted;
	}

	public String getResidencenumber_formatted() {

		return residencenumber_formatted;
	}

	public void setResidencenumber_formatted(String residencenumber_formatted) {

		this.residencenumber_formatted = residencenumber_formatted;
	}

	public String getCityname_formatted() {

		return cityname_formatted;
	}

	public void setCityname_formatted(String cityname_formatted) {

		this.cityname_formatted = cityname_formatted;
	}

	public String getStateabbreviation_formatted() {

		return stateabbreviation_formatted;
	}

	public void setStateabbreviation_formatted(String stateabbreviation_formatted) {

		this.stateabbreviation_formatted = stateabbreviation_formatted;
	}

	public String getFullpostalcode_formatted() {

		return fullpostalcode_formatted;
	}

	public void setFullpostalcode_formatted(String fullpostalcode_formatted) {

		this.fullpostalcode_formatted = fullpostalcode_formatted;
	}

	public String getStreetnumber_formatted() {

		return streetnumber_formatted;
	}

	public void setStreetnumber_formatted(String streetnumber_formatted) {

		this.streetnumber_formatted = streetnumber_formatted;
	}

	public String getStreetname_formatted() {

		return streetname_formatted;
	}

	public void setStreetname_formatted(String streetname_formatted) {

		this.streetname_formatted = streetname_formatted;
	}

	public String getStreetsuffix_formatted() {

		return streetsuffix_formatted;
	}

	public void setStreetsuffix_formatted(String streetsuffix_formatted) {

		this.streetsuffix_formatted = streetsuffix_formatted;
	}

	public String getPostdirectional_formatted() {

		return postdirectional_formatted;
	}

	public void setPostdirectional_formatted(String postdirectional_formatted) {

		this.postdirectional_formatted = postdirectional_formatted;
	}

	public String getPredirectional_formatted() {

		return predirectional_formatted;
	}

	public void setPredirectional_formatted(String predirectional_formatted) {

		this.predirectional_formatted = predirectional_formatted;
	}

	public String getCountryname_formatted() {

		return countryname_formatted;
	}

	public void setCountryname_formatted(String countryname_formatted) {

		this.countryname_formatted = countryname_formatted;
	}

	public String getLatitude() {

		return latitude;
	}

	public void setLatitude(String latitude) {

		this.latitude = latitude;
	}

	public String getLongitude() {

		return longitude;
	}

	public void setLongitude(String longitude) {

		this.longitude = longitude;
	}

	public String getAddresssource() {

		return addresssource;
	}

	public void setAddresssource(String addresssource) {

		this.addresssource = addresssource;
	}

	public String getMatchType() {
		return matchType;
	}

	public void setMatchType(String matchType) {
		this.matchType = matchType;
	}

	public String getOnelineAddress_formatted() {
		return onelineAddress_formatted;
	}

	public void setOnelineAddress_formatted(String onelineAddress_formatted) {
		this.onelineAddress_formatted = onelineAddress_formatted;
	}

	public boolean isAddressEmpty() {

		boolean isAddressone = false;

		boolean isCombinedAddress = false;

		boolean ret = false;

		if (((getAddresslineone_formatted() != null && getAddresslineone_formatted().trim().length() > 0))) {
			isAddressone = true;
		}

		if (getCombinedAddress() != null && getCombinedAddress().trim().length() > 0) {

			isCombinedAddress = true;
		}

		if ((isAddressone == false && isCombinedAddress == false))
			ret = false;
		else
			ret = (isAddressone && isCombinedAddress);

		// true - Address is Not present
		// false - Address is present
		return !ret;
	}
	// ELK Address Builders

	@Override
	public String toString() {

		return "Address : \n  addresslineone_formatted = " + addresslineone_formatted + "\n"
				+ "  addresslinetwo_formatted = " + addresslinetwo_formatted + "\n" + "  addresslinethree_formatted = "
				+ addresslinethree_formatted + "\n" + "  residencenumber_formatted = " + residencenumber_formatted
				+ "\n" + "  cityname_formatted = " + cityname_formatted + "\n" + "  stateabbreviation_formatted = "
				+ stateabbreviation_formatted + "\n" + "  fullpostalcode_formatted = " + fullpostalcode_formatted + "\n"
				+ "  streetnumber_formatted = " + streetnumber_formatted + "\n" + "  streetname_formatted = "
				+ streetname_formatted + "\n" + "  streetsuffix_formatted = " + streetsuffix_formatted + "\n"
				+ "  postdirectional_formatted = " + postdirectional_formatted + "\n" + "  predirectional_formatted = "
				+ predirectional_formatted + "\n" + "  countryname_formatted = " + countryname_formatted + "\n"
				+ "  latitude = " + latitude + "\n" + "  longitude = " + longitude + "\n" + "  addresssource = "
				+ addresssource;

	}

	public String getCombinedAddress() {

		String combinedAddress = "";

		if (addresslineone_formatted != null && addresslineone_formatted.trim().length() > 0) {
			// If Address line one is present
			combinedAddress = addresslineone_formatted;

			if (residencenumber_formatted != null && residencenumber_formatted.trim().length() > 0) {

				if (!combinedAddress.startsWith(residencenumber_formatted.trim()))
					combinedAddress = residencenumber_formatted.trim() + " " + combinedAddress;
			}

		} else {
			// If Address line one is not present
			if (residencenumber_formatted != null && residencenumber_formatted.trim().length() > 0) {
				combinedAddress = residencenumber_formatted.trim();
			}

			if (streetnumber_formatted != null && streetnumber_formatted.trim().length() > 0) {
				combinedAddress = combinedAddress + " " + streetnumber_formatted.trim();
			}

			if (streetname_formatted != null && streetname_formatted.trim().length() > 0) {
				combinedAddress = combinedAddress + " " + streetname_formatted.trim();
			}

			if (streetsuffix_formatted != null && streetsuffix_formatted.trim().length() > 0) {
				combinedAddress = combinedAddress + " " + streetsuffix_formatted.trim();
			}

		}

		if (cityname_formatted != null && cityname_formatted.trim().length() > 0) {

			combinedAddress = combinedAddress + " " + cityname_formatted;
		}

		if (fullpostalcode_formatted != null && fullpostalcode_formatted.trim().length() > 0) {

			combinedAddress = combinedAddress + " " + fullpostalcode_formatted;
		}

		if (stateabbreviation_formatted != null && stateabbreviation_formatted.trim().length() > 0
				&& !stateabbreviation_formatted.trim().equals("0")) {

			combinedAddress = combinedAddress + " " + stateabbreviation_formatted;
		}

		return combinedAddress;
	}

}
