package ca.bell.sda.dao;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import ca.bell.sda.config.AttributesConfig;
import ca.bell.sda.constant.log.LogKey;
import ca.bell.sda.constant.webclient.StreamSource;
import ca.bell.sda.elk.QueryBuilder;
import ca.bell.sda.model.Request;
import ca.bell.sda.model.config.AttributeProperties;
import ca.bell.sda.model.elk.Attribute;
import ca.bell.sda.model.elk.SearchQuery;

@Component
public class HierarchyDAO {

	@Autowired
	private SearchDAO searchDAO;

	@Autowired
	private QueryBuilder queryBuilder;

	@Autowired
	private AttributesConfig attributesConfig;

	private final String parentNodeParam = "childGK";
	private final String childNodeParam = "parentGK";
	private final String[] srcFilter = { "parent_gk", "parent_gk_name", "rel_tp","child_gk","child_gk_name","parentGKVirtualOrg","childGKVirtualOrg" };

	

	public Map<String, Object> getParentNodes(Request request, Object id, String index) {
		return getNodes(request, id, index, new String[] { parentNodeParam }, srcFilter);
	}
	
	public Map<String, Object> getParentNodes(Request request, Object[] id, String index) {
		return getNodes(request, id, index, new String[] { parentNodeParam }, srcFilter);
	}

	public Map<String, Object> getChildNodes(Request request, Object id, String index) {
		return getNodes(request, id, index, new String[] { childNodeParam }, srcFilter);
	}

	public Map<String, Object> getImediateHierarchy(Request request, Object id, String index) {
		String[] params = { parentNodeParam, childNodeParam };
		return getNodes(request, id, index, params, srcFilter);
	}

	public Map<String, Object> getParentNodes(Request request, Object id, String index, String[] srcFilter) {
		return getNodes(request, id, index, new String[] { parentNodeParam }, srcFilter);
	}

	public Map<String, Object> getChildNodes(Request request, Object id, String index, String[] srcFilter) {
		return getNodes(request, id, index, new String[] { childNodeParam }, srcFilter);
	}

	public Map<String, Object> getImediateHierarchy(Request request, Object id, String index, String[] srcFilter) {
		String[] params = { parentNodeParam, childNodeParam };
		return getNodes(request, id, index, params, srcFilter);
	}

	public List<Object> getFullHierarchy(String id, String index) {
		// Yet to implement
		return null;
	}

	@SuppressWarnings("unchecked")
	private Map<String, Object> getNodes(Request request, Object id, String index, String[] params,
			String[] srcFilter) {
		Map<String, Object> hrchyMap = new HashMap<>();
		Set<String> srcFilterSet = new HashSet<>();
		srcFilterSet.addAll(Arrays.asList(srcFilter));
		SearchQuery searchQuery = buildSearchQuery(getAttrbList(request.getReqId(), params, id), srcFilterSet);
		try {
			Object objMap = searchDAO.querySource(request.getReqId(),StreamSource.INDEX,searchQuery, index);
			hrchyMap = (Map<String, Object>) objMap;
		} catch (Exception e) {
			request.log(LogKey.REQ_LOG_EX_MSG, getClass().getName() + e.getMessage());
			request.log(LogKey.REQ_LOG_EX, e);
		}
		return hrchyMap;
	}

	private SearchQuery buildSearchQuery(List<Attribute> queryAttrbList, Set<String> srcFilter) {
		SearchQuery searchQuery = new SearchQuery();
		searchQuery.setMinScore("0");
		searchQuery.setSize("1000");
		searchQuery.setSourceFilter(srcFilter);
		searchQuery.setQuery(queryBuilder.createSearchQuery(queryAttrbList, null));
		return searchQuery;
	}

	private List<Attribute> getAttrbList(String grpId, String[] params, Object value) {
		List<Attribute> attrbList = new ArrayList<>();
		Attribute attrb;
		for (String param : params) {
			attrb = new Attribute();
			attrb.setValue(value);
			AttributeProperties attrbProperties = attributesConfig.getProperties().get(grpId).get(param);
			attrb.setProperties(attrbProperties);
			attrbList.add(attrb);
		}
		return attrbList;
	}
}
