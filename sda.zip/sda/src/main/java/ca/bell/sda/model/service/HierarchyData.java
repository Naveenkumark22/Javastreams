package ca.bell.sda.model.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import ca.bell.sda.model.config.DataAttributes;

public class HierarchyData {

	private String initialKey;
	private List<Map<String, Object>> profileList = new ArrayList<>();
	private Map<String, List<Map<String, Object>>> childListMap = new HashMap<>();
	private Map<String, List<Map<String, Object>>> parentListMap = new HashMap<>();
	private Map<String, Map<String, Object>> profileMap = new HashMap<>();
	private Set<String> processedKey = new HashSet<>();
	private Set<String> nextRoundKey = new HashSet<>();
	private Map<String, Map<String, Object>> nodes = new HashMap<>();

	private DataAttributes childDataAttrbs;
	private DataAttributes parentDataAttrbs;

	public String getInitialKey() {
		return initialKey;
	}

	public void setInitialKey(String initialKey) {
		this.initialKey = initialKey;
	}

	public List<Map<String, Object>> getProfileList() {
		return profileList;
	}

	public void setProfileList(List<Map<String, Object>> profileList) {
		this.profileList = profileList;
	}

	public Map<String, Map<String, Object>> getProfileMap() {
		return profileMap;
	}

	public void setProfileMap(Map<String, Map<String, Object>> profileMap) {
		this.profileMap = profileMap;
	}

	public Set<String> getProcessedKey() {
		return processedKey;
	}

	public void setProcessedKey(Set<String> processedKey) {
		this.processedKey = processedKey;
	}

	public Set<String> getNextRoundKey() {
		return nextRoundKey;
	}

	public void setNextRoundKey(Set<String> nextRoundKey) {
		this.nextRoundKey = nextRoundKey;
	}

	public Map<String, Map<String, Object>> getNodes() {
		return nodes;
	}

	public void setNodes(Map<String, Map<String, Object>> nodes) {
		this.nodes = nodes;
	}

	public DataAttributes getChildDataAttrbs() {
		return childDataAttrbs;
	}

	public void setChildDataAttrbs(DataAttributes childDataAttrbs) {
		this.childDataAttrbs = childDataAttrbs;
	}

	public DataAttributes getParentDataAttrbs() {
		return parentDataAttrbs;
	}

	public void setParentDataAttrbs(DataAttributes parentDataAttrbs) {
		this.parentDataAttrbs = parentDataAttrbs;
	}

	public Object[] getNextRoundKeyArr() {
		return nextRoundKey.toArray();
	}

	public Map<String, List<Map<String, Object>>> getChildListMap() {
		return childListMap;
	}

	public void setChildListMap(Map<String, List<Map<String, Object>>> childListMap) {
		this.childListMap = childListMap;
	}

	public Map<String, List<Map<String, Object>>> getParentListMap() {
		return parentListMap;
	}

	public void setParentListMap(Map<String, List<Map<String, Object>>> parentListMap) {
		this.parentListMap = parentListMap;
	}

}
