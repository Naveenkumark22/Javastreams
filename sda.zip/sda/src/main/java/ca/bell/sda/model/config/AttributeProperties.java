package ca.bell.sda.model.config;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import ca.bell.sda.constant.value.ValueConversion;
import ca.bell.sda.model.Status;

/**
 * @author Jagan Boopathi
 *
 */
public class AttributeProperties {

	private String id;
	private String name;
	private boolean enabled;
	private int nodeType;
	private int valueType;

	/**
	 * Default value ValueConversion.RAW
	 * 
	 */
	private int valueConversion = ValueConversion.RAW;

	private int conversionType;
	private String conversionMethod;
	private Map<String, String> conversionMap;
	private String parentNode;
	private String[] childNodes;
	private boolean multiField;
	private boolean nestedField;
	private String[] nestedPaths;
	private boolean mixedField;
	private Map<String, String[]> fields;

	private boolean multiType;
	private String[] types;
	private String checkType;
	private Map<String, Integer> matchTypeMap;
	private int matchType;
	private String fuzzyType;
	private int boolCondition;
	private boolean advancedSearch;
	private Map<Integer, Map<String, String>> boostMap = new HashMap<Integer, Map<String,String>>();

	private String serviceMethod;

	private int weightage;
	private int minLength;
	private String[] validationRules;
	private int filterLevel;
	private Set<String> permittedValues;
	private String dataValidationField;
	private Map<String, Status> dataValidationErrors;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public boolean isEnabled() {
		return enabled;
	}

	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}

	public int getNodeType() {
		return nodeType;
	}

	public void setNodeType(int nodeType) {
		this.nodeType = nodeType;
	}

	public int getValueType() {
		return valueType;
	}

	public void setValueType(int valueType) {
		this.valueType = valueType;
	}

	public String getParentNode() {
		return parentNode;
	}

	public void setParentNode(String parentNode) {
		this.parentNode = parentNode;
	}

	public String[] getChildNodes() {
		return childNodes;
	}

	public void setChildNodes(String[] childNodes) {
		this.childNodes = childNodes;
	}

	public boolean isMultiField() {
		return multiField;
	}

	public void setMultiField(boolean multiField) {
		this.multiField = multiField;
	}

	public boolean isNestedField() {
		return nestedField;
	}

	public void setNestedField(boolean nestedField) {
		this.nestedField = nestedField;
	}

	public String[] getNestedPaths() {
		return nestedPaths;
	}

	public void setNestedPaths(String[] nestedPaths) {
		this.nestedPaths = nestedPaths;
	}

	public boolean isMixedField() {
		return mixedField;
	}

	public void setMixedField(boolean mixedField) {
		this.mixedField = mixedField;
	}

	public Map<String, String[]> getFields() {
		return fields;
	}

	public void setFields(Map<String, String[]> fields) {
		this.fields = fields;
	}

	public boolean isMultiType() {
		return multiType;
	}

	public void setMultiType(boolean multiType) {
		this.multiType = multiType;
	}

	public String[] getTypes() {
		return types;
	}

	public void setTypes(String[] types) {
		this.types = types;
	}

	public String getCheckType() {
		return checkType;
	}

	public void setCheckType(String checkType) {
		this.checkType = checkType;
	}

	public int getMatchType() {
		return matchType;
	}

	public void setMatchType(int matchType) {
		this.matchType = matchType;
	}

	public String getFuzzyType() {
		return fuzzyType;
	}

	public void setFuzzyType(String fuzzyType) {
		this.fuzzyType = fuzzyType;
	}

	public int getBoolCondition() {
		return boolCondition;
	}

	public void setBoolCondition(int boolCondition) {
		this.boolCondition = boolCondition;
	}

	public int getWeightage() {
		return weightage;
	}

	public void setWeightage(int weightage) {
		this.weightage = weightage;
	}

	public int getMinLength() {
		return minLength;
	}

	public void setMinLength(int minLength) {
		this.minLength = minLength;
	}

	public String[] getValidationRules() {
		return validationRules;
	}

	public void setValidationRules(String[] validationRules) {
		this.validationRules = validationRules;
	}

	public int getFilterLevel() {
		return filterLevel;
	}

	public void setFilterLevel(int filterLevel) {
		this.filterLevel = filterLevel;
	}

	public Set<String> getPermittedValues() {
		return permittedValues;
	}

	public void setPermittedValues(Set<String> permittedValues) {
		this.permittedValues = permittedValues;
	}

	public Map<String, Integer> getMatchTypeMap() {
		return matchTypeMap;
	}

	public void setMatchTypeMap(Map<String, Integer> matchTypeMap) {
		this.matchTypeMap = matchTypeMap;
	}

	public boolean isAdvancedSearch() {
		return advancedSearch;
	}

	public void setAdvancedSearch(boolean advancedSearch) {
		this.advancedSearch = advancedSearch;
	}

	public Map<Integer, Map<String, String>> getBoostMap() {
		return boostMap;
	}

	public void setBoostMap(Map<Integer, Map<String, String>> boostMap) {
		this.boostMap = boostMap;
	}

	public int getValueConversion() {
		return valueConversion;
	}

	public void setValueConversion(int valueConversion) {
		this.valueConversion = valueConversion;
	}

	public int getConversionType() {
		return conversionType;
	}

	public void setConversionType(int conversionType) {
		this.conversionType = conversionType;
	}

	public String getConversionMethod() {
		return conversionMethod;
	}

	public void setConversionMethod(String conversionMethod) {
		this.conversionMethod = conversionMethod;
	}

	public Map<String, String> getConversionMap() {
		return conversionMap;
	}

	public void setConversionMap(Map<String, String> conversionMap) {
		this.conversionMap = conversionMap;
	}

	public String getServiceMethod() {
		return serviceMethod;
	}

	public void setServiceMethod(String serviceMethod) {
		this.serviceMethod = serviceMethod;
	}

	public String getDataValidationField() {
		return dataValidationField;
	}

	public void setDataValidationField(String dataValidationField) {
		this.dataValidationField = dataValidationField;
	}

	public Map<String, Status> getDataValidationErrors() {
		return dataValidationErrors;
	}

	public void setDataValidationErrors(Map<String, Status> dataValidationErrors) {
		this.dataValidationErrors = dataValidationErrors;
	}

	
	
}
