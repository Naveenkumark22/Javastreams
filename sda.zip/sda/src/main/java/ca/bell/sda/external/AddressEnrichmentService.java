/**
 * 
 */
package ca.bell.sda.external;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClientRequestException;

import ca.bell.sda.dao.SearchDAO;
import ca.bell.sda.model.whitespace.ELKAddress;
import ca.bell.sda.model.whitespace.StdOrgRecord;
import ca.bell.sda.model.whitespace.ml.AdditionalQueryCall;
import ca.bell.sda.service.CPMService;

/**
 * @author Kamalanathan Ranganathan
 *
 */

@Service
public class AddressEnrichmentService extends CPMService {
	
	@Autowired
	private SearchDAO searchDAO;

	@Async("asyncExecutor")
	public CompletableFuture<StdOrgRecord> queryAddressEnrichment(AdditionalQueryCall secondcall) throws Exception {

		StdOrgRecord secondCallResultRecord = new StdOrgRecord();

		try {			
			Map<String, Object> secondCallResult = searchDAO.querySource(secondcall.getEndpoint(), secondcall.getUrl(),
					secondcall.getQry(), secondcall.getFilterpath());

			List<StdOrgRecord> scncallresultlist = parseResponse(secondCallResult);
			
			
			if (scncallresultlist != null && scncallresultlist.size() > 0) {

				secondCallResultRecord = scncallresultlist.get(0);

				secondCallResultRecord.setNullRecord(false);

			}

			secondCallResultRecord.setSecondCall(secondcall);

		} catch (Exception e) {

			e.printStackTrace();

			if (e instanceof WebClientRequestException) {

				throw new Exception("ELK : Address Enrichment : " + e.getMessage());
			}
		}

		return CompletableFuture.completedFuture(secondCallResultRecord);
	}

	// Parsing the result
	@SuppressWarnings("unchecked")
	private List<StdOrgRecord> parseResponse(Map<String, Object> response) throws Exception {

		Map<String, Object> hits = (Map<String, Object>) response.get("hits");

		if (hits != null) {
			List<Map<String, Object>> lhits = (List<Map<String, Object>>) hits.get("hits");

			return getOrgRecordList(lhits);
		} else
			return null;
	}

	private List<StdOrgRecord> getOrgRecordList(List<Map<String, Object>> lhits) throws Exception {

		List<StdOrgRecord> records = new ArrayList<>();

		if (lhits != null) {

			for (Map<String, Object> hit : lhits) {

				records.add(getOrgRecord(hit));

			}
		}

		return records;
	}

	@SuppressWarnings("unchecked")
	private StdOrgRecord getOrgRecord(Map<String, Object> hit) throws Exception {

		StdOrgRecord orgRecord = new StdOrgRecord();

		if (hit != null) {

			double score = (Double) hit.get("_score");

			Map<String, Object> source = (Map<String, Object>) hit.get("_source");

			Map<String, Object> address = (Map<String, Object>) source.get("stdAddress");

			ELKAddress addr = getAddress(address);

			orgRecord = new StdOrgRecord.RecordBuilder()

					.gkId((String) source.get("gkId"))

					.stdOrgName((String) source.get("stdOrgName"))

					.score(score)

					.elkAddress(addr)

					.build();

			orgRecord.setSrc(source);
			
		}

		return orgRecord;

	}

	private ELKAddress getAddress(Map<String, Object> address) throws Exception {

		ELKAddress addr = new ELKAddress();

		if (address != null) {

			// This address is from ELK Bucketing

			addr = new ELKAddress.AddressBuilder()

					.combinedAddress((String) address.get("combinedAddress"))

					.addressLineOne((String) address.get("addressLineOne"))

					.country((String) address.get("country"))

					.postalCode((String) address.get("postalCode"))

					.addressLineTwo((String) address.get("addressLineTwo"))

					.province((String) address.get("province"))

					.city((String) address.get("city")).build();

		}

		return addr;

	}
}
