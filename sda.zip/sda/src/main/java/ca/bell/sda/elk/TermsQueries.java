package ca.bell.sda.elk;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;

@Component
public class TermsQueries {

	public static Map<String, Object> getTermsQuery(String attrb, Object value) {
		Map<String, Object> rootMap = new HashMap<>();
		Map<String, Object> terms = new HashMap<>();

		terms.put(attrb, value);
		rootMap.put("terms", terms);

		return rootMap;
	}

	public static Map<String, Object> getTermsQuery(String attrb, Object value, String boostVal) {
		Map<String, Object> rootMap = new HashMap<>();
		Map<String, Object> terms = new HashMap<>();

		terms.put("boost", boostVal);
		terms.put(attrb, value);
		rootMap.put("terms", terms);

		return rootMap;
	}

	public static Map<String, Object> getNestedTermsQuery(String attrb, String path, Object value,
			String boolCondition) {
		Map<String, Object> rootMap = new HashMap<>();
		Map<String, Object> nested = new HashMap<>();
		Map<String, Object> query = new HashMap<>();
		Map<String, List<Object>> bool = new HashMap<>();
		List<Object> termsList = new ArrayList<>();
		Map<String, Object> terms = new HashMap<>();
		Map<String, Object> termsQuery = new HashMap<>();

		terms.put(attrb, value);
		termsQuery.put("terms", terms);
		termsList.add(termsQuery);
		bool.put(boolCondition, termsList);
		query.put("bool", bool);
		nested.put("path", path);
		nested.put("query", query);
		rootMap.put("nested", nested);

		return rootMap;
	}

	public static Map<String, Object> getNestedTermsQuery(String attrb, String path, Object value, String boolCondition,
			String boostVal) {
		Map<String, Object> rootMap = new HashMap<>();
		Map<String, Object> nested = new HashMap<>();
		Map<String, Object> query = new HashMap<>();
		Map<String, List<Object>> bool = new HashMap<>();
		List<Object> termsList = new ArrayList<>();
		Map<String, Object> terms = new HashMap<>();
		Map<String, Object> termsQuery = new HashMap<>();

		terms.put(attrb, value);
		terms.put("boost", boostVal);
		termsQuery.put("terms", terms);
		termsList.add(termsQuery);
		bool.put(boolCondition, termsList);
		query.put("bool", bool);
		nested.put("path", path);
		nested.put("query", query);
		rootMap.put("nested", nested);

		return rootMap;
	}

	public static Map<String, Object> getMultiNestedTermsQuery(String[] attrbArr, Object value, String boolCondition) {
		Map<String, Object> rootMap = new HashMap<>();
		rootMap = getNestedTerms(attrbArr, 0, attrbArr[0], value, boolCondition);
		return rootMap;
	}

	private static Map<String, Object> getNestedTerms(String[] attrbArr, int position, String path, Object value,
			String boolCondition) {
		if (position == attrbArr.length - 1) {
			return getTermsQuery(path, value);
		} else {
			Map<String, Object> rootMap = new HashMap<>();
			Map<String, Object> nested = new HashMap<>();
			Map<String, Object> query = new HashMap<>();
			Map<String, List<Object>> bool = new HashMap<>();
			List<Object> objList = new ArrayList<>();
			nested.put("path", path);
			nested.put("query", query);
			query.put("bool", bool);
			bool.put(boolCondition, objList);
			position += 1;
			objList.add(getNestedTerms(attrbArr, position, path + "." + attrbArr[position], value, boolCondition));
			rootMap.put("nested", nested);
			return rootMap;
		}

	}

}
