package ca.bell.sda.validator;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import ca.bell.sda.constant.value.ValueType;
import ca.bell.sda.model.elk.Attribute;
import ca.bell.sda.service.SourceSystemService;
import ca.bell.sda.util.Utility;

@Component
public class AttributeValidator {
	
	private static SourceSystemService service;

	 @Autowired
	 public void setSourceSystemService(SourceSystemService servicebean) {
		 service = servicebean;		 
	 }
	
	
	public static boolean isValidLength(Attribute attrb) {
		int size = attrb.getProperties().getMinLength();
		String value = (String) attrb.getValue();
		if (value.length() < size) {
			return false;
		}
		return true;
	}

	public static boolean checkPermittedValues(Attribute attrb) {
		return attrb.getProperties().getPermittedValues().contains((String) attrb.getValue());
	}
	
	public static boolean checkSourceSystemPermittedValues(Attribute attrb) {
			return service.getSourceSystem().keySet().contains(attrb.getValue().toString().toLowerCase());
		
	}

	@SuppressWarnings("unchecked")
	public static boolean validateLocation(Attribute attrb) {
		Map<String, String> kpValue = (HashMap<String, String>) attrb.getValue();
		String type = attrb.getType();
		if (kpValue == null || kpValue.size() < 1) {
			return false;
		}
		if (type.equalsIgnoreCase(ValueType.LOCATION_NON_TOKENIZED) && kpValue.size() > 1) {
			return false;
		}
		return true;
	}	

	public static boolean validSizeLimit(Attribute attrb) {
		Object valueObj = attrb.getValue();
		int value = 0;
		if (valueObj.getClass() == String.class) {
			value = Integer.valueOf((String) valueObj);
		} else {
			value = (int) valueObj;
		}

		if (value < 0 || value > 10000) {
			return false;
		}
		return true;
	}

	public static boolean checkPositiveInt(Attribute attrb) {
		Object valueObj = attrb.getValue();
		int value = 0;
		if (valueObj.getClass() == String.class) {
			value = Integer.valueOf((String) valueObj);
		} else {
			value = (int) valueObj;
		}

		if (value <= 0) {
			return false;
		}
		return true;
	}

	public static String checkStringType(String strValue) {
		if (strValue.matches("^[0-9].*$"))
			return ValueType.ALPHA_NUMERIC;
		return ValueType.ALPHABETS;
	}

	public static String checkBanType(String ban) {
		ban = ban.trim();
		if (ban.matches(".*\\s+.*"))
			return ValueType.BTN_WITH_3_DIGIT; // Ban Type is BTN
		return ValueType.BAN; // Ban Type is BAN

	}

	public static String checkTokenization(LinkedHashMap<String, String> value) {
		Map<String, String> kpValue = value;
		if (kpValue.get("addr") != null) {
			return ValueType.LOCATION_NON_TOKENIZED;
		}
		return ValueType.LOCATION_TOKENIZED;
	}

}
