package ca.bell.sda.model.elk;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import ca.bell.sda.util.Utility;

public class MultiSearchQuery {

	private List<Map<String, Object>> searchQueryList = new ArrayList<>();

	public List<Map<String, Object>> getSearchQueryList() {
		return searchQueryList;
	}

	public void setSearchQueryList(List<Map<String, Object>> searchQueryList) {
		this.searchQueryList = searchQueryList;
	}

	public void addSearchQuery(String indexName, SearchQuery searchQuery) {
		Map<String, Object> map = new HashMap<>();
		map.put("index", indexName);
		searchQueryList.add(map);
		searchQueryList.add(Utility.convertPojoToMap(searchQuery));
	}

	public String getMultiQueryString() {
		String queryStr = "";
		for (int i = 0; i < searchQueryList.size(); i = i + 2) {
			String str = Utility.convertObjectToString(searchQueryList.get(i + 1));
			if (str != null) {
				queryStr += Utility.convertObjectToString(searchQueryList.get(i)) + "\n" + str + "\n";
			}
		}
		return queryStr;
	}

}
