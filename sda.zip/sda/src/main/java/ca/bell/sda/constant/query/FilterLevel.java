package ca.bell.sda.constant.query;

public class FilterLevel {

	public static final int ROOT = 1;
	public static final int NESTED = 2;
}
