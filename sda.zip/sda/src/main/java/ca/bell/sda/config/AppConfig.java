package ca.bell.sda.config;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

@Component
public class AppConfig {

	private String activeEnv;

	private String logEndpoint;

	@Autowired
	private Environment env;

	@Autowired
	private AppProperties appProps;

	@Autowired
	private ElasticQueryConfig elasticQueryConfig;

	@Autowired
	private AttributesConfig attributesConfig;

	public ElasticQueryConfig getElasticQueryConfig() {
		return elasticQueryConfig;
	}

	public void setElasticQueryConfig(ElasticQueryConfig elasticQueryConfig) {
		this.elasticQueryConfig = elasticQueryConfig;
	}

	public AttributesConfig getAttributesConfig() {
		return attributesConfig;
	}

	public void setAttributesConfig(AttributesConfig attributesConfig) {
		this.attributesConfig = attributesConfig;
	}

	public AppProperties getAppProps() {
		return appProps;
	}

	public void setAppProps(AppProperties appProps) {
		this.appProps = appProps;
	}

	public String getLogEndpoint() {
		if (logEndpoint == null) {
			if (getAcitveEnv().equalsIgnoreCase("local")||getAcitveEnv().equalsIgnoreCase("dev")) {
				logEndpoint = "sda-log-bbm-fastdb";
			} else if (getAcitveEnv().equalsIgnoreCase("uat")||getAcitveEnv().equalsIgnoreCase("uat1")) {
				logEndpoint = "sda-log-bbm-efastdb-uat";
			} else if (getAcitveEnv().equalsIgnoreCase("prod")){
				logEndpoint = "sda-log-bbm-efastdb";
			}
		}
		return logEndpoint;
	}

	public String getLogEndpoint(String env) {
		if (logEndpoint == null) {
			if (env.equalsIgnoreCase("local") || env.equalsIgnoreCase("dev") || env.equalsIgnoreCase("uat")) {
				logEndpoint = "ws-log-bbm-efastdb-uat";
			}else if(env.equalsIgnoreCase("uat1")) 
			{
				logEndpoint = "ws-log-bbm-efastdb-sit";
			}else {
				logEndpoint = "ws-log-bbm-fastdb";
			}
		}
		return logEndpoint;
	}

	public void setLogEndpoint(String logEndpoint) {
		this.logEndpoint = logEndpoint;
	}

	public String getAcitveEnv() {
		if (this.activeEnv == null) {
			String[] profiles = env.getActiveProfiles();
			for (String profile : profiles) {
				if (appProps.getEnvironments().contains(profile)) {
					this.activeEnv = profile;
					break;
				}
			}
		}
		return this.activeEnv;
	}

	public String getEndpointName(String reqId, String srcName) {
		return appProps.getService().get(reqId).getEndpoint(srcName).get(getAcitveEnv());
	}

	public String[] getIndexNames(String reqId) {
		String[] indexes;
		String defaultProf = "uat";
		String activeProf = getAcitveEnv();
		Map<String, String[]> indexMap = appProps.getService().get(reqId).getIndexMap();
		if (indexMap.containsKey(activeProf)) {
			indexes = indexMap.get(activeProf);
		} else {
			indexes = indexMap.get(defaultProf);
		}
		return indexes;
	}

}
