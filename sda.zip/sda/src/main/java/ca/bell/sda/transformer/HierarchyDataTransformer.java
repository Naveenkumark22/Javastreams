package ca.bell.sda.transformer;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import ca.bell.sda.config.AttributesConfig;
import ca.bell.sda.model.Request;
import ca.bell.sda.model.config.DataAttributes;
import ca.bell.sda.model.elk.response.ResponseData;
import ca.bell.sda.process.HierarchyDataProcessor;

@Component
public class HierarchyDataTransformer {

	@Autowired
	AttributesConfig attributesConfig;

	@Autowired
	private HierarchyDataProcessor hrchyDP;

	@SuppressWarnings("unchecked")
	public ResponseData childAsList(Request request, Object id, Object elkData) {
		Map<String, Object> dataMap = (Map<String, Object>) elkData;
		int total = hrchyDP.getTotalValue(dataMap);
		ResponseData resData = new ResponseData();
		if (total > 0) {

			Map<String, DataAttributes> dataAttrb = attributesConfig.getDataAttributes().get(request.getReqId());

			Map<String, String> rltdPrtyKeyPairs = dataAttrb.get("relatedParty").getKeyPairs();
			Map<String, Object> rltdPrtyDefaultValues = new HashMap<>(dataAttrb.get("relatedParty").getDefaultValues());
			rltdPrtyDefaultValues.put("parent_gk", id);
			
			Map<String, String> profKeyPairs = dataAttrb.get("childList").getKeyPairs();
			Map<String, Object> profDefaultValues = dataAttrb.get("childList").getDefaultValues();

			List<Map<String, Object>> profileList = hrchyDP.getProfileMapList(dataMap);
			List<Map<String, Object>> childList = new ArrayList<Map<String,Object>>();
			Map<String, Object> childNode = null;
			List<Map<String,Object>> rltdPartyList=null;
			Map<String, Object> rltdParty = null;
			for (Map<String, Object> profileMap : profileList) {
				Map<String, Object> sourceMap = (Map<String, Object>) profileMap.get("_source");
				rltdParty = new HashMap<>();
				hrchyDP.processDataMapWithDefault(sourceMap, rltdParty, rltdPrtyKeyPairs, rltdPrtyDefaultValues);
				
				childNode = new HashMap<>();
				hrchyDP.processDataMapWithDefault(sourceMap, childNode, profKeyPairs, profDefaultValues);
				rltdPartyList = new ArrayList<>();
				rltdPartyList.add(rltdParty);
				childNode.put("relatedParty", rltdPartyList);
				childList.add(childNode);
			}
			resData.setProfiles(childList);
		}
		return resData;
	}
}
