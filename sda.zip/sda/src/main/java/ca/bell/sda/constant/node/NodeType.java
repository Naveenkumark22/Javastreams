package ca.bell.sda.constant.node;

public class NodeType {

	public static final int QUERY = 1;
	public static final int QUERY_CONFIG = 2;
	public static final int QUERY_FILTER = 3;
	public static final int SOURCE_FILTER = 4;
	public static final int NODE_VALUE_TYPE = 5;
	public static final int REQUEST_CONFIG = 6;

}
