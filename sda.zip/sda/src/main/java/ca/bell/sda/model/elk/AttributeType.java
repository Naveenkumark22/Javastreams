package ca.bell.sda.model.elk;

public class AttributeType {
	private int type;
	private String queryType;

	public AttributeType(int type, String queryType) {
		super();
		this.type = type;
		this.queryType = queryType;
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

	public String getQueryType() {
		return queryType;
	}

	public void setQueryType(String queryType) {
		this.queryType = queryType;
	}

}
