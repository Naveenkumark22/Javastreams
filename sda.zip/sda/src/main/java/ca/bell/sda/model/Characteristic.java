package ca.bell.sda.model;

import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
@JsonInclude(Include.NON_NULL)
public class Characteristic {
	
	private List<Map<String,Object>> regionalisation;
    private Object name;
    private Object value;
	public List<Map<String, Object>> getRegionalisation() {
		return regionalisation;
	}
	public void setRegionalisation(List<Map<String, Object>> regionalisation) {
		this.regionalisation = regionalisation;
	}
	public Object getName() {
		return name;
	}
	public void setName(Object name) {
		this.name = name;
	}
	public Object getValue() {
		return value;
	}
	public void setValue(Object value) {
		this.value = value;
	}   
	
}
