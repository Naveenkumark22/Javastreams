/**
 * 
 */
package ca.bell.sda.model.whitespace.ml;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author Kamalanathan Ranganathan
 *
 */

public class MLInputRoot {

	private List<InputList> input_list = new ArrayList<InputList>();

	@JsonProperty("input_list")
	public List<InputList> getInput_list() {
		return this.input_list;
	}

	public void setInput_list(List<InputList> input_list) {
		this.input_list = input_list;
	}

	public void addInput_list(InputList input_list) {
		if (this.input_list == null)
			this.input_list = new ArrayList<InputList>();

		this.input_list.add(input_list);
	}

}
