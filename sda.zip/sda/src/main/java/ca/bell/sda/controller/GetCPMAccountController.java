package ca.bell.sda.controller;

import java.time.Instant;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import ca.bell.sda.constant.log.LogKey;
import ca.bell.sda.constant.status.StatusTypes;
import ca.bell.sda.model.Request;
import ca.bell.sda.model.Response;
import ca.bell.sda.process.RequestProcessor;
import ca.bell.sda.service.CPMAccountService;

@RestController
public class GetCPMAccountController extends SDAController {

	@Autowired
	private RequestProcessor processor;

	@Autowired
	private CPMAccountService service;

	@RequestMapping(value = "/bbm/GetCPMAccount", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public Response getCPMIndividual(@RequestBody Map<String, Object> requestMap) throws Exception {

		Request request = new Request("bbm","GetCPMAccount");
		request.logTime(LogKey.REQ_START);
		request.log(LogKey.TIMESTAMP, Instant.now().toString());
		request.log(LogKey.REQ_GRP_ID, request.getReqId());
		request.log(LogKey.REQ_MAP, requestMap);

		Response response = new Response(StatusTypes.REQUEST_SUCCESS);

		request.logTime(LogKey.QUERY_BUILD_START);
		processor.processRequest(requestMap, request, response);

		if (response.getStatus().getCode() == StatusTypes.REQUEST_SUCCESS.getCode()) {
			response.setData(service.getAccount(request,requestMap));
			request.log(LogKey.REQ_RESPONSE, response.getData());
		}
		checkRequestLog(request);

		
		return response;
	}

}
