/**
 *
 */
package ca.bell.sda.service.whitespace;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;

import ca.bell.sda.config.AppConfig;
import ca.bell.sda.constant.log.LogKey;
import ca.bell.sda.dao.SearchDAO;
import ca.bell.sda.model.Request;
import ca.bell.sda.model.config.Endpoint;
import ca.bell.sda.model.whitespace.ml.MLInputRoot;
import ca.bell.sda.service.CPMService;

/**
 * @author Kamalanathan Ranganathan
 */
@Service
public class MLDeDuplicationService extends CPMService {

	@Autowired
	private AppConfig appConfig;

	@Autowired
	private SearchDAO searchDAO;

	public MLInputRoot doDeDuplication(Request request, MLInputRoot root) throws Exception {

		try {

			String endPointName = "mlmatching";

			Endpoint ep = appConfig.getAppProps().getServers().getWebService().getEndPoints().get(endPointName);

			String eurl = String.format("%s/%s", ep.getHost(), ep.getUrl());
			
			Map<String, Object> result = searchDAO.querySource(endPointName, eurl, root);
		
			ObjectMapper mapper = new ObjectMapper();

			MLInputRoot ret = mapper.readValue(mapper.writeValueAsString(result), MLInputRoot.class);

			return ret;

		} catch (Exception e) {

			request.log(LogKey.REQ_LOG_EX_MSG, "M L (python) : " + e.getMessage());

			request.log(LogKey.REQ_LOG_EX, e);

			throw new Exception("M L (python) : " + e.getMessage());
		}
	}

}
