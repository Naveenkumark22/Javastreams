package ca.bell.sda.process;

import ca.bell.sda.config.AttributesConfig;
import ca.bell.sda.model.Request;
import ca.bell.sda.model.elk.response.ResponseData;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.*;

@Component
public class AccountDataProcessor extends ElasticDataProcessor implements DataProcessor {

	@Autowired
	private AttributesConfig attributesConfig;

	@SuppressWarnings("unchecked")
	@Override
	public <T> ResponseData processData(Request request, T data) {
		ResponseData resData = new ResponseData();
		Map<String, Object> dataMap = (Map<String, Object>) data;
		int total = getTotalValue(dataMap);
		resData.setTotal(total);
		if (total > 0) {
			Map<String, Object> profile;
			List<Map<String, Object>> profilesMap = getProfileMapList(dataMap);
			List<Map<String, Object>> profileList = new ArrayList<>();
			if (profilesMap != null) {
				for (Map<String, Object> profMap : profilesMap) {
					profile = new HashMap<>();
					Map<String, Object> sourceMap = (Map<String, Object>) profMap.get("_source");
					Set<String> keySet = null;
					keySet = attributesConfig.getDataAttributes().get(request.getReqId()).get("profile").getKeys();
					processDataMap(sourceMap, profile, keySet);

					if (profile.size() > 0)
						profileList.add(profile);
				}

				resData.setProfiles(profileList);
			}
		}
		return resData;
	}

}
