package ca.bell.sda.model;

import java.util.List;

@SuppressWarnings("serial")
public class InvalidRequestException extends Exception {

	private final String message = "Invalid Request";
	private List<Error> errorList;

	public InvalidRequestException(List<Error> errorList) {
		super();
		this.errorList = errorList;
	}

	public final List<Error> getErrorList() {
		return errorList;
	}

	public final void setErrorList(List<Error> errorList) {
		this.errorList = errorList;
	}

	public final String getMessage() {
		return message;
	}

}
