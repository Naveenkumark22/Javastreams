package ca.bell.sda.model.whitespace.mdm;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author Kamalanathan Ranganathan
 *
 */
public class BBMAddressBObjExt {

	private String addressLineOne;

	private String addressLineThree;

	private String addressLineTwo;

	private String city;

	private String residenceNumber;

	private String zipPostalCode;

	private String provinceStateValue;

	private String countryValue;

	private double latitudeDegrees;

	private double longitudeDegrees;

	private String streetNumber;

	private String streetName;

	private String streetSuffix;

	private String postDirectional;

	private String streetPrefix;

	private String buildingName;

	@JsonProperty("addressLineOne")
	public String getAddressLineOne() {
		return this.addressLineOne;
	}

	public void setAddressLineOne(String addressLineOne) {
		this.addressLineOne = addressLineOne;
	}

	@JsonProperty("addressLineThree")
	public String getAddressLineThree() {
		return this.addressLineThree;
	}

	public void setAddressLineThree(String addressLineThree) {
		this.addressLineThree = addressLineThree;
	}

	@JsonProperty("addressLineTwo")
	public String getAddressLineTwo() {
		return this.addressLineTwo;
	}

	public void setAddressLineTwo(String addressLineTwo) {
		this.addressLineTwo = addressLineTwo;
	}

	@JsonProperty("city")
	public String getCity() {
		return this.city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	@JsonProperty("residenceNumber")
	public String getResidenceNumber() {
		return this.residenceNumber;
	}

	public void setResidenceNumber(String residenceNumber) {
		this.residenceNumber = residenceNumber;
	}

	@JsonProperty("zipPostalCode")
	public String getZipPostalCode() {
		return this.zipPostalCode;
	}

	public void setZipPostalCode(String zipPostalCode) {
		this.zipPostalCode = zipPostalCode;
	}

	@JsonProperty("provinceStateValue")
	public String getProvinceStateValue() {
		return this.provinceStateValue;
	}

	public void setProvinceStateValue(String provinceStateValue) {
		this.provinceStateValue = provinceStateValue;
	}

	@JsonProperty("countryValue")
	public String getCountryValue() {
		return this.countryValue;
	}

	public void setCountryValue(String countryValue) {
		this.countryValue = countryValue;
	}

	@JsonProperty("latitudeDegrees")
	public double getLatitudeDegrees() {
		return this.latitudeDegrees;
	}

	public void setLatitudeDegrees(double latitudeDegrees) {
		this.latitudeDegrees = latitudeDegrees;
	}

	@JsonProperty("longitudeDegrees")
	public double getLongitudeDegrees() {
		return this.longitudeDegrees;
	}

	public void setLongitudeDegrees(double longitudeDegrees) {
		this.longitudeDegrees = longitudeDegrees;
	}

	@JsonProperty("streetNumber")
	public String getStreetNumber() {
		return this.streetNumber;
	}

	public void setStreetNumber(String streetNumber) {
		this.streetNumber = streetNumber;
	}

	@JsonProperty("streetName")
	public String getStreetName() {
		return this.streetName;
	}

	public void setStreetName(String streetName) {
		this.streetName = streetName;
	}

	@JsonProperty("streetSuffix")
	public String getStreetSuffix() {
		return this.streetSuffix;
	}

	public void setStreetSuffix(String streetSuffix) {
		this.streetSuffix = streetSuffix;
	}

	@JsonProperty("postDirectional")
	public String getPostDirectional() {
		return this.postDirectional;
	}

	public void setPostDirectional(String postDirectional) {
		this.postDirectional = postDirectional;
	}

	@JsonProperty("streetPrefix")
	public String getStreetPrefix() {
		return this.streetPrefix;
	}

	public void setStreetPrefix(String streetPrefix) {
		this.streetPrefix = streetPrefix;
	}

	@JsonProperty("buildingName")
	public String getBuildingName() {
		return this.buildingName;
	}

	public void setBuildingName(String buildingName) {
		this.buildingName = buildingName;
	}

}
