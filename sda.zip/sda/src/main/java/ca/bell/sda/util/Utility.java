package ca.bell.sda.util;

import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.Map;

import com.fasterxml.jackson.databind.ObjectMapper;

public class Utility {
	
	private static ObjectMapper objMapper = new ObjectMapper();

	public static String[] convertToStringArray(Object[] obj) {
		return Arrays.copyOf(obj, obj.length, String[].class);
	}

	public static <T extends Object> T convertValueToPojo(Object objValue, Class<T> objClass) {
		try {
			return objMapper.convertValue(objValue, objClass);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@SuppressWarnings("unchecked")
	public static Map<String, Object> convertPojoToMap(Object pojoObj) {
		try {
			if (pojoObj != null) {
				return objMapper.convertValue(pojoObj, Map.class);
			}
		} catch (Exception e) {
		}
		return null;
	}

	public static void consoleObject(Object obj) {
		try {
			System.out.println(new ObjectMapper().writeValueAsString(obj));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void consoleObject(Object obj, String str) {
		try {
			System.out.println(str);
			System.out.println(new ObjectMapper().writeValueAsString(obj));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static String convertObjectToString(Object obj) {
		try {
			return objMapper.writeValueAsString(obj);
		} catch (Exception e) {
		}
		return null;
	}

	@SuppressWarnings("rawtypes")
	public static <T> Object executeInstanceMethod(Class<T> cls, Object objIns, String methodName, Object... args) {
		try {
			int argLength = args.length;
			Class[] clsArr = new Class[argLength];

			for (int i = 0; i < argLength; i++) {
				clsArr[i] = args[i].getClass();
			}
			Method method = cls.getMethod(methodName, clsArr);
			return method.invoke(objIns, args);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return null;
	}

	public static <T> Object executeStaticMethod(Class<T> cls, String methodName, Object... args) {
		return executeInstanceMethod(cls, null, methodName, args);
	}
	
	public static String getAsString(Object obj) {

		String ret = "";

		if (obj != null) {

			if (obj instanceof Integer) {

				ret = ((Integer) obj).intValue() + "";

			} else if (obj instanceof Long) {

				ret = ((Long) obj).intValue() + "";

			} else if (obj instanceof Double) {

				ret = ((Double) obj).intValue() + "";

			} else if (obj instanceof String) {

				ret = obj.toString();

			}
		}

		return ret;
	}

	public static Long getAsLong(Object obj) {

		Long ret = 0L;

		if (obj != null) {

			ret = Long.valueOf((Integer) obj);

		}

		return ret;
	}

}
