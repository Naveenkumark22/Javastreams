package ca.bell.sda.model.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class ContactSuspectDetail {

	private List<String> requestContactList;
	private Set<String> contactSet = new HashSet<String>();
	private Map<String, Set<String>> linkedContactSet = new HashMap<>();
	private Map<String, String> suspectScore = new HashMap<>();

	// Suspect list for request contact
	private Map<String, List<Map<String, Object>>> suspectList = new HashMap<>();

	// Profile Map
	private Map<String, Map<String, Object>> profileMap = new HashMap<String, Map<String, Object>>();
	private List<Map<String, Object>> profileList = new ArrayList<>();

	public Map<String, List<Map<String, Object>>> getSuspectList() {
		return suspectList;
	}

	public void setSuspectList(Map<String, List<Map<String, Object>>> suspectList) {
		this.suspectList = suspectList;
	}

	public Map<String, Map<String, Object>> getProfileMap() {
		return profileMap;
	}

	public void setProfileMap(Map<String, Map<String, Object>> profileMap) {
		this.profileMap = profileMap;
	}

	public List<Map<String, Object>> getProfileList() {
		return profileList;
	}

	public void setProfileList(List<Map<String, Object>> profileList) {
		this.profileList = profileList;
	}

	public Set<String> getContactSet() {
		return contactSet;
	}

	public void setContactSet(Set<String> contactSet) {
		this.contactSet = contactSet;
	}

	public Map<String, String> getSuspectScore() {
		return suspectScore;
	}

	public void setSuspectScore(Map<String, String> suspectScore) {
		this.suspectScore = suspectScore;
	}

	public Map<String, Set<String>> getLinkedContactSet() {
		return linkedContactSet;
	}

	public void setLinkedContactSet(Map<String, Set<String>> linkedContactSet) {
		this.linkedContactSet = linkedContactSet;
	}

	public List<String> getRequestContactList() {
		return requestContactList;
	}

	public void setRequestContactList(List<String> requestContactList) {
		this.requestContactList = requestContactList;
	}

}
