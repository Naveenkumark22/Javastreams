package ca.bell.sda.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ca.bell.sda.config.AppConfig;
import ca.bell.sda.config.AttributesConfig;
import ca.bell.sda.constant.log.LogKey;
import ca.bell.sda.constant.query.ElasticKey;
import ca.bell.sda.dao.HierarchyDAO;
import ca.bell.sda.model.Request;
import ca.bell.sda.model.config.DataAttributes;
import ca.bell.sda.model.elk.Attribute;
import ca.bell.sda.model.elk.response.ResponseData;
import ca.bell.sda.model.service.HierarchyData;
import ca.bell.sda.process.HierarchyDataProcessor;
import ca.bell.sda.process.OrgDataProcessor;
import ca.bell.sda.transformer.HierarchyDataTransformer;

@Service
public class FindCPMOrgService extends CPMService {

	@Autowired
	private AppConfig appConfig;

	@Autowired
	private HierarchyDAO hrchyDAO;

	@Autowired
	private OrgDataProcessor orgDataProcessor;

	@Autowired
	private HierarchyDataProcessor hrchyDP;

	@Autowired
	private HierarchyDataTransformer hrchyDT;

	@Autowired
	private AttributesConfig attributesConfig;

	private enum HierarchyType {
		PARENT, CHILD, IMMEDIATE, NO_HIERARCHY, LEVEL_BASED
	}

	private final String parentNodeKey = "relatedParty";
	private final String parentCheckKey = "relatedParty.id";
	private final String parentKey = "parent_gk";

	private final String childNodeKey = "organizationChildRelationship";
	private final String childCheckKey = "organizationChildRelationship.id";
	private final String childKey = "child_gk";
	private final String parentVirtualKey = "parentGKVirtualOrg";
	private final String childVirtualKey = "childGKVirtualOrg";
	private final String virtualKey = "virtualOrganization";

	public Object findOrg(Request request) {
		String serviceMethod = request.getQueryAttrbList().get(0).getProperties().getServiceMethod();
		switch (serviceMethod) {
		case "getHierarchy":
			return getHierarchy(request);
		case "getChildList":
			return getChildList(request);
		default:
			return null;
		}
	}

	private ResponseData getChildList(Request request) {
		Attribute attrb = request.getQueryAttrbList().get(0);
		String param = attrb.getId().replace("-", ".");
		ResponseData resData = null;
		if (param.equalsIgnoreCase(parentCheckKey)) {
			try {
			Object[] idValue = { attrb.getValue() };
			String[] indexes = appConfig.getIndexNames(request.getReqId());
			request.logTime(LogKey.ELK_START);
			Object elkData = hrchyDAO.getChildNodes(request, idValue, indexes[0]);
			request.logTime(LogKey.ELK_START);
			request.logTime(LogKey.DATA_CONV_START);
			resData = hrchyDT.childAsList(request, attrb.getValue(), elkData);
			addSuccessLog(request);
			} catch (Exception e) {
				e.printStackTrace();
				request.log(LogKey.REQ_LOG_EX_MSG, getClass().getName() + e.getMessage());
				addExceptionLog(request,e);
			}
			return resData;
		}
		return null;
	}

	private ResponseData getHierarchy(Request request) {
		HierarchyType hierarchyType = checkHierarchyType(request);
		Object[] idArrObj = { request.getQueryAttrbList().get(0).getValue() };
		ResponseData resData = new ResponseData();
		try
		{
		if (hierarchyType == HierarchyType.LEVEL_BASED) {
			processNLevelNodeData(request, resData, idArrObj);
		} else {
			processNodeData(request, resData, hierarchyType, idArrObj);
		}
		addSuccessLog(request);
		} catch (Exception e) {
			e.printStackTrace();
			request.log(LogKey.REQ_LOG_EX_MSG, getClass().getName() + e.getMessage());
			addExceptionLog(request,e);
		}
		return resData;
	}

	@SuppressWarnings("unchecked")
	private void processNLevelNodeData(Request request, ResponseData resData, Object[] idArrObj) {
		String[] indexes = appConfig.getIndexNames(request.getReqId());
		int currentLevel = 0, level = getRequestNodeLevel(request);
		HierarchyData hrchyData = new HierarchyData();
		hrchyData.setInitialKey(idArrObj[0].toString());
		hrchyData.getNextRoundKey().add(hrchyData.getInitialKey());
		hrchyData.setChildDataAttrbs(
				attributesConfig.getDataAttributes().get(request.getReqId()).get("organizationChildRelationship"));
		hrchyData.setParentDataAttrbs(attributesConfig.getDataAttributes().get(request.getReqId()).get("relatedParty"));
		do {
			Object elkData = hrchyDAO.getImediateHierarchy(request, hrchyData.getNextRoundKeyArr(), indexes[0]);
			if (elkData != null) {
				Map<String, Object> data = (Map<String, Object>) elkData;
				if (hrchyDP.getTotalValue(data) > 0) {
					hrchyDP.processLevelBasedNodes(request, hrchyData, data);
				} else {
					break;
				}
			} else {
				break;
			}
			currentLevel++;
		} while ((!hrchyData.getNextRoundKey().isEmpty() && level == 0)
				|| (!hrchyData.getNextRoundKey().isEmpty() && currentLevel < level));
		processHierarchyFlag(request, hrchyData.getNodes(), hrchyData.getNextRoundKey());
		resData.setProfiles(hrchyData.getProfileList());
	}

	private void processNodeData(Request request, ResponseData resData, HierarchyType hierarchyType,
			Object[] idArrObj) {
		Map<String, Object> profile = new HashMap<>();
		Map<String, Map<String, Object>> nodes = new HashMap<>();
		String indexesName = appConfig.getIndexNames(request.getReqId())[0];
		Object elkData = null;
		switch (hierarchyType) {
		case IMMEDIATE: // Immediate Level Hierarchy Nodes
			elkData = hrchyDAO.getImediateHierarchy(request, idArrObj, indexesName);
			hrchyDP.processImmediateNodes(request, profile, elkData, nodes);
			break;
		case PARENT: // Parent Nodes only
			elkData = hrchyDAO.getParentNodes(request, idArrObj, indexesName);
			Object parentObjs = hrchyDP.parentAsRelatedParty(request, elkData, nodes);
			if (parentObjs != null) {
				profile.put(parentNodeKey, parentObjs);
			}
			break;
		case CHILD: // Child Nodes only
			elkData = hrchyDAO.getChildNodes(request, idArrObj, indexesName);
			Object childObjs = hrchyDP.childAsChildRelationship(request, elkData, nodes);
			if (childObjs != null) {
				profile.put(childNodeKey, childObjs);
			}
			break;
		default:
			break;
		}
		if (profile.size() == 0) { // If requested node doesn't have any parent or child
			elkData = hrchyDAO.getImediateHierarchy(request, idArrObj, indexesName);
		}
		processName(request, elkData, profile);
		if (isReqConfigFlag(request, "hierarchyFlag", "yes")) {
			processHierarchyFlag(request, nodes, null);
		}
		if (!profile.isEmpty()) {
			List<Map<String, Object>> profileList = new ArrayList<>();
			profileList.add(profile);
			resData.setProfiles(profileList);
		}
	}

	@SuppressWarnings("unchecked")
	private void processHierarchyFlag(Request request, Map<String, Map<String, Object>> nodes,
			Set<String> edgeNodeKeys) {
		String[] indexes = appConfig.getIndexNames(request.getReqId());
		String[] srcFilter = { parentKey, childKey };
		Set<String> keySet = (edgeNodeKeys != null ? edgeNodeKeys : nodes.keySet());
		// Get immediate node list
		Map<String, Object> dataMap = hrchyDAO.getImediateHierarchy(request, keySet, indexes[0], srcFilter);
		int total = orgDataProcessor.getTotalValue(dataMap);
		if (total > 0) {
			List<Map<String, Object>> profileList = hrchyDP.getProfileMapList(dataMap);
			for (Map<String, Object> profileMap : profileList) {
				Map<String, Object> sourceMap = (Map<String, Object>) profileMap.get(ElasticKey.SOURCE);
				String parentValue = (String) sourceMap.get(parentKey);
				String childValue = (String) sourceMap.get(childKey);
				if (nodes.containsKey(parentValue)) {
					nodes.get(parentValue).put("hasChild", "true");
				}
				if (nodes.containsKey(childValue)) {
					nodes.get(childValue).put("hasParent", "true");
				}
			}
		}
	}

	@SuppressWarnings("unchecked")
	private void processName(Request request, Object elkData, Map<String, Object> profile) {
		Object idObj = request.getQueryAttrbList().get(0).getValue();
		String idStr = (String) idObj;
		Map<String, Object> dataMap = (Map<String, Object>) elkData;
		int total = orgDataProcessor.getTotalValue(dataMap);
		if (total > 0) {
			Map<String, Object> profMap = orgDataProcessor.getProfileMapList(dataMap).get(0);
			Map<String, Object> sourceMap = (Map<String, Object>) profMap.get(ElasticKey.SOURCE);
			DataAttributes dataAttrb = attributesConfig.getDataAttributes().get(request.getReqId()).get("gkName");
			Map<String, String> srcKeyParis = dataAttrb.getKeyPairs();
			Set<String> srcKeySet = srcKeyParis.keySet();
			Map<String, Object> defaultValues = dataAttrb.getDefaultValues();
			String gkName = null;
			String virtualOrg = null;
			for (String srcKey : srcKeySet) {
				String idValue = (String) sourceMap.get(srcKey);
				if (idValue != null && !idValue.equalsIgnoreCase(idStr)) {
					gkName = (String) sourceMap.get(srcKeyParis.get(srcKey));
					if(srcKey.equalsIgnoreCase("child_gk"))
					 virtualOrg = sourceMap.getOrDefault(parentVirtualKey, "false").toString().toLowerCase();
					else
					 virtualOrg = sourceMap.getOrDefault(childVirtualKey, "false").toString().toLowerCase();	
					break;
				}
			}
			profile.put("id", idStr);
			profile.put("name", gkName);
			profile.put(virtualKey, virtualOrg);
			profile.putAll(defaultValues);
		}
	}

	private int getRequestNodeLevel(Request request) {
		try {
			return Integer.valueOf(request.getReqConfigAttrb().get("level").getValue().toString());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return 1;
	}

	private HierarchyType checkHierarchyType(Request request) {
		Set<String> srcFiterSet = request.getSourceFilter();
		if (isReqConfigFlag(request, "level")) {
			return HierarchyType.LEVEL_BASED;
		} else if (srcFiterSet.contains(childCheckKey) && srcFiterSet.contains(parentCheckKey)) {
			return HierarchyType.IMMEDIATE;
		} else if (srcFiterSet.contains(parentCheckKey)) {
			return HierarchyType.PARENT;
		} else if (srcFiterSet.contains(childCheckKey)) {
			return HierarchyType.CHILD;
		} else {
			return HierarchyType.NO_HIERARCHY;
		}
	}

}
