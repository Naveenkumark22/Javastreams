package ca.bell.sda.controller;

import java.time.Instant;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import ca.bell.sda.constant.log.LogKey;
import ca.bell.sda.constant.status.StatusTypes;
import ca.bell.sda.model.Request;
import ca.bell.sda.model.Response;
import ca.bell.sda.process.RequestProcessor;
import ca.bell.sda.service.CrossSellService;

@RestController
public class CrossSellController extends SDAController{

	@Autowired
	private RequestProcessor processor;

	@Autowired
	private CrossSellService service;

	@RequestMapping(value = "/bbm/GetCrossSellDetail", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public Response findOrg(@RequestBody Map<String, Object> requestMap) throws Exception {
		
		Request request = new Request("bbm","GetCrossSellDetail");
		request.logTime(LogKey.REQ_START);
		request.log(LogKey.TIMESTAMP, Instant.now().toString());
		request.log(LogKey.REQ_GRP_ID, request.getReqId());
		request.log(LogKey.REQ_MAP, requestMap);
		
		Response response = new Response(StatusTypes.REQUEST_SUCCESS);
		request.log(LogKey.QUERY_BUILD_START, System.currentTimeMillis());
		if(requestMap!=null&&requestMap.get("sourceSystem")!=null)
			{
			String sourceSystem=requestMap.get("sourceSystem").toString();
			if(sourceSystem.equalsIgnoreCase("OV"))
				requestMap.put("sourceSystem","SV");
			}
		processor.processRequest(requestMap, request, response);
		if (response.getStatus().getCode() == StatusTypes.REQUEST_SUCCESS.getCode()) {
			service.getCrossSellDetail(request,response);
			request.log(LogKey.REQ_RESPONSE, response.getData());
		}
		checkRequestLog(request);
		return response;
	}

}
