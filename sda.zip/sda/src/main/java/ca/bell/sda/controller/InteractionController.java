package ca.bell.sda.controller;

import java.time.Instant;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import ca.bell.sda.constant.log.LogKey;
import ca.bell.sda.constant.status.StatusTypes;
import ca.bell.sda.model.Request;
import ca.bell.sda.model.Response;
import ca.bell.sda.model.tmf.TMFSearch;
import ca.bell.sda.process.RequestProcessor;
import ca.bell.sda.process.TMFRequestProcessor;
import ca.bell.sda.service.CPMInteractionService;
import jakarta.validation.Valid;

@RestController
public class InteractionController extends SDAController {

	@Autowired
	private RequestProcessor processor;

	@Autowired
	private TMFRequestProcessor tmfProcessor;

	@Autowired
	private CPMInteractionService service;

	
	@RequestMapping(value = "/bbm/SearchInteraction", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public Response searchInteraction(@Valid @RequestBody TMFSearch tmfSearch) throws Exception {
		Request request = new Request("bbm", "SearchInteraction");
		request.logTime(LogKey.REQ_START);
		request.log(LogKey.TIMESTAMP, Instant.now().toString());
		request.log(LogKey.REQ_GRP_ID, request.getReqId());
		request.log(LogKey.REQ_MAP, tmfSearch);
		Response response = new Response(StatusTypes.REQUEST_SUCCESS);
		request.logTime(LogKey.QUERY_BUILD_START);
		tmfProcessor.processSearcRequest(tmfSearch, request, response);
		response.setData(service.searchInteraction(request, tmfSearch));
		request.log(LogKey.REQ_RESPONSE, response.getData());
		checkRequestLog(request);
		return response;
	}
	
	@RequestMapping(value = "/bbm/GetInteraction", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public Response getInteraction(@Valid @RequestBody TMFSearch tmfSearch) throws Exception {
		Request request = new Request("bbm", "GetInteraction");
		request.logTime(LogKey.REQ_START);
		request.log(LogKey.TIMESTAMP, Instant.now().toString());
		request.log(LogKey.REQ_GRP_ID, request.getReqId());
		request.log(LogKey.REQ_MAP, tmfSearch);
		Response response = new Response(StatusTypes.REQUEST_SUCCESS);
		request.logTime(LogKey.QUERY_BUILD_START);
		tmfProcessor.processSearcRequest(tmfSearch, request, response);
		response.setData(service.getInteraction(request, tmfSearch));
		request.log(LogKey.REQ_RESPONSE, response.getData());
		checkRequestLog(request);
		return response;
	}
		
	public Response getInteractionForCustomerTimeline(Request request,@RequestBody Map<String, Object> requestMap) throws Exception {
			request.logTime(LogKey.REQ_START);		
			request.log(LogKey.TIMESTAMP, Instant.now().toString());
			request.log(LogKey.REQ_GRP_ID, request.getReqId());		
			Response response = new Response(StatusTypes.REQUEST_SUCCESS);
			request.log(LogKey.QUERY_BUILD_START, System.currentTimeMillis());
			processor.processRequest(requestMap, request, response);	
			response.setData(service.getInteractionForCustomerTimeline(request,response,requestMap));
			//checkRequestLog(request);
			return response;
	}

}
