package ca.bell.sda.transformer;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import ca.bell.sda.config.AttributesConfig;
import ca.bell.sda.model.Request;
import ca.bell.sda.service.SourceSystemService;

@Component
public class IndividualDataTransformer {

	@Autowired
	private AttributesConfig attributesConfig;

	private final String idKey = "id";
	private final String externalIdKey = "externalId";
	private final String rltdPartyKey = "relatedParty";
	private final String relatedIdKey = "relatedId";
	private final String relatedRoleKey = "role";
	private final String relatedRoleValue = "Organization";
	private final String srcSystemKey = "sourceSystem";
	private final String contactMediumKey = "contactMedium";
	private final String contactKey = "contact";
	private final String mediumTypeKey = "mediumType";
	private final String statusKey = "status";
	private final String statusValue = "initialized";
	private final String externalRefKey = "bellExternalReference";
	private final String srcSystemIdKey = "sourceSystemId";
	private final String privacyPreferenceKey = "privacyPreference";
	private final String preferenceTypeKey = "preferenceType";
	private final String categoryKey = "category";
	private final String preferenceKey = "preference";
	private final String isOptedInKey = "isOptedIn";
	private final String enabledNotificationKey = "enabledNotification";
	private final String interestedKey = "Interested";
	private final String emailEnabledKey = "emailEnabled";
	private final String smsEnabledKey = "smsEnabled";
	private final String cpmSrcSystem = "cpm";
	
	@Autowired
	private SourceSystemService service;


	public void tranformData(Request request, Map<String, Object> profile) {
		if (profile != null) {
//			transformId(request, profile);
//			addExternalId(profile);
			transformRltdParty(request, profile);
			transformExtrnlSrcSystem(request, profile);
			addStatus(profile);
			transformPrivacyPref(profile);
		}
	}
	
	
	
	

	@SuppressWarnings("unchecked")
	private void transformPrivacyPref(Map<String, Object> profile) {
		if (profile.containsKey(privacyPreferenceKey)) {
			List<Map<String, Object>> privacyPrefList = (List<Map<String, Object>>) profile.get(privacyPreferenceKey);
			List<Map<String, Object>> newPrivacyPrefList = new ArrayList<>();
			Map<String, Map<String, Object>> privacyPrefMap = new HashMap<>();
			Map<String, Map<String, Object>> contactMap = getContactMap(profile);
			privacyPrefList.forEach(privacyPref -> {
				try {
					String prefType = privacyPref.get(preferenceTypeKey).toString();
					Map<String, Object> newPrivacyPref = privacyPrefMap.getOrDefault(prefType, null);
					if (newPrivacyPref == null) {
						newPrivacyPref = getNewPrivacyPrefMap(prefType);
						privacyPrefMap.put(prefType, newPrivacyPref);
						newPrivacyPrefList.add(newPrivacyPref);
					}
					updatePreference(contactMap, privacyPref, newPrivacyPref);
				} catch (Exception e) {
					e.printStackTrace();
				}
			});
			profile.put(privacyPreferenceKey, newPrivacyPrefList);
		}
	}

	private void updatePreference(Map<String, Map<String, Object>> contactMap, Map<String, Object> privacyPref,
			Map<String, Object> newPrivacyPref) {
		String contact = privacyPref.get(contactKey).toString();
		String mediumType = contactMap.get(contact).get(mediumTypeKey).toString();
		newPrivacyPref.put(isOptedInKey, privacyPref.get(preferenceKey).toString().equalsIgnoreCase("opt-in"));
		if (mediumType.equalsIgnoreCase("Email Address")) {// Email
			newPrivacyPref.put(emailEnabledKey,
					privacyPref.get(enabledNotificationKey).toString().equalsIgnoreCase(interestedKey));
		} else if (mediumType.equalsIgnoreCase("Telephone Number")) {// Mobile
			newPrivacyPref.put(smsEnabledKey,
					privacyPref.get(enabledNotificationKey).toString().equalsIgnoreCase(interestedKey));
		}
	}

	@SuppressWarnings("unchecked")
	private Map<String, Map<String, Object>> getContactMap(Map<String, Object> profile) {
		Map<String, Map<String, Object>> contactMap = new HashMap<>();
		try {
			if (profile.containsKey(contactMediumKey)) {
				List<Map<String, Object>> contactMediumList = (List<Map<String, Object>>) profile.get(contactMediumKey);
				contactMediumList.forEach(contactMedium -> {
					contactMap.put(contactMedium.get("contact").toString(), contactMedium);
				});
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return contactMap;
	}

	private Map<String, Object> getNewPrivacyPrefMap(String prefType) {
		Map<String, Object> newPrivacyPref = new HashMap<>();
		newPrivacyPref.put(categoryKey, prefType);
		newPrivacyPref.put(smsEnabledKey, false);
		newPrivacyPref.put(emailEnabledKey, false);
		newPrivacyPref.put(isOptedInKey, false);
		return newPrivacyPref;
	}

//	private void transformId(Request request, Map<String, Object> profile) {
//		String idValue = getRequestValue(request);
//		if (idValue != null) {
//			profile.put(idKey, profile.get(srcSystemKey).toString().toLowerCase() + "_" + idValue);
////			addExternalId(profile, idValue);
//		}
//	}

//	private void addExternalId(Map<String, Object> profile) {
//		profile.put(externalIdKey, profile.get("id"));
//	}

	@SuppressWarnings("unchecked")
	private void transformRltdParty(Request request, Map<String, Object> profile) {
		if (profile.containsKey(rltdPartyKey)) {
			Object rpObj = profile.get(rltdPartyKey);
			//Map<String, String> srcSysMap = attributesConfig.getDataAttributes().get(request.getReqId())
				//	.get("srcSystem").getKeyPairs();
			Map<String, String> srcSysMap=service.getSourceSystem();
			List<Map<String, String>> rltdPartyList = (List<Map<String, String>>) rpObj;
			List<Map<String, String>> newRltdPartyList = new ArrayList<>();
			Map<String, String> rp;
			for (Map<String, String> rltdParty : rltdPartyList) {
				rp = rltdParty;
				if (rltdParty.containsKey(relatedIdKey) && rltdParty.containsKey(srcSystemKey)) {
					String relatedId = rltdParty.get(relatedIdKey);
					String srcSystem = rltdParty.get(srcSystemKey).toLowerCase();
					if (!srcSystem.equalsIgnoreCase("cpm")) {
						if (srcSysMap.containsKey(srcSystem)) {
							relatedId = srcSysMap.get(srcSystem) + "_" + relatedId;
						}
						rp.put(relatedIdKey, relatedId);
					}
				}
				//rp.put(relatedRoleKey, relatedRoleValue);
				newRltdPartyList.add(rp);
			}
			profile.put(rltdPartyKey, newRltdPartyList);
		}
	}

	@SuppressWarnings({ "unchecked" })
	private void transformExtrnlSrcSystem(Request request, Map<String, Object> profile) {
		if (profile.containsKey(externalRefKey)) {
			Object refObjs = profile.get(externalRefKey);
			//Map<String, String> srcSysMap = attributesConfig.getDataAttributes().get(request.getReqId())
				//	.get("srcSystem").getKeyPairs();
			Map<String, String> srcSysMap=service.getSourceSystem();
			List<Map<String, String>> externalRefList = (List<Map<String, String>>) refObjs;
			List<Map<String, String>> newExternalRefList = new ArrayList<>();
			Map<String, String> extRef;
			for (Map<String, String> extRefMap : externalRefList) {
				extRef = extRefMap;
				if (extRef.containsKey(srcSystemIdKey)) {
					extRef.put(srcSystemIdKey, srcSysMap.get(extRef.get(srcSystemIdKey).toLowerCase()));
				}
				newExternalRefList.add(extRef);
			}
			profile.put(externalRefKey, newExternalRefList);
		}
	}

	private void addStatus(Map<String, Object> profile) {
		profile.put(statusKey, statusValue);
	}
}
