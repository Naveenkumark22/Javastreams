package ca.bell.sda.constant.status;

import ca.bell.sda.model.Status;

public class StatusTypes {

	public static final Status REQUEST_SUCCESS = new Status(200, "Request Success");
	public static final Status MOVED_PERMANENTLY = new Status(301,"Moved Permanently");
	public static final Status UNAUTHORIZED_REQUEST = new Status(401, "Unauthoried Request");
	public static final Status REQUEST_NOT_FOUND = new Status(404, "Request Not Found");
	public static final Status BAD_REQUEST = new Status(400, "Bad Request");
	public static final Status INTERNAL_ERROR = new Status(500, "Internal Error");

	public static final Status NO_DATA_FOUND = new Status(2000, "No Match Found");
	
	public static Status INVALID_LENGTH = new Status(2001, "Invalid character length in input field: ");

	public static final Status INVALID_LOCATION = new Status(2002, "Null/Multiple address not accepted: ");

	public static final Status INVALID_FILTER = new Status(2003,
			"Invalid Filter List - Filter should be either Complete or required fields");
	public static final Status DENIED_FILTER = new Status(2004,
			"Invalid Filter List - Requested attribute in filter is denied");

	public static final Status INVALID_REQUEST = new Status(2005, "Invalid Request - Atleast One field required");

	public static final Status NULL_VALUE_ATTRIBUTE = new Status(2006,
			"Invalid Request - NULL value is not accepted in attribute");

	public static final Status INVALID_ATTRIBUTE_NAME = new Status(2007, "Invalid attribute: ");

	public static final Status INVALID_VALUE = new Status(2008, "Invalid value in field: ");

	public static final Status NEGATIVE_VALUE = new Status(2009, "Negative/Zero value in field: ");

	public static final Status INVALID_SIZE_LIMIT = new Status(2010, "Invalid limit in field: ");

	public static final Status INVALID_OFFSET_VALUE = new Status(2011, "Invalid Offset value in field: ");

	public static final Status INVALID_OFFSET_LIMIT = new Status(2012, "Size & From value exceed 10000");

	public static final Status MULTIPLE_FIELDS_NOT_ACCEPTED = new Status(2013,
			"Invalid Request - Multiple Filed in request is not accepted");

	// Shipment Tracking Error Codes
	public static final Status ST_NO_MATCH_FOUND = new Status(555, "No Match Found or No Match Found For the Brand");

	public static final Status BRAND_UNKNOWN = new Status(555, "No Match Found or No Match Found For the ");

	public static Status getElkErrorStatus(String errorType) {
		try {
			return (Status) StatusTypes.class.getField(errorType).get(null);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return INTERNAL_ERROR;
	}

	public static Status appendErrorMessage(Status status, String msg) {
		Status msgStatus = new Status();
		msgStatus.setCode(status.getCode());
		msgStatus.setDesc(status.getDesc() + msg);

		return msgStatus;
	}

}
