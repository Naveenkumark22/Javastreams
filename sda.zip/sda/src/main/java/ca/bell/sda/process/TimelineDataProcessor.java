package ca.bell.sda.process;

import java.util.List;

import org.springframework.stereotype.Component;

import ca.bell.sda.model.CustomerTimeline;
import ca.bell.sda.model.Request;

@Component
public interface TimelineDataProcessor {
	
	public <T> List<CustomerTimeline> processData(Request request, T data);

}
