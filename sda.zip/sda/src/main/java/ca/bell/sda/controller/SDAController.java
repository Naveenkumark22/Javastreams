package ca.bell.sda.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import ca.bell.sda.constant.log.LogKey;
import ca.bell.sda.constant.status.StatusTypes;
import ca.bell.sda.dao.LogDAO;
import ca.bell.sda.model.Request;
import ca.bell.sda.model.Response;

@Component
public class SDAController {

	@Autowired
	LogDAO logDAO;

	private static String ENV_LOCATION;

	static {
		Map<String, String> envVars = System.getenv();
		ENV_LOCATION = envVars.get("SERVER_LOCATION");
	}

	@ResponseStatus(value = HttpStatus.BAD_REQUEST)
	@ExceptionHandler(HttpMessageNotReadableException.class)
	public @ResponseBody Response invalidJSONRequestHandler(Exception ex) {
		Response res = new Response();
		res.setStatus(StatusTypes.BAD_REQUEST);
		res.getStatus().setDesc("Invalid JSON request");
		return res;
	}
	
	
	@ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR)
	@ExceptionHandler(Exception.class)
	public @ResponseBody Response exceptionHandler(Exception ex) {
		Response res = new Response();
		res.setStatus(StatusTypes.INTERNAL_ERROR);
		ex.printStackTrace();
		return res;
	}

	public void checkRequestLog(Request request) throws Exception {
		request.getLog().put("SERVER_LOCATION", ENV_LOCATION);
		request.logTime(LogKey.REQ_END);
		Object exObj = request.getLog().get(LogKey.REQ_LOG_EX);
		new Thread(() -> {
			logDAO.pushLog(request.getLog());
		}).start();
		if (exObj != null) {
			throw (Exception) exObj;
		}
	}

	public void checkRequestLog(Request request, String env) throws Exception {
		request.getLog().put("SERVER_LOCATION", ENV_LOCATION);
		request.logTime(LogKey.REQ_END);
		Object exObj = request.getLog().get(LogKey.REQ_LOG_EX);
		new Thread(() -> {
			logDAO.pushLog(request.getLog(), env);
		}).start();
		if (exObj != null) {
			throw (Exception) exObj;
		}
	}

}
