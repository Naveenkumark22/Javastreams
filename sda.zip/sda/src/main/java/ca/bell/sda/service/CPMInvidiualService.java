package ca.bell.sda.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import ca.bell.sda.util.Utility;
import jdk.jshell.execution.Util;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ca.bell.sda.config.AppConfig;
import ca.bell.sda.config.AttributesConfig;
import ca.bell.sda.config.ElasticQueryConfig;
import ca.bell.sda.constant.log.LogKey;
import ca.bell.sda.constant.webclient.StreamSource;
import ca.bell.sda.dao.SearchDAO;
import ca.bell.sda.elk.QueryBuilder;
import ca.bell.sda.elk.TMFQueryBuilder;
import ca.bell.sda.model.Request;
import ca.bell.sda.model.elk.Attribute;
import ca.bell.sda.model.elk.SearchQuery;
import ca.bell.sda.model.elk.response.ResponseData;
import ca.bell.sda.model.tmf.TMFSearch;
import ca.bell.sda.process.IndividualDataProcessor;
import ca.bell.sda.transformer.IndividualDataTransformer;
import ca.bell.sda.process.AccountDataProcessor;

@Service
public class CPMInvidiualService extends CPMService {

	@Autowired
	private AppConfig appConfig;

	@Autowired
	private SearchDAO searchDAO;

	@Autowired
	private IndividualDataProcessor dataProcessor;
	@Autowired
	private AccountDataProcessor accountDataProcessor;

	@Autowired
	private IndividualDataTransformer individualDT;

	@Autowired
	private QueryBuilder queryBuilder;

	@Autowired
	private AttributesConfig attributesConfig;
	
	@Autowired
	private TMFQueryBuilder tmfQueryBuilder;

	@Autowired
	private ElasticQueryConfig elasticQueryConfig;

	private static final String PRIVACY_PREFERENCE_FLAG_KEY = "privacyPreferenceFlag";
	private static final String PRIVACY_PREFERENCE_KEY = "privacyPreference";
	private static final String SOURCE_SYSTEM_KEY = "sourceSystem";
	private static final String CONTACT_INDIVIDUAL_TYPE_KEY = "contactIndividualType";
	private static final String MASTER_CONTACT_KEY = "MasterContact";
	private static final String IS_W2U_SOURCE = "isW2USource";
	private static final String EMAIL_KEY = "email";
	private static final String CUSTOMER_ID_KEY = "customerId";
	private static final String BELL_MAIL_IDS = "@bell.ca";

	public Object getIndividual(Request request) {
		ResponseData resData = null;
		try {
			resData = getResponseData(request);
			if (resData != null) {
				//CPMMDM-460 GetIndividual - TMF 632 Party Management Individual - Needs to be added with all GK level LP Attribtutes
					if (resData.getProfiles() != null && !resData.getProfiles().isEmpty()) {
						if (request.getRequestMap().containsKey("customerSource")&&((String)request.getRequestMap().get("customerSource")).equalsIgnoreCase("cce")) {
						//Fetching the contacts GK
							String gkId = getContactGk(resData);
							if (gkId != null) {
								//Fetching the Lp and adding in the response
								processGKLP(resData, gkId,request);
							}
						}
						Map<String, Object> profile = resData.getProfiles().get(0);
						resData.setProfile(profile);
						if (isReqConfigFlag(request, "suspectFlag", "yes")) {
							Map<String, Map<String, Object>> individualProfileMap = new HashMap<>();
							profile.put("hasSuspect", "no");
							individualProfileMap.put(profile.get("externalId").toString(), profile);
							processSuspectFlag(request, individualProfileMap);
						}
						resData.setProfiles(null);
					}
				individualDT.tranformData(request, resData.getProfile());
				request.logTime(LogKey.DATA_CONV_END);
			}
			addSuccessLog(request);
		} catch (Exception e) {
			e.printStackTrace();
			request.log(LogKey.REQ_LOG_EX_MSG, getClass().getName() + e.getMessage());
			addExceptionLog(request,e);
		}

		return resData;
	}

	private void processGKLP(ResponseData resData,  String gkId,Request request ) {
		String indexName = appConfig.getIndexNames(request.getReqId())[2];
		List<Attribute> attrbQueryList = new ArrayList<>();
		attrbQueryList.add(getAttrb(request, "id", gkId));
		attrbQueryList.add(getAttrb(request, "sourceSystem", "cpm"));
		SearchQuery searchQuery = getSearchQuery(request);
		searchQuery.setSourceFilter(appConfig.getAttributesConfig().getDataAttributes().get(request.getReqId())
				.get("lpAttribute").getKeys());
		searchQuery.setMinScore(null);
		searchQuery.setQuery(queryBuilder.createSearchQuery(attrbQueryList));
		Object elkData = searchDAO.querySource(request.getReqId(), StreamSource.INDEX, searchQuery, indexName,
				request.getQueryConfig().getFilterPath());
		ResponseData resData1 = dataProcessor.processData(request, elkData);
		List<Map<String,Object>> profiles=resData1.getProfiles();
		if(profiles != null && !profiles.isEmpty()) {
			Map<String, Object> profile = profiles.get(0);
			if(!profile.isEmpty()) {
				List<Map<String, Object>> languagePreference = (List<Map<String, Object>>) profile.get("languagePreference");
				if (!languagePreference.isEmpty()) {
					resData.getProfiles().get(0).put("languagePreference", languagePreference);
				}
			}
		}
	}

	public Object findIndividual(Request request) throws Exception {
		ResponseData resData = null;
		try {
			resData = getResponseData(request);
		if (resData != null) {
			if (resData.getProfiles() != null && !resData.getProfiles().isEmpty()) {
				Map<String, Map<String, Object>> individualProfileMap = new HashMap<>();
				for (Map<String, Object> profile : resData.getProfiles()) {
					individualDT.tranformData(request, profile);
					if (isReqConfigFlag(request, "suspectFlag", "yes") && profile.get("externalId") != null) {
						profile.put("hasSuspect", "no");
						individualProfileMap.put(profile.get("externalId").toString(), profile);
					}
				}
				if (isReqConfigFlag(request, "suspectFlag", "yes") && individualProfileMap.size() > 0) {
					processSuspectFlag(request, individualProfileMap);
				}
			}
			else if(request.getRequestMap().containsKey(CUSTOMER_ID_KEY)&& resData.getProfiles() == null){
				long gkId= processAccountData( request);
				if (gkId!=0) {
					resData = processGk(request, gkId);
				}
			}
			request.logTime(LogKey.DATA_CONV_END);
		}
		addSuccessLog(request);
		} catch (Exception e) {
			e.printStackTrace();
			request.log(LogKey.REQ_LOG_EX_MSG, getClass().getName() + e.getMessage());
			addExceptionLog(request,e);
		}
		return resData;
	}





	private Object getElkdata(Request request,int indexPosition ,Map<String,Object> attrMap,String sourceFilter,String size)
	{
		String indexName = appConfig.getIndexNames(request.getReqId())[indexPosition];
		List<Attribute> attrbQueryList = new ArrayList<>();
		for (Map.Entry<String,Object>  entry : attrMap.entrySet()) {
			attrbQueryList.add(getAttrb(request, entry.getKey(), entry.getValue()));
		}
		SearchQuery searchQuery = getSearchQuery(request);
		searchQuery.setMinScore(null);
		if(size!=null)
		{
			searchQuery.setSize(size);
		}
		searchQuery.setQuery(queryBuilder.createSearchQuery(attrbQueryList));
		if(sourceFilter!=null) {
			searchQuery.setSourceFilter(appConfig.getAttributesConfig().getDataAttributes().get(request.getReqId())
					.get(sourceFilter).getKeys());
		}
		Object elkData = searchDAO.querySource(request.getReqId(), StreamSource.INDEX, searchQuery, indexName,
				request.getQueryConfig().getFilterPath());
		return elkData;
	}

	private long processAccountData(Request request) throws Exception {
		String indexName = appConfig.getIndexNames(request.getReqId())[2];
		List<Attribute> attrbQueryList = new ArrayList<>();
		attrbQueryList.add(getAttrb(request, "id", request.getRequestMap().get(CUSTOMER_ID_KEY)));
		attrbQueryList.add(getAttrb(request, "accountType", "customer"));
		attrbQueryList.add(getAttrb(request, "sourceSystem", "eom"));
		SearchQuery searchQuery = getSearchQuery(request);
		searchQuery.setMinScore(null);
		searchQuery.setQuery(queryBuilder.createSearchQuery(attrbQueryList));
		searchQuery.setSourceFilter(appConfig.getAttributesConfig().getDataAttributes().get(request.getReqId())
				.get("accountDetail").getKeys());
		Object elkData = searchDAO.querySource(request.getReqId(), StreamSource.INDEX, searchQuery, indexName,
				request.getQueryConfig().getFilterPath());
		ResponseData accountData = accountDataProcessor.processData(request, elkData);
		if(accountData.getProfiles()!=null&&!accountData.getProfiles().isEmpty()) {
			List<Map<String, Object>> accountProfiles = accountData.getProfiles();
			Map<String, Object> accountProfile = accountProfiles.get(0);
			return Long.parseLong(accountProfile.get("goldenKey")!=null?
						accountProfile.get("goldenKey").toString():"0");
			
		}

		return 0;
	}
	private ResponseData processGk(Request request, long gkId) throws Exception {
		String indexName = appConfig.getIndexNames(request.getReqId())[0];
		List<Attribute> attrbQueryList = new ArrayList<>();
		attrbQueryList.add(getAttrb(request, "gkId", gkId));
		attrbQueryList.add(getAttrb(request, EMAIL_KEY, new String[] {BELL_MAIL_IDS}));
		SearchQuery searchQuery = getSearchQuery(request);
		searchQuery.setMinScore(null);
		searchQuery.setQuery(queryBuilder.createSearchQuery(attrbQueryList));
		Object elkData = searchDAO.querySource(request.getReqId(), StreamSource.INDEX, searchQuery, indexName,
				request.getQueryConfig().getFilterPath());
		return dataProcessor.processData(request, elkData);
	}
	private void processSuspectFlag(Request request, Map<String, Map<String, Object>> individualProfileMap) {
		Object suspectData = getSuspectData(request, individualProfileMap);
		dataProcessor.processSuspectData(individualProfileMap, suspectData);
	}

	private ResponseData getResponseData(Request request) {
		String[] indexes=appConfig.getIndexNames(request.getReqId());
 		SearchQuery searchQuery = getSearchQuery(request);
		searchQuery.setMinScore(null);
		request.logTime(LogKey.QUERY_BUILD_END);
		ResponseData resData = null;
		try {
			if (isReqConfigFlag(request, PRIVACY_PREFERENCE_FLAG_KEY, "yes")
					|| isReqConfigFlag(request, PRIVACY_PREFERENCE_KEY)) {
				searchQuery.getSourceFilter().addAll(appConfig.getAttributesConfig().getDataAttributes()
						.get(request.getReqId()).get(PRIVACY_PREFERENCE_KEY).getKeys());
			}
			if (isReqConfigFlag(request, SOURCE_SYSTEM_KEY,"cpm")) {
				List<Attribute> attrbQueryList = request.getQueryAttrbList();
				attrbQueryList.add(getAttrb(request, CONTACT_INDIVIDUAL_TYPE_KEY, MASTER_CONTACT_KEY));
				searchQuery.setQuery(queryBuilder.createSearchQuery(attrbQueryList, request.getFilterAttrbList()));
			}
			if(isReqConfigFlag(request, CUSTOMER_ID_KEY))
			{
				List<Attribute> attrbQueryList = request.getQueryAttrbList();
				attrbQueryList.add(getAttrb(request, EMAIL_KEY, new String[] {BELL_MAIL_IDS}));
				searchQuery.setQuery(queryBuilder.createSearchQuery(attrbQueryList, request.getFilterAttrbList()));
			}
			request.log(LogKey.QUERY, searchQuery);
			request.logTime(LogKey.ELK_START);
			Utility.consoleObject(searchQuery);
			Object elkData = searchDAO.querySource(request.getReqId(), StreamSource.INDEX, searchQuery, indexes[0],
					request.getQueryConfig().getFilterPath());
			request.logTime(LogKey.ELK_END);
			request.logTime(LogKey.DATA_CONV_START);
			resData = dataProcessor.processData(request, elkData);
		} catch (Exception e) {
			request.log(LogKey.REQ_LOG_EX_MSG, getClass().getName() + e.getMessage());
			request.log(LogKey.REQ_LOG_EX, e);
		}
		return resData;
	}

	public String getContactGk(ResponseData resData) {

		Map<String,Object> profile=resData.getProfiles().get(0);
		String gkid=null;
		if (profile!=null && profile.containsKey("relatedParty"))
		{
			List<Map<String, Object>> relatedpartylist = (List<Map<String, Object>>) profile.get("relatedParty");
			for (Map<String,Object> relatedparty:relatedpartylist)
			{
				if(relatedparty.containsKey("description") && relatedparty.get("description").equals("GK"))
				{
					gkid= (String) relatedparty.get("relatedId");
					break;
				}
			}
		}
		return gkid;
	}


	private Object getSuspectData(Request request, Map<String, Map<String, Object>> individualProfileMap) {
		List<String> profileKeyList = new ArrayList<>(individualProfileMap.keySet());
		List<Attribute> attrbQueryList = new ArrayList<>();
		attrbQueryList.add(getAttrb(request, "contactGK", profileKeyList));
		SearchQuery searchQuery = getSearchQuery(request);
		searchQuery.setMinScore(null);
		searchQuery.setSize("10000");
		searchQuery.setQuery(queryBuilder.createSearchQuery(attrbQueryList));
		searchQuery.setSourceFilter(
				attributesConfig.getDataAttributes().get(request.getReqId()).get("suspectDetail").getKeys());
		String indexName = appConfig.getIndexNames(request.getReqId())[1];
		try {
			return searchDAO.querySource(request.getReqId(), StreamSource.INDEX, searchQuery, indexName,
					request.getQueryConfig().getFilterPath());
		} catch (Exception e) {
			request.log(LogKey.REQ_LOG_EX_MSG, getClass().getName() + e.getMessage());
			request.log(LogKey.REQ_LOG_EX, e);
		}
		return null;
	}
	
	public Object searchIndividual(Request request, TMFSearch tmfSearch) {
		if(isReqConfigFlag(request,"GetMCFlag"))
			modifyFilter(request,tmfSearch,"id","relatedPartyAccount.id");
		
		addFilter(tmfSearch,"AND",CONTACT_INDIVIDUAL_TYPE_KEY,"eq",new String[] {MASTER_CONTACT_KEY});
		SearchQuery searchQuery = tmfQueryBuilder.createSearchQuery(tmfSearch);
		String indexName = appConfig.getIndexNames(request.getReqId())[0];
		request.logTime(LogKey.QUERY_BUILD_END);
		request.log(LogKey.QUERY, searchQuery);
		ResponseData resData = null;
		try {
			request.logTime(LogKey.ELK_START);
			Object elkData = searchDAO.querySource(request.getReqId(), StreamSource.INDEX, searchQuery, indexName,
					elasticQueryConfig.getFilterPath());
			request.logTime(LogKey.ELK_END);
			request.logTime(LogKey.DATA_CONV_START);
			resData = dataProcessor.processData(request, elkData);
			request.logTime(LogKey.DATA_CONV_END);
			addSuccessLog(request);
		} catch (Exception e) {
			request.log(LogKey.REQ_LOG_EX_MSG, getClass().getName() + e.getMessage());
			addExceptionLog(request,e);
			e.printStackTrace();
		}
		if(resData!=null&&isReqConfigFlag(request,"GetMCFlag"))
		{
			resData.setProfile(resData.getProfiles()!=null?resData.getProfiles().get(0):null);
			resData.setProfiles(null);
		}
		return resData;
	}
	

}
