/**
 * 
 */
package ca.bell.sda.service.whitespace;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ca.bell.sda.constant.log.LogKey;
import ca.bell.sda.model.Request;
import ca.bell.sda.model.Response;
import ca.bell.sda.model.whitespace.RequestInputDetail;
import ca.bell.sda.model.whitespace.StdOrgRecord;
import ca.bell.sda.model.whitespace.mdm.MDMOutput;
import ca.bell.sda.model.whitespace.ml.InputList;
import ca.bell.sda.model.whitespace.ml.MLInputRoot;
import ca.bell.sda.service.CPMService;
import ca.bell.sda.util.JSONCreator;
import ca.bell.sda.util.JSONParser;

/**
 * @author Kamalanathan Ranganathan
 *
 */
@Service
public class MLPredictionService extends CPMService {

	@Autowired
	private JSONParser jsonParser;

	@Autowired
	private StandardizationService standardizationService;

	@Autowired
	private ELKMultipleNameBucketService elkNameBucketService;

	@Autowired
	private FrequencyCalculationService frequencyCalculationService;

	@Autowired
	private MLDeDuplicationService mlDeDuplicationService;

	@Autowired
	private JSONCreator jsonCreator;

	public void findProspect(Request request, Response response)  {
		try {
		// Parsing the data from JSON
		RequestInputDetail requestInputDetail = jsonParser.parseInput(request, request.getRequestMap());

	     // Standardization for name and address
		StdOrgRecord stdOrgRecord = null;
		boolean stdIndicator = true;
		if("yes".equalsIgnoreCase(requestInputDetail.getStdFlag()))
		{
			stdOrgRecord=standardizationService.standardize(request,requestInputDetail);		
			stdIndicator=false;
		}else if("no".equalsIgnoreCase(requestInputDetail.getStdFlag()))
		{
			stdOrgRecord=standardizationService.getStandardizedDataFromElk(request,requestInputDetail);				
		}
		else {
			 stdOrgRecord = standardizationService.standardize(request, requestInputDetail);			 
		}
				
		if (stdOrgRecord == null)
			throw new Exception("Standaridization : Standaridization Error");
		
		MLInputRoot op = null;

		if(stdIndicator) {
		// ELK Bucketing
		   MLInputRoot records = elkNameBucketService.doELKNameBucketing(request, stdOrgRecord);

		if (records != null) {

			// Calculating Token Frequency
			MLInputRoot freqCalulatedRecords = frequencyCalculationService.calucalteTokenFrequencyScore(request,
					records);

			//request.log(LogKey.ML_INPUT, freqCalulatedRecords);			
			
			// Input to ML
			op = mlDeDuplicationService.doDeDuplication(request, freqCalulatedRecords);
			
			
			if (op != null) {

				//request.log(LogKey.ML_OUTPUT, op);

				createResposnse(request, response, stdOrgRecord, op);

			} else
				throw new Exception("M L (python) : Invalid response from ML");

		} else {

			createResposnse(request, response, stdOrgRecord, op);
			}
		}
		else {
			createResposnse(request, response, stdOrgRecord, op);
		}
			addSuccessLog(request);
		}catch(Exception e)
		{
			e.printStackTrace();
			request.log(LogKey.REQ_LOG_EX_MSG, getClass().getName() + e.getMessage());
			addExceptionLog(request, e);			
		}
	}

	public void standardize(Request request, Response response) throws Exception {
		// Parsing the data from JSON
		RequestInputDetail requestInputDetail = jsonParser.parseInput(request, request.getRequestMap());

		// Standardization the given orgname and address
		StdOrgRecord stdOrgRecord = standardizationService.standardize(request, requestInputDetail);

		if (stdOrgRecord == null)
			throw new Exception("Standaridization : Standaridization Error");

		stdOrgRecord.setGkId(requestInputDetail.getAdminPartyId());

		MLInputRoot op = new MLInputRoot();

		op.setInput_list(new ArrayList<InputList>());

		createResposnse(request, response, stdOrgRecord, op);

	}

	private Response createResposnse(Request request, Response response, StdOrgRecord stdOrgRecord, MLInputRoot op)
			throws Exception {

		MDMOutput responseops = jsonCreator.getOutput(request, stdOrgRecord, op);

		response.setData(responseops);

		return response;

	}
}
