package ca.bell.sda.process;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import ca.bell.sda.config.AttributesConfig;
import ca.bell.sda.model.Request;
import ca.bell.sda.model.elk.response.ResponseData;

@Component
public class InteractionDataProcessor extends ElasticDataProcessor implements DataProcessor {

	@Autowired
	private AttributesConfig attributesConfig;
	
	@SuppressWarnings("unchecked")
	@Override
	public <T> ResponseData processData(Request request, T data) {

		ResponseData resData = new ResponseData();
		Map<String, Object> dataMap = (Map<String, Object>) data;
		int total = getTotalValue(dataMap);
		resData.setTotal(total);
		if (total > 0) {
			Map<String, Object> profile;
			List<Map<String, Object>> profilesMap = getProfileMapList(dataMap);
			List<Map<String, Object>> profileList = new ArrayList<>();
			if (profilesMap != null && profilesMap.size() > 0) {
				for (Map<String, Object> profMap : profilesMap) {
					profile = new HashMap<>();
					Map<String, Object> sourceMap = (Map<String, Object>) profMap.get("_source");
					Set<String> keySet = attributesConfig.getDataAttributes().get(request.getReqId()).get("profile")
							.getKeys();
					processDataMap(sourceMap, profile, keySet);
					profileList.add(profile);
				}
			}
			resData.setProfiles(profileList);
		}
		return resData;
	}
	
	
	@SuppressWarnings("unchecked")
	public  <T> ResponseData processDataTimeline(T data) {
		ResponseData resData = new ResponseData();
		Map<String, Object> dataMap = (Map<String, Object>) data;
		int total = getTotalValue(dataMap);
		resData.setTotal(total);
		if (total > 0) {
			List<Map<String, Object>> profilesMap = getProfileMapList(dataMap);
			List<Map<String, Object>> profileList = new ArrayList<>();
			if (profilesMap != null && !profilesMap.isEmpty()) {
				for (Map<String, Object> profMap : profilesMap) {
					Map<String, Object> sourceMap = (Map<String, Object>) profMap.get("_source");
					if(sourceMap.containsKey("interactionEventDescEn")) {
						sourceMap.put("event_name", sourceMap.get("interactionEventDescEn"));
						sourceMap.remove("interactionEventDescEn");
					}					
                    if(sourceMap.containsKey("recordedDate") || sourceMap.containsKey("interactionOriginalIssueDate") || 
                    		sourceMap.containsKey("interactionStartDateTime") || sourceMap.containsKey("interactionLastUpdateDate")) 
                    	    dateFormat(sourceMap);              			
					
					profileList.add(sourceMap);
				}
			}
			resData.setProfiles(profileList);
		}
		return resData;
	}

	   private void dateFormat(Map<String, Object> sourceMap) {
			if (sourceMap.get("recordedDate")!=null &&sourceMap.get("recordedDate").toString().contains("Z"))
				sourceMap.put("recordedDate", sourceMap.get("recordedDate").toString().substring(0, sourceMap.get("recordedDate").toString().lastIndexOf(".")));
	  		if (sourceMap.get("interactionOriginalIssueDate")!=null && sourceMap.get("interactionOriginalIssueDate").toString().contains("Z"))
				sourceMap.put("interactionOriginalIssueDate", sourceMap.get("interactionOriginalIssueDate").toString().substring(0, sourceMap.get("interactionOriginalIssueDate").toString().lastIndexOf(".")));
			if (sourceMap.get("interactionStartDateTime")!=null && sourceMap.get("interactionStartDateTime").toString().contains("Z"))
				sourceMap.put("interactionStartDateTime", sourceMap.get("interactionStartDateTime").toString().substring(0, sourceMap.get("interactionStartDateTime").toString().lastIndexOf(".")));
			if (sourceMap.get("interactionLastUpdateDate")!=null && sourceMap.get("interactionLastUpdateDate").toString().contains("Z"))
				sourceMap.put("interactionLastUpdateDate", sourceMap.get("interactionLastUpdateDate").toString().substring(0, sourceMap.get("interactionLastUpdateDate").toString().lastIndexOf(".")));		
	       }	
}
