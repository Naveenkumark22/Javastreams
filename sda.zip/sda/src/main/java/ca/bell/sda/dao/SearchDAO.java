package ca.bell.sda.dao;

import java.util.Map;

import ca.bell.sda.util.Utility;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import ca.bell.sda.config.AppConfig;
import ca.bell.sda.config.ElasticQueryConfig;
import ca.bell.sda.model.elk.SearchQuery;
import ca.bell.sda.util.WebService;
import reactor.core.publisher.Mono;

@Component
public class SearchDAO {

	@Autowired
	AppConfig appConfig;

	@Autowired
	private ElasticQueryConfig elasticQueryConfig;

	@Autowired
	private WebService webService;

	public Object querySource(String reqId, String srcName, SearchQuery query, String url) throws Exception {
		return querySource(reqId, srcName, query, url, elasticQueryConfig.getFilterPath());
	}

	public Object querySource(String reqId, String srcName, SearchQuery query, String url, String filterPath) {
//		Utility.consoleObject(query+"   -----query");
//		Utility.consoleObject(srcName+"   -----query");
//		Utility.consoleObject(url+"  -----url");
//		Utility.consoleObject(filterPath+"     -----filterPath");
		Utility.consoleObject(query.getQuery()+"     -----qq");

		WebClient wc = webService.getWebClientInstance(appConfig.getEndpointName(reqId, srcName));
		Object resObj = null;
		resObj = wc.post().uri(url + "/_search?filter_path=" + filterPath).body(Mono.just(query), SearchQuery.class)
				.retrieve().bodyToMono(Map.class).block();
		return resObj;
	}

	public Object multiQuerySource(String reqId, String srcName, String queryStr, String filterPath) {
		WebClient wc = webService.getWebClientInstance(appConfig.getEndpointName(reqId, srcName));
		Object resObj = null;
		resObj = wc.method(HttpMethod.GET).uri("/_msearch?filter_path=" + filterPath)
				.header(HttpHeaders.CONTENT_TYPE, "application/x-ndjson").body(Mono.just(queryStr), String.class)
				.retrieve().bodyToMono(Map.class).block();
		return resObj;
	}

	@SuppressWarnings("unchecked")
	public Map<String, Object> querySourceMSearch(String endPointName, String entityName, String queryString)
			throws Exception {

		WebClient wc = webService.getWebClientInstance(endPointName);

		Map<String, Object> wcResMap = null;

		wcResMap = wc.post().uri(entityName + "/_msearch")
				.header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE).bodyValue(queryString)
				.exchangeToMono(wcRes -> wcRes.bodyToMono(Map.class)).block();

		return wcResMap;
	}

	@SuppressWarnings("unchecked")
	public Map<String, Object> querySource(String endPointName, String entityName, String queryString,
			String filterPath) throws Exception {

		WebClient wc = webService.getWebClientInstance(endPointName);

		Map<String, Object> wcResMap = null;

		wcResMap = wc.post().uri(entityName + "/_search?filter_path=" + filterPath)
				.header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE).bodyValue(queryString)
				.exchangeToMono(wcRes -> wcRes.bodyToMono(Map.class)).block();

		return wcResMap;
	}
	
	@SuppressWarnings("unchecked")
	public Map<String, Object> querySource(String endPointName, String entityName, Object queryString)
			throws Exception {
		WebClient wc = webService.getWebClientInstance(endPointName);

		Map<String, Object> wcResMap = null;

		wcResMap = wc.post().uri(entityName).header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
				.bodyValue(queryString).exchangeToMono(wcRes -> wcRes.bodyToMono(Map.class)).block();

		return wcResMap;
	}

}
