/**
 * 
 */
package ca.bell.sda.model.whitespace.ml;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author Kamalanathan Ranganathan
 *
 */

public class InputList {

	@JsonProperty("token_freq")
	private double token_freq = 0.0;

	@JsonProperty("ml_score")
	private String ml_score = "";

	@JsonProperty("ml_flag")
	private String ml_flag = "";

	@JsonProperty("address_match_score")
	private String address_match_score = "";

	@JsonProperty("name_match_score")
	private String name_match_score = "";

	@JsonProperty("input_record")
	private Record input_record;

	@JsonProperty("suspect_record")
	private Record suspect_record;

	@JsonIgnore
	private AdditionalQueryCall secondCall;

	public Record getInput_record() {
		return this.input_record;
	}

	public void setInput_record(Record inputrecord) {
		this.input_record = inputrecord;
	}

	public Record getSuspect_record() {
		return this.suspect_record;
	}

	public void setSuspect_record(Record suspectrecord) {

		this.suspect_record = suspectrecord;
	}

	public double getToken_freq() {
		return token_freq;
	}

	public void setToken_freq(double token_freq) {
		this.token_freq = token_freq;
	}

	public String getMl_score() {
		return ml_score;
	}

	public void setMl_score(String ml_score) {
		this.ml_score = ml_score;
	}

	public String getMl_flag() {
		return ml_flag;
	}

	public void setMl_flag(String ml_flag) {
		this.ml_flag = ml_flag;
	}

	public String getAddress_match_score() {
		return address_match_score;
	}

	public void setAddress_match_score(String address_match_score) {
		this.address_match_score = address_match_score;
	}

	public String getName_match_score() {
		return name_match_score;
	}

	public void setName_match_score(String name_match_score) {
		this.name_match_score = name_match_score;
	}

	public AdditionalQueryCall getSecondCall() {
		return secondCall;
	}

	public void setSecondCall(AdditionalQueryCall secondCall) {
		this.secondCall = secondCall;
	}

}
