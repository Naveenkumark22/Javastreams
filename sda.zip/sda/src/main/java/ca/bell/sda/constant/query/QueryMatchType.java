package ca.bell.sda.constant.query;

public class QueryMatchType {

	public static final int EXACT = 1;
	public static final int FUZZY = 2;
	public static final int TERM = 3;
	public static final int TERMS = 4;
	public static final int MATCH = 5;
	public static final int MATCH_STANDARD = 6;
	public static final int WILD_CARD = 7;

}
