package ca.bell.sda.constant.query;

public class SourceFilterSet {

	public static String DEFAULT = "default";
	public static String DENIED = "denied";
	public static String COMPLETE = "complete";

}
