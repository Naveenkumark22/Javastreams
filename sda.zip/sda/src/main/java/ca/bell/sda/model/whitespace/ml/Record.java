/**
 *
 */
package ca.bell.sda.model.whitespace.ml;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import ca.bell.sda.model.whitespace.ELKAddress;
import ca.bell.sda.model.whitespace.STDAddress;
import ca.bell.sda.util.Utility;

/**
 * @author Kamalanathan Ranganathan
 *
 */
public class Record {

	private Map<String, Object> record = new HashMap<>() {

		private static final long serialVersionUID = 1L;

		{
			put("gkId", "");

			put("score", "");

			put("stdAddress", new HashMap<>());

			put("stdOrgName", "");

			put("sourceId", "");

			put("sourceTypeName", "");

			put("description", "");

			put("profileType", "");

			put("parent_duns", "");

			put("is_franchies", "");

			put("utl_parent_duns", "");

			put("customer_phone", "");

			put("customer_prime_contact", "");

			put("customer_url", "");

			put("input_phone", "");

			put("input_contact", "");

			put("input_url", "");
			
			put("keySegment", "");

			put("keyType", "");

			put("keyStatus", "");
			
			put("linkedKey", "");
		}
	};

	@JsonProperty("record")
	public Map<String, Object> getRecord() {

		return record;
	}

	public void setRecord(Map<String, Object> icnrecord) {

		this.record.clear();

		this.record.putAll(icnrecord);
	}

	public void setGkId(String gkId) {

		record.put("gkId", gkId);
	}
	
	public void setLinkedKey(String linkedKey) {

		record.put("linkedKey", linkedKey);
	}

	public void setScore(double score) {
		record.put("score", score);
	}

	public void setStdAddress(StdAddress stdAddress) {
		record.put("stdAddress", stdAddress);
	}

	public void setStdOrgName(String stdOrgName) {
		record.put("stdOrgName", stdOrgName);
	}

	public void setSourceId(String sourceId) {
		record.put("sourceId", sourceId);
	}

	public void setSourceTypeName(String sourceTypeName) {
		record.put("sourceTypeName", sourceTypeName);
	}

	public void setDescription(String description) {
		record.put("description", description);
	}

	public void setProfileType(String profileType) {
		record.put("profileType", profileType);
	}

	public void setParent_duns(String parent_duns) {
		record.put("parent_duns", parent_duns);
	}

	public void setIs_franchies(String is_franchies) {
		record.put("is_franchies", is_franchies);
	}

	public void setUtl_parent_duns(String utl_parent_duns) {
		record.put("utl_parent_duns", utl_parent_duns);
	}

	public void setCustomer_phone(String customer_phone) {
		record.put("customer_phone", customer_phone);
	}
	public void setKeyStatus(String keyStatus) {
		record.put("keyStatus", keyStatus);
	}
	public void setKeySegment(String keySegment) {
		record.put("keySegment", keySegment);
	}
	public void setKeyType(String keyType) {
		record.put("keyType", keyType);
	}

	public void setCustomer_prime_contact(String customer_prime_contact) {
		record.put("customer_prime_contact", customer_prime_contact);
	}

	public void setCustomer_url(String customer_url) {
		record.put("customer_url", customer_url);
	}

	public void setInput_phone(String input_phone) {
		record.put("input_phone", input_phone);
	}

	public void setInput_contact(String input_contact) {
		record.put("input_contact", input_contact);
	}

	public void setInput_url(String input_url) {
		record.put("input_url", input_url);
	}

	// This method is used to assign values from Standardization
	@JsonIgnore
	public void setStdAddress(STDAddress address) {

		StdAddress stdAddress = new StdAddress();

		stdAddress.setCombinedAddress(address.getCombinedAddress());

		stdAddress.setAddressLineOne(address.getAddresslineone_formatted());

		stdAddress.setAddressLineTwo(address.getAddresslinetwo_formatted());

		stdAddress.setCity(address.getCityname_formatted());

		stdAddress.setPostalCode(address.getFullpostalcode_formatted());

		stdAddress.setProvince(address.getStateabbreviation_formatted());

		stdAddress.setCountry(address.getCountryname_formatted());

		if (!address.isAddressEmpty())
			record.put("stdAddress", stdAddress);

	}

	// This method is used to assign values from ELK Bucketing
	public void setStdAddress(ELKAddress address) {

		StdAddress stdAddress = new StdAddress();

		stdAddress.setCombinedAddress(address.getCombinedAddress());

		stdAddress.setAddressLineOne(address.getAddressLineOne());

		stdAddress.setAddressLineTwo(address.getAddressLineTwo());

		stdAddress.setCity(address.getCity());

		stdAddress.setPostalCode(address.getPostalCode());

		stdAddress.setProvince(address.getProvince());

		stdAddress.setCountry(address.getCountry());

		if (!address.isAddressEmpty())
			record.put("stdAddress", stdAddress);
	}

	@JsonIgnore
	public String getStdOrgName() {

		Object obj = record.get("stdOrgName");

		return obj == null ? "" : (String) obj;
	}

	@JsonIgnore
	public Object getStdAddress() {

		return record.get("stdAddress");
	}

	@JsonIgnore
	public String getGkId() {

		return Utility.getAsString(record.get("gkId"));
	}
	
	@JsonIgnore
	public String getLinkedKey() {

		return Utility.getAsString(record.get("linkedKey"));
	}

	@JsonIgnore
	public String getScore() {
		return Utility.getAsString(record.get("score"));
	}

	@JsonIgnore
	public String getSourceId() {
		return Utility.getAsString(record.get("sourceId"));
	}

	@JsonIgnore
	public String getSourceTypeName() {
		return Utility.getAsString(record.get("sourceTypeName"));
	}

	@JsonIgnore
	public String getDescription() {
		return Utility.getAsString(record.get("description"));
	}

	@JsonIgnore
	public String getProfileType() {
		return Utility.getAsString(record.get("profileType"));
	}

	@JsonIgnore
	public String getParent_duns() {

		return Utility.getAsString(record.get("parent_duns"));
	}

	@JsonIgnore
	public String getIs_franchies() {
		return Utility.getAsString(record.get("is_franchies"));
	}
	@JsonIgnore
	public String getKeyStatus() {
		return Utility.getAsString(record.get("keyStatus"));
	}
	@JsonIgnore
	public String getKeySegment() {
		return Utility.getAsString(record.get("keySegment"));
	}
	@JsonIgnore
	public String getKeyType() {
		return Utility.getAsString(record.get("keyType"));
	}

	@JsonIgnore
	public String getUtl_parent_duns() {
		return Utility.getAsString(record.get("utl_parent_duns"));
	}

	@JsonIgnore
	public String getCustomer_phone() {
		return Utility.getAsString(record.get("customer_phone"));
	}

	@JsonIgnore
	public String getCustomer_prime_contact() {
		return Utility.getAsString(record.get("customer_prime_contact"));
	}

	@JsonIgnore
	public String getCustomer_url() {
		return Utility.getAsString(record.get("customer_url"));
	}

	@JsonIgnore
	public String getInput_phone() {
		return Utility.getAsString(record.get("input_phone"));
	}

	@JsonIgnore
	public String getInput_contact() {
		return Utility.getAsString(record.get("input_contact"));
	}

	@JsonIgnore
	public String getInput_url() {
		return Utility.getAsString(record.get("input_url"));
	}

	@Override
	public boolean equals(Object obj) {

		if (obj == null)
			return false;

		Record cRec = (Record) obj;

		if (!isEqual(this.record.get("gkId"), cRec.getGkId())) {
			return false;
		}

		if (!isEqual(this.record.get("score"), cRec.getScore())) {
			return false;
		}

		System.out.println(this.record.get("stdOrgName"));
		System.out.println(cRec.getStdOrgName());
		System.out.println(isEqual(this.record.get("stdOrgName"), cRec.getStdOrgName()));
		System.out.println(isEqual(this.record.get("stdOrgName").toString(), cRec.getStdOrgName()));

		if (!isEqual(this.record.get("stdOrgName"), cRec.getStdOrgName())) {
			return false;
		}

		if (!isEqual(this.record.get("sourceId"), cRec.getSourceId())) {
			return false;
		}

		if (!isEqual(this.record.get("sourceTypeName"), cRec.getSourceTypeName())) {
			return false;
		}

		if (!isEqual(this.record.get("description"), cRec.getDescription())) {
			return false;
		}

		if (!isEqual(this.record.get("profileType"), cRec.getProfileType())) {
			return false;
		}

		if (!isEqual(this.record.get("parent_duns"), cRec.getParent_duns())) {
			return false;
		}

		if (!isEqual(this.record.get("is_franchies"), cRec.getIs_franchies())) {
			return false;
		}

		if (!isEqual(this.record.get("utl_parent_duns"), cRec.getUtl_parent_duns())) {
			return false;
		}

		if (!isEqual(this.record.get("customer_phone"), cRec.getCustomer_phone())) {
			return false;
		}

		if (!isEqual(this.record.get("customer_prime_contact"), cRec.getCustomer_prime_contact())) {
			return false;
		}

		if (!isEqual(this.record.get("customer_url"), cRec.getCustomer_url())) {
			return false;
		}

		if (!isEqual(this.record.get("input_phone"), cRec.getInput_phone())) {
			return false;
		}

		if (!isEqual(this.record.get("input_contact"), cRec.getInput_contact())) {
			return false;
		}

		if (!isEqual(this.record.get("input_url"), cRec.getInput_url())) {
			return false;
		}

		if (!isAddressEquals(this.getStdAddress(), cRec.getStdAddress())) {
			return false;
		}
		return true;
	}

	private boolean isAddressEquals(Object addr1, Object addr2) {

		if (addr1 == null || addr2 == null)
			return false;

		if (addr1 instanceof StdAddress && addr2 instanceof StdAddress) {

			StdAddress std1 = (StdAddress) addr1;

			StdAddress std2 = (StdAddress) addr2;

			if (!std1.getAddressLineOne().equals(std2.getAddressLineOne())) {
				return false;
			}
			if (!std1.getAddressLineTwo().equals(std2.getAddressLineTwo())) {
				return false;
			}
			if (!std1.getCombinedAddress().equals(std2.getCombinedAddress())) {
				return false;
			}
			if (!std1.getCountry().equals(std2.getCountry())) {
				return false;
			}
			if (!std1.getProvince().equals(std2.getProvince())) {
				return false;
			}
			if (!std1.getPostalCode().equals(std2.getPostalCode())) {
				return false;
			}
			if (!std1.getCity().equals(std2.getCity())) {
				return false;
			}

		} else
			return false;

		return true;
	}

	private boolean isEqual(Object obj1, Object obj2) {

		boolean ret = true;

		if (obj1 == null || obj2 == null)
			ret = false;
		else {
			String str1 = obj1.toString();
			String str2 = obj2.toString();

			ret = str1.equals(str2);
		}

		return ret;
	}

	@Override
	public int hashCode() {
		return super.hashCode();
	}

}
