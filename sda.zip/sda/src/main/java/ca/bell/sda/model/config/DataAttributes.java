package ca.bell.sda.model.config;

import java.util.Map;
import java.util.Set;

public class DataAttributes {

	private Map<String, String> keyPairs;
	private Set<String> keys;
	private Map<String, Object> defaultValues;

	public Map<String, String> getKeyPairs() {
		return keyPairs;
	}

	public void setKeyPairs(Map<String, String> keyPairs) {
		this.keyPairs = keyPairs;
	}

	public Set<String> getKeys() {
		return keys;
	}

	public void setKeys(Set<String> keys) {
		this.keys = keys;
	}

	public Map<String, Object> getDefaultValues() {
		return defaultValues;
	}

	public void setDefaultValues(Map<String, Object> defaultValues) {
		this.defaultValues = defaultValues;
	}

}
