package ca.bell.sda.process;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import ca.bell.sda.config.AttributesConfig;
import ca.bell.sda.model.Request;
import ca.bell.sda.model.elk.response.ResponseData;

@Component
public class GetAccountManagementProcessor extends ElasticDataProcessor implements DataProcessor {
	
	@Autowired
	private AttributesConfig attributesConfig;
	
	@SuppressWarnings("unchecked")
	@Override
	public <T> ResponseData processData(Request request, T data) {
		
		Map<String, Object> dataMap = (Map<String, Object>) data;
		ResponseData resData = new ResponseData();
		if (getTotalValue(dataMap) > 0) {
			List<Map<String, Object>> profilesList = getProfileMapList(dataMap);
			Map<String, Object> profileMap = profilesList.get(0);
			Map<String, Object> profile = new HashMap<String, Object>();
			Map<String, Object> sourceMap = (Map<String, Object>) profileMap.get("_source");
			profile=sourceMap;
			profile.putAll((Map<String, Object>)sourceMap.get("bi360_customer"));
			profile.remove("bi360_customer");
			resData.setProfile(profile);
		}
		return resData;
	}

}
