package ca.bell.sda.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ca.bell.sda.config.AppConfig;
import ca.bell.sda.constant.log.LogKey;
import ca.bell.sda.constant.status.StatusTypes;
import ca.bell.sda.constant.webclient.StreamSource;
import ca.bell.sda.dao.HierarchyDAO;
import ca.bell.sda.dao.SearchDAO;
import ca.bell.sda.elk.QueryBuilder;
import ca.bell.sda.model.Request;
import ca.bell.sda.model.Response;
import ca.bell.sda.model.elk.Attribute;
import ca.bell.sda.model.elk.SearchQuery;
import ca.bell.sda.model.elk.response.ResponseData;
import ca.bell.sda.process.OrgDataProcessor;
import ca.bell.sda.transformer.OrgDataTransformer;

@Service
public class GetCPMOrgService extends CPMService {

	@Autowired
	private AppConfig appConfig;

	@Autowired
	private SearchDAO searchDAO;

	@Autowired
	private QueryBuilder queryBuilder;

	@Autowired
	private OrgDataProcessor dataProcessor;

	@Autowired
	private OrgDataTransformer orgDT;

	@Autowired
	private HierarchyDAO hrchyDAO;

	private final String externalIdKey = "externalId";
	private final String goldenKeyIdKey = "goldenKey";

	public void getOrg(Request request, Response response) {
		String serviceMethod = request.getQueryAttrbList().get(0).getProperties().getServiceMethod();
		if (serviceMethod!=null && serviceMethod.equalsIgnoreCase("getAccountProfile")) {
			request.getSourceFilter().removeIf(str-> str.equalsIgnoreCase("languagePreference"));
		}
		SearchQuery searchQuery = getSearchQuery(request);
		searchQuery.setMinScore("0.1");
		String[] indexes = appConfig.getIndexNames(request.getReqId());
		String url = String.join(",", indexes[0], indexes[1]);

		String idValue = null;
		request.logTime(LogKey.QUERY_BUILD_END);
		ResponseData resData = null;
		try {
			request.log(LogKey.QUERY, searchQuery);
			request.logTime(LogKey.ELK_START);
			Object elkData = searchDAO.querySource(request.getReqId(), StreamSource.INDEX, searchQuery, url,
					request.getQueryConfig().getFilterPath());
			request.logTime(LogKey.ELK_END);
			request.logTime(LogKey.DATA_CONV_START);
			resData = dataProcessor.processData(request, elkData);
			boolean orgProfile = true;
			if (resData.getProfile() != null) {
				Object idObj = resData.getProfile().get("id");
				idValue = (String) idObj;
				if (resData.getProfile().containsKey(goldenKeyIdKey)) { // If it is account level profile
					idObj = resData.getProfile().get(goldenKeyIdKey);
					orgProfile = false;
				}
				if (serviceMethod!=null && serviceMethod.equalsIgnoreCase("getAccountProfile")
						&& resData.getProfile().get("sourceSystem")!=null
						&&resData.getProfile().get("sourceSystem").toString().equalsIgnoreCase("cpm")) {
					resData = new ResponseData();
				} else if (idObj != null) {
					if (orgProfile && serviceMethod!=null && serviceMethod.equalsIgnoreCase("getOrgProfile")) {
						resData = processGKObj(request, resData, idObj, indexes[1]);
						if (resData.getProfile() != null) {
							processBanProductDetail(request, resData, idObj, indexes[3]);
							processMainCA(request, resData, idObj, indexes[0]);
							if (request.getSourceFilter().contains("bellExternalReference.externalId")) {
								processExtRefObj(request, resData, idObj, indexes[0]);
							}
						}
					}
				}
			}
			if (resData.getProfile() != null) {
				orgDT.tranformData(request, serviceMethod, idValue, resData);
				if (orgProfile && idValue != null && request.getSourceFilter().contains("relatedParty.relatedId")) {
					processHierarchy(request, resData, idValue, indexes[2]);
				}
				if (orgProfile) {
					String reqIdValue = orgDT.getRequestValue(request);
					if (!idValue.equalsIgnoreCase(reqIdValue)) {
						resData.getProfile().put(externalIdKey, idValue);
						response.setStatus(StatusTypes.MOVED_PERMANENTLY);
					}
				}
			}
			addSuccessLog(request);
		} catch (Exception e) {
			request.log(LogKey.REQ_LOG_EX_MSG, getClass().getName() + e.getMessage());
			addExceptionLog(request,e);
		}
		request.logTime(LogKey.DATA_CONV_END);
		response.setData(resData);
	}

	public void getOrgList(Request request, Response response) {

		SearchQuery searchQuery = getSearchQuery(request);
		searchQuery.setMinScore("0.1");
		String[] indexes = appConfig.getIndexNames(request.getReqId());
		String url = indexes[1];
		request.logTime(LogKey.QUERY_BUILD_END);
		ResponseData resData = null;
		Map<String, Map<String, Object>> profilesMap = new HashMap<>();
		try {
			request.log(LogKey.QUERY, searchQuery);
			request.logTime(LogKey.ELK_START);
			Object elkData = searchDAO.querySource(request.getReqId(), StreamSource.INDEX, searchQuery, url,
					request.getQueryConfig().getFilterPath());
			request.logTime(LogKey.ELK_END);
			request.logTime(LogKey.DATA_CONV_START);

			resData = dataProcessor.processData(request, elkData, profilesMap);
			processMainCA(request, profilesMap, indexes[0]);
			if (request.getSourceFilter().contains("bellExternalReference.externalId")) {
				processExtRefObj(request, profilesMap, indexes[0]);
			}
			if (!profilesMap.isEmpty() && request.getSourceFilter().contains("relatedParty.relatedId")) {
				processHierarchy(request, profilesMap, indexes[2]);
			}
			addSuccessLog(request);
		} catch (Exception e) {
			request.log(LogKey.REQ_LOG_EX_MSG, getClass().getName() + e.getMessage());
			addExceptionLog(request,e);
		}
		request.logTime(LogKey.DATA_CONV_END);
		response.setData(resData);
	}

	private ResponseData processGKObj(Request request, ResponseData resData, Object gkObj, String index) {
		List<Attribute> attrbQueryList = new ArrayList<>();
		attrbQueryList.add(getAttrb(request, "id", gkObj));
		SearchQuery searchQuery = getSearchQuery(request);
		searchQuery.setMinScore(null);
		searchQuery.setQuery(queryBuilder.createSearchQuery(attrbQueryList));
		ResponseData gkRes = null;
		try {
			Object gkData = searchDAO.querySource(request.getReqId(), StreamSource.INDEX, searchQuery, index,
					request.getQueryConfig().getFilterPath());
			gkRes = dataProcessor.processData(request, gkData);
		} catch (Exception e) {
			request.log(LogKey.REQ_LOG_EX_MSG, getClass().getName() + e.getMessage());
			request.log(LogKey.REQ_LOG_EX, e);
		}
		return gkRes;
	}

	private void processExtRefObj(Request request, ResponseData resData, Object gkObj, String index) {
		try {
			List<Attribute> attrbQueryList = new ArrayList<>();
			attrbQueryList.add(getAttrb(request, goldenKeyIdKey, gkObj));
			attrbQueryList.add(getAttrb(request, "accountType", "customer"));
			SearchQuery searchQuery = getSearchQuery(request);
			searchQuery.setMinScore(null);
			searchQuery.setSourceFilter(appConfig.getAttributesConfig().getDataAttributes().get(request.getReqId())
					.get("externalRef").getKeys());
			searchQuery.setSize("10000");
			searchQuery.setQuery(queryBuilder.createSearchQuery(attrbQueryList));
			Object gkData = searchDAO.querySource(request.getReqId(), StreamSource.INDEX, searchQuery, index,
					request.getQueryConfig().getFilterPath());
			Object extRefObj = dataProcessor.processExtReference(request, gkData, resData);
			resData.getProfile().put("bellExternalReference", extRefObj);			
		} catch (Exception e) {
			request.log(LogKey.REQ_LOG_EX_MSG, getClass().getName() + e.getMessage());
			request.log(LogKey.REQ_LOG_EX, e);
		}
	}

	private void processExtRefObj(Request request, Map<String, Map<String, Object>> profilesMap, String index) {
		try {
			String idArr[] = profilesMap.keySet().toArray(new String[profilesMap.size()]);
			List<Attribute> attrbQueryList = new ArrayList<>();
			attrbQueryList.add(getAttrb(request, goldenKeyIdKey, idArr));
			attrbQueryList.add(getAttrb(request, "accountType", "customer"));
			SearchQuery searchQuery = getSearchQuery(request);
			searchQuery.setMinScore(null);
			searchQuery.setSourceFilter(appConfig.getAttributesConfig().getDataAttributes().get(request.getReqId())
					.get("externalRef").getKeys());
			searchQuery.setSize("10000");
			searchQuery.setQuery(queryBuilder.createSearchQuery(attrbQueryList));
			Object elkData = searchDAO.querySource(request.getReqId(), StreamSource.INDEX, searchQuery, index,
					request.getQueryConfig().getFilterPath());
			dataProcessor.processExtReference(request, elkData, profilesMap);
		} catch (Exception e) {
			request.log(LogKey.REQ_LOG_EX_MSG, getClass().getName() + e.getMessage());
			request.log(LogKey.REQ_LOG_EX, e);
		}
	}

	private void processMainCA(Request request, ResponseData resData, Object gkObj, String index) {
		try {
			List<Attribute> attrbQueryList = new ArrayList<>();
			attrbQueryList.add(getAttrb(request, goldenKeyIdKey, gkObj));
			attrbQueryList.add(getAttrb(request, "accountType", "customer"));
			attrbQueryList.add(getAttrb(request, "mainCustomerInd", "true"));
			SearchQuery searchQuery = getSearchQuery(request);
			searchQuery.setMinScore(null);
			searchQuery.setSourceFilter(appConfig.getAttributesConfig().getDataAttributes().get(request.getReqId())
					.get("mainCA").getKeys());
			searchQuery.setQuery(queryBuilder.createSearchQuery(attrbQueryList));
			Object elkData = searchDAO.querySource(request.getReqId(), StreamSource.INDEX, searchQuery, index,
					request.getQueryConfig().getFilterPath());
			Map<String, Object> mainCAMap = dataProcessor.processMainCA(request, elkData);
			if (mainCAMap != null) {
				resData.getProfile().putAll(mainCAMap);
			}
		} catch (Exception e) {
			request.log(LogKey.REQ_LOG_EX_MSG, getClass().getName() + e.getMessage());
			request.log(LogKey.REQ_LOG_EX, e);
		}
	}

	private void processMainCA(Request request, Map<String, Map<String, Object>> profilesMap, String index) {
		try {
			String idArr[] = profilesMap.keySet().toArray(new String[profilesMap.size()]);
			List<Attribute> attrbQueryList = new ArrayList<>();
			attrbQueryList.add(getAttrb(request, goldenKeyIdKey, idArr));
			attrbQueryList.add(getAttrb(request, "accountType", "customer"));
			attrbQueryList.add(getAttrb(request, "mainCustomerInd", "true"));
			SearchQuery searchQuery = getSearchQuery(request);
			searchQuery.setMinScore(null);
			searchQuery.setSourceFilter(appConfig.getAttributesConfig().getDataAttributes().get(request.getReqId())
					.get("mainCASrcFilter").getKeys());
			searchQuery.setQuery(queryBuilder.createSearchQuery(attrbQueryList));
			Object elkData = searchDAO.querySource(request.getReqId(), StreamSource.INDEX, searchQuery, index,
					request.getQueryConfig().getFilterPath());
			dataProcessor.processMainCA(request, elkData, profilesMap);
		} catch (Exception e) {
			request.log(LogKey.REQ_LOG_EX_MSG, getClass().getName() + e.getMessage());
			request.log(LogKey.REQ_LOG_EX, e);
		}
	}

	@SuppressWarnings("unchecked")
	private void processHierarchy(Request request, ResponseData resData, String gkId, String index) {
		Map<String, Object> hierarchy = hrchyDAO.getParentNodes(request, gkId, index);
		List<Map<String, Object>> hrchyList = dataProcessor.processHirerchyData(request, hierarchy);
		List<Object> rltdPartyList = (List<Object>) resData.getProfile().get("relatedParty");
		if (rltdPartyList == null) {
			rltdPartyList = new ArrayList<>();
		}
		if (hrchyList != null) {
			rltdPartyList.addAll(hrchyList);
			resData.getProfile().put("relatedParty", rltdPartyList);
		}
	}

	private void processHierarchy(Request request, Map<String, Map<String, Object>> profilesMap, String index) {
		String idArr[] = profilesMap.keySet().toArray(new String[profilesMap.size()]);
		Map<String, Object> hierarchy = hrchyDAO.getParentNodes(request, idArr, index);
		dataProcessor.processHirerchyData(request, profilesMap, hierarchy);
	}

	private void processBanProductDetail(Request request, ResponseData resData, Object gkObj, String index) {
		if (isReqConfigFlag(request, "banProduct", "yes")) {
			List<Attribute> attrbQueryList = new ArrayList<>();
			attrbQueryList.add(getAttrb(request, goldenKeyIdKey, gkObj));
			SearchQuery searchQuery = getSearchQuery(request);
			searchQuery.setSize("1000");
			searchQuery.setMinScore(null);
			searchQuery.setSourceFilter(appConfig.getAttributesConfig().getDataAttributes().get(request.getReqId())
					.get("banProductDetail").getKeys());
			searchQuery.setQuery(queryBuilder.createSearchQuery(attrbQueryList));
			try {
				Object elkData = searchDAO.querySource(request.getReqId(), StreamSource.INDEX, searchQuery, index,
						request.getQueryConfig().getFilterPath());
				dataProcessor.processBanProductDetail(resData.getProfile(), elkData);
			} catch (Exception e) {
				request.log(LogKey.REQ_LOG_EX_MSG, e.getMessage());
				e.printStackTrace();
			}
		}
	}
}
