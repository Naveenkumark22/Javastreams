package ca.bell.sda.process;

import org.springframework.stereotype.Component;

import ca.bell.sda.model.Request;
import ca.bell.sda.model.elk.response.ResponseData;

@Component
public interface DataProcessor {

	public <T> ResponseData processData(Request request, T data);

}
