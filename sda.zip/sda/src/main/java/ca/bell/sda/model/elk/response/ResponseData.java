package ca.bell.sda.model.elk.response;

import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

public class ResponseData {

	@JsonInclude(Include.NON_DEFAULT)
	private int total;

	@JsonInclude(Include.NON_DEFAULT)
	private double maxScore;

	@JsonInclude(Include.NON_NULL)
	private Map<String, Object> profile;

	@JsonInclude(Include.NON_NULL)
	private List<Map<String,Object>> profiles;

	public int getTotal() {
		return total;
	}

	public void setTotal(int total) {
		this.total = total;
	}

	public double getMaxScore() {
		return maxScore;
	}

	public void setMaxScore(double maxScore) {
		this.maxScore = maxScore;
	}

	public Map<String, Object> getProfile() {
		return profile;
	}

	public void setProfile(Map<String, Object> profile) {
		this.profile = profile;
	}

	public List<Map<String,Object>> getProfiles() {
		return profiles;
	}

	public void setProfiles(List<Map<String,Object>> profiles) {
		this.profiles = profiles;
	}
	
	

}
