/**
 *
 */
package ca.bell.sda.model.whitespace;

import java.util.Map;

/**
 * @author Kamalanathan Ranganathan
 */

/*
 * Used to extract data from request
 *
 * Send these detail for Standardization. Response will be OrgRecord
 *
 */
public class RequestInputDetail {

	// org Name
	private String organizationName = "";
	
	// org Name
		private String organizationAAName = "";
		
		private String stdAAAlternateName = "";

		private String stdAANumberEquivalent = "";	

	private String stdAlternateName = "";

	private String stdNumberEquivalent = "";

	// GK Id
	private String adminPartyId = "";

	// Franchise Flag
	private String franchiseFlag = null;

	// Address
	// This is extracting from Request input
	private Map<String, String> address;

	// Contact Methods
	private Map<String, String> contactMethodMap;

	private Map<Long, String> partyIDMap;

	private Map<String, String> extraMasterKey;

	private String profileType = "GK";
	
	private String stdFlag;

	// This is extracting from AA Standardization
	private ELKAddress stdaddressAA;

	public RequestInputDetail() {

	}

	public String getOrganizationName() {

		return organizationName;
	}

	public void setOrganizationName(String organizationName) {

		if (organizationName != null)
			this.organizationName = organizationName.trim();
	}
	
	public String getOrganizationAAName() {

		return organizationAAName;
	}

	public void setOrganizationAAName(String organizationAAName) {

		if (organizationAAName != null)
			this.organizationAAName = organizationAAName.trim();
	}

	public String getAdminPartyId() {

		return adminPartyId;
	}

	public void setAdminPartyId(String skid) {

		adminPartyId = skid;
	}

	public String getFranchiseFlag() {
		return franchiseFlag;
	}

	public void setFranchiseFlag(String franchiseFlag) {
		this.franchiseFlag = franchiseFlag;
	}

	public boolean isNameEmpty() {

		return this.organizationName.trim().length() == 0;
	}

	public boolean isAddressEmpty() {

		String addressLineOne = address.get("AddressLineOne");

		String city = address.get("City");

		String zipPostalCode = address.get("ZipPostalCode");

		return addressLineOne == null && city == null && zipPostalCode == null;
	}

	public boolean isContactTNEmpty() {

		return this.contactMethodMap == null || this.contactMethodMap.get("tn") == null
				|| this.contactMethodMap.get("tn").trim().length() == 0;
	}

	public boolean isContactEmailEmpty() {

		return this.contactMethodMap == null || this.contactMethodMap.get("email") == null
				|| this.contactMethodMap.get("email").trim().length() == 0;
	}

	public Map<String, String> getContactMethodMap() {
		return contactMethodMap;
	}

	public void setContactMethodMap(Map<String, String> contactMethodMap) {
		this.contactMethodMap = contactMethodMap;
	}

	public Map<Long, String> getPartyIDMap() {
		return partyIDMap;
	}

	public void setPartyIDMap(Map<Long, String> partyIDMap) {
		this.partyIDMap = partyIDMap;
	}

	public Map<String, String> getAddress() {
		return address;
	}

	public void setAddress(Map<String, String> address) {
		this.address = address;
	}

	public Map<String, String> getExtraMasterKey() {
		return extraMasterKey;
	}

	public void setExtraMasterKey(Map<String, String> extraMasterKey) {
		this.extraMasterKey = extraMasterKey;
	}

	public String getStdNumberEquivalent() {
		return stdNumberEquivalent;
	}

	public void setStdNumberEquivalent(String stdNumberEquivalent) {
		this.stdNumberEquivalent = stdNumberEquivalent;
	}

	public String getStdAlternateName() {
		return stdAlternateName;
	}

	public void setStdAlternateName(String stdAlternateName) {
		this.stdAlternateName = stdAlternateName;
	}

	public String getProfileType() {
		return profileType;
	}

	public void setProfileType(String profileType) {
		this.profileType = profileType;
	}

	public ELKAddress getStdaddressAA() {
		return stdaddressAA;
	}

	public void setStdaddressAA(ELKAddress stdaddressAA) {
		this.stdaddressAA = stdaddressAA;
	}

	public String getStdAAAlternateName() {
		return stdAAAlternateName;
	}

	public void setStdAAAlternateName(String stdAAAlternateName) {
		this.stdAAAlternateName = stdAAAlternateName;
	}

	public String getStdAANumberEquivalent() {
		return stdAANumberEquivalent;
	}

	public void setStdAANumberEquivalent(String stdAANumberEquivalent) {
		this.stdAANumberEquivalent = stdAANumberEquivalent;
	}

	public String getStdFlag() {
		return stdFlag;
	}

	public void setStdFlag(String stdFlag) {
		this.stdFlag = stdFlag;
	}
	
	

}
