package ca.bell.sda.model.config;

public class Endpoint {

	/**
	 * Webservice Endpoint Desc
	 */
	private String desc;

	/**
	 * Webservice Endpoint Name
	 */
	private String envName;

	/**
	 * Webserivce endpoint Host name
	 */
	private String host;
	/**
	 * Endpoint URL to connect
	 */
	private String url;
	/**
	 * Endpoint Authentication Type - Basic, Username & Password, etc..
	 */
	private String authType;
	/**
	 * Endpoint Username if authentication type is Username & Password
	 */
	private String username;
	/**
	 * Endpoint Password if authentication type is Username & Password
	 */
	private String password;
	/**
	 * Endpoint Authorization value if authentication type is Basic
	 */
	private String authorization;

	/**
	 * Webserivce endpoint Host name
	 */
	public String getHost() {
		return host;
	}

	/**
	 * Webserivce endpoint Host name
	 */
	public void setHost(String host) {
		this.host = host;
	}

	/**
	 * Endpoint URL to connect
	 */
	public String getUrl() {
		return url;
	}

	/**
	 * Endpoint URL to connect
	 */
	public void setUrl(String url) {
		this.url = url;
	}

	/**
	 * Endpoint Authentication Type - Basic, Username & Password, etc..
	 */
	public String getAuthType() {
		return authType;
	}

	/**
	 * Endpoint Authentication Type - Basic, Username & Password, etc..
	 */
	public void setAuthType(String authType) {
		this.authType = authType;
	}

	/**
	 * Endpoint Username if authentication type is Username & Password
	 */
	public String getUsername() {
		return username;
	}

	/**
	 * Endpoint Username if authentication type is Username & Password
	 */
	public void setUsername(String username) {
		this.username = username;
	}

	/**
	 * Endpoint Password if authentication type is Username & Password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * Endpoint Password if authentication type is Username & Password
	 */
	public void setPassword(String password) {
		this.password = password;
	}

	/**
	 * Endpoint Authorization value if authentication type is Basic
	 */
	public String getAuthorization() {
		return authorization;
	}

	/**
	 * Endpoint Authorization value if authentication type is Basic
	 */
	public void setAuthorization(String authorization) {
		this.authorization = authorization;
	}

	public String getEnvName() {
		return envName;
	}

	public void setEnvName(String envName) {
		this.envName = envName;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

}
