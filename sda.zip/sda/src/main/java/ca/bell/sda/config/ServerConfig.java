package ca.bell.sda.config;

import org.springframework.stereotype.Component;

@Component
public class ServerConfig {

	private WebServiceConfig webService;

	public WebServiceConfig getWebService() {
		return webService;
	}

	public void setWebService(WebServiceConfig webService) {
		this.webService = webService;
	}
	
	
	
	
	
}
