package ca.bell.sda.controller;

import java.time.Instant;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import ca.bell.sda.constant.log.LogKey;
import ca.bell.sda.constant.status.StatusTypes;
import ca.bell.sda.model.Request;
import ca.bell.sda.model.Response;
import ca.bell.sda.process.RequestProcessor;
import ca.bell.sda.service.GetCPMOrgService;

@RestController
public class GetCPMOrgController extends SDAController {

	@Autowired
	private RequestProcessor processor;

	@Autowired
	private GetCPMOrgService service;

	@RequestMapping(value = "/bbm/GetCPMOrganization", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public Response getCPMOrg(@RequestBody Map<String, Object> requestMap) throws Exception {
		return getOrgService(new Request("bbm", "GetCPMOrganization"), requestMap);
	}

	@RequestMapping(value = "/bbm/GetCPMOrganizationList", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public Response getCPMOrgList(@RequestBody Map<String, Object> requestMap) throws Exception {
		return getOrgService(new Request("bbm","GetCPMOrganizationList"), requestMap);
	}

	public Response getOrgService(Request request, Map<String, Object> requestMap) throws Exception{
		request.logTime(LogKey.REQ_START);
		request.log(LogKey.TIMESTAMP, Instant.now().toString());
		request.log(LogKey.REQ_GRP_ID, request.getReqId());
		request.log(LogKey.REQ_MAP, requestMap);

		Response response = new Response(StatusTypes.REQUEST_SUCCESS);
		request.log(LogKey.QUERY_BUILD_START, System.currentTimeMillis());

		processor.processRequest(requestMap, request, response);

		if (request.getQueryAttrbList().size() > 1) {
			response.setStatus(StatusTypes.MULTIPLE_FIELDS_NOT_ACCEPTED);
		} else {
			if (response.getStatus().getCode() == StatusTypes.REQUEST_SUCCESS.getCode()) {
				switch (request.getReqId()) {
				case "GetCPMOrganization":
					service.getOrg(request, response);
					break;
				case "GetCPMOrganizationList":
					service.getOrgList(request, response);
					break;
				}
				request.log(LogKey.REQ_RESPONSE, response.getData());
			}
		}
		checkRequestLog(request);
		return response;
	}

}
