package ca.bell.sda.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

/**
 * Response Object
 * 
 * @author Jagan Boopathi
 *
 */
@JsonInclude(Include.NON_NULL)
public class Response {

	private Status status;
	private Object data;

	public Response() {

	}

	public Response(Status status) {
		super();
		this.status = status;
	}

	/**
	 * Get Status object
	 * 
	 * @return {@link Status} - Status
	 *
	 */
	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

	public Object getData() {
		return data;
	}

	public void setData(Object data) {
		this.data = data;
	}

}
