package ca.bell.sda.constant.node;

public class NodeValueType {

	public static final int STRING = 1;
	public static final int OBJECT = 2;
	public static final int ARRAY = 3;

}
