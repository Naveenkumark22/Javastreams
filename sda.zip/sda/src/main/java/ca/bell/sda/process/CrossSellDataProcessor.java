package ca.bell.sda.process;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import ca.bell.sda.config.AttributesConfig;
import ca.bell.sda.model.Request;
import ca.bell.sda.model.elk.response.ResponseData;

@Component
public class CrossSellDataProcessor  extends ElasticDataProcessor implements DataProcessor {
	
	@Autowired
	private AttributesConfig attributesConfig;

	@SuppressWarnings("unchecked")
	@Override
	public <T> ResponseData processData(Request request, T data) {
		Map<String, Object> dataMap = (Map<String, Object>) data;
		Map<String, Object> sourceMap=null;
		int total = getTotalValue(dataMap);
		if (total > 0) {
			Map<String,Object> profile = new HashMap<>();
			List<Map<String, Object>> profileList = getProfileMapList(dataMap);
			sourceMap = (Map<String, Object>) profileList.get(0).get("_source");
			Set<String> keySet = attributesConfig.getDataAttributes().get(request.getReqId()).get("profile")
					.getKeys();
			processDataMap(sourceMap, profile, keySet);
			ResponseData resData=new ResponseData();
			resData.setProfile(profile);
			return resData;
		}
		return null;

	}
	

}
