package ca.bell.sda.constant.webclient;

public class WebServiceAuth {
	public static final String BASIC = "BASIC";
	public static final String USER_PASS = "USER_PASS";
}
