/**
 * 
 */
package ca.bell.sda.util;

import java.io.StringWriter;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import org.springframework.stereotype.Component;

import freemarker.cache.ClassTemplateLoader;
import freemarker.template.Configuration;
import freemarker.template.Template;

/**
 * @author Kamalanathan Ranganathan
 *
 */
@Component
public class Freemaker {

	private static final Configuration CONFIGURATION = new Configuration(Configuration.VERSION_2_3_0);

	private ClassTemplateLoader loader = new ClassTemplateLoader(this.getClass(), "/fmtemplate/mlprediction");

	/**
	 * 
	 */
	public Freemaker() {

		CONFIGURATION.setTemplateLoader(loader);

		CONFIGURATION.setDefaultEncoding("UTF-8");

		CONFIGURATION.setLocale(Locale.US);
	}

	public String generateByTemplate(String templatename, Map<String, Object> inputMap) throws Exception {

		String sourceCode = "";

		try {

			Template template = CONFIGURATION.getTemplate(templatename + ".ftl");

			Map<String, Object> input = new HashMap<String, Object>();

			StringWriter writer = new StringWriter();

			input.put("input", inputMap);

			template.process(input, writer);

			sourceCode = writer.toString();

		} catch (Exception e) {

			e.printStackTrace();

			throw new Exception(" FreeMaker : " + e.getMessage());

		}

		// System.out.println(sourceCode);

		return sourceCode;
	}
}
