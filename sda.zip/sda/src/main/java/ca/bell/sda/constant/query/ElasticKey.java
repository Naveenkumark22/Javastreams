package ca.bell.sda.constant.query;

public class ElasticKey {
	
	public static final String SOURCE="_source";
	public static final String HITS="hits";
	public static final String TOTAL="total";
	public static final String RESPONSES="responses";
	public static final String MAX_SCORE="max_score";
	public static final String BUCKETS="buckets";
	public static final String AGGREGATIONS="aggregations";
	public static final String ERROR="error";
	
	

}
