package ca.bell.sda.service;

import java.util.ArrayList;
import java.util.List;

import ca.bell.sda.util.Utility;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ca.bell.sda.config.AppConfig;
import ca.bell.sda.config.AttributesConfig;
import ca.bell.sda.constant.log.LogKey;
import ca.bell.sda.constant.webclient.StreamSource;
import ca.bell.sda.dao.SearchDAO;
import ca.bell.sda.elk.QueryBuilder;
import ca.bell.sda.model.Request;
import ca.bell.sda.model.elk.Attribute;
import ca.bell.sda.model.elk.MultiSearchQuery;
import ca.bell.sda.model.elk.SearchQuery;
import ca.bell.sda.model.elk.response.ResponseData;
import ca.bell.sda.model.service.ContactSuspectDetail;
import ca.bell.sda.process.SuspectDataProcessor;

@Service
public class SuspectListService extends CPMService {

	@Autowired
	private AppConfig appConfig;

	@Autowired
	private AttributesConfig attributesConfig;

	@Autowired
	private SearchDAO searchDAO;

	@Autowired
	private SuspectDataProcessor dataProcessor;

	@Autowired
	private QueryBuilder queryBuilder;

	private static final String CONTACT_GK_KEY = "contactGK";

	public Object getSuspectList(Request request) {
		ResponseData resData = null;
		try
		{
			ContactSuspectDetail csDetail = new ContactSuspectDetail();
			collectSuspectContacts(request, csDetail);		
			if (!csDetail.getContactSet().isEmpty()) {
				Object elkData = getSuspectProfiles(request, csDetail);
				request.logTime(LogKey.DATA_CONV_START);
				if (elkData != null) {
					dataProcessor.processSuspectProfile(request, csDetail, elkData);
					if (!csDetail.getProfileList().isEmpty()) {
						resData = new ResponseData();
						resData.setProfiles(csDetail.getProfileList());
					}
				}
			}
			addSuccessLog(request);
		}catch(Exception e)
		{
			e.printStackTrace();
			request.log(LogKey.REQ_LOG_EX_MSG, getClass().getName() + e.getMessage());
			addExceptionLog(request, e);			
		}
		return resData;
	}

	private Object getSuspectProfiles(Request request, ContactSuspectDetail csDetail) {
		List<Attribute> attrbQueryList = new ArrayList<>();
		attrbQueryList.add(getAttrb(request, "contactId", csDetail.getContactSet()));
		SearchQuery searchQuery = getSearchQuery(request);
		searchQuery.setMinScore(null);
		searchQuery.setSize("1000");
		searchQuery.setQuery(queryBuilder.createSearchQuery(attrbQueryList));
		searchQuery.setSourceFilter(
				attributesConfig.getDataAttributes().get(request.getReqId()).get("suspectProfile").getKeys());
		String indexName = appConfig.getIndexNames(request.getReqId())[1];
		try {
			Object elkData = searchDAO.querySource(request.getReqId(), StreamSource.INDEX, searchQuery, indexName,
					request.getQueryConfig().getFilterPath());
			request.logTime(LogKey.ELK_END);
			return elkData;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;

	}

	@SuppressWarnings("unchecked")
	private void collectSuspectContacts(Request request, ContactSuspectDetail csDetail) {
		List<String> contactsList = (List<String>) request.getRequestMap().get(CONTACT_GK_KEY);
		csDetail.setRequestContactList(contactsList);
		Object elkData = getSuspectData(request, csDetail);
		Utility.consoleObject(elkData);
		dataProcessor.processSuspectData(request, csDetail, elkData);
	}

	private Object getSuspectData(Request request, ContactSuspectDetail csDetail) {
		MultiSearchQuery multiQuery = new MultiSearchQuery();
		csDetail.getRequestContactList().forEach(contactId -> {
			addContactQuery(request, multiQuery, contactId);
		});
		request.logTime(LogKey.QUERY_BUILD_END);
		try {
			request.log(LogKey.QUERY, multiQuery);
			request.logTime(LogKey.ELK_START);
			Utility.consoleObject(multiQuery);
			return searchDAO.multiQuerySource(request.getReqId(), StreamSource.INDEX,
					multiQuery.getMultiQueryString(), request.getQueryConfig().getMultiQueryFilterPath());
		} catch (Exception e) {
			request.log(LogKey.REQ_LOG_EX_MSG, getClass().getName() + e.getMessage());
			request.log(LogKey.REQ_LOG_EX, e);
		}
		return null;
	}

	public void addContactQuery(Request request, MultiSearchQuery multiQuery, String contactId) {
		String indexName = appConfig.getIndexNames(request.getReqId())[0];
		List<Attribute> attrbQueryList = new ArrayList<>();
		String[] idArr = { contactId };
		attrbQueryList.add(getAttrb(request, CONTACT_GK_KEY, idArr));
		SearchQuery searchQuery = getSearchQuery(request);
		searchQuery.setMinScore(null);
		searchQuery.setSize("1000");
		searchQuery.setSourceFilter(
				attributesConfig.getDataAttributes().get(request.getReqId()).get("suspectDetail").getKeys());
		searchQuery.setQuery(queryBuilder.createSearchQuery(attrbQueryList));
		multiQuery.addSearchQuery(indexName, searchQuery);
	}

}
