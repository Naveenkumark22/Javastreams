/**
 *
 */
package ca.bell.sda.model.whitespace;

/**
 * @author Kamalanathan Ranganathan
 */
public class ELKAddress {

	// ELK input/ output Address
	private String combinedAddress = "";

	private String addressLineOne = "";

	private String country = "";

	private String postalCode = "";

	private String addressLineTwo = "";

	private String province = "";

	private String city = "";

	public ELKAddress() {

	}

	public ELKAddress(AddressBuilder builder) {

		this.combinedAddress = builder.combinedAddress;

		this.addressLineOne = builder.addressLineOne;

		this.country = builder.country;

		this.postalCode = builder.postalCode;

		this.addressLineTwo = builder.addressLineTwo;

		this.province = builder.province;

		this.city = builder.city;

		createCombinedAddress();
	}

	public String getCombinedAddress() {

		createCombinedAddress();

		return this.combinedAddress;
	}

	public void setCombinedAddress(String combinedAddress) {

		this.combinedAddress = combinedAddress;
	}

	public String getAddressLineOne() {

		return addressLineOne;
	}

	public void setAddressLineOne(String addressLineOne) {

		this.addressLineOne = addressLineOne;
	}

	public String getCountry() {

		return country;
	}

	public void setCountry(String country) {

		this.country = country;
	}

	public String getPostalCode() {

		return postalCode;
	}

	public void setPostalCode(String postalCode) {

		this.postalCode = postalCode;
	}

	public String getAddressLineTwo() {

		return addressLineTwo;
	}

	public void setAddressLineTwo(String addressLineTwo) {

		this.addressLineTwo = addressLineTwo;
	}

	public String getProvince() {

		return province;
	}

	public void setProvince(String province) {

		this.province = province;
	}

	public String getCity() {

		return city;
	}

	public void setCity(String city) {

		this.city = city;
	}

	public boolean isAddressEmpty() {

		boolean isAddressone = false;

		boolean isCombinedAddress = false;

		boolean ret = false;

		if (((getAddressLineOne() != null || getAddressLineOne().trim().length() > 0))) {
			isAddressone = true;
		}

		if (getCombinedAddress() != null && getCombinedAddress().trim().length() > 0) {

			isCombinedAddress = true;
		}

		if ((isAddressone == false && isCombinedAddress == false))
			ret = false;
		else
			ret = (isAddressone && isCombinedAddress);

		// true - Address is Not present
		// false - Address is present
		return !ret;
	}

	public void createCombinedAddress() {

		if (this.combinedAddress == null || this.combinedAddress.trim().length() == 0) {

			this.combinedAddress = (this.addressLineOne + " " + this.city + " " + this.postalCode + " " + this.province + " " + this.country)
					.trim();
		}
	}

	@Override
	public String toString() {

		return "Address : \n " +

				" combinedAddress = " + combinedAddress +

				" addressLineOne = " + addressLineOne +

				" country = " + country +

				" postalCode = " + postalCode +

				" addressLineTwo = " + addressLineTwo +

				" province = " + province;

	}

	// ELK Address Builders
	public static class AddressBuilder {

		private static final String REPLACESTRING = "";

		private String combinedAddress = "";

		private String addressLineOne = "";

		private String country = "";

		private String postalCode = "";

		private String addressLineTwo = "";

		private String province = "";

		private String city = "";

		public AddressBuilder combinedAddress(String combineaddress) {

			combinedAddress = combineaddress != null ? combineaddress.trim() : REPLACESTRING;

			return this;
		}

		public AddressBuilder addressLineOne(String addrlineone) {

			addressLineOne = addrlineone != null ? addrlineone.trim() : REPLACESTRING;

			return this;
		}

		public AddressBuilder country(String addrcountry) {

			country = addrcountry != null ? addrcountry.trim() : REPLACESTRING;

			return this;
		}

		public AddressBuilder postalCode(String addrpostalcode) {

			postalCode = addrpostalcode != null ? addrpostalcode.trim() : REPLACESTRING;

			return this;
		}

		public AddressBuilder addressLineTwo(String addrlinetwo) {

			addressLineTwo = addrlinetwo != null ? addrlinetwo.trim() : REPLACESTRING;

			return this;
		}

		public AddressBuilder province(String addrprovince) {

			province = addrprovince != null ? addrprovince.trim() : REPLACESTRING;

			return this;
		}

		public AddressBuilder city(String addrcity) {

			city = addrcity != null ? addrcity.trim() : REPLACESTRING;

			return this;
		}

		public ELKAddress build() {

			return new ELKAddress(this);
		}

	}

}
