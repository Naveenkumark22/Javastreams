package ca.bell.sda.model.whitespace.mdm;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author Kamalanathan Ranganathan
 */
public class GKMatchingProcess {

	private String stdGkName;

	private String stdAlternateName;

	private String stdNumberEquivalent;

	private String standardizedindicatorEmail = "N";

	private String phone;

	private String standardizedindicatorPhone = "Y";

	private String mail;

	private String url;

	private BBMPartyAddressBObjExt bBMPartyAddressBObjExt;

	private BBMAddressBObjExt bBMAddressBObjExt;

	private List<GKProcessBObj> gKProcessBObj;

	@JsonProperty("stdGkName")
	public String getStdGkName() {
		return this.stdGkName;
	}

	public void setStdGkName(String stdGkName) {
		this.stdGkName = stdGkName;
	}

	@JsonProperty("stdAlternateName")
	public String getStdAlternateName() {
		return this.stdAlternateName;
	}

	public void setStdAlternateName(String stdAlternateName) {
		this.stdAlternateName = stdAlternateName;
	}

	@JsonProperty("stdNumberEquivalent")
	public String getStdNumberEquivalent() {
		return this.stdNumberEquivalent;
	}

	public void setStdNumberEquivalent(String stdNumberEquivalent) {
		this.stdNumberEquivalent = stdNumberEquivalent;
	}

	@JsonProperty("BBMPartyAddressBObjExt")
	public BBMPartyAddressBObjExt getBBMPartyAddressBObjExt() {

		return this.bBMPartyAddressBObjExt;
	}

	public void setBBMPartyAddressBObjExt(BBMPartyAddressBObjExt bBMPartyAddressBObjExt) {

		this.bBMPartyAddressBObjExt = bBMPartyAddressBObjExt;
	}

	@JsonProperty("BBMAddressBObjExt")
	public BBMAddressBObjExt getBBMAddressBObjExt() {

		return this.bBMAddressBObjExt;
	}

	public void setBBMAddressBObjExt(BBMAddressBObjExt bBMAddressBObjExt) {

		this.bBMAddressBObjExt = bBMAddressBObjExt;
	}

	@JsonProperty("standardizedindicatorEmail")
	public String getStandardizedindicatorEmail() {

		return this.standardizedindicatorEmail;
	}

	public void setStandardizedindicatorEmail(String standardizedindicatorEmail) {

		this.standardizedindicatorEmail = standardizedindicatorEmail;
	}

	@JsonProperty("phone")
	public String getPhone() {

		return this.phone;
	}

	public void setPhone(String phone) {

		this.phone = phone;
	}

	@JsonProperty("standardizedindicatorPhone")
	public String getStandardizedindicatorPhone() {

		return this.standardizedindicatorPhone;
	}

	public void setStandardizedindicatorPhone(String standardizedindicatorPhone) {

		this.standardizedindicatorPhone = standardizedindicatorPhone;
	}

	@JsonProperty("mail")
	public String getMail() {

		return this.mail;
	}

	public void setMail(String mail) {

		this.mail = mail;
	}

	@JsonProperty("GKProcessBObj")
	public List<GKProcessBObj> getGKProcessBObj() {

		return this.gKProcessBObj;
	}

	public void setGKProcessBObj(List<GKProcessBObj> gKProcessBObj) {

		this.gKProcessBObj = gKProcessBObj;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

}
