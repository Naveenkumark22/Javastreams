/**
 *
 */
package ca.bell.sda.util;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import ca.bell.sda.config.AppConfig;
import ca.bell.sda.constant.log.LogKey;
import ca.bell.sda.model.Request;
import ca.bell.sda.model.whitespace.RequestInputDetail;

/**
 * @author Kamalanathan Ranganathan
 */
@Component
public class JSONParser {

	private static final List<String> GKNAMELIST = Arrays.asList("MAINGK");

	private static final Map<Integer, String> CONTACTMETHOD = new HashMap<>() {

		private static final long serialVersionUID = 1L;

		{
			put(1, "tn");
			put(2, "email");
			put(4, "url");
		}
	};

	@Autowired
	private AppConfig appConfig;

	private Map<String, String> partyids;

	// Parsing Input object
	public RequestInputDetail parseInput(Request request, Map<String, Object> value) throws Exception {

		try {

			partyids = appConfig.getAttributesConfig().getDataAttributes().get(request.getReqId()).get("partyids")
					.getKeyPairs();

			RequestInputDetail requestDetail = new RequestInputDetail();

			Map<String, Object> obj = getOrgJSONObject(value);

			// Extracting Org Name
			Map<String, String> names = getOrgName(obj);

			requestDetail.setOrganizationName(names.get("organizationName"));

			if (names.containsKey("stdAlternateName"))
				requestDetail.setStdAlternateName(names.get("stdAlternateName"));

			// Extracting Org Contact methods
			requestDetail.setContactMethodMap(getOrgContactMethods(obj));

			// Extracting Org Address
			requestDetail.setAddress(getOrgAddress(obj));

			// Extracting Org SK Id
			requestDetail.setAdminPartyId(getOrgSKId(obj));

			requestDetail.setProfileType(getProfileType(obj));

			requestDetail.setFranchiseFlag(getFranchiseFlag(obj));

			requestDetail.setPartyIDMap(getPartyID(obj, partyids));
			
			requestDetail.setStdFlag((String)obj.get("StandardizedFlag"));
			
			request.getRequestMap().put("standardizedFlag",obj.get("StandardizedFlag"));
			
			request.getRequestMap().put("suspectType",obj.get("SuspectType"));

			return requestDetail;

		} catch (Exception e) {

			request.log(LogKey.REQ_LOG_EX_MSG, "JSON Parser : " + e.getMessage());

			request.log(LogKey.REQ_LOG_EX, e);

			throw new Exception("JSON Parser : " + e.getMessage());
		}
	}

	@SuppressWarnings("unchecked")
	private Map<String, Object> getOrgJSONObject(Map<String, Object> value) throws Exception {

		Map<String, Object> _TCRMOrganizationBObj = null;

		try {

			if (value.containsKey("BBMAccountBObj")) {

				Map<String, Object> _BBMAccountBObj = (Map<String, Object>) value.get("BBMAccountBObj");

				if (_BBMAccountBObj.containsKey("TCRMOrganizationBObj")) {

					_TCRMOrganizationBObj = (Map<String, Object>) _BBMAccountBObj.get("TCRMOrganizationBObj");
				}
			}

		} catch (Exception e) {

			throw e;
		}

		return _TCRMOrganizationBObj;
	}

	@SuppressWarnings("unchecked")
	private Map<String, String> getOrgName(Map<String, Object> orgObject) throws Exception {

		Map<String, String> _OrganizationName = new HashMap<>();

		try {

			if (orgObject != null) {

				if (orgObject.containsKey("TCRMOrganizationNameBObj")) {

					Object _TCRMOrganizationNameBObj = orgObject.get("TCRMOrganizationNameBObj");

					if (_TCRMOrganizationNameBObj instanceof Map) {

						Map<String, Object> jobj = (Map<String, Object>) _TCRMOrganizationNameBObj;

						if (_TCRMOrganizationNameBObj != null && jobj.containsKey("OrganizationName")) {

							_OrganizationName.put("organizationName", (String) jobj.get("OrganizationName"));
						}

					} else if (_TCRMOrganizationNameBObj instanceof List) {

						List<Map<String, Object>> jobj = (List<Map<String, Object>>) _TCRMOrganizationNameBObj;

						for (int i = 0; i < jobj.size(); i++) {

							Map<String, Object> obj = (Map<String, Object>) jobj.get(i);

							if (obj != null && obj.containsKey("OrganizationName")) {

								if (obj.containsKey("NameUsageType")) {

									String type = Utility.getAsString(obj.get("NameUsageType"));

									if (type.equals("2000001"))
										_OrganizationName.put("stdAlternateName", (String) obj.get("OrganizationName"));
									else if (type.equals("1000008") || type.equals("1000018"))
										_OrganizationName.put("organizationName", (String) obj.get("OrganizationName"));

								} else {

									_OrganizationName.put("organizationName", (String) obj.get("OrganizationName"));
								}
							}

						}

					}

				}
			}

		} catch (Exception e) {

			throw e;
		}

		return _OrganizationName;

	}

	@SuppressWarnings("unchecked")
	private Map<String, String> getOrgContactMethods(Map<String, Object> orgObject) throws Exception {

		Map<String, String> contacts = new HashMap<>();

		try {

			if (orgObject != null && orgObject.containsKey("TCRMPartyContactMethodBObj")) {

				Object obj = orgObject.get("TCRMPartyContactMethodBObj");

				if (obj != null) {

					List<Map<String, Object>> _TCRMPartyContactMethodBObj = null;

					if (obj instanceof Map) {

						if (orgObject.containsKey("TCRMPartyContactMethodBObj")) {

							Map<String, Object> __TCRMPartyContactMethodBObj = (Map<String, Object>) orgObject
									.get("TCRMPartyContactMethodBObj");

							_TCRMPartyContactMethodBObj = new ArrayList<>();

							_TCRMPartyContactMethodBObj.add(__TCRMPartyContactMethodBObj);
						}

					} else if (obj instanceof List) {

						_TCRMPartyContactMethodBObj = (List<Map<String, Object>>) orgObject
								.get("TCRMPartyContactMethodBObj");
					}

					if (_TCRMPartyContactMethodBObj != null) {

						int size = _TCRMPartyContactMethodBObj.size();

						for (int i = 0; i < size; i++) {

							Map<String, Object> contactMethod = (Map<String, Object>) _TCRMPartyContactMethodBObj
									.get(i);

							if (contactMethod != null && contactMethod.containsKey("TCRMContactMethodBObj")) {

								Map<String, Object> contact = (Map<String, Object>) contactMethod
										.get("TCRMContactMethodBObj");

								if (contact != null && contact.containsKey("ReferenceNumber")) {

									Object rf = contact.get("ReferenceNumber");

									if (contact.containsKey("ContactMethodType")) {

										Object contactModeObj = contact.get("ContactMethodType");

										if (rf != null && contactModeObj != null) {

											contacts.put(CONTACTMETHOD.get(contactModeObj), rf.toString());

										}
									} else {

										if (rf != null) {

											contacts.put(CONTACTMETHOD.get(1), rf.toString());

										}
									}

								}

							}

						}
					}
				}
			}

		} catch (Exception e) {

			throw e;
		}

		return contacts;
	}

	@SuppressWarnings("unchecked")
	private Map<String, String> getOrgAddress(Map<String, Object> orgObject) throws Exception {

		Map<String, String> address = new HashMap<String, String>();

		try {

			if (orgObject != null) {

				if (orgObject.containsKey("TCRMPartyAddressBObj")) {

					Map<String, Object> _TCRMPartyAddressBObj = (Map<String, Object>) orgObject
							.get("TCRMPartyAddressBObj");

					if (_TCRMPartyAddressBObj != null && _TCRMPartyAddressBObj.containsKey("TCRMAddressBObj")) {

						Map<String, Object> _TCRMAddressBObj = (Map<String, Object>) _TCRMPartyAddressBObj
								.get("TCRMAddressBObj");

						if (_TCRMAddressBObj != null) {

							address.put("AddressLineOne", getJSONValue(_TCRMAddressBObj, "AddressLineOne"));

							address.put("City", getJSONValue(_TCRMAddressBObj, "City"));

							address.put("ZipPostalCode", getJSONValue(_TCRMAddressBObj, "ZipPostalCode"));
													
							address.put("ProvinceStateValue",getJSONValue(_TCRMAddressBObj,"ProvinceStateValue"));

							address.put("CountryValue",getJSONValue(_TCRMAddressBObj, "CountryValue"));
							
						}
					}
				}
			}

		} catch (Exception e) {

			throw e;
		}

		return address;
	}

	@SuppressWarnings("unchecked")
	private String getOrgSKId(Map<String, Object> orgObject) throws Exception {

		String ret = "";
		// Long l = Long.valueOf(0);

		try {

			if (orgObject != null && orgObject.containsKey("TCRMAdminContEquivBObj")) {

				Map<String, Object> _TCRMAdminContEquivBObj = (Map<String, Object>) orgObject
						.get("TCRMAdminContEquivBObj");

				if (_TCRMAdminContEquivBObj != null && _TCRMAdminContEquivBObj.containsKey("AdminPartyId")) {

					ret = getJSONValue(_TCRMAdminContEquivBObj, "AdminPartyId");
				}
			}

		} catch (Exception e) {

			e.printStackTrace();

			throw e;
		}

		ret = ret.equals("0") ? "" : ret;

		// logs.log(LogEvent.REQ_KEYS, ret);

		return ret;
	}

	@SuppressWarnings("unchecked")
	private String getProfileType(Map<String, Object> orgObject) throws Exception {

		String ret = "GK";
		// Long l = Long.valueOf(0);

		try {

			if (orgObject != null && orgObject.containsKey("TCRMAdminContEquivBObj")) {

				Map<String, Object> _TCRMAdminContEquivBObj = (Map<String, Object>) orgObject
						.get("TCRMAdminContEquivBObj");

				if (_TCRMAdminContEquivBObj != null && _TCRMAdminContEquivBObj.containsKey("Description")) {

					ret = getJSONValue(_TCRMAdminContEquivBObj, "Description");
				}
			}

		} catch (Exception e) {

			e.printStackTrace();

			throw e;
		}

		ret = getASProfileName(ret).toUpperCase();

		// logs.log(LogEvent.REQ_KEYS, ret);

		return ret;
	}

	@SuppressWarnings("unchecked")
	private String getFranchiseFlag(Map<String, Object> orgObject) throws Exception {

		String ret = null;

		try {

			if (orgObject != null) {

				if (orgObject.containsKey("TCRMAdminContEquivBObj")) {

					Map<String, Object> _TCRMAdminContEquivBObj = (Map<String, Object>) orgObject
							.get("TCRMAdminContEquivBObj");

					if (_TCRMAdminContEquivBObj.containsKey("TCRMExtension")) {

						Map<String, Object> _TCRMExtension = (Map<String, Object>) _TCRMAdminContEquivBObj
								.get("TCRMExtension");

						if (_TCRMExtension.containsKey("BBMContEquivBObjExt")) {

							Map<String, Object> _BBMContEquivBObjExt = (Map<String, Object>) _TCRMExtension
									.get("BBMContEquivBObjExt");

							if (_BBMContEquivBObjExt.containsKey("FranchiseFlag")) {

								ret = getJSONValueNULL(_BBMContEquivBObjExt, "FranchiseFlag");
							}
						}

					}
				}
			}

		} catch (Exception e) {

			e.printStackTrace();

			throw e;
		}

		if (ret != null)
			ret = ret.equalsIgnoreCase("y") ? "Y" : "N";

		return ret;
	}

	@SuppressWarnings("unchecked")
	private Map<Long, String> getPartyID(Map<String, Object> orgObject, Map<String, String> keypair) throws Exception {

		Map<Long, String> partyIDs = new HashMap<>();

		try {
			// TCRMPartyIdentificationBObj
			if (orgObject != null && orgObject.containsKey("TCRMPartyIdentificationBObj")) {

				List<Map<String, Object>> _TCRMPartyIdentificationBObj = (List<Map<String, Object>>) orgObject
						.get("TCRMPartyIdentificationBObj");

				if (_TCRMPartyIdentificationBObj != null) {

					int size = _TCRMPartyIdentificationBObj.size();

					for (int i = 0; i < size; i++) {

						Map<String, Object> partyid = (Map<String, Object>) _TCRMPartyIdentificationBObj.get(i);

						if (partyid != null && partyid.containsKey("IdentificationType")
								&& partyid.containsKey("IdentificationNumber")) {

							String pid = partyid.get("IdentificationType") + "";

							if (keypair.containsKey(pid))
								partyIDs.put(Utility.getAsLong(partyid.get("IdentificationType")),
										Utility.getAsString(partyid.get("IdentificationNumber")));
						}

					}
				}
			}

		} catch (Exception e) {

			throw e;
		}

		return partyIDs;
	}

	private String getASProfileName(String profile) {

		String ret = "GK";

		if (profile != null && profile.trim().length() > 0) {

			ret = GKNAMELIST.contains(profile.trim().toUpperCase()) ? "GK" : "SK";
		}

		return ret;
	}

	private static String getJSONValue(Map<String, Object> jsonObject, String key) throws Exception {

		String ret = "";

		if (jsonObject != null) {

			if (jsonObject.containsKey(key)) {

				Object obj = jsonObject.get(key);

				ret = Utility.getAsString(obj);
			}
		}
		return ret;
	}

	private static String getASValue(Map<String, String> cheetSheet, Map<String, Object> jsonObject, String key)
			throws Exception {

		String value = getJSONValue(jsonObject, key);

		String str = "";

		if (isDigit(value) && cheetSheet != null && cheetSheet.size() > 0)
			str = cheetSheet.get(value);
		else
			str = value.trim();

		return str;

	}

	public static boolean isDigit(String value) {

		if (value != null && value.trim().length() > 0) {

			String regex = "[0-9]+";

			Pattern p = Pattern.compile(regex);

			Matcher m = p.matcher(value.trim());

			return m.matches();
		} else
			return false;

	}

	private static String getJSONValueNULL(Map<String, Object> jsonObject, String key) throws Exception {

		String ret = null;

		if (jsonObject != null) {

			if (jsonObject.containsKey(key)) {

				Object obj = jsonObject.get(key);

				ret = Utility.getAsString(obj);
			}
		}
		return ret;
	}

}
