package ca.bell.sda.constant.query;

import java.util.HashMap;
import java.util.Map;

public class QueryBoolCondition {

	public static final int SHOULD = 1;
	public static final int MUST = 2;
	public static final String AND = "and";
	public static final String OR = "or";
	public static final int MUST_NOT = 3;
	private static Map<Object, String> _BOOL_MAP;

	static {
		_BOOL_MAP = new HashMap<Object, String>();
		_BOOL_MAP.put(MUST, "must");
		_BOOL_MAP.put(SHOULD, "should");
		_BOOL_MAP.put(AND, "must");
		_BOOL_MAP.put(OR, "should");
		_BOOL_MAP.put(MUST_NOT, "must_not");
	}

	public static String getBoolCondition(Object condition) {
		return _BOOL_MAP.get(condition);
	}
}
