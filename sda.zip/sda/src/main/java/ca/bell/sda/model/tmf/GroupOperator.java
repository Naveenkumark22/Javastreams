package ca.bell.sda.model.tmf;

public class GroupOperator {

	public static final String AND = "and";
	public static final String OR = "or";
}
