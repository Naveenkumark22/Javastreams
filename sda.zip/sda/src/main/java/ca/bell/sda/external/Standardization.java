package ca.bell.sda.external;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamConstants;
import javax.xml.stream.XMLStreamReader;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import ca.bell.sda.config.AppConfig;
import ca.bell.sda.constant.log.LogKey;
import ca.bell.sda.model.Request;
import ca.bell.sda.model.config.Endpoint;
import ca.bell.sda.model.whitespace.ELKAddress;
import ca.bell.sda.model.whitespace.RequestInputDetail;
import ca.bell.sda.model.whitespace.STDAddress;
import ca.bell.sda.util.Freemaker;
import ca.bell.sda.util.WebService;

/**
 * @author Kamalanathan Ranganathan
 */

@Service
public class Standardization {

	@Autowired
	private AppConfig appConfig;

	@Autowired
	private WebService webService;

	private WebClient wc;

	@Autowired
	private Freemaker freemaker;

	private static final String STD_AA_NAME = "nameAAStand";

	// private static final String STD_WS_NAME = "contactStand";

	private static final String STD_WS_CONTACT = "contactStand";

	private static final String STD_WS_ADDRESS = "addressStand";

	private List<String> nameKeys = Arrays.asList("stdGkName","stdAlternateName","stdNumberEquivalent","stdGkNameAA", "stdAlternateNameAA", "stdAddresslineOneAA",
			"stdCityAA", "stdPostalCodeAA", "stdProvinceAA", "stdCountryAA");

	private List<String> contactKeys = Arrays.asList("tn", "email", "url");

	private List<String> addressKeys = Arrays.asList("addresslineone_formatted", "addresslinetwo_formatted",
			"addresslinethree_formatted", "residencenumber_formatted", "cityname_formatted",
			"stateabbreviation_formatted", "fullpostalcode_formatted", "streetnumber_formatted", "streetname_formatted",
			"streetsuffix_formatted", "postdirectional_formatted", "predirectional_formatted", "countryname_formatted",
			"latitude", "longitude", "addresssource", "matchType", "fulladdress");

	@Async("asyncExecutor")
	public CompletableFuture<RequestInputDetail> getStandardizedName(Request request, RequestInputDetail orgDetail)
			throws Exception {

		if (orgDetail != null) {

			try {

				String url = getAsURL(STD_AA_NAME);

				String req = getNameReqXML(orgDetail);

				request.log(LogKey.STD_REQ_NAMEAA, req);
				String nameStd = getStandardizedDetailFromRemote(request, url, req);

				request.log(LogKey.STD_RES_NAMEAA, nameStd);
				return CompletableFuture.completedFuture(parseAAName(nameStd));

			} catch (Exception e) {

				request.log(LogKey.REQ_LOG_EX_MSG, "Standardization : Name : " + e.getMessage());

				request.log(LogKey.REQ_LOG_EX, e);

				throw new Exception("Standardization : Name : " + e.getMessage());
			}
		}
		return null;
	}
	
	public RequestInputDetail getStandardizedName(Request request, RequestInputDetail orgDetail,
			STDAddress stdAddress) throws Exception {
		
		if (orgDetail != null&&stdAddress!=null) {

			try {

				String url = getAsURL(STD_AA_NAME);
                String req = getNameReqXML(orgDetail,stdAddress);
                //request.log(LogKey.STD_REQ_NAMEAA, req);
				String nameStd = getStandardizedDetailFromRemote(request, url, req);
				//request.log(LogKey.STD_RES_NAMEAA, nameStd);
				return parseAAName(nameStd);

			} catch (Exception e) {

				request.log(LogKey.REQ_LOG_EX_MSG, "Standardization : Name : " + e.getMessage());

				request.log(LogKey.REQ_LOG_EX, e);

				throw new Exception("Standardization : Name : " + e.getMessage());
			}
		}
		return null;
	}

	

	@Async("asyncExecutor")
	public CompletableFuture<RequestInputDetail> getStandardizedContactMethods(Request request,
			RequestInputDetail orgDetail) throws Exception {

		if (orgDetail != null) {

			try {

				String url = getAsURL(STD_WS_CONTACT);

				String contactStd = "";

				if (!orgDetail.isContactTNEmpty() || !orgDetail.isContactEmailEmpty()) {

					String contactxml = getContactReqXML(orgDetail);

					//request.log(LogKey.STD_REQ_CONTACTWS, contactxml);

					contactStd = getStandardizedDetailFromRemote(request, url, contactxml);

					//request.log(LogKey.STD_RES_CONTACTWS, contactStd);
				}

				return CompletableFuture.completedFuture(parseContact(contactStd));

			} catch (Exception e) {

				e.printStackTrace();

				request.log(LogKey.REQ_LOG_EX_MSG, "Standardization : Contact : " + e.getMessage());

				request.log(LogKey.REQ_LOG_EX, e);

				throw new Exception("Standardization : Contact : " + e.getMessage());
			}
		}
		return null;
	}

	@Async("asyncExecutor")
	public CompletableFuture<STDAddress> getStandardizedAddress(Request request, RequestInputDetail orgDetail)
			throws Exception {

		if (orgDetail != null) {

			try {

				String url = getAsURL(STD_WS_ADDRESS);

				String addrStd = "";

				if (!orgDetail.isAddressEmpty()) {

					String addrxml = getAddressReqXML(orgDetail);

					//request.log(LogKey.STD_REQ_ADDRWS, addrxml);

					addrStd = getStandardizedDetailFromRemote(request, url, addrxml);

					//request.log(LogKey.STD_RES_ADDRWS, addrStd);

				}
				return CompletableFuture.completedFuture(parseAddress(addrStd));

			} catch (Exception e) {

				e.printStackTrace();

				request.log(LogKey.REQ_LOG_EX_MSG, "Standardization : Address : " + e.getMessage());

				request.log(LogKey.REQ_LOG_EX, e);

				throw new Exception("Standardization : Address : " + e.getMessage());
			}
		}

		return null;
	}

	private String getNameReqXML(RequestInputDetail orgDetail) throws Exception {

		Map<String, Object> name = new HashMap<>();

		name.put("customerName", getXMLString(orgDetail.getOrganizationName()));

		Map<String, String> address = orgDetail.getAddress();

		name.put("addresslineOne", getValue(address.get("AddressLineOne")));

		name.put("city", getValue(address.get("City")));

		name.put("postalCode", getValue(address.get("ZipPostalCode")));

		name.put("province", getValue(address.get("ProvinceStateValue")));

		name.put("country", getValue(address.get("CountryValue")));

		String str = freemaker.generateByTemplate("STD_Name_AA_XML", name);

		return str;

	}
	
	private String getNameReqXML(RequestInputDetail orgDetail,STDAddress stdAddress) throws Exception {

		Map<String, Object> name = new HashMap<>();

		name.put("customerName", getXMLString(orgDetail.getOrganizationName()));

		//Map<String, String> address = orgDetail.getAddress();
		
		name.put("addresslineOne", getValue(stdAddress.getAddresslineone_formatted()));

		name.put("city", getValue(stdAddress.getCityname_formatted()));

		name.put("postalCode", getValue(stdAddress.getFullpostalcode_formatted()));

		name.put("province", getValue(stdAddress.getStateabbreviation_formatted()));

		name.put("country", getValue(stdAddress.getCountryname_formatted()));

		String str = freemaker.generateByTemplate("STD_Name_AA_XML", name);

		return str;

	}

	private String getXMLString(String value) throws Exception {

		return value == null ? ""
				: value.trim().replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;");

	}

	private String getContactReqXML(RequestInputDetail orgDetail) throws Exception {

		String email = orgDetail.getContactMethodMap().get("email");

		String tn = orgDetail.getContactMethodMap().get("tn");

		Map<String, Object> name = new HashMap<>();

		name.put("orgname", "");

		name.put("tn", tn == null ? "" : tn.trim());

		name.put("email", email == null ? "" : email.trim());

		return freemaker.generateByTemplate("STD_Name_Contact_XML", name);
	}

	private String getAddressReqXML(RequestInputDetail orgDetail) throws Exception {

		Map<String, Object> addr = new HashMap<>();

		Map<String, String> address = orgDetail.getAddress();

		addr.put("AddressLineOne", address.get("AddressLineOne") == null ? "" : address.get("AddressLineOne").trim());

		addr.put("City", address.get("City") == null ? "" : address.get("City").trim());

		addr.put("ZipPostalCode", address.get("ZipPostalCode") == null ? "" : address.get("ZipPostalCode").trim());

		addr.put("ProvinceStateValue", getAsValid(address.get("ProvinceStateValue")));

		addr.put("CountryValue", getAsValid(address.get("CountryValue")));

		return freemaker.generateByTemplate("STD_Address_XML", addr);

	}

	private String getAsValid(String value) {

		String ret = "";

		if (value != null && value.trim().length() > 0) {

			String regex = "[0-9]+";

			Pattern p = Pattern.compile(regex);

			Matcher m = p.matcher(value.trim());

			if (!m.matches())
				ret = value.trim();
		}
		return ret;
	}

	private String getStandardizedDetailFromRemote(Request request, String url, String reqXML) throws Exception {

		if (wc == null) {
			wc = webService.getWebClient_Default();
		}
		try {
			
			return wc.post().uri(url).header("Content-Type", "text/xml;charset=utf-8").bodyValue(reqXML).retrieve()
					.bodyToMono(String.class).block();
		} catch (Exception e) {
			e.printStackTrace();

			request.log(LogKey.REQ_LOG_EX_MSG, " Server Error : " + e.getMessage());

			request.log(LogKey.REQ_LOG_EX, e);

			throw e;
		}
	}
		private Map<String, String> readXMLForNameStd(String resXMLStr) throws Exception {		
				Map<String, String> nameMap = new HashMap<>();
				DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();		
				InputStream inpStreamOne = new ByteArrayInputStream(resXMLStr.getBytes());
				Document doc = builder.parse(inpStreamOne);
				doc.getDocumentElement().normalize();		
				 Node first = doc.getElementsByTagName("standardizeWhiteSpaceNameResult").item(0);
				    NodeList nodeList = first.getChildNodes();
				    int n = nodeList.getLength();
				    Node current;
				    for (int i=0; i<n; i++) {
				        current = nodeList.item(i);
				        if(current.getNodeType() == Node.ELEMENT_NODE) {
				              nameMap.put(current.getNodeName(),current.getTextContent());
				        }
				    }
					return nameMap;		
			}
	

	private RequestInputDetail parseAAName(String xml) throws Exception {

		if (xml.trim().length() == 0)
			return new RequestInputDetail();

		Map<String, String> values = readXMLForNameStd(xml);

		RequestInputDetail org = new RequestInputDetail();

		try {

			Iterator<Map.Entry<String, String>> itr = values.entrySet().iterator();

			ELKAddress addr = new ELKAddress();

			while (itr.hasNext()) {

				Map.Entry<String, String> entry = itr.next();

				String key = entry.getKey().trim();

				String value = entry.getValue();

				if (key.trim().equals("stdGkName")) {

					org.setOrganizationName(getValue(value));

				}else if (key.trim().equals("stdNumberEquivalent")) {

					org.setStdNumberEquivalent(getValue(value));

				} else if (key.trim().equals("stdAlternateName")) {

					org.setStdAlternateName(getValue(value));

				}else if (key.trim().equals("stdGkNameAA")) {

					org.setOrganizationAAName(getValue(value));

				}
				else if (key.trim().equals("stdNumberEquivalentAA")) {

					org.setStdAANumberEquivalent(getValue(value));

				} else if (key.trim().equals("stdAlternateNameAA")) {

					org.setStdAAAlternateName(getValue(value));

				} else if (key.trim().equals("stdAddresslineOneAA")) {

					addr.setAddressLineOne(getValue(value));

				} else if (key.trim().equals("stdCityAA")) {

					addr.setCity(getValue(value));

				} else if (key.trim().equals("stdPostalCodeAA")) {

					addr.setPostalCode(getValue(value));
					

				} else if (key.trim().equals("stdProvinceAA")) {

					addr.setProvince(getValue(value));

				} else if (key.trim().equals("stdCountryAA")) {

					addr.setCountry(getValue(value));

				}

			}

			org.setStdaddressAA(addr);

		} catch (Exception e) {

			e.printStackTrace();

			throw e;
		}

		return org;
	}

	private RequestInputDetail parseContact(String xml) throws Exception {

		if (xml.trim().length() == 0)
			return new RequestInputDetail();

		Map<String, String> values = readXML(xml, contactKeys);

		RequestInputDetail org = new RequestInputDetail();

		try {

			Iterator<Map.Entry<String, String>> itr = values.entrySet().iterator();

			Map<String, String> contacts = new HashMap<>();

			while (itr.hasNext()) {

				Map.Entry<String, String> entry = itr.next();

				String key = entry.getKey().trim();

				String value = entry.getValue();

				if (key.trim().equals("stdTnIndicator")) {

					contacts.put("stdTnIndicator", getValue(value));

				} else if (key.trim().equals("tn")) {

					contacts.put("tn", getValue(value));

				} else if (key.trim().equals("email")) {

					contacts.put("email", getValue(value));

				} else if (key.trim().equals("url")) {

					contacts.put("url", getValue(value));

				}

			}

			org.setContactMethodMap(contacts);

		} catch (Exception e) {

			e.printStackTrace();

			throw e;
		}

		return org;
	}

	private STDAddress parseAddress(String xml) throws Exception {

		if (xml.trim().length() == 0)
			return new STDAddress();

		STDAddress stdAddress = new STDAddress();

		Map<String, String> values = readXML(xml, addressKeys);

		try {

			Iterator<Map.Entry<String, String>> itr = values.entrySet().iterator();

			while (itr.hasNext()) {

				Map.Entry<String, String> entry = itr.next();

				String key = entry.getKey().trim();

				String value = entry.getValue();

				if (key.trim().equals("addresslineone_formatted")) {

					stdAddress.setAddresslineone_formatted(getValue(value));

				} else if (key.trim().equals("addresslinetwo_formatted")) {

					stdAddress.setAddresslinetwo_formatted(getValue(value));

				} else if (key.trim().equals("addresslinethree_formatted")) {

					stdAddress.setAddresslinethree_formatted(getValue(value));

				} else if (key.trim().equals("residencenumber_formatted")) {

					stdAddress.setResidencenumber_formatted(getValue(value));

				} else if (key.trim().equals("cityname_formatted")) {

					stdAddress.setCityname_formatted(getValue(value));

				} else if (key.trim().equals("stateabbreviation_formatted")) {

					stdAddress.setStateabbreviation_formatted(getValue(value));

				} else if (key.trim().equals("fullpostalcode_formatted")) {

					stdAddress.setFullpostalcode_formatted(getValue(value));

				} else if (key.trim().equals("streetnumber_formatted")) {

					stdAddress.setStreetnumber_formatted(getValue(value));

				} else if (key.trim().equals("streetname_formatted")) {

					stdAddress.setStreetname_formatted(getValue(value));

				} else if (key.trim().equals("streetsuffix_formatted")) {

					stdAddress.setStreetsuffix_formatted(getValue(value));

				} else if (key.trim().equals("postdirectional_formatted")) {

					stdAddress.setPostdirectional_formatted(getValue(value));

				} else if (key.trim().equals("predirectional_formatted")) {

					stdAddress.setPredirectional_formatted(getValue(value));

				} else if (key.trim().equals("countryname_formatted")) {

					stdAddress.setCountryname_formatted(getValue(value));

				} else if (key.trim().equals("latitude")) {

					stdAddress.setLatitude(getValue(value));

				} else if (key.trim().equals("longitude")) {

					stdAddress.setLongitude(getValue(value));

				} else if (key.trim().equals("addresssource")) {

					stdAddress.setAddresssource(getValue(value));

				} else if (key.trim().equals("matchType")) {

					stdAddress.setMatchType(getValue(value));

				} else if (key.trim().equals("fulladdress")) {

					stdAddress.setOnelineAddress_formatted(getValue(value));
				}

			}

		} catch (Exception e) {

			e.printStackTrace();

			throw e;
		}

		return stdAddress;

	}

	private String getValue(String value) throws Exception {

		return value != null ? value.trim() : "";

	}

	private String getAsURL(String configName) throws Exception {

		String url = "";

		Endpoint endPoint = appConfig.getAppProps().getServers().getWebService().getEndPoints().get(configName);

		if (endPoint != null)
			url = endPoint.getHost() + endPoint.getUrl();

		return url;

	}

	private Map<String, String> readXML(String resXMLStr, List<String> taglist) throws Exception {

		if (resXMLStr != null && resXMLStr.trim() != "") {

			Map<String, String> nameMap = new HashMap<>();

			InputStream inpStream = new ByteArrayInputStream(resXMLStr.getBytes());

			XMLInputFactory xmlFac = XMLInputFactory.newDefaultFactory();

			XMLStreamReader xmlReader = xmlFac.createXMLStreamReader(inpStream);

			while (xmlReader.hasNext()) {

				xmlReader.next();

				if (xmlReader.getEventType() == XMLStreamConstants.START_ELEMENT) {

					if (isContain(xmlReader.getName().toString(), taglist)) {

						String nodeName = xmlReader.getName().toString();

						int attrbCnt = xmlReader.getAttributeCount();

						boolean nil = false;

						for (int i = 0; i < attrbCnt; i++) {

							if (xmlReader.getAttributeLocalName(i).equalsIgnoreCase("nil")) {

								nil = Boolean.getBoolean(xmlReader.getAttributeValue(i));

							}
						}

						if (!nil) {

							xmlReader.next();

							if (xmlReader.getEventType() == XMLStreamConstants.CHARACTERS) {

								String n = nodeName.replace("{http://MDMQSService.MDMQS.isd.ibm.com/soapoverhttp/}",
										"");

								nameMap.put(n, xmlReader.getText());
							}
						}
					}

					if (nameMap.size() == taglist.size()) {
						break;
					}
				}
			}

			return nameMap;
		} else {
			return null;
		}
	}

	private boolean isContain(String value, List<String> keyList) {

		boolean ret = false;

		for (Iterator<String> iterator = keyList.iterator(); iterator.hasNext();) {

			String str = iterator.next();

			ret = value.toUpperCase().contains(str.toUpperCase());

			if (ret)
				break;

		}

		return ret;
	}

	

	
}
