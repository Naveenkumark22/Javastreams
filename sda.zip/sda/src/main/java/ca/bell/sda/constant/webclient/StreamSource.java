package ca.bell.sda.constant.webclient;

public class StreamSource {
	public static final String INDEX="index";

}
