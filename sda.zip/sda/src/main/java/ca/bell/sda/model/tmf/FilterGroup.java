package ca.bell.sda.model.tmf;

import java.util.List;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;



public class FilterGroup {

	@Valid
	@NotNull(message = "Atleast 1 attribute filter is needed")
	private List<AttributeFilter> filter;

	@Pattern(regexp = "and|or", flags = Pattern.Flag.CASE_INSENSITIVE, message= "Invalid Group Operator")
	private String groupOperator;

	public List<AttributeFilter> getFilter() {
		return filter;
	}

	public void setFilter(List<AttributeFilter> filter) {
		this.filter = filter;
	}

	public String getGroupOperator() {
		return groupOperator;
	}

	public void setGroupOperator(String groupOperator) {
		this.groupOperator = groupOperator;
	}

}
