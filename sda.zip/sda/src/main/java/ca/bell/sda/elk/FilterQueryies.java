package ca.bell.sda.elk;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Component;

@Component
public class FilterQueryies {

	public static Map<String, Object> getTermQuery(String attrb, String value) {
		Map<String, String> termField = new HashMap<>();
		termField.put(attrb, value);

		Map<String, Object> term = new HashMap<>();
		term.put("term", termField);

		return term;
	}

	public static Map<String, Object> getNestedTermQuery(String attrb, String path, String value) {
		Map<String, Object> rootMap = new HashMap<>();
		Map<String, Object> nested = new HashMap<>();
		Map<String, Object> query = new HashMap<>();
		Map<String, Object> term = new HashMap<>();
		Map<String, Object> emptyMap = new HashMap<>();

		term.put(attrb, value);
		query.put("term", term);
		nested.put("path", path);
		nested.put("query", query);
		nested.put("inner_hits", emptyMap);
		rootMap.put("nested", nested);

		return rootMap;
	}
}
