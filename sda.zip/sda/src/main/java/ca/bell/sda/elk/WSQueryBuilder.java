/**
 *
 */
package ca.bell.sda.elk;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import ca.bell.sda.model.whitespace.StdOrgRecord;
import ca.bell.sda.util.Freemaker;

/**
 * @author Kamalanathan Ranganathan
 */
@Component
public class WSQueryBuilder {

	private static final String FIRST_CALL_QUERY_SINGLE_NAME_FTL = "Query_Name_Bucket";

	private static final String FIRST_CALL_QUERY_MULTIPLENAME_FTL = "Query_Multiple_Name_Bucket";

	private static final String SECOND_CALL_QUERY_FTL = "Query_Address_Enrichment";

	private static final String FREQUNCY_CALL_QUERY_FTL = "Query_Freq";

	private static final String FILLING_MISSING_FIELDS_QUERY_FTL = "FillingMissingFields";
	
	private static final String FIRST_CALL_QUERY_MAINGK_FTL = "Query_MainGk_NameBucket";
	
	private static final String FIRST_CALL_QUERY_MAINSK_FTL = "Query_MainSk_NameBucket";

	@Autowired
	private Freemaker freemaker;

	public String getFirstCallQueryString(String matchvalue, String notmatch, String min_score, String from,
			String size) throws Exception {

		Map<String, Object> qrycall1 = new HashMap<>();

		qrycall1.put("min_score", min_score);

		qrycall1.put("from", from);

		qrycall1.put("size", size);

		qrycall1.put("orgname", matchvalue);

		qrycall1.put("notmatch", notmatch);
		return freemaker.generateByTemplate(FIRST_CALL_QUERY_SINGLE_NAME_FTL, qrycall1);
	}

	public String getFirstCallQueryString(StdOrgRecord inputOrgdetail, String index, String min_score, String from,
			String size,String suspectType) throws Exception {

		Map<String, Object> qrycall1 = new HashMap<>();

		qrycall1.put("min_score", min_score);

		qrycall1.put("from", from);

		qrycall1.put("size", size);

		qrycall1.put("index", index);

		qrycall1.put("names", inputOrgdetail.getNames());

		qrycall1.put("id", inputOrgdetail.getGkId());

		qrycall1.put("franchise", inputOrgdetail.getFranchiseFlag());
		
		qrycall1.put("address", inputOrgdetail.getElkAddress().getCombinedAddress());

		if("Gk".equalsIgnoreCase(suspectType)) {
			return freemaker.generateByTemplate(FIRST_CALL_QUERY_MAINGK_FTL, qrycall1);
		}else if("Sk".equalsIgnoreCase(suspectType)) {
			return freemaker.generateByTemplate(FIRST_CALL_QUERY_MAINSK_FTL, qrycall1);
		}else {
		    return freemaker.generateByTemplate(FIRST_CALL_QUERY_MULTIPLENAME_FTL, qrycall1);
		}
	}

	// Second call query building
	public String getSecondCallQueryString(String gk_sk_id, String combinedaddr) throws Exception {

		Map<String, Object> qrycall2 = new HashMap<>();

		qrycall2.put("id", gk_sk_id);

		qrycall2.put("combinedaddress", combinedaddr);
		
		return freemaker.generateByTemplate(SECOND_CALL_QUERY_FTL, qrycall2);
	}

	// Token Frequency query building
	public String getTokenFrequencyQueryString(List<String> common) throws Exception {

		Map<String, Object> matching = new HashMap<>();

		matching.put("tokens", common);

		
		return freemaker.generateByTemplate(FREQUNCY_CALL_QUERY_FTL, matching);
	}

	// Filling missing fields
	public String getFillMissingFieldsQueryString(Map<String, Object> matching) throws Exception {

		String str = freemaker.generateByTemplate(FILLING_MISSING_FIELDS_QUERY_FTL, matching);
		
		return str;
	}

}
