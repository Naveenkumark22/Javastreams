package ca.bell.sda.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ca.bell.sda.config.AppConfig;
import ca.bell.sda.constant.log.LogKey;
import ca.bell.sda.constant.webclient.StreamSource;
import ca.bell.sda.dao.SearchDAO;
import ca.bell.sda.elk.QueryBuilder;
import ca.bell.sda.model.Request;
import ca.bell.sda.model.Response;
import ca.bell.sda.model.elk.Attribute;
import ca.bell.sda.model.elk.SearchQuery;
import ca.bell.sda.model.elk.response.ResponseData;
import ca.bell.sda.process.GetAccountManagementProcessor;


@Service
public class GetAccountManagementService extends CPMService {

	@Autowired
	private AppConfig appConfig;

	@Autowired
	private SearchDAO searchDAO;

	@Autowired
	private GetAccountManagementProcessor dataProcessor;
	
	@Autowired
	private GetCustomerManagementService service;
	
	@Autowired
	private QueryBuilder queryBuilder;

	
	
	public ResponseData getAccountManagement(Request request, Response response, Map<String, Object> requestMap) {
		String eomId = service.getEomAccountId(request, appConfig.getIndexNames(request.getReqId())[1]);
		ResponseData resData = new ResponseData();
		String parent_acct = null;
		if (eomId != null) {
			parent_acct = eomId;
		} else {
			parent_acct = (String) requestMap.get("parent_acct");
		}
		List<Attribute> attrbQueryList = new ArrayList<>();
		attrbQueryList.add(getAttrb(request, "eom_id", parent_acct));

		SearchQuery searchQuery = getSearchQuery(request);
		searchQuery.setMinScore(null);
		searchQuery.setSize("10");
		String index = appConfig.getIndexNames(request.getReqId())[0];
		searchQuery.setQuery(queryBuilder.createSearchQuery(attrbQueryList));

		searchQuery.setSourceFilter(
				appConfig.getAttributesConfig().getDataAttributes().get(request.getReqId()).get("profile").getKeys());

		request.logTime(LogKey.QUERY_BUILD_END);
		try {
			request.log(LogKey.QUERY, searchQuery);
			request.logTime(LogKey.ELK_START);
			Object elkData = searchDAO.querySource(request.getReqId(), StreamSource.INDEX, searchQuery, index,
					request.getQueryConfig().getFilterPath());
			request.logTime(LogKey.ELK_END);
			request.logTime(LogKey.DATA_CONV_START);
			resData = dataProcessor.processData(request, elkData);
			addSuccessLog(request);
		} catch (Exception e) {
			request.log(LogKey.REQ_LOG_EX_MSG, getClass().getName() + e.getMessage());
			addExceptionLog(request,e);
		}
		request.logTime(LogKey.DATA_CONV_END);
		response.setData(resData);
		return resData;
	}
	 
	
	
}
