package ca.bell.sda.model.tmf;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Pattern;

public class AttributeFilter {

	@NotEmpty(message = "Field name is required")
	private String field;

	@NotEmpty(message = "Atleast 1 value required")
	private String[] value;

	@Pattern(regexp = "eq|neq|gt|gte|lt|lte|null|notNull|in|notIn|regex|contains", flags = Pattern.Flag.CASE_INSENSITIVE, message = "Invalid Operator")
	private String operator;
	private boolean caseInsensitive;
	private String dataType;

	public String getField() {
		return field;
	}

	public void setField(String field) {
		this.field = field;
	}

	public String[] getValue() {
		return value;
	}

	public void setValue(String[] value) {
		this.value = value;
	}

	public String getOperator() {
		return operator;
	}

	public void setOperator(String operator) {
		this.operator = operator;
	}

	public boolean isCaseInsensitive() {
		return caseInsensitive;
	}

	public void setCaseInsensitive(boolean caseInsensitive) {
		this.caseInsensitive = caseInsensitive;
	}

	public String getDataType() {
		return dataType;
	}

	public void setDataType(String dataType) {
		this.dataType = dataType;
	}

}
