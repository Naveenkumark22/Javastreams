package ca.bell.sda.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import ca.bell.sda.config.AppConfig;
import ca.bell.sda.constant.log.LogKey;
import ca.bell.sda.constant.status.StatusTypes;
import ca.bell.sda.constant.webclient.StreamSource;
import ca.bell.sda.controller.GetCPMOrgController;
import ca.bell.sda.dao.SearchDAO;
import ca.bell.sda.elk.QueryBuilder;
import ca.bell.sda.model.Request;
import ca.bell.sda.model.Response;
import ca.bell.sda.model.elk.Attribute;
import ca.bell.sda.model.elk.SearchQuery;
import ca.bell.sda.model.elk.response.ResponseData;
import ca.bell.sda.process.AccountDataProcessor;
import ca.bell.sda.process.OrgDataProcessor;

@Service
public class CPMAccountService extends CPMService{

	@Autowired
	private AppConfig appConfig;

	@Autowired
	private SearchDAO searchDAO;
	
	@Autowired
	private AccountDataProcessor dataProcessor;
	
	@Autowired
	private OrgDataProcessor orgDataProcessor;
	
	@Autowired
	private QueryBuilder queryBuilder;
	
	@Autowired
	GetCPMOrgController getOrgController;

	private final static String BAN_FLAG_KEY = "banFlag";
	private final String customerAccountIdKey = "customerAccountId";
	
	public Object getAccount(Request request, Map<String, Object> requestMap) throws Exception {
		String indexName = appConfig.getIndexNames(request.getReqId())[0];
		SearchQuery searchQuery = getSearchQuery(request);
		searchQuery.setMinScore(null);

		request.logTime(LogKey.QUERY_BUILD_END);
		ResponseData resData = null;
		try {
			request.log(LogKey.QUERY, searchQuery);
			request.logTime(LogKey.ELK_START);
			Object elkData = searchDAO.querySource(request.getReqId(), StreamSource.INDEX, searchQuery, indexName,
					request.getQueryConfig().getFilterPath());
			request.logTime(LogKey.ELK_END);
			request.logTime(LogKey.DATA_CONV_START);
			resData = dataProcessor.processData(request, elkData);
			addSuccessLog(request);
		} catch (Exception e) {
			request.log(LogKey.REQ_LOG_EX_MSG, getClass().getName() + e.getMessage());
			addExceptionLog(request,e);
		}
	
		if (resData != null) {
			if (resData.getProfiles() != null && !resData.getProfiles().isEmpty()) {
				Map<String, Map<String, Object>> accountProfileMap = new HashMap<>();
				//List<Map<String, Object>> gkBanList = new ArrayList<>();
				for (Map<String, Object> profile : resData.getProfiles()) {
					if(profile.get("contactMedium")!=null) {
						profile.put("contactAddress", profile.get("contactMedium"));
						profile.remove("contactMedium");
					}
					if(isReqConfigFlag(request, BAN_FLAG_KEY, "yes"))
					{
						List<Attribute> attrbQueryList = new ArrayList<>();
						
						attrbQueryList.add(getAttrb(request, customerAccountIdKey, profile.get("id")));
						attrbQueryList.add(getAttrb(request, "accountType", "billing"));						
						searchQuery = getSearchQuery(request);
						searchQuery.setSize("1000");
						searchQuery.setMinScore(null);
						searchQuery.setSourceFilter(appConfig.getAttributesConfig().getDataAttributes().get(request.getReqId())
								.get("banDetail").getKeys());
						searchQuery.setQuery(queryBuilder.createSearchQuery(attrbQueryList));
						try {
							Object elkData = searchDAO.querySource(request.getReqId(), StreamSource.INDEX, searchQuery, indexName,
									request.getQueryConfig().getFilterPath());
							orgDataProcessor.processBanDetail(profile, elkData);
						} catch (Exception e) {
							request.log(LogKey.REQ_LOG_EX_MSG, e.getMessage());
							e.printStackTrace();
							addExceptionLog(request,e);
						}
					}
				}
				
			}
			//adding GK Profile
			if(isReqConfigFlag(request, "goldenKey")&&isReqConfigFlag(request, BAN_FLAG_KEY, "yes"))
			{
			Map<String, Object> orgRequestMap=new HashMap<String, Object>();
			orgRequestMap.put("id", requestMap.get("goldenKey"));
			orgRequestMap.put("sourceSystem","cpm");
			List<String> filter = new ArrayList<String>();
			filter.add("complete");
			orgRequestMap.put("filter",filter);
			Response orgResponse=getOrgController.getOrgService(new Request("bbm", "GetCPMOrganization"), orgRequestMap);
			if(orgResponse!=null&&orgResponse.getData()!=null&&orgResponse.getData()!=null)
			{
				ResponseData orgRespData= (ResponseData) orgResponse.getData();
				if(orgRespData.getProfile()!=null)
				{
				List<Attribute> attrbQueryList = new ArrayList<>();
				
				attrbQueryList.add(getAttrb(request, "goldenKey", requestMap.get("goldenKey")));
				//attrbQueryList.add(getAttrb(request, customerAccountIdKey, ""));
				attrbQueryList.add(getAttrb(request, "accountType", "billing"));
				searchQuery = getSearchQuery(request);
				searchQuery.setSize("1000");
				searchQuery.setMinScore(null);
				searchQuery.setSourceFilter(appConfig.getAttributesConfig().getDataAttributes().get(request.getReqId())
						.get("banDetail").getKeys());
				searchQuery.setQuery(queryBuilder.createSearchQuery(attrbQueryList));
				try {
					Object elkData = searchDAO.querySource(request.getReqId(), StreamSource.INDEX, searchQuery, indexName,
							request.getQueryConfig().getFilterPath());
					orgDataProcessor.processBanDetail(orgRespData.getProfile(), elkData);
				} catch (Exception e) {
					request.log(LogKey.REQ_LOG_EX_MSG, e.getMessage());
					e.printStackTrace();
					addExceptionLog(request,e);
				}
				}
				if(resData.getProfiles()!=null&&orgRespData.getProfile()!=null)
					resData.getProfiles().add(orgRespData.getProfile());
				else if(orgRespData.getProfile()!=null)
				{
					resData.setProfiles(List.of(orgRespData.getProfile()));
				}
			}
			}
			request.logTime(LogKey.DATA_CONV_END);
		}
		return resData;
	}

}
