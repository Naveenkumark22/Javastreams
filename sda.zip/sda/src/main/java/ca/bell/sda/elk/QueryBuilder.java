package ca.bell.sda.elk;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;

import ca.bell.sda.constant.query.QueryBoolCondition;
import ca.bell.sda.constant.query.QueryMatchType;
import ca.bell.sda.model.config.AttributeProperties;
import ca.bell.sda.model.elk.Attribute;

@Component
public class QueryBuilder {

	public Map<String, Object> createSearchQuery(List<Attribute> queryList) {
		return createSearchQuery(queryList, null);
	}
	
	/**public Map<String, Object> createSearchQuery(List<Attribute> queryList, List<Attribute> filterList) {
		Map<String, Object> rootMap = new HashMap<>();
		List<Object> queryMap = new ArrayList<>();
		List<Object> filterMap = null;
		boolean advancedSearch = false;
		String boolCondition = QueryBoolCondition.getBoolCondition(QueryBoolCondition.MUST);
		for (Attribute attrb : queryList) {
			AttributeProperties attrbProp = attrb.getProperties();
			int attrbBoolCond = attrbProp.getBoolCondition();
			int matchType = attrbProp.getMatchType();

			if (!advancedSearch) {
				advancedSearch = attrbProp.isAdvancedSearch();
			}
			if (attrbProp.isMultiType()) {
				matchType = attrbProp.getMatchTypeMap().get(attrb.getType());
			}
			if (attrbBoolCond != QueryBoolCondition.MUST) {
				boolCondition = QueryBoolCondition.getBoolCondition(attrbBoolCond);
			}
			queryMap.addAll(searchQuery(attrb, boolCondition, matchType));
		}

		if (filterList != null && !filterList.isEmpty()) {
			filterMap = filterQuery(filterList);
		}
		rootMap = buildQuery(boolCondition, queryMap, filterMap, advancedSearch);
		return rootMap;
	}
	**/
	public Map<String, Object> createSearchQuery(List<Attribute> queryList, List<Attribute> filterList) {
		Map<String, Object> rootMap = new HashMap<>();
		boolean advancedSearch = false;
		List<Map<String, Object>> mustQueryList = new ArrayList<Map<String, Object>>();
		List<Map<String, Object>> shouldQueryList = new ArrayList<Map<String, Object>>();
		List<Map<String, Object>> mustNotQueryList = new ArrayList<Map<String, Object>>();
		String boolCondition = QueryBoolCondition.getBoolCondition(QueryBoolCondition.MUST);
		List<Object> filterMap = null;
		for (Attribute attrb : queryList) {
			AttributeProperties attrbProp = attrb.getProperties();
			int attrbBoolCond = attrbProp.getBoolCondition();
			int matchType = attrbProp.getMatchType();

			if (!advancedSearch) {
				advancedSearch = attrbProp.isAdvancedSearch();
			}
			if (attrbProp.isMultiType()) {
				matchType = attrbProp.getMatchTypeMap().get(attrb.getType());
			}
				boolCondition = QueryBoolCondition.getBoolCondition(attrbBoolCond);
				
			if(boolCondition.equalsIgnoreCase(QueryBoolCondition.getBoolCondition(QueryBoolCondition.MUST)))	
			{
				mustQueryList.addAll(searchQuery(attrb, boolCondition, matchType));
			}
			else if(boolCondition.equalsIgnoreCase(QueryBoolCondition.getBoolCondition(QueryBoolCondition.SHOULD)))
			{
				shouldQueryList.addAll(searchQuery(attrb, boolCondition, matchType));
			}
			else if(boolCondition.equalsIgnoreCase(QueryBoolCondition.getBoolCondition(QueryBoolCondition.MUST_NOT)))
			{
				mustNotQueryList.addAll(searchQuery(attrb, boolCondition, matchType));
			}
		}
		
		List<Map<String,Object>> searchQueryList= new ArrayList<Map<String,Object>>();
		if (!mustQueryList.isEmpty())
			searchQueryList.add(getBooleanQuery(QueryBoolCondition.getBoolCondition(QueryBoolCondition.MUST),mustQueryList,false));
		if (!shouldQueryList.isEmpty())
			searchQueryList.add(getBooleanQuery(QueryBoolCondition.getBoolCondition(QueryBoolCondition.SHOULD),shouldQueryList,advancedSearch));
		if (!mustNotQueryList.isEmpty())
			searchQueryList.add(getBooleanQuery(QueryBoolCondition.getBoolCondition(QueryBoolCondition.MUST_NOT),mustNotQueryList,false));
		if (filterList != null && !filterList.isEmpty()) {
			filterMap = filterQuery(filterList);
		}
		Map<String, List<Map<String, Object>>> searchQueryGrp = new HashMap<>();	
		rootMap=buildQuery(searchQueryGrp, searchQueryList, filterMap, advancedSearch);
		return rootMap;
	}
	private Map<String, Object> buildQuery(Map<String, List<Map<String, Object>>> searchQueryGrp,
			List<Map<String, Object>> searchQueryList, List<Object> filterMap, boolean advancedSearch) {
		Map<String, Object> rootMap = new HashMap<>();
		Map<String, Object> boolContextMap = new HashMap<>();
		boolContextMap.put(QueryBoolCondition.getBoolCondition(QueryBoolCondition.MUST),searchQueryList);
		if (filterMap != null) {
			boolContextMap.put("filter", filterMap);
			/*if (advancedSearch) {
				boolContextMap.put("minimum_should_match", "1");
			}*/
		}
		rootMap.put("bool", boolContextMap);
		return rootMap;
	}

	private Map<String, Object> getBooleanQuery(String conditionKey, List<Map<String, Object>> queryList, boolean advancedSearch) {
		// TODO Auto-generated method stub
		Map<String, Object> boolMap=new HashMap<String, Object>();
		Map<String,Object> conditionMap= new HashMap<String,Object>();
		if (advancedSearch) {
			conditionMap.put("minimum_should_match", "1");
		}
		conditionMap.put(conditionKey, queryList);
		boolMap.put("bool", conditionMap);
		
		return boolMap;
	}

	private List<Map<String, Object>> searchQuery(Attribute attrb, String boolCondition, int matchType) {
		List<Map<String, Object>> queryList = new ArrayList<Map<String, Object>>();
		AttributeProperties attrbProp = attrb.getProperties();
		Object value = attrb.getValue();

		boolean nestedField = attrbProp.isNestedField();
		String[] nestedPaths = attrbProp.getNestedPaths();
		Map<String, String[]> fields = attrbProp.getFields();
		boolean advancedSearch = attrbProp.isAdvancedSearch();
		Map<Integer, Map<String, String>> boosMatchtMap = attrbProp.getBoostMap();
		if (matchType == QueryMatchType.EXACT) { // Exact Match
			queryList.addAll(searchQueryExactMulti(nestedField, nestedPaths, fields, value, boolCondition));
		}
		if (matchType == QueryMatchType.FUZZY || advancedSearch) { // Fuzzy Match
			String fuzzyType = attrbProp.getFuzzyType();
			queryList.addAll(searchQueryFuzzyMulti(nestedField, nestedPaths, fields, value, fuzzyType, boolCondition,
					boosMatchtMap.get(QueryMatchType.FUZZY)));
		}
		if (matchType == QueryMatchType.TERM || advancedSearch) {
			queryList.addAll(searchQueryTermMulti(nestedField, nestedPaths, fields, value, boolCondition,
					advancedSearch, boosMatchtMap.get(QueryMatchType.TERM)));
		}
		if (matchType == QueryMatchType.TERMS) {
			queryList.addAll(searchQueryTermsMulti(nestedField, nestedPaths, fields, value, boolCondition,
					boosMatchtMap.get(QueryMatchType.TERMS)));
		}
		if (matchType == QueryMatchType.MATCH || advancedSearch) {
			queryList.addAll(searchQueryMatchMulti(nestedField, nestedPaths, fields, value, boolCondition,
					advancedSearch, boosMatchtMap.get(QueryMatchType.MATCH), null, "and"));
			if (advancedSearch) {
				queryList.addAll(searchQueryMatchMulti(nestedField, nestedPaths, fields, value, boolCondition,
						advancedSearch, boosMatchtMap.get(QueryMatchType.MATCH_STANDARD), "standard", "or"));
			}
		}
		if (matchType == QueryMatchType.WILD_CARD)
		{
			queryList.addAll(searchQueryWildCard(nestedField, nestedPaths, fields, value, boolCondition));					
		}
	
		return queryList;
	}

	private List<Map<String, Object>> searchQueryWildCard(boolean nestedField, String[] nestedPaths,
			Map<String, String[]> fields, Object value, String boolCondition) {
		List<Map<String, Object>> queryList = new ArrayList<>();
		// Nested Attribute
		if(nestedField && fields.get(nestedPaths[0]) != null) 
		{
			String[] nestedPath = fields.get(nestedPaths[0]);
			nestedPaths = nestedPath[0].split("\\.");
			queryList.add(WildCardQueries.getNestedWildcard(nestedPaths, 0, nestedPaths[0], value, boolCondition));		
		}else
		{
			String[] fieldNameArr = fields.get("root");
			if (fieldNameArr != null && fieldNameArr.length > 0) {
			for (String fieldName : fieldNameArr) {
				queryList.add(WildCardQueries.getWildcardQuery(fieldName, new String[] {(String) value}));
			}
			}
		}
		return queryList;
	}

	private Map<String, Object> searchQueryExactMono(boolean nestedField, String path, String fieldName, Object value,
			String boolCondition) {
		if (nestedField) { // Nested Attribute
			return MatchQueries.getExactMatch_Nested(fieldName, value, path, boolCondition);
		} else { // Non-Nested Attribute
			return MatchQueries.getExactMatch(fieldName, value);
		}
	}

	private List<Map<String, Object>> searchQueryExactMulti(boolean nestedField, String[] nestedPaths,
			Map<String, String[]> fields, Object value, String boolCondition) {
		List<Map<String, Object>> queryList = new ArrayList<>();
		// Nested Attribute
		if (nestedField) {
			for (String path : nestedPaths) {
				String[] fieldNames = fields.get(path);
				for (String fieldName : fieldNames) {
					queryList.add(searchQueryExactMono(nestedField, path, fieldName, value, boolCondition));
				}
			}
		}
		// Non-Nested Attribute
		String[] fieldNames = fields.get("root");
		if (fieldNames != null && fieldNames.length > 0) {
			for (String fieldName : fieldNames) {
				queryList.add(searchQueryExactMono(false, null, fieldName, value, boolCondition));
			}
		}
		return queryList;
	}

	private Map<String, Object> searchQueryFuzzyMono(boolean nestedField, String path, String[] fieldNameArr,
			Object value, String fuzzyType, String boolCondition, Map<String, String> boostMap) {
		if (nestedField) { // Nested Attribute
			String boostVal = getMaxBoostValue(fieldNameArr, QueryMatchType.FUZZY, boostMap);
			return MatchQueries.getFuzzyMatch_Nested(fieldNameArr, value, fuzzyType, path, boolCondition, boostVal);
		} else { // Non-Nested Attribute
			String boostVal = getMaxBoostValue(fieldNameArr, QueryMatchType.FUZZY, boostMap);
			return MatchQueries.getFuzzyMultiMatch(fieldNameArr, value, fuzzyType, boostVal);
		}
	}

	private List<Map<String, Object>> searchQueryFuzzyMulti(boolean nestedField, String[] nestedPaths,
			Map<String, String[]> fields, Object value, String fuzzyType, String boolCondition,
			Map<String, String> boostMap) {
		List<Map<String, Object>> queryList = new ArrayList<>();

		if (nestedField) { // Nested Attribute
			for (String path : nestedPaths) {
				String[] fieldNameArr = fields.get(path);
				queryList.add(searchQueryFuzzyMono(nestedField, path, fieldNameArr, value, fuzzyType, boolCondition,
						boostMap));
			}
		}
		// Non-Nested Attribute
		String[] fieldNameArr = fields.get("root");
		if (fieldNameArr != null && fieldNameArr.length > 0) {
			queryList.add(searchQueryFuzzyMono(false, null, fieldNameArr, value, fuzzyType, boolCondition, boostMap));
		}
		return queryList;
	}

	private Map<String, Object> searchQueryTermMono(boolean nestedField, String path, String fieldName, Object value,
			String boolCondition, boolean advancedSearch, Map<String, String> boostMap) {
		String boostVal = getBoostValue(fieldName, boostMap);
		if (nestedField) { // Nested Attribute
			if (advancedSearch) {
				return TermQueries.getNestedTermQuery(fieldName + ".raw", path, value, boolCondition, boostVal);
			} else {
				return TermQueries.getNestedTermQuery(fieldName, path, value, boolCondition, boostVal);
			}
		} else { // Non-Nested Attribute
			if (advancedSearch) {
				return TermQueries.getTermQuery(fieldName + ".raw", value, boostVal);
			} else {
				return TermQueries.getTermQuery(fieldName, value, boostVal);
			}
		}
	}

	private List<Map<String, Object>> searchQueryTermMulti(boolean nestedField, String[] nestedPaths,
			Map<String, String[]> fields, Object value, String boolCondition, boolean advancedSearch,
			Map<String, String> boostMap) {
		List<Map<String, Object>> queryList = new ArrayList<>();

		if (nestedField) { // Nested Attribute
			for (String path : nestedPaths) {
				String[] fieldNameArr = fields.get(path);
				for (String fieldName : fieldNameArr) {
					queryList.add(searchQueryTermMono(nestedField, path, fieldName, value, boolCondition,
							advancedSearch, boostMap));
				}
			}
		}
		String[] fieldNameArr = fields.get("root");
		if (fieldNameArr != null && fieldNameArr.length > 0) {
			for (String fieldName : fieldNameArr) {
				queryList.add(
						searchQueryTermMono(false, null, fieldName, value, boolCondition, advancedSearch, boostMap));
			}
		}
		return queryList;
	}

	private Map<String, Object> searchQueryTermsMono(boolean nestedField, String path, String fieldName, Object value,
			String boolCondition, Map<String, String> boostMap) {
		String boostVal = getBoostValue(fieldName, boostMap);
		if (nestedField) { // Nested Attribute
			return TermsQueries.getNestedTermsQuery(fieldName, path, value, boolCondition, boostVal);
		} else { // Non-Nested Attribute
			return TermsQueries.getTermsQuery(fieldName, value, boostVal);
		}
	}

	private List<Map<String, Object>> searchQueryTermsMulti(boolean nestedField, String[] nestedPaths,
			Map<String, String[]> fields, Object value, String boolCondition, Map<String, String> boostMap) {
		List<Map<String, Object>> queryList = new ArrayList<>();

		if (nestedField) { // Nested Attribute
			for (String path : nestedPaths) {
				String[] fieldNameArr = fields.get(path);
				for (String fieldName : fieldNameArr) {
					queryList.add(searchQueryTermsMono(nestedField, path, fieldName, value, boolCondition, boostMap));
				}
			}
		}
		String[] fieldNameArr = fields.get("root");
		if (fieldNameArr != null && fieldNameArr.length > 0) {
			for (String fieldName : fieldNameArr) {
				queryList.add(searchQueryTermsMono(false, null, fieldName, value, boolCondition, boostMap));
			}
		}
		return queryList;
	}

	private Map<String, Object> searchQueryMatchMono(boolean nestedField, String path, String fieldName, Object value,
			String boolCondition, boolean advancedSearch, Map<String, String> boostMap, String analyzer,
			String operator) {
		if (nestedField) { // Nested Attribute
			String boostVal = getBoostValue(fieldName, boostMap);
			if (advancedSearch) {
				return MatchQueries.getMatchAdvanced_Nested(fieldName, value, path, boolCondition, boostVal, analyzer,
						operator);
			} else {
				return MatchQueries.getMatchDefault_Nested(fieldName, value, path, boolCondition, boostVal);
			}
		} else { // Non-Nested Attribute
			String boostVal = getBoostValue(fieldName, boostMap);
			if (advancedSearch) {
				return MatchQueries.getMatchAdvanced(fieldName, value, boolCondition, boostVal, analyzer, operator);
			} else {
				return MatchQueries.getMatchDefault(fieldName, value, boolCondition, boostVal);
			}
		}
	}

	private List<Map<String, Object>> searchQueryMatchMulti(boolean nestedField, String[] nestedPaths,
			Map<String, String[]> fields, Object value, String boolCondition, boolean advancedSearch,
			Map<String, String> boostMap, String analyzer, String operator) {
		List<Map<String, Object>> queryList = new ArrayList<>();

		if (nestedField) { // Nested Attribute
			for (String path : nestedPaths) {
				String[] fieldNameArr = fields.get(path);
				for (String fieldName : fieldNameArr) {
					queryList.add(searchQueryMatchMono(nestedField, path, fieldName, value, boolCondition,
							advancedSearch, boostMap, analyzer, operator));
				}
			}
		}
		// Non-Nested Attribute
		String[] fieldNameArr = fields.get("root");
		if (fieldNameArr != null && fieldNameArr.length > 0) {
			for (String fieldName : fieldNameArr) {
				queryList.add(searchQueryMatchMono(false, null, fieldName, value, boolCondition, advancedSearch,
						boostMap, analyzer, operator));
			}
		}
		return queryList;
	}

	private Map<String, Object> buildQuery(String boolCondition, Object boolObject, Object filterObject,
			boolean advancedSearch) {
		Map<String, Object> rootMap = new HashMap<>();
		Map<String, Object> boolContextMap = new HashMap<>();

		boolContextMap.put(boolCondition, boolObject);

		if (filterObject != null) {
			boolContextMap.put("filter", filterObject);
			if (advancedSearch) {
				boolContextMap.put("minimum_should_match", "1");
			}
		}
		rootMap.put("bool", boolContextMap);

		return rootMap;
	}

	private List<Object> filterQuery(List<Attribute> filterList) {
		List<Object> filterQueryList = new ArrayList<>();
		for (Attribute attrb : filterList) {
			AttributeProperties attrbProp = attrb.getProperties();
			boolean nestedField = attrbProp.isNestedField();
			String valueStr = (String) attrb.getValue();
			if (nestedField) {
				String path = attrbProp.getNestedPaths()[0];
				String fieldName = attrbProp.getFields().get(path)[0];
				filterQueryList.add(FilterQueryies.getNestedTermQuery(fieldName, path, valueStr));
			} else {
				String fieldName = attrbProp.getFields().get("root")[0];
				filterQueryList.add(FilterQueryies.getTermQuery(fieldName, valueStr));
			}
		}
		return filterQueryList;
	}

	private String getMaxBoostValue(String[] fieldNameArr, int matchType, Map<String, String> boostMap) {
		String boostVal = "1"; // Default value
		if (boostMap != null) {
			int boostValInt = 1;
			int fieldBoostInt;
			String fieldBoostStr;
			for (String fieldName : fieldNameArr) {
				fieldBoostStr = getBoostValue(fieldName, boostMap);
				fieldBoostInt = Integer.valueOf(fieldBoostStr);
				if (boostValInt < fieldBoostInt) {
					boostValInt = fieldBoostInt;
				}
			}
			boostVal = String.valueOf(boostValInt);
		}
		return boostVal;
	}

	private String getBoostValue(String fieldName, Map<String, String> boostMap) {
		if (boostMap != null) {
			String boostStr = boostMap.get(fieldName);
			if (boostStr != null && !boostStr.trim().isEmpty()) {
				return boostStr;
			}
		}
		return "1";
	}

}
