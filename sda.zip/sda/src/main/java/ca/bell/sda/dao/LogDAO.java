package ca.bell.sda.dao;

import java.util.Map;

import org.apache.commons.lang3.RandomStringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;

import com.fasterxml.jackson.databind.ObjectMapper;

import ca.bell.sda.config.AppConfig;
import ca.bell.sda.config.AppProperties;
import ca.bell.sda.constant.log.LogKey;
import ca.bell.sda.util.Utility;
import ca.bell.sda.util.WebService;

@Component
public class LogDAO {

	private final String[] timeLogKeys = { "REQ", "QUERY_BUILD", "NAME_STD", "ELK", "DATA_CONV" };
	private final String[] jsonLogKeys = { "REQ_MAP", "REQ_RESPONSE", "QUERY", "ELK_RESPONSE" };

	@Autowired
	AppConfig appConfig;

	@Autowired
	private AppProperties appProps;

	@Autowired
	private WebService webService;

	@SuppressWarnings("unchecked")
	public void pushLog(Map<String, Object> log) {
		boolean isLogEnabled = appProps.getService().get((String) log.get(LogKey.REQ_GRP_ID)).isRequestLog();
		if (isLogEnabled) {
			try {
				processLog(log);
				convertJSONLog(log);
				WebClient wc = webService.getWebClientInstance((appConfig.getLogEndpoint()));
				String id = System.currentTimeMillis() + "-" + RandomStringUtils.randomAlphanumeric(8);
				Map<String, Object> logRes = (Map<String, Object>) wc.post().uri("/_doc/" + id).bodyValue(log)
						.retrieve().bodyToMono(Map.class).block();
				if (logRes.containsKey("result")) {
					System.out.println("Log Result - " + logRes.get("result"));
				}
			} catch (Exception e) {
				System.out.println("Log push failed. Exception occured: " + e.getMessage());
				Utility.consoleObject(log);
			}
		}
	}

	@SuppressWarnings("unchecked")
	public void pushLog(Map<String, Object> log, String env) {
		boolean isLogEnabled = appProps.getService().get((String) log.get(LogKey.REQ_GRP_ID)).isRequestLog();

		if (isLogEnabled) {
			try {
				processLog(log);
				convertJSONLog(log);
				WebClient wc = webService.getWebClientInstance((appConfig.getLogEndpoint(env)));
				String id = System.currentTimeMillis() + "-" + RandomStringUtils.randomAlphanumeric(8);
				Map<String, Object> logRes = (Map<String, Object>) wc.post().uri("/_doc/" + id).bodyValue(log)
						.retrieve().bodyToMono(Map.class).block();
				if (logRes.containsKey("result")) {
					System.out.println("Log Result - " + logRes.get("result"));
				}
			} catch (Exception e) {
				System.out.println("Log push failed. Exception occured: " + e.getMessage());
				Utility.consoleObject(log);
			}
		}
	}

	private void processLog(Map<String, Object> log) {
		log.remove(LogKey.REQ_LOG_EX);
		for (String logKey : timeLogKeys) {
			if (log.containsKey(logKey + "_START") && log.containsKey(logKey + "_END")) {
				log.put(logKey, (long) log.get(logKey + "_END") - (long) log.get(logKey + "_START"));
			}
			log.remove(logKey + "_START");
			log.remove(logKey + "_END");
		}
	}

	private void convertJSONLog(Map<String, Object> log) throws Exception {
		ObjectMapper objMapper = new ObjectMapper();
		for (String jsonKey : jsonLogKeys) {
			if (log.containsKey(jsonKey)) {
				log.put(jsonKey, objMapper.writeValueAsString(log.get(jsonKey)));
			}
		}
	}

}
