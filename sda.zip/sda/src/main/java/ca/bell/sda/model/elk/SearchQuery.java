package ca.bell.sda.model.elk;

import java.util.List;
import java.util.Map;
import java.util.Set;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(Include.NON_NULL)
public class SearchQuery {

	private String size;
	private String from;
	private String minScore;
	private Set<String> sourceFilter;
	private Map<String, Object> query;
	private String scroll;
	private String scrollId;
	private List<Map<String, Object>> sort;

	public String getSize() {
		return size;
	}

	public void setSize(String size) {
		this.size = size;
	}

	public String getFrom() {
		return from;
	}

	public void setFrom(String from) {
		this.from = from;
	}

	public void setMinScore(String minScore) {
		this.minScore = minScore;
	}

	@JsonProperty("min_score")
	public String getMinScore() {
		return minScore;
	}

	@JsonProperty("_source")
	public Set<String> getSourceFilter() {
		return sourceFilter;
	}

	public void setSourceFilter(Set<String> sourceFilter) {
		this.sourceFilter = sourceFilter;
	}

	public Map<String, Object> getQuery() {
		return query;
	}

	public void setQuery(Map<String, Object> query) {
		this.query = query;
	}

	public String getScroll() {
		return scroll;
	}

	public void setScroll(String scroll) {
		this.scroll = scroll;
	}

	@JsonProperty("scroll_id")
	public String getScrollId() {
		return scrollId;
	}

	public void setScrollId(String scrollId) {
		this.scrollId = scrollId;
	}
	public List<Map<String, Object>> getSort() {
		return sort;
	}

	public void setSort(List<Map<String, Object>> sort) {
		this.sort = sort;
	}

}
