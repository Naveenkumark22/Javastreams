package ca.bell.sda.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.fasterxml.jackson.databind.ObjectMapper;

import ca.bell.sda.config.ElasticQueryConfig;
import ca.bell.sda.constant.log.LogKey;
import ca.bell.sda.model.elk.Attribute;

public class Request {

	private String serviceGrp;
	private String reqId;
	private ElasticQueryConfig queryConfig;
	private List<Attribute> queryAttrbList = new ArrayList<>();
	private List<Attribute> filterAttrbList = new ArrayList<>();
	private List<Attribute> aggrAttrbList = new ArrayList<>();
	private Map<String, Attribute> reqConfigAttrb = new HashMap<>();
	private Set<String> sourceFilter;
	private Map<String, Attribute> nodeValueTypes = new HashMap<>();
	private Map<String, Object> log = new HashMap<>();
	private boolean reqLog;
	private List<Object> inputValues;
	private	Map<String, Object> requestMap;
	
	

	public Request() {
		super();
	}

	public Request(String serviceGrp, String reqId) {
		super();
		this.serviceGrp = serviceGrp;
		this.reqId = reqId;
	}

	public String getServiceGrp() {
		return serviceGrp;
	}

	public void setServiceGrp(String serviceGrp) {
		this.serviceGrp = serviceGrp;
	}

	public String getReqId() {
		return reqId;
	}

	public void setReqId(String reqId) {
		this.reqId = reqId;
	}

	public List<Attribute> getQueryAttrbList() {
		return queryAttrbList;
	}

	public void setQueryAttrbList(List<Attribute> queryAttrbList) {
		this.queryAttrbList = queryAttrbList;
	}

	public List<Attribute> getFilterAttrbList() {
		return filterAttrbList;
	}

	public void setFilterAttrbList(List<Attribute> filterAttrbList) {
		this.filterAttrbList = filterAttrbList;
	}

	public List<Attribute> getAggrAttrbList() {
		return aggrAttrbList;
	}

	public void setAggrAttrbList(List<Attribute> aggrAttrbList) {
		this.aggrAttrbList = aggrAttrbList;
	}

	public Set<String> getSourceFilter() {
		return sourceFilter;
	}

	public void setSourceFilter(Set<String> sourceFilter) {
		this.sourceFilter = sourceFilter;
	}

	public ElasticQueryConfig getQueryConfig() {
		return queryConfig;
	}

	public void setQueryConfig(ElasticQueryConfig queryConfig) {
		this.queryConfig = queryConfig;
	}

	public Map<String, Attribute> getNodeValueTypes() {
		return nodeValueTypes;
	}

	public void setNodeValueTypes(Map<String, Attribute> nodeValueTypes) {
		this.nodeValueTypes = nodeValueTypes;
	}

	public Map<String, Object> getLog() {
		return log;
	}

	public void setLog(Map<String, Object> log) {
		this.log = log;
	}

	public String getLogAsJson() {
		try {
			return new ObjectMapper().writeValueAsString(this.log);
		} catch (Exception e) {
			return "---{\"" + LogKey.REQ_LOG_EX_MSG + "\":\"" + getClass().getName() + e.getMessage() + "\"}";
		}

	}

	public void log(String key, Object message) {
		this.log.put(key, message);
	}

	public void logTime(String key) {
		this.log.put(key, System.currentTimeMillis());
		if (key.contains("_END")) {
			try {
				long end = (long) log.get(key);
				long start = (long) log.get(key.replace("_END", "_START"));
				log.put(key.replace("_END", ""), end - start);
			} catch (Exception e) {

			}
		}
	}

	public void logInput(Object inpValue) {
		if (inputValues == null) {
			inputValues = new ArrayList<Object>();
		}
		inputValues.add(inpValue);
		log.put(LogKey.INPUT_VALUE, inputValues);
	}

	public boolean isReqLog() {
		return reqLog;
	}

	public void setReqLog(boolean reqLog) {
		this.reqLog = reqLog;
	}

	public Map<String, Attribute> getReqConfigAttrb() {
		return reqConfigAttrb;
	}

	public void setReqConfigAttrb(Map<String, Attribute> reqConfigAttrb) {
		this.reqConfigAttrb = reqConfigAttrb;
	}
	
	public Map<String, Object> getRequestMap() {
		return requestMap;
	}
	
	public void setRequestMap(Map<String, Object> requestMap) {
		this.requestMap = requestMap;
	}

}
