package ca.bell.sda.service;

import java.util.HashMap;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ca.bell.sda.config.AppConfig;
import ca.bell.sda.config.ElasticQueryConfig;
import ca.bell.sda.constant.log.LogKey;
import ca.bell.sda.constant.webclient.StreamSource;
import ca.bell.sda.dao.SearchDAO;
import ca.bell.sda.model.Request;
import ca.bell.sda.model.elk.SearchQuery;
import ca.bell.sda.process.OrgDataProcessor;
import jakarta.annotation.PostConstruct;

@Service
public class SourceSystemService {

	
	@Autowired
	private SearchDAO searchDAO;
	
	@Autowired
	private AppConfig appConfig;
	
	@Autowired
	private OrgDataProcessor dataProcessor;

	@Autowired
	private ElasticQueryConfig elasticQueryConfig;
	
	Map<String,String> sourceMap;
	
	@PostConstruct
	public void fetchSourceSystem()
	{
		Request request = new Request("bbm","SourceSystem");		
		SearchQuery searchQuery = new SearchQuery();
		searchQuery.setSize("1000");
		searchQuery.setMinScore(null);
		String indexName= appConfig.getIndexNames(request.getReqId())[0];
		request.setQueryConfig(elasticQueryConfig.clone());
		sourceMap=new HashMap<>(); 
		try {
			Object elkData = searchDAO.querySource(request.getReqId(), StreamSource.INDEX, searchQuery, indexName,
					request.getQueryConfig().getFilterPath());
			sourceMap=dataProcessor.processSourceData(elkData);
		} catch (Exception e) {
			request.log(LogKey.REQ_LOG_EX_MSG, getClass().getName() + e.getMessage());
			e.printStackTrace();
		}		
		
	}
	
	public Map<String,String> getSourceSystem()
	{
		return sourceMap;
		
	}

}
