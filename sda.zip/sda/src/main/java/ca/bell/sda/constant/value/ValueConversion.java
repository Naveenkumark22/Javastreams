package ca.bell.sda.constant.value;

public class ValueConversion {

	public static final int RAW = 1;
	public static final int CONVERTED_VALUE = 2;
	public static final int RAW_N_CONVERTED = 3;

}
	