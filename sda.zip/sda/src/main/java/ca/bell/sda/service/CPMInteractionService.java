package ca.bell.sda.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import ca.bell.sda.config.AppConfig;
import ca.bell.sda.config.ElasticQueryConfig;
import ca.bell.sda.constant.log.LogKey;
import ca.bell.sda.constant.status.StatusTypes;
import ca.bell.sda.constant.webclient.StreamSource;
import ca.bell.sda.dao.SearchDAO;
import ca.bell.sda.elk.QueryBuilder;
import ca.bell.sda.elk.TMFQueryBuilder;
import ca.bell.sda.model.Request;
import ca.bell.sda.model.Response;
import ca.bell.sda.model.elk.Attribute;
import ca.bell.sda.model.elk.SearchQuery;
import ca.bell.sda.model.elk.response.ResponseData;
import ca.bell.sda.model.tmf.AttributeFilter;
import ca.bell.sda.model.tmf.FilterGroup;
import ca.bell.sda.model.tmf.TMFSearch;
import ca.bell.sda.process.InteractionDataProcessor;
import ca.bell.sda.util.Utility;

@Service
public class CPMInteractionService extends CPMService {

	@Autowired
	private AppConfig appConfig;

	@Autowired
	private SearchDAO searchDAO;

	@Autowired
	private InteractionDataProcessor dataProcessor;

	@Autowired
	private TMFQueryBuilder tmfQueryBuilder;

	@Autowired
	private ElasticQueryConfig elasticQueryConfig;
	
	@Autowired
	private QueryBuilder queryBuilder;

	

	public Object searchInteraction(Request request, TMFSearch tmfSearch) {
		addFilter(tmfSearch,"AND","sourceSystem","eq",new String[] {"SSC","GM-NM1_CONTACT","CPMKEY"});
				
		SearchQuery searchQuery = tmfQueryBuilder.createSearchQuery(tmfSearch);
		String indexName = appConfig.getIndexNames(request.getReqId())[0];
		request.logTime(LogKey.QUERY_BUILD_END);
		request.log(LogKey.QUERY, searchQuery);
		ResponseData resData = null;
		try {
			request.logTime(LogKey.ELK_START);
			Object elkData = searchDAO.querySource(request.getReqId(), StreamSource.INDEX, searchQuery, indexName,
					elasticQueryConfig.getFilterPath());
			request.logTime(LogKey.ELK_END);
			request.logTime(LogKey.DATA_CONV_START);
			resData = dataProcessor.processData(request, elkData);
			request.logTime(LogKey.DATA_CONV_END);
			addSuccessLog(request);
		} catch (Exception e) {
			request.log(LogKey.REQ_LOG_EX_MSG, getClass().getName() + e.getMessage());
			e.printStackTrace();
			addExceptionLog(request,e);
		}
		return resData;
	}
	
	private void filterSource(Request request, TMFSearch tmfSearch) {
		FilterGroup filterGroup=	new FilterGroup();
		filterGroup.setGroupOperator("AND");
		AttributeFilter attributeFilter =new AttributeFilter();
		attributeFilter.setField("sourceSystem");
		attributeFilter.setOperator("eq");
		attributeFilter.setValue(new String[]{"SSC","GM-NM1_CONTACT","CPMKEY"});
		List<AttributeFilter> attributeFilterList=new ArrayList<AttributeFilter>();
		attributeFilterList.add(attributeFilter);
		filterGroup.setFilter(attributeFilterList);
		List<FilterGroup> filterGroupList=new ArrayList<FilterGroup>();
		filterGroupList.add(filterGroup);
		tmfSearch.getFilter().addAll(filterGroupList);

		
	}
	
	public Object getInteraction(Request request, TMFSearch tmfSearch) {
		SearchQuery searchQuery = tmfQueryBuilder.createSearchQuery(tmfSearch);
		String indexName = appConfig.getIndexNames(request.getReqId())[0];
		request.logTime(LogKey.QUERY_BUILD_END);
		request.log(LogKey.QUERY, searchQuery);
		ResponseData resData = null;
		try {
			request.logTime(LogKey.ELK_START);
			Object elkData = searchDAO.querySource(request.getReqId(), StreamSource.INDEX, searchQuery, indexName,
					elasticQueryConfig.getFilterPath());
			request.logTime(LogKey.ELK_END);
			request.logTime(LogKey.DATA_CONV_START);
			resData = dataProcessor.processData(request, elkData);
			if (resData != null) {
					if (resData.getProfiles() != null && resData.getProfiles().size() > 0) {
						Map<String, Object> profile = resData.getProfiles().get(0);
						resData.setProfile(profile);
						resData.setProfiles(null);
					}
				}
			request.logTime(LogKey.DATA_CONV_END);
			addSuccessLog(request);
		} catch (Exception e) {
			request.log(LogKey.REQ_LOG_EX_MSG, getClass().getName() + e.getMessage());
			addExceptionLog(request,e);
			e.printStackTrace();
		}
		return resData;
	}

	public ResponseData getInteractionForCustomerTimeline(Request request, Response response,
			Map<String, Object> requestMap) {		 
		String indexName = appConfig.getIndexNames(request.getReqId())[0]; 
		SearchQuery searchQuery = getSearchQuery(request);
		searchQuery.setMinScore(null);
		searchQuery.setSize("10000");		
		request.logTime(LogKey.QUERY_BUILD_END);
		ResponseData resData = null;
		try {
			searchQuery.setSourceFilter(appConfig.getAttributesConfig().getDataAttributes().get(request.getReqId())
					.get("profileTimeline").getKeys());
			Object elkData = searchDAO.querySource(request.getReqId(), StreamSource.INDEX, searchQuery, indexName,
					request.getQueryConfig().getFilterPath());
			request.log(LogKey.QUERY, searchQuery);
			request.logTime(LogKey.ELK_START);
			request.logTime(LogKey.ELK_END);
			request.logTime(LogKey.DATA_CONV_START);
			resData = dataProcessor.processDataTimeline(elkData);			
		} catch (Exception e) {
			request.log(LogKey.REQ_LOG_EX_MSG, getClass().getName() + e.getMessage());
			request.log(LogKey.REQ_LOG_EX, e);
			addExceptionLog(request,e);
		}
		request.logTime(LogKey.DATA_CONV_END);
		return resData;
	}


}
