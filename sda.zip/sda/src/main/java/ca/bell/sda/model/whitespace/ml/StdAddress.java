/**
 * 
 */
package ca.bell.sda.model.whitespace.ml;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author Kamalanathan Ranganathan
 *
 */
public class StdAddress {

	private String province;

	private String combinedAddress;

	private String addressLineOne;

	private String country;

	private String postalCode;

	private String addressLineTwo;

	private String city;

	@JsonProperty("combinedAddress")
	public String getCombinedAddress() {
		return this.combinedAddress;
	}

	public void setCombinedAddress(String combinedAddress) {
		this.combinedAddress = combinedAddress;
	}

	@JsonProperty("addressLineOne")
	public String getAddressLineOne() {
		return this.addressLineOne;
	}

	public void setAddressLineOne(String addressLineOne) {
		this.addressLineOne = addressLineOne;
	}

	@JsonProperty("country")
	public String getCountry() {
		return this.country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	@JsonProperty("postalCode")
	public String getPostalCode() {
		return this.postalCode;
	}

	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}

	@JsonProperty("addressLineTwo")
	public String getAddressLineTwo() {
		return this.addressLineTwo;
	}

	public void setAddressLineTwo(String addressLineTwo) {
		this.addressLineTwo = addressLineTwo;
	}

	@JsonProperty("province")
	public String getProvince() {
		return this.province;
	}

	public void setProvince(String province) {
		this.province = province;
	}

	@JsonProperty("city")
	public String getCity() {
		return this.city;
	}

	public void setCity(String city) {
		this.city = city;
	}

}
