package ca.bell.sda.process;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import ca.bell.sda.external.OrgNameStandardization;
import ca.bell.sda.model.Request;

@Component
public class AttrbValueConvertors {

	@Autowired
	OrgNameStandardization orgNameStdzr;

	public Object getStandardizedName(Request request, String orgName) throws Exception {
		return orgNameStdzr.getStandardizedName(request, orgName);
	}

}
