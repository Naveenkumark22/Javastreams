package ca.bell.sda.process;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;

import ca.bell.sda.model.Characteristic;
import ca.bell.sda.model.CustomerTimeline;
import ca.bell.sda.model.ReferencedInteraction;
import ca.bell.sda.model.Request;
import ca.bell.sda.model.Response;
import ca.bell.sda.model.SBMEventOrder;
import ca.bell.sda.model.elk.response.ResponseData;
import ca.bell.sda.util.Utility;

@Component
public class GetCustomerTimelineProcessor extends ElasticDataProcessor implements TimelineDataProcessor {
	
	private static final String SRC_SYSTEM = "srcSystem";
	private static final String SRC_SYSTEM_DIGITEK = "digitek";
	private static final String EVENT_ID = "event_id";
	private static final String EVENT_NAME = "event_name";
	private static final String ACTION_ID = "actionid";
	private static final String ACTION = "action";
	
	
	
	
	@SuppressWarnings("unchecked")
	@Override
	public <T> List<CustomerTimeline> processData(Request request, T data) {
				
		Map<String, Object> dataMap = (Map<String, Object>) data;
		Map<String, List<Map<String, Object>>> eventDataMap = new HashMap<>(1);
		Map<String, List<Map<String, Object>>> sbmDataMap = new HashMap<>(1);

		Map<String, Map<String, Object>> digitekMap = new HashMap<>();

		if (getTotalValue(dataMap) > 0) {
			List<Map<String, Object>> profilesMap = getProfileMapList(dataMap);
			for (Map<String, Object> profMap : profilesMap) {
				Map<String, Object> sourceMap = (Map<String, Object>) profMap.get("_source");
				String eventId = getStringOrNull(sourceMap.get(EVENT_ID));
				if (eventId != null) {
					String srcSystem = getStringOrNull(sourceMap.get(SRC_SYSTEM));
					if (srcSystem != null && srcSystem.equalsIgnoreCase(SRC_SYSTEM_DIGITEK)) { // Process for Digitek
						processDigitekData(digitekMap, eventId, sourceMap);
					} else {
						String eventName = getStringOrNull(sourceMap.get(EVENT_NAME));
						if (eventName != null && eventName.equalsIgnoreCase("EventOrderSBM")) { // SBM Data
							if (sourceMap.containsKey("event_date")) {
								 dateFormat(sourceMap.get("event_date"),sourceMap); }
							addDataToList(sbmDataMap, eventId, sourceMap);							
						} else {							
							 if (sourceMap.containsKey("event_date")) {
							 dateFormat(sourceMap.get("event_date"),sourceMap); }		 
							
							addEventToList(eventDataMap, eventId, sourceMap);							
						}
					}
				}
			}
		}		
		if(sbmDataMap!=null) {
		       processSBMOrderEvent(eventDataMap, sbmDataMap);}	
		
		Map<String, List<Map<String, Object>>> digitekList = new HashMap<>();
		if (digitekMap.size() > 0) {// adding Digitek Events			
			digitekMap.forEach((k, v) -> {				
				List<Map<String, Object>> digiVal=new ArrayList<>();
				digiVal.add(v);
				digitekList.put(k, digiVal);				
		 });		}				
		if(digitekList!=null) {
			eventDataMap.putAll(digitekList);
		}		
		return groupDataByEventId(eventDataMap);
	}

	
	@SuppressWarnings("unchecked")
	private void processDigitekData(Map<String, Map<String, Object>> digitekMap, String eventId,
			Map<String, Object> sourceMap) {
		List<Map<String, Object>> actionList = null;
		if (digitekMap.containsKey(eventId)) {
			actionList = (List<Map<String, Object>>) digitekMap.get(eventId).get(ACTION);
			if (actionList == null)
				actionList = new ArrayList<Map<String, Object>>();
			if(sourceMap.get(ACTION) != null)
				actionList.add((Map<String, Object>) sourceMap.get(ACTION));
			
			long actionId = Long.parseLong((digitekMap.get(eventId).get(ACTION_ID))!=null?digitekMap.get(eventId).get(ACTION_ID).toString():"0");
			long sourceActionId = Long.parseLong(sourceMap.get(ACTION_ID)!=null?sourceMap.get(ACTION_ID).toString():"0");
			if (sourceActionId > actionId) {
				digitekMap.put(eventId, sourceMap);
			}
			digitekMap.get(eventId).put(ACTION, actionList);
		} else {
			digitekMap.put(eventId, sourceMap);
			if (sourceMap.containsKey(ACTION) && sourceMap.get(ACTION) != null) {
				actionList=new ArrayList<>();
				actionList.add((Map<String, Object>) sourceMap.get(ACTION));
				digitekMap.get(eventId).put(ACTION, actionList);
			}
		}		
	}
	
	private List<CustomerTimeline> groupDataByEventId(Map<String, List<Map<String, Object>>> eventDataMap) {
		if (eventDataMap != null && !eventDataMap.isEmpty()) {
			List<CustomerTimeline> ctList = new ArrayList<>();
			eventDataMap.forEach((eventId, eventDataList) -> {
				ctList.add(new CustomerTimeline(eventId, eventDataList));
			});
			return ctList;
		}
		return null;
	}

   
	@SuppressWarnings("unchecked")
	private void processSBMOrderEvent(Map<String, List<Map<String, Object>>> eventDataMp,
			Map<String, List<Map<String, Object>>> sbmDataMap) {		
		
		sbmDataMap.forEach((eventId, eventList) -> {
			if (eventList != null && !eventList.isEmpty()) {
				SBMEventOrder sbmOrder = new SBMEventOrder();				
				List<Map<String, Object>> sbmList=new ArrayList<>();
				Map<String, Object> event = eventList.get(0);
				sbmOrder.setInteractionDate(event.get("event_date"));
				sbmOrder.setInteractionType("EventOrder");
				sbmOrder.setEvent_name("Event");
				sbmOrder.setParent_event_name(event.get("parent_event_name"));
				sbmOrder.setId(eventId);
				processRelatedPartyList(sbmOrder, event);
				processCharacteristicList(sbmOrder, event);
				sbmOrder.setReferencedInteraction(setReferenceInteractionItems(eventList));				
				Map<String, Object> sbmObj = new ObjectMapper().convertValue(sbmOrder, Map.class);
				sbmList.add(sbmObj);				
				eventDataMp.put(eventId, sbmList);								
				}			
		});
	}
	private void processRelatedPartyList(SBMEventOrder sbmOrder, Map<String, Object> event) {		
		List<Object> charactisticList = new ArrayList<>(1);
		charactisticList.add(createNameValueMap("OrganizationCode", "Bell"));		
		Map<String, Object> relatedParty = new HashMap<>(3);
		relatedParty.put("role", "Customer");
		relatedParty.put("id", event.get("parent_acct"));
		relatedParty.put("characteristic", charactisticList);
		sbmOrder.getRelatedParty().add(relatedParty);
	}

	private void processCharacteristicList(SBMEventOrder sbmOrder, Map<String, Object> event) {
		List<Map<String, Object>> charactisticList = sbmOrder.getCharacteristic();
		charactisticList.add(createNameValueMap("OrderSource", "EOM"));
		charactisticList.add(createNameValueMap("IssueDate", event.get("event_date")));
		charactisticList.add(createNameValueMap("OrderNumber", event.get("event_id")));
	}
	
	private Map<String, Object> dateFormat(Object date, Map<String, Object> sourceMap) {
		if (date != null) {
			String dateString = date.toString();
			if (dateString.contains("Z"))
				sourceMap.put("event_date", dateString.substring(0, dateString.lastIndexOf(".")));
		}
		return sourceMap;
	}

	@SuppressWarnings("unchecked")
	private List<ReferencedInteraction> setReferenceInteractionItems(List<Map<String, Object>> eventList) {

		Map<String, Object> serviceObj;
		List<Map<String, Object>> serviceList;
		Map<String, List<Map<String, Object>>> interItem;
		List<Map<String, List<Map<String, Object>>>> interItemList;
		ReferencedInteraction refInterObj;
		Map<String, Object> regionOne;
		Map<String, Object> regionTwo;
		List<Map<String, Object>> regionListOne;
		List<Map<String, Object>> regionListTwo;
		Characteristic charObjOne;
		Characteristic charObjTwo;
		List<Characteristic> charList;		
		List<ReferencedInteraction> refList = new ArrayList<>();
		for (Map<String, Object> event : eventList) {

			refInterObj = new ReferencedInteraction();
			serviceList = new ArrayList<>(1);
			serviceObj = new HashMap<>(2);
			interItem = new HashMap<>(1);
			interItemList = new ArrayList<>(1);
			serviceObj.put("name", event.get("CT_EventOrder_ServiceType"));
			serviceObj.put("id", event.get("service_id"));
			serviceList.add(serviceObj);
			interItem.put("service", serviceList);
			interItemList.add(interItem);
			refInterObj.setInteractionItem(interItemList);
			refInterObj.setInteractionType(event.get("CT_EventOrder_OrderType"));
			refInterObj.setInteractionStatus(event.get("CT_SBM_OrderStatus"));

			regionOne = new HashMap<>(3);
			regionOne.put("name", "OrderStatus");
			regionOne.put("langdescriptor", "en");
			regionOne.put("value", event.get("CT_SBM_OrderStatus"));
			regionListOne = new ArrayList<>(1);
			regionListOne.add(regionOne);
			charObjOne = new Characteristic();
			charObjOne.setRegionalisation(regionListOne);
			charObjOne.setName("OrderStatus");
			charObjOne.setValue(event.get("CT_SBM_OrderStatus"));

			regionTwo = new HashMap<>(3);
			regionTwo.put("name", "OrderType");
			regionTwo.put("langdescriptor", "en");
			regionTwo.put("value", event.get("CT_EventOrder_OrderType"));
			regionListTwo = new ArrayList<>(1);
			regionListTwo.add(regionTwo);
			charObjTwo = new Characteristic();
			charObjTwo.setRegionalisation(regionListTwo);
			charObjTwo.setName("OrderType");
			charObjTwo.setValue(event.get("CT_EventOrder_OrderType"));
			charList = new ArrayList<>(2);
			charList.add(charObjOne);
			charList.add(charObjTwo);
			refInterObj.setCharacteristic(charList);							
			refList.add(refInterObj);				
		}
		return refList;
	}

	private void addEventToList(Map<String, List<Map<String, Object>>> eventDataMap, String key,
			Map<String, Object> event) {
		List<Map<String, Object>> eventList = eventDataMap.get(key);
		if (eventList == null) {
			eventList = new ArrayList<>(1);
			eventDataMap.put(key, eventList);
		}
		eventList.add(event);
	}

	public List<CustomerTimeline> groupIntData(Response intResponse) {		
		Map<String, List<Map<String, Object>>> interactionDataMap = null;
		ResponseData intRespData= (ResponseData) intResponse.getData();
		List<CustomerTimeline> eomIntData = null;
		if(intRespData.getProfiles()!=null && !intRespData.getProfiles().isEmpty())
		{  
			interactionDataMap = new HashMap<>(1);
			for(Map<String,Object> intprf:intRespData.getProfiles()) {		
				addDataToList(interactionDataMap, intprf.get("id").toString(), intprf);
			}			
			eomIntData=groupDataByEventId(interactionDataMap);
		  }			
		return eomIntData;
	    }	
	
	
	
	
	
	}


