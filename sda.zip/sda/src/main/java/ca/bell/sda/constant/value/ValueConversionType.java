package ca.bell.sda.constant.value;

public class ValueConversionType {

	public static final int VALUE_MAP = 1;
	public static final int METHOD = 2;

}
