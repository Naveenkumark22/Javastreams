package ca.bell.sda.util;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.client.reactive.ClientHttpConnector;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.ExchangeStrategies;
import org.springframework.web.reactive.function.client.WebClient;

import ca.bell.sda.config.AppProperties;
import ca.bell.sda.constant.webclient.WebServiceAuth;
import ca.bell.sda.model.config.Endpoint;
import io.netty.handler.ssl.SslContext;
import io.netty.handler.ssl.SslContextBuilder;
import io.netty.handler.ssl.util.InsecureTrustManagerFactory;
import reactor.netty.http.client.HttpClient;

@Component
public class WebService {

	@Autowired
	private AppProperties appProps;

	private static Map<String, WebClient> WEB_CLIENT_STORE = new HashMap<>();

	public static final String DEFAULT = "DEFAULT";

	private ClientHttpConnector getCustomClientHttpConnector() {
		ClientHttpConnector httpConnector = null;
		try {
			SslContext sslContext = SslContextBuilder.forClient().trustManager(InsecureTrustManagerFactory.INSTANCE)
					.build();

			// Allow Self-Signed SSL Certificates
			HttpClient httpClient = HttpClient.create().secure(sslContextSpec -> sslContextSpec.sslContext(sslContext));

			httpConnector = new ReactorClientHttpConnector(httpClient);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return httpConnector;
	}

	private ExchangeStrategies getExchangeStrategies() {
		return ExchangeStrategies.builder().codecs(configurer -> configurer.defaultCodecs()
				.maxInMemorySize(Integer.parseInt(appProps.getServers().getWebService().getCodecsMaxInMemory())))
				.build();
	}

	/**
	 * Default Profile for WebClient. Allow all Self-Signed SSL Certificates No
	 * Headers/Authorization/URL
	 * 
	 * @param webClientProfileName
	 */
	private void createWebClient_Default() {

		try {
			WebClient wc = WebClient.builder().clientConnector(getCustomClientHttpConnector())
					.exchangeStrategies(getExchangeStrategies()).build();

			WEB_CLIENT_STORE.put(DEFAULT, wc);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public WebClient getWebClient_Default() {
		return getWebClientInstance();
	}

	public WebClient getWebClientInstance() {
		WebClient wc = null;
		try {
			if (WEB_CLIENT_STORE.get(DEFAULT) == null) {
				createWebClient_Default();
			}
			wc = WEB_CLIENT_STORE.get(DEFAULT);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return wc;
	}

	public WebClient getWebClientInstance(String endPointName) {
		WebClient wc = null;
		try {
			if (WEB_CLIENT_STORE.get(endPointName) == null) {
				createWebClient(endPointName);
			}
			wc = WEB_CLIENT_STORE.get(endPointName);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return wc;
	}

	/**
	 * Default Profile for WebClient. Allow all Self-Signed SSL Certificates No
	 * Headers/Authorization/URL
	 * 
	 * @param webClientProfileName
	 */
	private void createWebClient(String endPointName) {
		try {
			Endpoint endpoint = appProps.getServers().getWebService().getEndPoints().get(endPointName);
			String authType = endpoint.getAuthType();
			String baseUrl = endpoint.getHost() + endpoint.getUrl();
Utility.consoleObject(endpoint);
			WebClient wc = null;
			if (authType != null && authType.equalsIgnoreCase(WebServiceAuth.BASIC)) {
				String auth = endpoint.getAuthorization();
				wc = WebClient.builder().clientConnector(getCustomClientHttpConnector()).baseUrl(baseUrl)
						.defaultHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
						.defaultHeader("Authorization", auth).exchangeStrategies(getExchangeStrategies()).build();
			} else {
				wc = WebClient.builder().clientConnector(getCustomClientHttpConnector()).baseUrl(baseUrl)
						.defaultHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
						.exchangeStrategies(getExchangeStrategies()).build();
			}
			WEB_CLIENT_STORE.put(endPointName, wc);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
