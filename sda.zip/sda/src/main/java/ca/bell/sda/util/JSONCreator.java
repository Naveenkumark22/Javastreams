/**
 * 
 */
package ca.bell.sda.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.stereotype.Component;

import ca.bell.sda.constant.log.LogKey;
import ca.bell.sda.model.Request;
import ca.bell.sda.model.whitespace.STDAddress;
import ca.bell.sda.model.whitespace.StdOrgRecord;
import ca.bell.sda.model.whitespace.mdm.BBMAddressBObjExt;
import ca.bell.sda.model.whitespace.mdm.BBMPartyAddressBObjExt;
import ca.bell.sda.model.whitespace.mdm.GKMatchingProcess;
import ca.bell.sda.model.whitespace.mdm.GKProcessBObj;
import ca.bell.sda.model.whitespace.mdm.MDMOutput;
import ca.bell.sda.model.whitespace.ml.InputList;
import ca.bell.sda.model.whitespace.ml.MLInputRoot;
import ca.bell.sda.model.whitespace.ml.Record;

/**
 * @author Kamalanathan Ranganathan
 *
 */
@Component
public class JSONCreator {

	// Constructing the Response from the output of standardization and ML findings

	public MDMOutput getOutput(Request request, StdOrgRecord stdorgrecord, MLInputRoot input) throws Exception {

		try {

			MDMOutput op = new MDMOutput();

			GKMatchingProcess _GKMatchingProcess = new GKMatchingProcess();

			_GKMatchingProcess.setStandardizedindicatorPhone(stdorgrecord.getTnIndicator());
			
			if("no".equalsIgnoreCase((String)request.getRequestMap().get("standardizedFlag")))
			{
				_GKMatchingProcess.setStdGkName(stdorgrecord.getStdOrgName());
			}
			else {
			_GKMatchingProcess.setStdGkName(getNameWithPiped(stdorgrecord.getStdMalibuOrgName(),
					stdorgrecord.getStdAddress().getOnelineAddress_formatted(), stdorgrecord.getFranchiseFlag()));
			
			_GKMatchingProcess.setStdAlternateName(getNameWithPiped(stdorgrecord.
					  getStdAlternateName(),
					  stdorgrecord.getStdAddress().getOnelineAddress_formatted(),
					  stdorgrecord.getFranchiseFlag()));
					  
					  _GKMatchingProcess.setStdNumberEquivalent(getNameWithPiped(stdorgrecord.
					  getStdNumberEquivalent(),
					  stdorgrecord.getStdAddress().getOnelineAddress_formatted(),
					  stdorgrecord.getFranchiseFlag()));
			}						 
			_GKMatchingProcess.setPhone(stdorgrecord.getTn().trim());

			_GKMatchingProcess.setMail(stdorgrecord.getEmail());

			_GKMatchingProcess.setUrl(stdorgrecord.getUrl());

			if (stdorgrecord.isInputAddressPresent()) {
				
				if(!"no".equalsIgnoreCase((String)request.getRequestMap().get("standardizedFlag"))) {

				_GKMatchingProcess.setBBMPartyAddressBObjExt(getBBMPartyAddressBObjExt(stdorgrecord));

				_GKMatchingProcess.setBBMAddressBObjExt(getBBMAddressBObjExt(stdorgrecord));
				}
			}

			_GKMatchingProcess.setGKProcessBObj(getGKProcessBObjList(input));

			op.setGKMatchingProcess(_GKMatchingProcess);

			return op;

		} catch (Exception e) {

			request.log(LogKey.REQ_LOG_EX_MSG, "JSON Creator : " + e.getMessage());

			request.log(LogKey.REQ_LOG_EX, e);

			throw new Exception("JSON Creator : " + e.getMessage());
		}
	}

	private BBMPartyAddressBObjExt getBBMPartyAddressBObjExt(StdOrgRecord stdorgrecord) throws Exception {

		BBMPartyAddressBObjExt _BBMPartyAddressBObjExt = new BBMPartyAddressBObjExt();

		String styoe = stdorgrecord.getStdAddress().getAddresssource();

		if (styoe != null && styoe.trim().length() > 0) {
			_BBMPartyAddressBObjExt.setAddressSourceType(Integer.parseInt(styoe));
		}

		_BBMPartyAddressBObjExt.setMatchType(stdorgrecord.getStdAddress().getMatchType());

		return _BBMPartyAddressBObjExt;

	}

	private BBMAddressBObjExt getBBMAddressBObjExt(StdOrgRecord stdorgrecord) throws Exception {

		// Assigning value to the address object
		BBMAddressBObjExt _BBMAddressBObjExt = new BBMAddressBObjExt();
		//commented since we need to send Malibu standardization address to MDM
		/**_BBMAddressBObjExt.setAddressLineOne(stdorgrecord.getElkAddress().getAddressLineOne());

		_BBMAddressBObjExt.setAddressLineTwo(stdorgrecord.getElkAddress().getAddressLineTwo());

		_BBMAddressBObjExt.setCity(stdorgrecord.getElkAddress().getCity());

		_BBMAddressBObjExt.setZipPostalCode(stdorgrecord.getElkAddress().getPostalCode());

		_BBMAddressBObjExt.setProvinceStateValue(stdorgrecord.getElkAddress().getProvince());

		_BBMAddressBObjExt.setCountryValue(stdorgrecord.getElkAddress().getCountry());
		**/

		STDAddress saddr = stdorgrecord.getStdAddress();

		// send malibu address to MDM 

		if (saddr != null && !saddr.isAddressEmpty()) {
			
			_BBMAddressBObjExt.setAddressLineOne(saddr.getAddresslineone_formatted());
			
			_BBMAddressBObjExt.setAddressLineTwo(saddr.getAddresslinetwo_formatted());
			
			_BBMAddressBObjExt.setCity(saddr.getCityname_formatted());
			
			_BBMAddressBObjExt.setZipPostalCode(saddr.getFullpostalcode_formatted());

			_BBMAddressBObjExt.setProvinceStateValue(saddr.getStateabbreviation_formatted());

			_BBMAddressBObjExt.setCountryValue(saddr.getCountryname_formatted());
						
			_BBMAddressBObjExt.setAddressLineThree(saddr.getAddresslinethree_formatted());

			_BBMAddressBObjExt.setResidenceNumber(saddr.getResidencenumber_formatted());

			_BBMAddressBObjExt.setLatitudeDegrees(getLatLonValue(saddr.getLatitude()));

			_BBMAddressBObjExt.setLongitudeDegrees(getLatLonValue(saddr.getLongitude()));

			_BBMAddressBObjExt.setStreetNumber(saddr.getStreetnumber_formatted());

			_BBMAddressBObjExt.setStreetName(saddr.getStreetname_formatted());

			_BBMAddressBObjExt.setStreetSuffix(saddr.getStreetsuffix_formatted());

		} else {

			_BBMAddressBObjExt.setAddressLineThree("");

			_BBMAddressBObjExt.setResidenceNumber("");

			_BBMAddressBObjExt.setLatitudeDegrees(0.0);

			_BBMAddressBObjExt.setLongitudeDegrees(0.0);

			_BBMAddressBObjExt.setStreetNumber("");

			_BBMAddressBObjExt.setStreetName("");

			_BBMAddressBObjExt.setStreetSuffix("");

		}

		_BBMAddressBObjExt.setPostDirectional("");

		_BBMAddressBObjExt.setStreetPrefix("");

		_BBMAddressBObjExt.setBuildingName("");

		return _BBMAddressBObjExt;
	}

	private List<GKProcessBObj> getGKProcessBObjList(MLInputRoot output) throws Exception {

		List<GKProcessBObj> processObjList = new ArrayList<>();

		if (output == null)
			return processObjList;

		List<InputList> ipList = output.getInput_list();

		if (ipList != null) {

			for (InputList input : ipList) {

				GKProcessBObj gkProcessBObj = new GKProcessBObj();

				Record record = input.getSuspect_record();

				gkProcessBObj.setToken_freq(input.getToken_freq() + "");

				gkProcessBObj.setScore(input.getMl_score() + "");

				gkProcessBObj.setMl_flag(input.getMl_flag());

				gkProcessBObj.setAddress_match_score(input.getAddress_match_score());

				gkProcessBObj.setName_match_score(input.getName_match_score());

				gkProcessBObj.setDescription(record.getDescription());

				gkProcessBObj.setSuspectName(record.getStdOrgName());
				
				gkProcessBObj.setSuspectID(record.getGkId());

				@SuppressWarnings("unchecked")
				Map<String, String> adr = transform((Map<String, Object>) record.getStdAddress());

				if (adr.size() > 0)
					gkProcessBObj.setStdAddress(adr);

				gkProcessBObj.setScore(input.getMl_score());

				gkProcessBObj.setSourceSystemID(record.getSourceId());

				gkProcessBObj.setSourceSystem(record.getSourceTypeName());

				gkProcessBObj.setToken_freq(input.getToken_freq() + "");

				gkProcessBObj.setMl_flag(input.getMl_flag());

				gkProcessBObj.setProfileType(record.getProfileType());

				gkProcessBObj.setParent_duns(record.getParent_duns());

				gkProcessBObj.setIs_franchies(record.getIs_franchies());

				gkProcessBObj.setUtl_parent_duns(record.getUtl_parent_duns());

				gkProcessBObj.setCustomer_phone(record.getCustomer_phone());

				gkProcessBObj.setCustomer_prime_contact(record.getCustomer_prime_contact());

				gkProcessBObj.setCustomer_url(record.getCustomer_url());

				gkProcessBObj.setInput_phone(record.getInput_phone());

				gkProcessBObj.setInput_contact(record.getInput_contact());
				
				gkProcessBObj.setKeyType(record.getKeyType());
				
				gkProcessBObj.setKeySegment(record.getKeySegment());
				
				gkProcessBObj.setKeyStatus(record.getKeyStatus());

				gkProcessBObj.setInput_url(record.getInput_url());

				processObjList.add(gkProcessBObj);

			}
		}

		return processObjList;

	}

	private Map<String, String> transform(Map<String, Object> input) throws Exception {
		if (input != null)
			return input.entrySet().stream().collect(Collectors.toMap(e -> e.getKey(), e -> (String) e.getValue()));
		else
			return new HashMap<>();
	}

	@SuppressWarnings("unused")
	private String getNameWithPiped(String name, String address, String flag) throws Exception {

		String ret = "";

		if (name != null && name.trim().length() > 0) {

			ret = name;

			if (address != null && address.trim().length() > 0) {

				if (flag != null && flag.trim().length() > 0 && flag.trim().equalsIgnoreCase("Y")) {

					ret = name + "|" + address;
				}
			}
		}

		// Franchice flasg Y mean return with adddress else name only
		// return ret;
		return name;
	}

	private double getLatLonValue(String value) {

		double val = 0.0;

		try {

			if (value != null && value.trim().length() > 0)
				val = Double.parseDouble(value.trim());
		} catch (Exception e) {
			val = 0.0;
		}

		return val;
	}
}
