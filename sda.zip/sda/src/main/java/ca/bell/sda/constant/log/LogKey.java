package ca.bell.sda.constant.log;

public class LogKey {

	public static final String TIMESTAMP = "TIMESTAMP";
	public static final String REQ_LOG_EX_MSG = "REQ_LOG_EX_MSG";
	public static final String REQ_LOG_EX = "REQ_LOG_EX";

	public static final String REQ_GRP_ID = "REQ_GRP_ID";
	public static final String REQ_MAP = "REQ_MAP";

	public static final String REQ_START = "REQ_START";
	public static final String REQ_END = "REQ_END";
	public static final String REQ_TIME = "REQ_TIME";
	public static final String REQ_RESPONSE = "REQ_RESPONSE";

	public static final String QUERY_BUILD_START = "QUERY_BUILD_START";
	public static final String QUERY_BUILD_END = "QUERY_BUILD_END";
	public static final String QUERY_BUILD_TIME = "QUERY_BUILD_TIME";

	public static final String NAME_STD_START = "NAME_STD_START";
	public static final String NAME_STD_END = "NAME_STD_END";
	public static final String NAME_STD_TIME = "NAME_STD_TIME";

	public static final String ELK_START = "ELK_START";
	public static final String ELK_END = "ELK_END";
	public static final String ELK_TIME = "ELK_TIME";
	public static final String ELK_RESPONSE = "ELK_RESPONSE";

	public static final String DATA_CONV_START = "DATA_CONV_START";
	public static final String DATA_CONV_END = "DATA_CONV_END";
	public static final String DATA_CONV_TIME = "DATA_CONV_TIME";

	public static final String INPUT_VALUE = "INPUT_VALUE";
	public static final String QUERY = "QUERY";
	public static final String SOURCE_FILTER = "SOURCE_FILTER";

	public static final String PARSE_START = "data_parse_start";
	public static final String PARSE_END = "data_parse_end";
	public static final String PARSE_CREATE = "data_create_respose";

	public static final String STD_START = "data_std_start";
	public static final String STD_REQ_NAMEAA = "data_std_req_nameAA";
	public static final String STD_REQ_ADDRWS = "data_std_req_addrws";
	public static final String STD_REQ_CONTACTWS = "data_std_req_contactws";
	public static final String STD_RES_NAMEAA = "data_std_res_nameAA";
	public static final String STD_RES_ADDRWS = "data_std_res_addrws";
	public static final String STD_RES_CONTACTWS = "data_std_res_contactws";
	public static final String STD_END = "data_std_end";

	public static final String ELK_MATCH_QUERIES = "data_elk_qry";

	public static final String FREQ_START = "data_freq_start";
	public static final String FREQ_END = "data_freq_end";
	public static final String FREQ_INPUT = "data_freq_input";
	public static final String FREQ_OUTPUT = "data_freq_output";

	public static final String ML_START = "data_ml_start";
	public static final String ML_END = "data_ml_end";
	public static final String ML_INPUT = "data_ml_input";
	public static final String ML_OUTPUT = "data_ml_output";

	public static final String QUERY_NAME_BUCKET = "name_bucketing";
	public static final String QUERY_ADDRESS_ENRICHMENT = "address_enrichment";

	public static final String QUERY_BOOST_ENRICHMENT = "boost_enrichment";
	
	public static final String STACK_TRACE = "STACK_TRACE";
	public static final String RESPONSE_CODE = "RESPONSE_CODE";
	public static final String HTTP_STATUS = "HTTP_STATUS";
	public static final String START_TIME = "START_TIME";
	public static final String END_TIME = "END_TIME";

}
