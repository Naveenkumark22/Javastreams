package ca.bell.sda.elk;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import ca.bell.sda.constant.query.QueryBoolCondition;
import ca.bell.sda.model.elk.SearchQuery;
import ca.bell.sda.model.tmf.AttributeFilter;
import ca.bell.sda.model.tmf.TMFSearch;

@Component
public class TMFQueryBuilder extends QueryBuilder {

	private final static String MUST_KEY = "must";
	private final static String SHOULD_KEY = "should";
	private final static String CONTAINS_KEY = "contains";
	private final static String NOT_EQUAL_KEY = "neq";
	private final static String MUST_NOT_KEY = "must_not";
	private final static String BOOL_KEY = "bool";

	public SearchQuery createSearchQuery(TMFSearch tmfSearch) {
		SearchQuery searchQuery = new SearchQuery();
		setParameters(tmfSearch, searchQuery);
		Map<String, Object> boolMap = new HashMap<>(1);
		boolMap.put(BOOL_KEY, processSearchQuery(tmfSearch));
		searchQuery.setQuery(boolMap);
		return searchQuery;
	}

	private Map<String, List<Map<String, Object>>> processSearchQuery(TMFSearch tmfSearch) {
		Map<String, List<Map<String, Object>>> searchQueryGrp = new HashMap<>();
		List<Map<String, Object>> mustQueryList = new ArrayList<Map<String, Object>>();
		List<Map<String, Object>> shouldQueryList = new ArrayList<Map<String, Object>>();
		List<Map<String, Object>> mustNotQueryList = new ArrayList<Map<String, Object>>();
		tmfSearch.getFilter().forEach(filterGrp -> {
			String boolCondition = QueryBoolCondition.getBoolCondition(filterGrp.getGroupOperator().toLowerCase());
			filterGrp.getFilter().forEach(attrbFilter -> {
				if (boolCondition.equalsIgnoreCase(MUST_KEY)) {
					setQueryList(boolCondition,attrbFilter,mustQueryList,mustNotQueryList);
				}
				else if (boolCondition.equalsIgnoreCase(SHOULD_KEY)) 
				{
					setQueryList(boolCondition,attrbFilter,shouldQueryList,mustNotQueryList);
				}
				
				
			});
			// searchQueryGrp.put(boolCondition, queryList);
		});
		
		List<Map<String,Object>> searchQueryList= new ArrayList<Map<String,Object>>();
		if (mustQueryList.size() > 0)
			searchQueryList.add(getBooleanQuery(MUST_KEY,mustQueryList));
		if (shouldQueryList.size() > 0)
			searchQueryList.add(getBooleanQuery(SHOULD_KEY,shouldQueryList));
		if (mustNotQueryList.size() > 0)
			searchQueryList.add(getBooleanQuery(MUST_NOT_KEY,mustNotQueryList));
		
		if(searchQueryList.size()>0)
		{
			if(tmfSearch.getGroupOperator()==null||tmfSearch.getGroupOperator().equalsIgnoreCase("AND"))			
				searchQueryGrp.put(MUST_KEY, searchQueryList);			
			else
				searchQueryGrp.put(SHOULD_KEY, searchQueryList);
		}
		return searchQueryGrp;
	}

	private Map<String, Object> getBooleanQuery(String conditionKey, List<Map<String, Object>> queryList) {
		// TODO Auto-generated method stub
		Map<String, Object> boolMap=new HashMap<String, Object>();
		Map<String,Object> conditionMap= new HashMap<String,Object>();		
		conditionMap.put(conditionKey, queryList);
		boolMap.put(BOOL_KEY, conditionMap);
		
		return boolMap;
	}

	private void setQueryList(String boolCondition, AttributeFilter attrbFilter,
			List<Map<String, Object>> queryList, List<Map<String, Object>> mustNotQueryList) {
		String operator=attrbFilter.getOperator();
		String fieldName = attrbFilter.getField();
		if(operator!=null&&fieldName!=null&&boolCondition!=null)
		{
			if (fieldName.contains(".")) { // Nested level field
				String[] nestedPaths = fieldName.split("\\.");
				
				if (operator.equalsIgnoreCase(CONTAINS_KEY)) {
					queryList.add(WildCardQueries.getMultiNestedWildcardQuery(nestedPaths,
							attrbFilter.getValue(), boolCondition));
				}
				else if(operator.equalsIgnoreCase(NOT_EQUAL_KEY)){
					mustNotQueryList.add(TermsQueries.getMultiNestedTermsQuery(nestedPaths, attrbFilter.getValue(),
							boolCondition));
				}else {
					
					queryList.add(TermsQueries.getMultiNestedTermsQuery(nestedPaths, attrbFilter.getValue(),
							boolCondition));
				}
			} else { // Root level field
				if (operator.equalsIgnoreCase(CONTAINS_KEY)) {
					queryList.add(WildCardQueries.getWildcardQuery(fieldName, attrbFilter.getValue()));
				}
				else if(operator.equalsIgnoreCase(NOT_EQUAL_KEY)){
					mustNotQueryList.add(TermsQueries.getTermsQuery(fieldName, attrbFilter.getValue()));
				}
				else {
					queryList.add(TermsQueries.getTermsQuery(fieldName, attrbFilter.getValue()));
				}
			}
		
	}
	}

	private void setParameters(TMFSearch tmfSearch, SearchQuery searchQuery) {
		if (tmfSearch.getSize() != null) {
			searchQuery.setSize(tmfSearch.getSize().toString());
			if (tmfSearch.getFrom() != null) {
				searchQuery.setFrom(tmfSearch.getFrom().toString());
			}
		}

		// Getting Sort String
		String sortString = tmfSearch.getSort();

		// Validating not null and not an empty string
		if (sortString != null && sortString.trim().length() > 0)
			searchQuery.setSort(getSort(tmfSearch.getSort().trim()));

		if (tmfSearch.getFields() != null) {
			searchQuery.setSourceFilter(tmfSearch.getFields());
		}
	}

	private List<Map<String, Object>> getSort(String searchStr) {

		List<Map<String, Object>> qryList = new ArrayList<>();

		Map<String, Object> qry = new HashMap<String, Object>();

		Map<String, Object> order = new HashMap<String, Object>();
		String searchString=searchStr;
		if(StringUtils.startsWithAny(searchStr, "+", "-"))
		{
			searchString=searchStr.substring(1);
		}
		if(searchString.contains("."))
		{
			order.put("nested_path", searchString.split("\\.")[0]);	
		}
		// - -> descending order
		// +or no sign -> ascending order
		order.put("order", searchStr.startsWith("-") ? "desc" : "asc");

		// If order signature is present trimming the sign otherwise no trimming
		qry.put(searchString, order);

		qryList.add(qry);

		return qryList;
	}

}
