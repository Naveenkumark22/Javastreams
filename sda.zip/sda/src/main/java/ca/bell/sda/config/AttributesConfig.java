package ca.bell.sda.config;

import java.util.Map;
import java.util.Set;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.stereotype.Component;

import ca.bell.sda.constant.query.SourceFilterSet;
import ca.bell.sda.model.config.AttributeProperties;
import ca.bell.sda.model.config.DataAttributes;

@Component
@EnableConfigurationProperties
@ConfigurationProperties("attributes")
public class AttributesConfig {

	private Map<String, Map<String, DataAttributes>> dataAttributes;

	private Map<String, Map<String, Set<String>>> entityMap;

	private Map<String, Map<String, Set<String>>> source;

	private Map<String, Map<String, AttributeProperties>> properties;

	private Map<String, String> errorStatus;

	private Map<String, String> validationRuleMap;

	public Set<String> getSourceDefaultSet(String grpId) {
		return source.get(grpId).get(SourceFilterSet.DEFAULT);
	}

	public Set<String> getSourceDeniedSet(String grpId) {
		return source.get(grpId).get(SourceFilterSet.DENIED);
	}

	public Set<String> getSourceCompleteSet(String grpId) {
		return source.get(grpId).get(SourceFilterSet.COMPLETE);
	}

	public Map<String, Map<String, Set<String>>> getSource() {
		return source;
	}

	public void setSource(Map<String, Map<String, Set<String>>> source) {
		this.source = source;
	}

	public Map<String, Map<String, AttributeProperties>> getProperties() {
		return properties;
	}

	public void setProperties(Map<String, Map<String, AttributeProperties>> properties) {
		this.properties = properties;
	}

	public Map<String, String> getErrorStatus() {
		return errorStatus;
	}

	public void setErrorStatus(Map<String, String> errorStatus) {
		this.errorStatus = errorStatus;
	}

	public Map<String, String> getValidationRuleMap() {
		return validationRuleMap;
	}

	public void setValidationRuleMap(Map<String, String> validationRuleMap) {
		this.validationRuleMap = validationRuleMap;
	}

	public Map<String, Map<String, Set<String>>> getEntityMap() {
		return entityMap;
	}

	public void setEntityMap(Map<String, Map<String, Set<String>>> entityMap) {
		this.entityMap = entityMap;
	}

	public Map<String, Map<String, DataAttributes>> getDataAttributes() {
		return dataAttributes;
	}

	public void setDataAttributes(Map<String, Map<String, DataAttributes>> dataAttributes) {
		this.dataAttributes = dataAttributes;
	}

}
