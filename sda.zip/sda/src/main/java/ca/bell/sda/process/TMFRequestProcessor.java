package ca.bell.sda.process;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;

import ca.bell.sda.model.Error;
import ca.bell.sda.model.InvalidRequestException;
import ca.bell.sda.model.Request;
import ca.bell.sda.model.Response;
import ca.bell.sda.model.tmf.AttributeFilter;
import ca.bell.sda.model.tmf.FilterGroup;
import ca.bell.sda.model.tmf.FilterOperator;
import ca.bell.sda.model.tmf.TMFSearch;

@Component
public class TMFRequestProcessor {

//	@Autowired
//	private AttributesConfig attributesConfig;
//


	public void processSearcRequest(TMFSearch tmfSearch, Request request, Response response)
			throws InvalidRequestException {
//		Map<String, AttributeProperties> attrbProperties = attributesConfig.getProperties().get(request.getReqId());
		List<FilterGroup> filterGrpList = tmfSearch.getFilter();
		List<Error> errorList = new ArrayList<>();
		for (int i = 0; i < filterGrpList.size(); i++) {
			validateFilterGroup(i, filterGrpList.get(i), errorList,request);
		}
		if (!errorList.isEmpty()) {
			throw new InvalidRequestException(errorList);
		}
	}

	private void validateFilterGroup(int index, FilterGroup filterGrp, List<Error> errorList,Request request) {
		List<AttributeFilter> attrbFilterList = filterGrp.getFilter();
		for (int i = 0; i < attrbFilterList.size(); i++) {
			AttributeFilter attrbFilter = attrbFilterList.get(i);
			Map<String,Object> requestMap=new HashMap<String,Object>();
			
			if(attrbFilter.getField().equalsIgnoreCase("relatedPartyAccount.relatedId")||attrbFilter.getField().equalsIgnoreCase("relatedEntity.relatedId"))
			{
				requestMap.put("relatedId", attrbFilter.getValue()[0]);
				request.setRequestMap(requestMap);
			}
			if(attrbFilter.getField().equalsIgnoreCase("id"))
			{
				requestMap.put("id", attrbFilter.getValue()[0]);
				request.setRequestMap(requestMap);
			}
			if (attrbFilter.getOperator().equalsIgnoreCase(FilterOperator.EQUAL) && attrbFilter.getValue().length > 1) {
				errorList.add(new Error("filter[" + index + "].filter[" + i + "].value", "Invalid value count"));
			}
		}
	}

}
