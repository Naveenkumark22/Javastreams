package ca.bell.sda.model;

import java.util.Map;

public class AppProperty {

	private String name;
	private Map<String, String[]> indexMap;
	private Map<String,Map<String, String>> endpoints;
	private boolean requestLog;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Map<String, String[]> getIndexMap() {
		return indexMap;
	}

	public void setIndexMap(Map<String, String[]> indexMaps) {
		this.indexMap = indexMaps;
	}

	public boolean isRequestLog() {
		return requestLog;
	}

	public void setRequestLog(boolean requestLog) {
		this.requestLog = requestLog;
	}

	public Map<String,Map<String, String>> getEndpoints() {
		return endpoints;
	}

	public void setEndpoints(Map<String,Map<String, String>> endpoints) {
		this.endpoints = endpoints;
	}
	
	public Map<String,String> getEndpoint(String srcName){
		return getEndpoints().get(srcName);
	}

}
