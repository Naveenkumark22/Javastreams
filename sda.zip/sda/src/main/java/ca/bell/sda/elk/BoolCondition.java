package ca.bell.sda.elk;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Component;

@Component
public class BoolCondition {

	public static Map<String, Object> getBoolCondition(String boolCondition, Object boolObject) {
		Map<String, Object> rootMap = new HashMap<>();
		Map<String, Object> boolConditionMap = new HashMap<>();

		boolConditionMap.put(boolCondition, boolObject);
		rootMap.put("bool", boolConditionMap);

		return rootMap;
	}

	public static Map<String, Object> getAndCondition(Object boolObject) {
		return getBoolCondition("must", boolObject);
	}

	public static Map<String, Object> getOrCondition(Object boolObject) {
		return getBoolCondition("should", boolObject);
	}

}
