package ca.bell.sda.process;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import ca.bell.sda.config.AttributesConfig;
import ca.bell.sda.constant.query.ElasticKey;
import ca.bell.sda.model.Request;
import ca.bell.sda.model.config.DataAttributes;
import ca.bell.sda.model.elk.response.ResponseData;
import ca.bell.sda.model.service.HierarchyData;

@Component
public class HierarchyDataProcessor extends ElasticDataProcessor implements DataProcessor {

	@Autowired
	private AttributesConfig attributesConfig;

	private final String idKey = "id";
	private final String nameKey = "name";
	private final String childHrchyNode = "organizationChildRelationship";
	private final String parentHrchyNode = "relatedParty";
	private final String parentNodeKey = "parent_gk";
	private final String parentNameKey = "parent_gk_name";
	private final String parentVirtualKey = "parentGKVirtualOrg";
	private final String childVirtualKey = "childGKVirtualOrg";
	private final String virtualKey = "virtualOrganization";
	private final String childNodeKey = "child_gk";
	private final String childNameKey = "child_gk_name";

	@Override
	public <T> ResponseData processData(Request request, T data) {
		return null;
	}

	public List<Map<String, Object>> childAsChildRelationship(Request request, Object elkData,
			Map<String, Map<String, Object>> nodes) {
		return processHrchyNodes(request, elkData, childHrchyNode, nodes);
	}

	public List<Map<String, Object>> parentAsRelatedParty(Request request, Object elkData,
			Map<String, Map<String, Object>> nodes) {
		return processHrchyNodes(request, elkData, parentHrchyNode, nodes);
	}

	@SuppressWarnings("unchecked")
	public void processLevelBasedNodes(Request request, HierarchyData hrchyData, Map<String, Object> data) {
		Set<String> keySet = hrchyData.getNextRoundKey();
		Set<String> nextRoundKeySet = new HashSet<>();
		List<Map<String, Object>> srcProfileList = getProfileMapList(data);
		for (Map<String, Object> srcProfile : srcProfileList) {
			Map<String, Object> sourceMap = (Map<String, Object>) srcProfile.get(ElasticKey.SOURCE);
			String parentNodeId = (String) sourceMap.get(parentNodeKey);
			String childNodeId = (String) sourceMap.get(childNodeKey);
			Map<String, Object> relatedProfile = null;
			if (keySet.contains(parentNodeId)) {// Process Child GK
				relatedProfile = processNetworkNode(hrchyData, parentNodeId, parentNameKey,parentVirtualKey,
						hrchyData.getChildDataAttrbs(), childHrchyNode, sourceMap);
				addHierarchyFlag(hrchyData, parentNodeId, "hasChild");
				relatedProfile.put(virtualKey,
						sourceMap.getOrDefault(childVirtualKey, "false").toString().toLowerCase());
				relatedProfile.put("hasParent", "true");
			} else if (keySet.contains(childNodeId)) {// Process Parent GK
				relatedProfile = processNetworkNode(hrchyData, childNodeId, childNameKey,childVirtualKey,
						hrchyData.getParentDataAttrbs(), parentHrchyNode, sourceMap);
				addHierarchyFlag(hrchyData, parentNodeId, "hasParent");
				relatedProfile.put(virtualKey,
						sourceMap.getOrDefault(parentVirtualKey, "false").toString().toLowerCase());
				relatedProfile.put("hasChild", "true");
			}
			if (relatedProfile != null) {
				String relatedId = relatedProfile.get(idKey).toString();
				hrchyData.getNodes().put(relatedId, relatedProfile);
				if (!keySet.contains(relatedId) && !hrchyData.getProcessedKey().contains(relatedId)) {
					nextRoundKeySet.add(relatedId);
				}
			}
		}
		hrchyData.getProcessedKey().addAll(keySet);
		hrchyData.getNextRoundKey().clear();
		hrchyData.getNextRoundKey().addAll(nextRoundKeySet);
	}

	private void addHierarchyFlag(HierarchyData hrchyData, String targetKey, String hrchyFlag) {
		if (hrchyData.getNodes().containsKey(targetKey)) {
			hrchyData.getNodes().get(targetKey).put(hrchyFlag, "true");
		}
	}

	private Map<String, Object> processNetworkNode(HierarchyData hrchyData, String targetNodeId, String targetNameKey,
			String targetVirtualKey, DataAttributes targetDataAttrbs, String targetHrchykey, Map<String, Object> sourceMap) {
		Map<String, Map<String, Object>> masterProfileMap = hrchyData.getProfileMap();
		Map<String, Object> profile;
		if (masterProfileMap.containsKey(targetNodeId)) {
			profile = masterProfileMap.get(targetNodeId);
		} else {
			profile = getNewProfileMap(targetNodeId, sourceMap.get(targetNameKey).toString(),
					sourceMap.getOrDefault(targetVirtualKey, "false").toString().toLowerCase());
			hrchyData.getProfileList().add(profile);
			masterProfileMap.put(targetNodeId, profile);
		}
		Map<String, Object> relatedProfile = processNetworkProfile(sourceMap, targetDataAttrbs);
		addToProfileList(profile, targetHrchykey, relatedProfile);
		return relatedProfile;
	}

	private Map<String, Object> getNewProfileMap(String id, String name,String virtualOrg) {
		Map<String, Object> profile = new HashMap<>();
		profile.put(idKey, id);
		profile.put(nameKey, name);
		profile.put(virtualKey, virtualOrg);
		return profile;
	}

	private Map<String, Object> processNetworkProfile(Map<String, Object> sourceMap, DataAttributes dataAttrbs) {
		Map<String, Object> targetMap = new HashMap<>();
		processDataMapWithDefault(sourceMap, targetMap, dataAttrbs.getKeyPairs(), dataAttrbs.getDefaultValues());
		return targetMap;
	}

	@SuppressWarnings("unchecked")
	private void addToProfileList(Map<String, Object> targetProfile, String targetKey, Map<String, Object> srcProfile) {
		Object targetObj = targetProfile.get(targetKey);
		List<Map<String, Object>> targetList = new ArrayList<>();
		if (targetObj != null) {
			targetList = (List<Map<String, Object>>) targetObj;
		} else {
			targetProfile.put(targetKey, targetList);
		}
		targetList.add(srcProfile);

	}

	@SuppressWarnings("unchecked")
	public void processImmediateNodes(Request request, Map<String, Object> proflie, Object elkData,
			Map<String, Map<String, Object>> nodes) {
		Map<String, Object> data = (Map<String, Object>) elkData;
		String idStr = (String) request.getQueryAttrbList().get(0).getValue();
		int total = getTotalValue(data);
		if (total > 0) {
			DataAttributes childDataAttrbs = attributesConfig.getDataAttributes().get(request.getReqId())
					.get(childHrchyNode);
			DataAttributes parentDataAttrbs = attributesConfig.getDataAttributes().get(request.getReqId())
					.get(parentHrchyNode);
			List<Map<String, Object>> profileList = getProfileMapList(data);
			List<Map<String, Object>> childNodeList = new ArrayList<>();
			List<Map<String, Object>> parentNodeList = new ArrayList<>();
			Map<String, Object> targetMap;
			for (Map<String, Object> profile : profileList) {
				Map<String, Object> sourceMap = (Map<String, Object>) profile.get(ElasticKey.SOURCE);
				String profileIdStr = (String) sourceMap.get(parentNodeKey);
				targetMap = new HashMap<>();
				if (idStr.equalsIgnoreCase(profileIdStr)) { // Process Child GK
					targetMap.put(virtualKey,
							sourceMap.getOrDefault(childVirtualKey, "false").toString().toLowerCase());
					processDataMapWithDefault(sourceMap, targetMap, childDataAttrbs.getKeyPairs(),
							childDataAttrbs.getDefaultValues());
					childNodeList.add(targetMap);
					nodes.put((String) sourceMap.get(childNodeKey), targetMap);
				} else { // Process Parent GK
					targetMap.put(virtualKey,
							sourceMap.getOrDefault(parentVirtualKey, "false").toString().toLowerCase());
					processDataMapWithDefault(sourceMap, targetMap, parentDataAttrbs.getKeyPairs(),
							parentDataAttrbs.getDefaultValues());
					parentNodeList.add(targetMap);
					nodes.put(profileIdStr, targetMap);
				}
			}
			if (!childNodeList.isEmpty()) {
				proflie.put(childHrchyNode, childNodeList);
			}
			if (!parentNodeList.isEmpty()) {
				proflie.put(parentHrchyNode, parentNodeList);
			}
		}
	}

	@SuppressWarnings("unchecked")
	public List<Map<String, Object>> processHrchyNodes(Request request, Object elkData, String hrchyType,
			Map<String, Map<String, Object>> nodes) {
		Map<String, Object> data = (Map<String, Object>) elkData;
		int total = getTotalValue(data);
		if (total > 0) {
			DataAttributes dataAttrbs = attributesConfig.getDataAttributes().get(request.getReqId()).get(hrchyType);
			List<Map<String, Object>> profileList = getProfileMapList(data);
			List<Map<String, Object>> nodeList = new ArrayList<>();
			Map<String, Object> targetMap;
			for (Map<String, Object> profile : profileList) {
				Map<String, Object> sourceMap = (Map<String, Object>) profile.get(ElasticKey.SOURCE);
				targetMap = new HashMap<>();
				if(hrchyType.equalsIgnoreCase(childHrchyNode))
				{
					targetMap.put(virtualKey,
							sourceMap.getOrDefault(childVirtualKey, "false").toString().toLowerCase());
				}
				else
				{
					targetMap.put(virtualKey,
							sourceMap.getOrDefault(parentVirtualKey, "false").toString().toLowerCase());
				}
				processDataMapWithDefault(sourceMap, targetMap, dataAttrbs.getKeyPairs(),
						dataAttrbs.getDefaultValues());
				nodes.put((String) targetMap.get(idKey), targetMap);
				nodeList.add(targetMap);
			}
			return nodeList;
		}
		return null;
	}

}
