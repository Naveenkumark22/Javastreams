package ca.bell.sda.model.config;

import java.util.List;

public class AppGroup {

	private Endpoint endPoint;
	private List<String> indexNames;

	public Endpoint getEndPoint() {
		return endPoint;
	}

	public void setEndPoint(Endpoint endPoint) {
		this.endPoint = endPoint;
	}

	public List<String> getIndexNames() {
		return indexNames;
	}

	public void setIndexNames(List<String> indexNames) {
		this.indexNames = indexNames;
	}

}
