/**
 *
 */
package ca.bell.sda.model.whitespace;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import ca.bell.sda.model.whitespace.ml.AdditionalQueryCall;

/**
 * @author Kamalanathan Ranganathan
 */

/*
 * This will be used to get as response from Standardization
 *
 * Same will be input of ELK Bucketing. Response will be List of OrgRecord
 */
public class StdOrgRecord {

	private boolean isNullRecord = true;

	private AdditionalQueryCall secondCall = null;

	private List<String> names = new ArrayList<>();

	private String qryName = "";

	private Map<String, Object> src = new HashMap<>();

	private ELKAddress elkAddress = new ELKAddress();

	private STDAddress stdAddress = new STDAddress();

	private boolean isInputAddressPresent = true;

	private String profileType = "";

	// Franchise Flag
	private String franchiseFlag = null;

	private String gkId = "";

	//AA standardized name
	private String stdOrgName = "";
	
	//Malibu standardized name from AA
	private String stdMalibuOrgName = "";

	private String stdAlternateName = "";

	private String stdNumberEquivalent = "";

	private String tn = "";

	private String email = "";

	private String url = "";

	private String tnIndicator = "N";

	private double score;

	private Map<Long, String> partyIDMap;

	private Map<String, String> extraMasterKey;

	private String combinedAddress = "";

	private String parent_duns = null;
	
	private String customer_url = null;
	
	private String customer_phone = null;
	
	private String utl_parent_duns = null;
	
	private String customer_prime_contact = null;
	
	private String keyStatus=null;
	
	private String keySegment=null;
	
	private String keyType=null;
	
	private String linkedKey=null;

	public StdOrgRecord() {

	}

	public StdOrgRecord(RecordBuilder builder) {

		this.gkId = builder.gkId;

		this.stdOrgName = builder.stdOrgName;
		
		this.stdMalibuOrgName = builder.stdMalibuOrgName;

		this.stdAlternateName = builder.stdAlternateName;

		this.stdNumberEquivalent = builder.stdNumberEquivalent;

		this.score = builder.score;

		this.stdAddress = builder.stdAddress;

		this.elkAddress = builder.elkAddress;

		this.tn = builder.tn;

		this.email = builder.email;

		this.tnIndicator = builder.tnIndicator;

		this.url = builder.url;

		this.qryName = builder.qryName;

		this.franchiseFlag = builder.franchiseFlag;

		this.profileType = builder.profileType;

		this.combinedAddress = builder.combinedAddress;
		
		this.linkedKey = builder.linkedKey;
		
		
	}

	
	public String getLinkedKey() {
		return linkedKey;
	}

	public void setLinkedKey(String linkedKey) {
		this.linkedKey = linkedKey;
	}

	public String getKeyStatus() {
		return keyStatus;
	}

	public void setKeyStatus(String keyStatus) {
		this.keyStatus = keyStatus;
	}

	public String getKeySegment() {
		return keySegment;
	}

	public void setKeySegment(String keySegment) {
		this.keySegment = keySegment;
	}

	public String getKeyType() {
		return keyType;
	}

	public void setKeyType(String keyType) {
		this.keyType = keyType;
	}

	public String getParent_duns() {
		return parent_duns;
	}

	public void setParent_duns(String parent_duns) {
		this.parent_duns = parent_duns;
	}

	public String getCustomer_url() {
		return customer_url;
	}

	public void setCustomer_url(String customer_url) {
		this.customer_url = customer_url;
	}

	public String getCustomer_phone() {
		return customer_phone;
	}

	public void setCustomer_phone(String customer_phone) {
		this.customer_phone = customer_phone;
	}

	public String getUtl_parent_duns() {
		return utl_parent_duns;
	}

	public void setUtl_parent_duns(String utl_parent_duns) {
		this.utl_parent_duns = utl_parent_duns;
	}

	public String getCustomer_prime_contact() {
		return customer_prime_contact;
	}

	public void setCustomer_prime_contact(String customer_prime_contact) {
		this.customer_prime_contact = customer_prime_contact;
	}

	public String getCombinedAddress() {
		return combinedAddress;
	}

	public void setCombinedAddress(String combinedAddress) {
		this.combinedAddress = combinedAddress;
	}

	public String getGkId() {

		return gkId;
	}

	public void setGkId(String gkId) {

		this.gkId = gkId;
	}

	public String getQryName() {
		return qryName;
	}

	public void setQryName(String qryName) {
		this.qryName = qryName;
	}

	public String getStdOrgName() {

		return stdOrgName;
	}

	public void setStdOrgName(String stdOrgName) {

		this.stdOrgName = stdOrgName;
	}
	
	public String getStdMalibuOrgName() {

		return stdMalibuOrgName;
	}

	public void setStdMalibuOrgName(String malibuOrgName) {

		this.stdMalibuOrgName = malibuOrgName;
	}

	public String getTn() {

		return tn;
	}

	public void setTn(String tn) {

		this.tn = tn;
	}

	public String getEmail() {

		return email;
	}

	public void setEmail(String email) {

		this.email = email;
	}

	public double getScore() {

		return score;
	}

	public void setScore(double score) {

		this.score = score;
	}

	public ELKAddress getElkAddress() {

		return elkAddress;
	}

	public STDAddress getStdAddress() {

		return stdAddress;
	}

	public String getStdAlternateName() {
		return stdAlternateName;
	}

	public void setStdAlternateName(String stdAlternateName) {
		this.stdAlternateName = stdAlternateName;
	}

	public String getStdNumberEquivalent() {
		return stdNumberEquivalent;
	}

	public void setStdNumberEquivalent(String stdNumberEquivalent) {
		this.stdNumberEquivalent = stdNumberEquivalent;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getTnIndicator() {
		return tnIndicator;
	}

	public void setTnIndicator(String tnIndicator) {
		this.tnIndicator = tnIndicator;
	}

	public Map<Long, String> getPartyIDMap() {
		return partyIDMap;
	}

	public void setPartyIDMap(Map<Long, String> partyIDMap) {
		this.partyIDMap = partyIDMap;
	}

	public Map<String, String> getExtraMasterKey() {
		return extraMasterKey;
	}

	public void setExtraMasterKey(Map<String, String> extraMasterKey) {
		this.extraMasterKey = extraMasterKey;
	}

	public Map<String, Object> getSrc() {
		return src;
	}

	public void setSrc(Map<String, Object> src) {
		this.src = src;
	}

	public AdditionalQueryCall getSecondCall() {
		return secondCall;
	}

	public void setSecondCall(AdditionalQueryCall secondCall) {
		this.secondCall = secondCall;
	}

	public List<String> getNames() {
		return names;
	}

	public void setNames(List<String> names) {
		this.names = names;
	}

	public String getFranchiseFlag() {
		return franchiseFlag;
	}

	public void setFranchiseFlag(String franchiseFlag) {
		this.franchiseFlag = franchiseFlag;
	}

	public boolean isInputAddressPresent() {
		return isInputAddressPresent;
	}

	public void setInputAddressPresent(boolean isInputAddressPresent) {
		this.isInputAddressPresent = isInputAddressPresent;
	}

	public String getProfileType() {
		return profileType;
	}

	public void setProfileType(String profileType) {
		this.profileType = profileType;
	}

	public boolean isNullRecord() {
		return isNullRecord;
	}

	public void setNullRecord(boolean isNullRecord) {
		this.isNullRecord = isNullRecord;
	}

	@Override
	public String toString() {

		String str = "Org : \n";

		str = str + "  gkId = " + gkId + "\n" +

				"  stdOrgName = " + printNames() + "\n" +

				"  tn = " + tn + "\n" +

				"  email = " + email + "\n";

		if (stdAddress != null) {
			str = str + stdAddress.toString();
		}

		return str;
	}

	private String printNames() {

		return names.toString();
	}

	public static class RecordBuilder {

		private static final String REPLACESTRING = "";

		private String gkId = "";

		private String stdOrgName = "";
		
		private String stdMalibuOrgName = "";

		private String stdAlternateName = "";

		private String stdNumberEquivalent = "";

		private String tn = "";

		private String email = "";

		private double score;

		private String tnIndicator = "";

		private String qryName = "";

		private String franchiseFlag = "";

		private String url = "";

		private ELKAddress elkAddress = null;

		private STDAddress stdAddress = null;

		private String profileType = "";

		private String combinedAddress = "";
		
		private String linkedKey = null;
		
		public RecordBuilder linkedKey(String linkedKey) {

			linkedKey = linkedKey != null ? linkedKey.trim() : REPLACESTRING;

			return this;
		}

		public RecordBuilder tnIndicator(String tn) {

			tnIndicator = tn != null ? tn.trim() : REPLACESTRING;

			return this;
		}

		public RecordBuilder gkId(String id) {

			gkId = id != null ? id.trim() : REPLACESTRING;

			return this;
		}

		public RecordBuilder stdAlternateName(String name) {

			stdAlternateName = name != null ? name.trim() : REPLACESTRING;

			return this;

		}

		public RecordBuilder stdNumberEquivalent(String name) {

			stdNumberEquivalent = name != null ? name.trim() : REPLACESTRING;

			return this;

		}

		public RecordBuilder stdOrgName(String name) {

			stdOrgName = name != null ? name.trim() : REPLACESTRING;

			return this;

		}

		public RecordBuilder tn(String value) {

			tn = value != null ? value.trim() : REPLACESTRING;

			return this;

		}

		public RecordBuilder url(String value) {

			url = value != null ? value.trim() : REPLACESTRING;

			return this;

		}

		public RecordBuilder email(String value) {

			email = value != null ? value.trim() : REPLACESTRING;

			return this;

		}

		public RecordBuilder stdAddress(STDAddress address) {

			stdAddress = address;

			return this;
		}

		public RecordBuilder elkAddress(ELKAddress address) {

			elkAddress = address;

			return this;
		}

		public RecordBuilder score(double scr) {

			score = scr;

			return this;
		}

		public RecordBuilder qryName(String value) {

			qryName = value != null ? value.trim() : REPLACESTRING;

			return this;

		}

		public RecordBuilder franchiseFlag(String value) {

			franchiseFlag = value != null ? value.trim() : REPLACESTRING;

			return this;

		}

		public RecordBuilder profileType(String value) {

			profileType = value != null ? value.trim() : REPLACESTRING;

			return this;

		}

		public RecordBuilder combinedAddress(String value) {

			combinedAddress = value != null ? value.trim() : REPLACESTRING;

			return this;

		}
		
		
		
		

		public StdOrgRecord build() {

			return new StdOrgRecord(this);
		}

		public RecordBuilder stdMalibuOrgName(String malibuOrgName) {
			stdMalibuOrgName = malibuOrgName != null ? malibuOrgName.trim() : REPLACESTRING;

			return this;
		}

		
	}

}
