package ca.bell.sda.config;

import java.util.Map;
import java.util.Set;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.stereotype.Component;

import ca.bell.sda.model.AppProperty;

@Component
@EnableConfigurationProperties
@ConfigurationProperties("app-prop")
public class AppProperties {

	private Map<String, AppProperty> service;
	private ServerConfig servers;
	private Set<String> environments;

	public Map<String, AppProperty> getService() {
		return service;
	}

	public void setService(Map<String, AppProperty> service) {
		this.service = service;
	}

	public ServerConfig getServers() {
		return servers;
	}

	public void setServers(ServerConfig servers) {
		this.servers = servers;
	}

	public Set<String> getEnvironments() {
		return environments;
	}

	public void setEnvironments(Set<String> environments) {
		this.environments = environments;
	}

}
