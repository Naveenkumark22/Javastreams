package ca.bell.sda.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@EnableConfigurationProperties
@ConfigurationProperties("elk.query")
public class ElasticQueryConfig implements Cloneable {

	private String size;
	private String from;
	private String sort;
	private String minScore;
	private String filterPath;
	private String multiQueryFilterPath;

	public String getSize() {
		return size;
	}

	public void setSize(String size) {
		this.size = size;
	}

	public String getFrom() {
		return from;
	}

	public void setFrom(String from) {
		this.from = from;
	}

	public String getMinScore() {
		return minScore;
	}

	public void setMinScore(String minScore) {
		this.minScore = minScore;
	}

	public String getFilterPath() {
		return filterPath;
	}

	public void setFilterPath(String filterPath) {
		this.filterPath = filterPath;
	}

	@Override
	public ElasticQueryConfig clone() {
		try {
			return (ElasticQueryConfig) super.clone();
		} catch (CloneNotSupportedException ex) {
			return null;
		}
	}

	public String getMultiQueryFilterPath() {
		return multiQueryFilterPath;
	}

	public void setMultiQueryFilterPath(String multiQueryFilterPath) {
		this.multiQueryFilterPath = multiQueryFilterPath;
	}
	
	/**
	 * @return the sort
	 */
	public String getSort() {
		return sort;
	}

	/**
	 * @param sort the sort to set
	 */
	public void setSort(String sort) {
		this.sort = sort;
	}


}
