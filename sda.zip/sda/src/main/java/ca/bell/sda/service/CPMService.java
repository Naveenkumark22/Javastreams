package ca.bell.sda.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;

import ca.bell.sda.config.AttributesConfig;
import ca.bell.sda.config.ElasticQueryConfig;
import ca.bell.sda.constant.log.LogKey;
import ca.bell.sda.constant.status.StatusTypes;
import ca.bell.sda.elk.QueryBuilder;
import ca.bell.sda.model.Error;
import ca.bell.sda.model.Request;
import ca.bell.sda.model.config.AttributeProperties;
import ca.bell.sda.model.elk.Attribute;
import ca.bell.sda.model.elk.SearchQuery;
import ca.bell.sda.model.tmf.AttributeFilter;
import ca.bell.sda.model.tmf.FilterGroup;
import ca.bell.sda.model.tmf.FilterOperator;
import ca.bell.sda.model.tmf.TMFSearch;
import ca.bell.sda.model.whitespace.ml.MLInputRoot;

@Component
public class CPMService {

	public static final int CALL_SEQUENCE_NAME_BUCKET = 0;

	public static final int CALL_SEQUENCE_ADDRESS_ENRICH = 1;

	public static final int CALL_SEQUENCE_FREQ_CALC = 2;

	public static final int CALL_SEQUENCE_ML_DEDUPLICATE = 3;

	@Autowired
	private QueryBuilder queryBuilder;

	@Autowired
	private AttributesConfig attributesConfig;

	public SearchQuery getSearchQuery(Request request) {
		ElasticQueryConfig elkQueryConfg = request.getQueryConfig();
		SearchQuery searchQuery = new SearchQuery();
		searchQuery.setSize(elkQueryConfg.getSize());
		searchQuery.setFrom(elkQueryConfg.getFrom());
		searchQuery.setMinScore(elkQueryConfg.getMinScore());
		searchQuery.setSourceFilter(request.getSourceFilter());
		searchQuery.setQuery(queryBuilder.createSearchQuery(request.getQueryAttrbList(), request.getFilterAttrbList()));
		return searchQuery;
	}

	public Attribute getAttrb(Request request, String param, Object value) {
		Attribute attrb = new Attribute();
		attrb.setValue(value);
		AttributeProperties attrbProperties = attributesConfig.getProperties().get(request.getReqId()).get(param);
		attrb.setProperties(attrbProperties);
		return attrb;
	}

	public boolean isReqConfigFlag(Request request, String attrbName, String matchValue) {
		Attribute flagAttrb = request.getReqConfigAttrb().get(attrbName);
		if (flagAttrb != null && flagAttrb.getValue().toString().equalsIgnoreCase(matchValue)) {
			return true;
		}
		return false;
	}

	public boolean isReqConfigFlag(Request request, String attrbName) {
		for (Entry<String, Object> entry : request.getRequestMap().entrySet()) {
			if (entry.getKey().equalsIgnoreCase(attrbName)) {
				return true;
			}
		}
		return false;
	}

	
	
	// Printing
	public String getAsJSON(MLInputRoot root) throws Exception {

		String json = "";

		try {

			ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();

			json = ow.writeValueAsString(root);

		} catch (Exception e) {

			e.printStackTrace();
		}

		return json;

	}
	
	protected void addFilter(TMFSearch tmfSearch,String groupOperator,String field,String operator,String[] value) {
		FilterGroup filterGroup=	new FilterGroup();
		filterGroup.setGroupOperator(groupOperator);
		AttributeFilter attributeFilter =new AttributeFilter();
		attributeFilter.setField(field);
		attributeFilter.setOperator(operator);
		attributeFilter.setValue(value);
		List<AttributeFilter> attributeFilterList=new ArrayList<AttributeFilter>();
		attributeFilterList.add(attributeFilter);
		filterGroup.setFilter(attributeFilterList);
		List<FilterGroup> filterGroupList=new ArrayList<FilterGroup>();
		filterGroupList.add(filterGroup);
		tmfSearch.getFilter().addAll(filterGroupList);		
	}
	
	protected void modifyFilter(Request request, TMFSearch tmfSearch, String field1, String field2) {
		List<AttributeFilter> attrbFilterList = tmfSearch.getFilter().get(0).getFilter();
		for (int i = 0; i < attrbFilterList.size(); i++) {
			AttributeFilter attrbFilter = attrbFilterList.get(i);
			if(attrbFilter.getField().equalsIgnoreCase(field1))
				attrbFilter.setField(field2);
			
		}
	}
	protected void addExceptionLog(Request request, Exception e) {
		request.log(LogKey.REQ_LOG_EX, e);
		request.log(LogKey.STACK_TRACE, e.getStackTrace());
		request.log(LogKey.RESPONSE_CODE, StatusTypes.INTERNAL_ERROR);
		request.log(LogKey.HTTP_STATUS, HttpStatus.INTERNAL_SERVER_ERROR.value());
		
	}
	
	protected void addSuccessLog(Request request) {
		request.log(LogKey.RESPONSE_CODE, StatusTypes.REQUEST_SUCCESS);
		request.log(LogKey.HTTP_STATUS, HttpStatus.OK.value());	
	}

}
