package ca.bell.sda.model.whitespace.mdm;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author Kamalanathan Ranganathan
 *
 */
public class MDMOutput {

    private GKMatchingProcess gKMatchingProcess;

    @JsonProperty("GKMatchingProcess")
    public GKMatchingProcess getGKMatchingProcess() {
        return this.gKMatchingProcess;
    }

    public void setGKMatchingProcess(GKMatchingProcess gKMatchingProcess) {
        this.gKMatchingProcess = gKMatchingProcess;
    }

}
