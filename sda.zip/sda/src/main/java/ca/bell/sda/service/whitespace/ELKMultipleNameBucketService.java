/**
 *
 */
package ca.bell.sda.service.whitespace;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ca.bell.sda.config.AppConfig;
import ca.bell.sda.constant.log.LogKey;
import ca.bell.sda.constant.webclient.StreamSource;
import ca.bell.sda.dao.SearchDAO;
import ca.bell.sda.elk.WSQueryBuilder;
import ca.bell.sda.external.AddressEnrichmentService;
import ca.bell.sda.model.Request;
import ca.bell.sda.model.config.Endpoint;
import ca.bell.sda.model.whitespace.ELKAddress;
import ca.bell.sda.model.whitespace.STDAddress;
import ca.bell.sda.model.whitespace.StdOrgRecord;
import ca.bell.sda.model.whitespace.ml.AdditionalQueryCall;
import ca.bell.sda.model.whitespace.ml.InputList;
import ca.bell.sda.model.whitespace.ml.MLInputRoot;
import ca.bell.sda.model.whitespace.ml.Record;
import ca.bell.sda.service.CPMService;

/**
 * @author Kamalanathan Ranganathan
 */
@Service
public class ELKMultipleNameBucketService extends CPMService {

	private static final String FROM = "0";

	private static final String SIZE = "5";

	private static final String MINSCORE = "9.0";

	@Autowired
	private WSQueryBuilder queryBuilder;

	@Autowired
	private AppConfig appConfig;

	@Autowired
	private SearchDAO searchDAO;

	@Autowired
	private AddressEnrichmentService addressEnrichmentService;

	//private Map<String, Object> fstqri = new HashMap<>();

	private String[] indexes;

	public MLInputRoot doELKNameBucketing(Request request, StdOrgRecord stdInputOrgdetail) throws Exception {

		try {

			String profileType = getAsFullProfileName(stdInputOrgdetail.getProfileType());

			MLInputRoot root = null;

			indexes = appConfig.getIndexNames(request.getReqId());

			String endPointName = appConfig.getEndpointName(request.getReqId(), StreamSource.INDEX);

			Endpoint ep = appConfig.getAppProps().getServers().getWebService().getEndPoints().get(endPointName);

			String index = indexes[CALL_SEQUENCE_NAME_BUCKET];

			String eurl = String.format("%s/%s", ep.getHost(), index);
			String suspectType=(String) request.getRequestMap().get("suspectType");

			// First Call for getting suspect list from elk
			// Formatting Query
			String qry = queryBuilder.getFirstCallQueryString(stdInputOrgdetail, index, MINSCORE, FROM, SIZE,suspectType);
			
			//fstqri.put(LogKey.QUERY_NAME_BUCKET, qry);
			// Getting filter path from properties
			// Address enrichment
			String filterPath = appConfig.getElasticQueryConfig().getFilterPath();
			
			// Result from DAO
			Map<String, Object> result = searchDAO.querySourceMSearch(endPointName, eurl, qry);
		

			// Address is ELK Address
			List<StdOrgRecord> calloneresultrecords = parseResponse(result);
			
			if (calloneresultrecords != null && calloneresultrecords.size() > 0) {
				
				
				root = new MLInputRoot();

				Map<String, String> partyids = appConfig.getAttributesConfig().getDataAttributes()
						.get(request.getReqId()).get("partyids").getKeyPairs();

				String gkid = stdInputOrgdetail.getGkId();

				STDAddress addr = stdInputOrgdetail.getStdAddress();

				boolean isAddrNull = (addr == null || addr.isAddressEmpty());

				int i = 0;

				if (isAddrNull) {

					List<String> qryNames = stdInputOrgdetail.getNames();

					for (Iterator<String> qryNameItr = qryNames.iterator(); qryNameItr.hasNext();) {

						String qryname = qryNameItr.next().trim();

						for (Iterator<StdOrgRecord> orgrecItr = calloneresultrecords.iterator(); orgrecItr.hasNext();) {

							StdOrgRecord orgRecord = orgrecItr.next();

							if (qryname.equals(orgRecord.getQryName())) {

								Record inputRecord = new Record();

								inputRecord.setGkId(gkid);

								inputRecord.setStdOrgName(qryname);

								inputRecord.setProfileType(profileType);
								
								
								Record suspectRecord = new Record();

								InputList ipList = new InputList();
								
								
								if (orgRecord.getElkAddress().isAddressEmpty()) {

									// Address is null
									// No second call, if input and suspect records address are null

									suspectRecord.setGkId(orgRecord.getGkId());

									suspectRecord.setStdOrgName(orgRecord.getStdOrgName());

									suspectRecord.setScore(orgRecord.getScore());

								} else {

									// Address is not null
									// Second call to match the address of the input record, if suspect record is
									// not null

									suspectRecord.setGkId(orgRecord.getGkId());

									suspectRecord.setStdOrgName(orgRecord.getStdOrgName());

									suspectRecord.setScore(orgRecord.getScore());

									suspectRecord.setStdAddress(orgRecord.getElkAddress());

									qry = queryBuilder.getSecondCallQueryString(gkid,
											orgRecord.getElkAddress().getCombinedAddress());

									// Result from DAO

									index = indexes[CALL_SEQUENCE_ADDRESS_ENRICH];

									String url = String.format("%s/%s", ep.getHost(), index);

									ipList.setSecondCall(
											new AdditionalQueryCall(i, isAddrNull, qry, endPointName, url, filterPath));

								}

								suspectRecord.setCustomer_phone(orgRecord.getCustomer_phone());

								suspectRecord.setCustomer_url(orgRecord.getCustomer_url());

								suspectRecord.setCustomer_prime_contact(orgRecord.getCustomer_prime_contact());

								suspectRecord.setParent_duns(orgRecord.getParent_duns());

								suspectRecord.setUtl_parent_duns(orgRecord.getUtl_parent_duns());
								
								suspectRecord.setKeyStatus(orgRecord.getKeyStatus());
								
								suspectRecord.setKeySegment(orgRecord.getKeySegment());
								
								suspectRecord.setKeyType(orgRecord.getKeyType());
								
								loadinputDetail(inputRecord, stdInputOrgdetail.getPartyIDMap(), partyids);

								loadSuspectDetail(suspectRecord, orgRecord.getSrc());
								
								ipList.setInput_record(inputRecord);

								ipList.setSuspect_record(suspectRecord);

								root.addInput_list(ipList);

								orgrecItr.remove();

							}

						}

						qryNameItr.remove();

					}

				} else {

					List<String> qryNames = stdInputOrgdetail.getNames();

					for (Iterator<String> qryNameItr = qryNames.iterator(); qryNameItr.hasNext();) {

						String qryname = qryNameItr.next().trim();

						for (Iterator<StdOrgRecord> orgrecItr = calloneresultrecords.iterator(); orgrecItr.hasNext();) {

							StdOrgRecord orgRecord = orgrecItr.next();

							if (qryname.equals(orgRecord.getQryName())) {

								Record inputRecord = new Record();

								inputRecord.setGkId(gkid);

								inputRecord.setStdOrgName(qryname);

								inputRecord.setProfileType(profileType);

								// Std Address into input record
								// This will be only applied to input record only
								// For Suspect list is loaded from ELK outputs
								
								
								inputRecord.setStdAddress(stdInputOrgdetail.getElkAddress());

								Record suspectRecord = new Record();

								InputList ipList = new InputList();

								if (orgRecord.getElkAddress().isAddressEmpty()) {

									// Address is null
									// Second call to match the address of the input record, if suspect record is
									// null

									suspectRecord.setGkId(orgRecord.getGkId());

									suspectRecord.setStdOrgName(orgRecord.getStdOrgName());

									suspectRecord.setScore(orgRecord.getScore());
									
									// Matching with result record's GK id and input address
									qry = queryBuilder.getSecondCallQueryString(orgRecord.getGkId(),
											stdInputOrgdetail.getElkAddress().getCombinedAddress());

									index = indexes[CALL_SEQUENCE_ADDRESS_ENRICH];

									String url = String.format("%s/%s", ep.getHost(), index);

									ipList.setSecondCall(
											new AdditionalQueryCall(i, isAddrNull, qry, endPointName, url, filterPath));

								} else {

									// Address is not null
									// No second call, if input and suspect records address are not null

									suspectRecord.setGkId(orgRecord.getGkId());

									suspectRecord.setStdOrgName(orgRecord.getStdOrgName());

									suspectRecord.setStdAddress(orgRecord.getElkAddress());

									suspectRecord.setScore(orgRecord.getScore());

								}

								suspectRecord.setCustomer_phone(orgRecord.getCustomer_phone());

								suspectRecord.setCustomer_url(orgRecord.getCustomer_url());

								suspectRecord.setCustomer_prime_contact(orgRecord.getCustomer_prime_contact());

								suspectRecord.setParent_duns(orgRecord.getParent_duns());

								suspectRecord.setUtl_parent_duns(orgRecord.getUtl_parent_duns());
								
                                suspectRecord.setKeyStatus(orgRecord.getKeyStatus());
								
								suspectRecord.setKeySegment(orgRecord.getKeySegment());
								
								suspectRecord.setKeyType(orgRecord.getKeyType());
								
								

								loadinputDetail(inputRecord, stdInputOrgdetail.getPartyIDMap(), partyids);

								loadSuspectDetail(suspectRecord, orgRecord.getSrc());
								
							
								ipList.setInput_record(inputRecord);

								ipList.setSuspect_record(suspectRecord);

								root.addInput_list(ipList);

								orgrecItr.remove();
							}
						}
						qryNameItr.remove();
					}
				}
			
				if (!isAddrNull || (gkid != null && gkid.trim().length() > 0 && !gkid.trim().equals("0"))) {
					
					applyAddressEnrichment(request, root);
							

				}				

				applyBoostEnrichment(request, root, stdInputOrgdetail.getGkId(), profileType, endPointName, eurl);				
				

				//request.log(LogKey.ELK_MATCH_QUERIES, fstqri);

			}

			return root;

		} catch (Exception e) {

			e.printStackTrace();

			request.log(LogKey.REQ_LOG_EX_MSG, "ELK : " + e.getMessage());

			request.log(LogKey.REQ_LOG_EX, e);

			throw new Exception("ELK : " + e.getMessage());

		}
	}

	@SuppressWarnings("unchecked")
	private void applyAddressEnrichment(Request request, MLInputRoot input) throws Exception {

		List<String> secondqueries = new ArrayList<>();

		try {

			List<AdditionalQueryCall> secArr = getAddressEnrinchList(input);

			if (secArr != null && secArr.size() > 0) {

				CompletableFuture<StdOrgRecord>[] secCallCF = new CompletableFuture[secArr.size()];
				
			
				// Initiating Parallel Call
				for (int i = 0; i < secArr.size(); i++) {

					String sqry = secArr.get(i).getQry();
					// adding for Log
					secondqueries.add(sqry);
					secCallCF[i] = addressEnrichmentService.queryAddressEnrichment(secArr.get(i));
				}

							
				// waiting to complete
				CompletableFuture.allOf(secCallCF);

				List<InputList> inputlist = input.getInput_list();

				for (InputList iplst : inputlist) {

					AdditionalQueryCall scip = iplst.getSecondCall();

					if (scip != null) {

						for (int i = 0; i < secCallCF.length; i++) {

							StdOrgRecord org = secCallCF[i].get();
							
						
							if (org != null && !org.isNullRecord()) {

								AdditionalQueryCall sc = org.getSecondCall();

								if (scip.getIndex() == sc.getIndex()) {

									if (scip.isAddrNull() && iplst.getInput_record().getGkId().equalsIgnoreCase(org.getGkId())) {
										

										iplst.getInput_record().setStdAddress(org.getElkAddress());

									} else if(iplst.getSuspect_record().getGkId().equalsIgnoreCase(org.getGkId())){
										iplst.getSuspect_record().setStdAddress(org.getElkAddress());
									}
								}

							}
						}
					}
				}

				// adding for Log
				//fstqri.put(LogKey.QUERY_ADDRESS_ENRICHMENT, secondqueries);

			}

		} catch (Exception e) {

			request.log(LogKey.REQ_LOG_EX_MSG, " Address Enrichment : " + e.getMessage());

			request.log(LogKey.REQ_LOG_EX, e);

		}
	}

	private List<AdditionalQueryCall> getAddressEnrinchList(MLInputRoot input) throws Exception {
		List<InputList> ipList = input.getInput_list();

		if (ipList == null || ipList.size() == 0)
			return null;

		List<AdditionalQueryCall> secCall = new ArrayList<>();

		for (InputList inputList : ipList) {

			AdditionalQueryCall sec = inputList.getSecondCall();

			if (sec != null) {
				secCall.add(sec);
			}
		}
       
		return secCall;// .toArray(new SecondCall[0]);
	}

	// Parsing the result
	@SuppressWarnings("unchecked")
	private List<StdOrgRecord> parseResponse(Map<String, Object> response) throws Exception {

		String error = isValidResponse(response);

		if (error == null || error.length() == 0) {

			List<Map<String, Object>> responselist = (List<Map<String, Object>>) response.get("responses");

			return getRecordsList(responselist);

		} else
			throw new Exception(error);
	}

	private String isValidResponse(Map<String, Object> response) {

		String ret = "";

		if (response.containsKey("error")) {

			@SuppressWarnings("unchecked")
			Map<String, Object> rootcause = (Map<String, Object>) response.get("error");

			ret = (String) rootcause.get("reason") + " : " + (String) rootcause.get("due_to");

		}

		return ret;
	}

	@SuppressWarnings("unchecked")
	private List<StdOrgRecord> getRecordsList(Object responseobj) throws Exception {

		List<StdOrgRecord> recs = new ArrayList<>();

		if (responseobj != null) {

			List<Map<String, Object>> response = (List<Map<String, Object>>) responseobj;

			response.stream().forEach(res -> {

				try {
					recs.addAll(getRecords((Map<String, Object>) res));
				} catch (Exception e) {

					e.printStackTrace();
				}

			});
		}

		return recs;
	}

	@SuppressWarnings("unchecked")
	private List<StdOrgRecord> getRecords(Map<String, Object> response) throws Exception {

		Map<String, Object> hits = (Map<String, Object>) response.get("hits");

		List<Map<String, Object>> lhits = (List<Map<String, Object>>) hits.get("hits");

		return getOrgRecordList(lhits);

	}

	private void loadSuspectDetail(Record record, Map<String, Object> src) throws Exception {

		Map<String, Object> orgrec = record.getRecord();

		if (src != null && src.size() > 0) {

			src.entrySet().stream().filter(field -> !field.getKey().startsWith("stdAddress")).forEach(entry -> {

				orgrec.put(entry.getKey(), (String) entry.getValue());
			});

		}
	}

	private void loadinputDetail(Record record, Map<Long, String> parties, Map<String, String> fields)
			throws Exception {

		Map<String, Object> orgrec = record.getRecord();

		if ((parties != null && parties.size() > 0) && (fields != null && fields.size() > 0)) {

			parties.entrySet().stream().forEach(entry -> {

				String obj = fields.get(entry.getKey() + "");

				if (obj != null) {

					orgrec.put(obj, entry.getValue());
				}
			});
		}

	}

	private List<StdOrgRecord> getOrgRecordList(List<Map<String, Object>> lhits) throws Exception {

		List<StdOrgRecord> records = null;

		if (lhits != null) {

			records = new ArrayList<>();

			for (Map<String, Object> hit : lhits) {

				records.add(getOrgRecord(hit));

			}
		}

		return records;
	}

	@SuppressWarnings("unchecked")
	private StdOrgRecord getOrgRecord(Map<String, Object> hit) throws Exception {

		StdOrgRecord orgRecord = new StdOrgRecord();

		if (hit != null) {

			double score = (Double) hit.get("_score");

			Map<String, Object> source = (Map<String, Object>) hit.get("_source");

			Map<String, Object> address = (Map<String, Object>) source.get("stdAddress");

			ELKAddress addr = getAddress(address);

			String qName = getQueryName((List<String>) hit.get("matched_queries"));

			orgRecord = new StdOrgRecord.RecordBuilder()

					.gkId((String) source.get("sourceId"))

					.stdOrgName((String) source.get("stdOrgName"))

					.profileType((String) source.get("profileType"))

					.score(score)

					.qryName(qName)

					.elkAddress(addr)
					
					.linkedKey((String) source.get("linkedKey"))
					
					.build();
			orgRecord.setLinkedKey((String) source.get("linkedKey"));

			orgRecord.setParent_duns((String) source.get("parent_duns"));

			orgRecord.setCustomer_url((String) source.get("customer_url"));

			orgRecord.setCustomer_phone((String) source.get("customer_phone"));

			orgRecord.setCustomer_prime_contact((String) source.get("customer_prime_contact"));

			orgRecord.setUtl_parent_duns((String) source.get("utl_parent_duns"));
			
			orgRecord.setKeyStatus((String) source.get("keyStatus"));
			
			orgRecord.setKeySegment((String) source.get("keySegment"));
			
			orgRecord.setKeyType((String) source.get("keyType"));
			
			if(orgRecord.getProfileType().equalsIgnoreCase("SKAccounts"))
				orgRecord.setGkId((String) source.get("gkId"));
			else if(orgRecord.getProfileType().equalsIgnoreCase("Accountbasic"))
				orgRecord.setGkId((String) source.get("linkedKey"));
			
			orgRecord.setSrc(source);

		}

		return orgRecord;

	}

	private ELKAddress getAddress(Map<String, Object> address) throws Exception {

		ELKAddress addr = new ELKAddress();

		if (address != null) {

			// This address is from ELK Bucketing
			addr = new ELKAddress.AddressBuilder()

					.combinedAddress((String) address.get("combinedAddress"))

					.addressLineOne((String) address.get("addressLineOne"))

					.country((String) address.get("country"))

					.postalCode((String) address.get("postalCode"))

					.addressLineTwo((String) address.get("addressLineTwo"))

					.province((String) address.get("province"))

					.city((String) address.get("city")).build();

		}

		return addr;

	}

	private String getQueryName(List<String> qryname) throws Exception {

		String ret = "";

		if (qryname != null) {

			if (qryname.size() > 0) {

				ret = qryname.get(0);

			}

		}

		return ret;
	}

	private void applyBoostEnrichment(Request request, MLInputRoot input, String inputgkid, String profiletype,
			String endPointName, String eurl) throws Exception {

		List<InputList> inputlist = input.getInput_list();

		StringBuilder qryBuffer = new StringBuilder();
		
			
		for (InputList inputList : inputlist) {

			Record ipRecord = inputList.getInput_record();

			Record spRecord = inputList.getSuspect_record();

			String id = "";

			Map<String, Object> match = null;

			if (profiletype.equals("GKAccounts")) {

				id = inputgkid;

				if (spRecord.getProfileType().equals("SKAccounts")) {

					match = getMatchedValues(id, spRecord);
				}

				Map<String, Object> result = getResultFromAPIMSearch(match, endPointName, eurl, qryBuffer);

				fillValues(ipRecord, result);

			} else if (spRecord.getProfileType().equals("GKAccounts")||spRecord.getProfileType().equals("Accountbasic")) {
				
				if(spRecord.getProfileType().equals("Accountbasic"))
					id=spRecord.getLinkedKey();
				else
					id = spRecord.getGkId();
				if (profiletype.equals("SKAccounts")) {

					match = getMatchedValues(id, ipRecord);
				}

				
				Map<String, Object> result = getResultFromAPIMSearch(match, endPointName, eurl, qryBuffer);

				fillValues(spRecord, result);
			}

		}
		
		//request.log(LogKey.QUERY_BOOST_ENRICHMENT, qryBuffer.toString());

	}

	@SuppressWarnings("unchecked")
	private void fillValues(Record record, Map<String, Object> result) {

		if (result != null && result.size() > 0) {

			String error = isValidResponse(result);

			if (error == null || error.length() == 0) {

				List<Map<String, Object>> responselist = (List<Map<String, Object>>) result.get("responses");

				for (Map<String, Object> response : responselist) {

					Map<String, Object> hits = (Map<String, Object>) response.get("hits");

					List<Map<String, Object>> lhits = (List<Map<String, Object>>) hits.get("hits");

					for (Map<String, Object> hit : lhits) {

						Map<String, Object> src = (Map<String, Object>) hit.get("_source");

						String value = (String) src.get("customer_phone");
						if (value != null)
							record.setCustomer_phone((String) src.get("customer_phone"));

						value = (String) src.get("customer_url");
						if (value != null)
							record.setCustomer_url((String) src.get("customer_url"));

						value = (String) src.get("customer_prime_contact");
						if (value != null)
							record.setCustomer_prime_contact((String) src.get("customer_prime_contact"));

						value = (String) src.get("parent_duns");
						if (value != null)
							record.setParent_duns((String) src.get("parent_duns"));

						value = (String) src.get("utl_parent_duns");
						if (value != null)
							record.setUtl_parent_duns((String) src.get("utl_parent_duns"));
					}

				}

			}

		}
	}

	private Map<String, Object> getResultFromAPIMSearch(Map<String, Object> matching, String endpoint, String url,
			StringBuilder qryBuffer) throws Exception {

		if (matching == null || matching.size() == 0)
			return null;

		String qry = queryBuilder.getFillMissingFieldsQueryString(matching);

		if (qry.trim().length() > 0) {

			qryBuffer.append(qry);

			Map<String, Object> result = searchDAO.querySourceMSearch(endpoint, url, qry);
			
			return result;

		}

		else
			return null;

	}

	private Map<String, Object> getMatchedValues(String ipid, Record record) throws Exception {

		Map<String, Object> values = new HashMap<>();

		values.put("id", ipid);

		String value = record.getUtl_parent_duns();
		if (value != null && value.trim().length() > 0) {

			values.put("utl_parent_duns", value);
		}

		value = record.getParent_duns();
		if (value != null && value.trim().length() > 0) {

			values.put("parent_duns", value);
		}

		value = record.getCustomer_prime_contact();
		if (value != null && value.trim().length() > 0) {

			values.put("customer_prime_contact", value);
		}
		
		value = record.getCustomer_phone();
		if (value != null && value.trim().length() > 0) {

			values.put("customer_phone", value);
		}
		
		value = record.getCustomer_url();
		if (value != null && value.trim().length() > 0) {

			values.put("customer_url", value);
		}

		return values;
	}

	private String getAsFullProfileName(String profile) {

		String ret = "GKAccounts";

		if (profile.equalsIgnoreCase("SK") || profile.equalsIgnoreCase("SKAccounts"))
			ret = "SKAccounts";
		else if (profile.equalsIgnoreCase("GK") || profile.equalsIgnoreCase("GKAccounts"))
			ret = "GKAccounts";

		return ret;
	}
}
