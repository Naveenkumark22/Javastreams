package ca.bell.sda.model.whitespace.mdm;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author Kamalanathan Ranganathan
 *
 */
public class BBMPartyAddressBObjExt {

    private int addressSourceType = 1000001;

    private String matchType = "CORRECTED";

    @JsonProperty("addressSourceType")
    public int getAddressSourceType() {
        return this.addressSourceType;
    }

    public void setAddressSourceType(int addressSourceType) {
        this.addressSourceType = addressSourceType;
    }

    @JsonProperty("matchType")
    public String getMatchType() {
        return this.matchType;
    }

    public void setMatchType(String matchType) {
        this.matchType = matchType;
    }

}
