package ca.bell.sda.controller;

import java.time.Instant;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import ca.bell.sda.config.AppConfig;
import ca.bell.sda.constant.log.LogKey;
import ca.bell.sda.constant.status.StatusTypes;
import ca.bell.sda.model.Request;
import ca.bell.sda.model.Response;
import ca.bell.sda.service.whitespace.MLPredictionService;

@RestController
@RequestMapping("/bbm")
public class MLPredictionController extends SDAController {

	@Autowired
	MLPredictionService service;

	@Autowired
	AppConfig appConfig;

	@PostMapping(value = "/MLPredictionAPI", produces = MediaType.APPLICATION_JSON_VALUE)
	public Response findProspect(@RequestBody Map<String, Object> requestMap) throws Exception {

		Request request = new Request("bbm", "MLPredictionAPI");

		request.logTime(LogKey.REQ_START);

		request.log(LogKey.TIMESTAMP, Instant.now().toString());

		request.log(LogKey.REQ_GRP_ID, request.getReqId());

		request.log(LogKey.REQ_MAP, requestMap);

		request.setRequestMap(requestMap);

		Response response = new Response(StatusTypes.REQUEST_SUCCESS);

		request.log(LogKey.QUERY_BUILD_START, System.currentTimeMillis());

		if (response.getStatus().getCode() == StatusTypes.REQUEST_SUCCESS.getCode()) {

			service.findProspect(request, response);

			request.log(LogKey.REQ_RESPONSE, response.getData());
		}

		request.logTime(LogKey.REQ_END);

		checkRequestLog(request);

		return response;
	}

	/*This method is used for internal MDM testing*/
	@PostMapping(value = "/stdapi", produces = MediaType.APPLICATION_JSON_VALUE)
	public Response standardize(@RequestBody Map<String, Object> requestMap) throws Exception {

		Request request = new Request("bbm", "MLPredictionAPI");

		request.setRequestMap(requestMap);

		Response response = new Response(StatusTypes.REQUEST_SUCCESS);

		if (response.getStatus().getCode() == StatusTypes.REQUEST_SUCCESS.getCode()) {

			service.standardize(request, response);

		}

		return response;
	}
}
