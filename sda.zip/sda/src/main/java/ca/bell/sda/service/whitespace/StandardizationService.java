/**
 *
 */
package ca.bell.sda.service.whitespace;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CompletableFuture;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ca.bell.sda.config.AppConfig;
import ca.bell.sda.constant.log.LogKey;
import ca.bell.sda.constant.webclient.StreamSource;
import ca.bell.sda.dao.SearchDAO;
import ca.bell.sda.elk.QueryBuilder;
import ca.bell.sda.external.Standardization;
import ca.bell.sda.model.Request;
import ca.bell.sda.model.elk.Attribute;
import ca.bell.sda.model.elk.SearchQuery;
import ca.bell.sda.model.whitespace.ELKAddress;
import ca.bell.sda.model.whitespace.RequestInputDetail;
import ca.bell.sda.model.whitespace.STDAddress;
import ca.bell.sda.model.whitespace.StdOrgRecord;
import ca.bell.sda.process.whitespace.standardizationProcessor;
import ca.bell.sda.service.CPMService;


/**
 * @author Kamalanathan Ranganathan
 *
 */

@Service
public class StandardizationService extends CPMService {

	@Autowired
	private Standardization standardization;
	
	@Autowired
	private AppConfig appConfig;
	
	@Autowired
	private QueryBuilder queryBuilder;
	
	@Autowired
	private SearchDAO searchDAO;

	@Autowired
	private standardizationProcessor dataProcessor;

	public StdOrgRecord standardize(Request request, RequestInputDetail orgDetail) throws Exception {

		try {

			// Contact Methods Standardization
			CompletableFuture<RequestInputDetail> contact = standardization.getStandardizedContactMethods(request,
					orgDetail);

			// Address Standardization
			// This will be used to construct response to MDM.
			CompletableFuture<STDAddress> addr = standardization.getStandardizedAddress(request, orgDetail);
			
			CompletableFuture.allOf(contact, addr).join();
			// Standardize the data here
			// Name Standardization
			RequestInputDetail org = standardization.getStandardizedName(request, orgDetail,addr.get());
				        
			// Building Standardized detail
			Map<String, String> cont = contact.get().getContactMethodMap();

			StdOrgRecord.RecordBuilder builder = new StdOrgRecord.RecordBuilder();

			List<String> names = new ArrayList<>();

			if (org != null) {
					builder = builder.gkId(orgDetail.getAdminPartyId()).stdOrgName(org.getOrganizationAAName())/* AA standardized name*/
							.stdMalibuOrgName(org.getOrganizationName()) /* Malibu standardized name coming from AA*/
							.stdAlternateName(org.getStdAlternateName())
							.stdNumberEquivalent(org.getStdNumberEquivalent()).elkAddress(org.getStdaddressAA());
					names.add(org.getOrganizationAAName());
					if (org.getStdAAAlternateName() != null && org.getStdAAAlternateName().length() > 0)

						names.add(org.getStdAAAlternateName());
				}
			
			// Adding alternative number from MDM input
			String altN = orgDetail.getStdAlternateName();

			if (altN != null && altN.trim().length() > 0)
				names.add(orgDetail.getStdAlternateName());

			if (cont != null) {

				builder = builder.tn(cont.get("tn")).email(cont.get("email"))
						.url(orgDetail.getContactMethodMap().get("url")).tnIndicator(cont.get("stdTnIndicator"));

			}

			if (addr != null) {
				builder = builder.stdAddress(addr.get());
			}

			StdOrgRecord orgRec = builder.build();
			orgRec.setNames(names);

			orgRec.setPartyIDMap(orgDetail.getPartyIDMap());

			orgRec.setExtraMasterKey(orgDetail.getExtraMasterKey());

			orgRec.setFranchiseFlag(orgDetail.getFranchiseFlag());

			orgRec.setInputAddressPresent(orgDetail.getAddress().size() > 0);

			orgRec.setGkId(orgDetail.getAdminPartyId()); // MDM AdminPArtyId = Std GKId

			orgRec.setProfileType(orgDetail.getProfileType());

			orgRec.setCombinedAddress(orgRec.getElkAddress().getCombinedAddress());

			return orgRec;

		} catch (Exception e) {

			e.printStackTrace();

			request.log(LogKey.REQ_LOG_EX_MSG, e.getMessage());

			request.log(LogKey.REQ_LOG_EX, e);

			throw new Exception(e.getMessage());
		}

	}
	
	@SuppressWarnings("unchecked")
	public StdOrgRecord getStandardizedDataFromElk(Request request, RequestInputDetail orgDetail) throws Exception
	{
		
		StdOrgRecord.RecordBuilder builder = new StdOrgRecord.RecordBuilder();
		Map<String,Object> stdObj=collectStandardizedDataFromElk(request,orgDetail);	
		ELKAddress elkAddr=getElkAddress(stdObj);
		STDAddress stdAddr=getStdAddress(stdObj);
		
		StdOrgRecord orgRec = null;
		
		if(stdObj!=null && !stdObj.isEmpty())
		{
			builder=builder.gkId(orgDetail.getAdminPartyId())
					.elkAddress(elkAddr).stdMalibuOrgName((String)stdObj.get("orgName"))
					.stdOrgName((String)stdObj.get("stdOrgName")).stdAddress(stdAddr);
		    orgRec = builder.build();
			
			orgRec.setNames((List<String>)stdObj.get("names"));
			
			orgRec.setPartyIDMap(orgDetail.getPartyIDMap());

			orgRec.setExtraMasterKey(orgDetail.getExtraMasterKey());

			orgRec.setFranchiseFlag(orgDetail.getFranchiseFlag());

			//orgRec.setInputAddressPresent(orgDetail.getAddress().size() > 0);

			orgRec.setGkId(orgDetail.getAdminPartyId()); // MDM AdminPArtyId = Std GKId

			orgRec.setProfileType(orgDetail.getProfileType());

			
			orgRec.setCombinedAddress(orgRec.getElkAddress().getCombinedAddress());			
			
		}
		return orgRec;		
	}
	

	@SuppressWarnings("unchecked")
	private ELKAddress getElkAddress(Map<String, Object> stdObj) throws Exception {		
		ELKAddress elkAddr = null ;	
		if(stdObj!=null) {
		elkAddr = new ELKAddress();
		Map<String,Object> addr=(Map<String, Object>) stdObj.get("stdAddress");
		elkAddr.setCombinedAddress(getValue((String)addr.get("combinedAddress")));
		elkAddr.setCountry(getValue((String)addr.get("country")));
		elkAddr.setCity(getValue((String)addr.get("city")));
		elkAddr.setProvince(getValue((String)addr.get("province")));
		elkAddr.setAddressLineTwo(getValue((String)addr.get("addressLineTwo")));
		elkAddr.setAddressLineOne(getValue((String)addr.get("addressLineOne")));
		elkAddr.setPostalCode(getValue((String)addr.get("postalCode")));
		}else {
			throw new Exception("Standaridization : Standaridization Error"); 
		}
		return elkAddr;
	}
	@SuppressWarnings("unchecked")
	private STDAddress getStdAddress(Map<String, Object> stdObj) throws Exception {		
		STDAddress stdAddr = new STDAddress();		
		Map<String,Object> addr=(Map<String, Object>) stdObj.get("stdAddress");
		stdAddr.setOnelineAddress_formatted(getValue((String)addr.get("combinedAddress")));
		stdAddr.setCountryname_formatted(getValue((String)addr.get("country")));
		stdAddr.setCityname_formatted(getValue((String)addr.get("city")));
		stdAddr.setStateabbreviation_formatted(getValue((String)addr.get("province")));
		stdAddr.setAddresslinetwo_formatted(getValue((String)addr.get("addressLineTwo")));
		stdAddr.setAddresslineone_formatted(getValue((String)addr.get("addressLineOne")));
		stdAddr.setFullpostalcode_formatted(getValue((String)addr.get("postalCode")));
		return stdAddr;
	}
	
	private String getValue(String value) throws Exception {
		return value != null ? value.trim() : "";
	}

	public Map<String, Object> collectStandardizedDataFromElk(Request request, RequestInputDetail requestInputDetail) {		
		List<Attribute> attrbQueryList = new ArrayList<>();
		attrbQueryList.add(getAttrb(request, "sourceId", requestInputDetail.getAdminPartyId()));
		SearchQuery searchQuery = new SearchQuery();
		searchQuery.setMinScore(null);
		searchQuery.setSize("10");
		String indexName = appConfig.getIndexNames(request.getReqId())[0];
		searchQuery.setQuery(queryBuilder.createSearchQuery(attrbQueryList));
		request.logTime(LogKey.QUERY_BUILD_END);
		request.log(LogKey.QUERY, searchQuery);
		Map<String,Object> resData = null;
		try {
			request.logTime(LogKey.ELK_START);
			Object elkData = searchDAO.querySource(request.getReqId(), StreamSource.INDEX, searchQuery, indexName);
			request.logTime(LogKey.ELK_END);
			request.logTime(LogKey.DATA_CONV_START);
			resData=dataProcessor.processData(request, elkData,requestInputDetail);
			request.logTime(LogKey.DATA_CONV_END);
		} catch (Exception e) {
			request.log(LogKey.REQ_LOG_EX_MSG, getClass().getName() + e.getMessage());
			request.log(LogKey.REQ_LOG_EX, e);
			e.printStackTrace();
		}
		return resData;		
	}
}
