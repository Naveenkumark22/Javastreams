package ca.bell.sda.constant.value;

public class ValueType {

	/**
	 * GK Name Types
	 */
	public static final String ALPHA_NUMERIC = "AlphaNumeric";
	public static final String ALPHABETS = "Alphapets";

	/**
	 * BAN Types
	 */
	public static final String BAN = "BAN";
	public static final String BTN_WITH_3_DIGIT = "BTN_With_3_Digit";
	public static final String BTN_WITHOUT_3_DIGIT = "BTN_Without_3_Digit";

	/**
	 * Location Types
	 */
	public static final String LOCATION_TOKENIZED = "tokenized";
	public static final String LOCATION_NON_TOKENIZED = "non-tokenized";

}
