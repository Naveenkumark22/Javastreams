package ca.bell.sda.model.tmf;

/**
 * Filter Operator ENUM
 */

public class FilterOperator {

	public static final String EQUAL = "eq";
	public static final String IN = "in";
	public static final String NOT_EQUAL = "neq";
	public static final String GREATER_THAN = "gt";

}
