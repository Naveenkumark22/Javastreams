package ca.bell.sda.constant.query;

public class QueryConfig {
	public static String SIZE = "size";
	public static String FROM = "from";
	public static String MIN_SCORE = "minScore";
	public static String FILTER_PATH = "filterPath";
}
