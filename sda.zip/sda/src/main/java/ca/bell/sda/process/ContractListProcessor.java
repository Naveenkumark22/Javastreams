package ca.bell.sda.process;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;

import ca.bell.sda.constant.query.ElasticKey;
import ca.bell.sda.model.Request;
import ca.bell.sda.model.elk.response.ResponseData;

@Component
public class ContractListProcessor extends ElasticDataProcessor implements DataProcessor {

	private final static String GK_KEY = "goldenKey";
	private final static String ADDITIONAL_GK_KEY = "additionalGk";

	@SuppressWarnings("unchecked")
	@Override
	public <T> ResponseData processData(Request request, T data) {
		Map<String, Object> dataMap = (Map<String, Object>) data;
		ResponseData resData = new ResponseData();
		int total = getTotalValue(dataMap);
		if (total > 0) {
			Map<String, List<Map<String, Object>>> contractMapList = new HashMap<>();
			List<Map<String, Object>> resProfileList = new ArrayList<>();
			List<Map<String, Object>> profilesList = getProfileMapList(dataMap);
			profilesList.forEach(profileMap -> {
				Map<String, Object> sourceMap = (Map<String, Object>) profileMap.get(ElasticKey.SOURCE);
				String gkId = sourceMap.get(GK_KEY).toString();
				sourceMap.remove(GK_KEY);
				if (sourceMap.containsKey(ADDITIONAL_GK_KEY)) {
					List<Map<String, Object>> additionalGKList = (List<Map<String, Object>>) sourceMap
							.get(ADDITIONAL_GK_KEY);
					additionalGKList.removeIf(additionalGk -> additionalGk.get("gk").toString().equals(gkId));
				}
				if (!contractMapList.containsKey(gkId)) {
					addContractDataToList(gkId, resProfileList, contractMapList);
				}
				contractMapList.get(gkId).add(sourceMap);
			});
			resData.setProfiles(resProfileList);
		}
		return resData;
	}

	private void addContractDataToList(String gkId, List<Map<String, Object>> resProfileList,
			Map<String, List<Map<String, Object>>> contractMapList) {
		List<Map<String, Object>> contractList = new ArrayList<>();
		Map<String, Object> contractMap = new HashMap<>();
		contractMap.put(GK_KEY, gkId);
		contractMap.put("contractDetails", contractList);
		resProfileList.add(contractMap);
		contractMapList.put(gkId, contractList);
	}

}
