/**
 * 
 */
package ca.bell.sda.service.whitespace;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ca.bell.sda.config.AppConfig;
import ca.bell.sda.constant.log.LogKey;
import ca.bell.sda.constant.webclient.StreamSource;
import ca.bell.sda.dao.SearchDAO;
import ca.bell.sda.elk.WSQueryBuilder;
import ca.bell.sda.model.Request;
import ca.bell.sda.model.config.Endpoint;
import ca.bell.sda.model.whitespace.ml.InputList;
import ca.bell.sda.model.whitespace.ml.MLInputRoot;
import ca.bell.sda.service.CPMService;

/**
 * @author Kamalanathan Ranganathan
 *
 */
@Service
public class FrequencyCalculationService extends CPMService {

	private static final String DELIMITER = " ";

	@Autowired
	private SearchDAO searchDAO;

	@Autowired
	private AppConfig appConfig;

	@Autowired
	private WSQueryBuilder queryBuilder;

	private String[] indexes;

	public MLInputRoot calucalteTokenFrequencyScore(Request request, MLInputRoot root) throws Exception {

		try {

			List<String> lst = getUniqueWordsList(root);

			String qry = queryBuilder.getTokenFrequencyQueryString(lst);

			//request.log(LogKey.FREQ_INPUT, qry);

			indexes = appConfig.getIndexNames(request.getReqId());

			String endPointName = appConfig.getEndpointName(request.getReqId(), StreamSource.INDEX);

			Endpoint ep = appConfig.getAppProps().getServers().getWebService().getEndPoints().get(endPointName);

			String index = indexes[CALL_SEQUENCE_FREQ_CALC];

			String eurl = String.format("%s/%s", ep.getHost(), index);

			// Getting filter path from properties
			String filterPath = appConfig.getElasticQueryConfig().getFilterPath();
					
			// Result from DAO
			Map<String, Object> result = searchDAO.querySource(endPointName, eurl, qry, filterPath);
		
			Map<String, Double> freqscore = parseResponse(result);

			loadFrequencyScore(freqscore, root);

			return root;

		} catch (Exception e) {

			e.printStackTrace();

			request.log(LogKey.REQ_LOG_EX_MSG, "Frequency Calculation : " + e.getMessage());

			request.log(LogKey.REQ_LOG_EX, e);

			throw new Exception("Frequency Calculation : " + e.getMessage());

		}
	}

	private List<String> getUniqueWordsList(MLInputRoot root) throws Exception {

		List<String> ulist = new ArrayList<>();

		List<InputList> lst = root.getInput_list();

		if (lst != null) {
			for (InputList input : lst) {

				String str = input.getInput_record().getStdOrgName().toUpperCase().trim();

				if (str != null && str.trim().length() > 0) {

					String[] strArr = str.split(DELIMITER);

					for (String token : strArr) {

						if (!ulist.contains(token.toUpperCase().trim()))
							ulist.add(token.toUpperCase().trim());
					}

				}

				str = input.getSuspect_record().getStdOrgName().toUpperCase().trim();

				if (str != null && str.trim().length() > 0) {

					String[] strArr = str.split(DELIMITER);

					for (String token : strArr) {

						if (!ulist.contains(token.toUpperCase().trim()))
							ulist.add(token.toUpperCase().trim());
					}

				}
			}
		}
		return ulist;
	}

	@SuppressWarnings("unchecked")
	private Map<String, Double> parseResponse(Map<String, Object> response) throws Exception {

		Map<String, Double> freq = new HashMap<>();

		Map<String, Object> hits = (Map<String, Object>) response.get("hits");

		List<Map<String, Object>> lhits = (List<Map<String, Object>>) hits.get("hits");

		if (lhits != null) {

			for (Map<String, Object> hit : lhits) {

				if (hit != null) {

					Map<String, Object> source = (Map<String, Object>) hit.get("_source");

					String name = (String) source.get("stdOrgName");

					Object obj = source.get("counterlog");

					double counterlog = 1;

					if (obj != null) {

						counterlog = (double) obj;

					}
					freq.put(name, counterlog);

				}

			}
		}

		return freq;
	}

	private void loadFrequencyScore(Map<String, Double> freqscore, MLInputRoot root) throws Exception {

		List<InputList> list = root.getInput_list();

		if (list != null) {

			for (InputList inputList : list) {

				Map<String, List<String>> tokens = getFrequencyList(inputList.getInput_record().getStdOrgName(),
						inputList.getSuspect_record().getStdOrgName());

				double commonScore = getScore(freqscore, tokens.get("common"));

				double inputScore = getScore(freqscore, tokens.get("input"));

				double suspectScore = getScore(freqscore, tokens.get("suspect"));

				double divisor = (inputScore + suspectScore);

				divisor = (divisor > 0 ? divisor : 1);

				double token_freq = (commonScore * 2) / divisor;

				inputList.setToken_freq(token_freq);

			}
		}
	}

	private double getScore(Map<String, Double> freqMap, List<String> list) throws Exception {

		double dbl = 0;

		for (String token : list) {

			double retval = 1;

			if (freqMap.containsKey(token))
				retval = freqMap.get(token).doubleValue();

			dbl += retval;
		}

		return dbl;
	}

	private Map<String, List<String>> getFrequencyList(String inputorgname, String suspectorgname) throws Exception {

		Map<String, List<String>> tokens = new HashMap<>();

		List<String> ipnameList = new ArrayList<>();

		List<String> suspectnameList = new ArrayList<>();

		if (inputorgname != null && inputorgname.trim().length() > 0 && suspectorgname != null
				&& suspectorgname.trim().length() > 0) {

			if (inputorgname.contains(DELIMITER)) {

				String[] ipnameArr = inputorgname.toUpperCase().split(DELIMITER);

				ipnameList = Arrays.asList(ipnameArr);

			} else {
				ipnameList.add(inputorgname.toUpperCase());
			}

			if (suspectorgname.contains(DELIMITER)) {

				String[] suspectnameArr = suspectorgname.toUpperCase().split(DELIMITER);

				suspectnameList = Arrays.asList(suspectnameArr);

			} else {
				suspectnameList.add(suspectorgname.toUpperCase());
			}

		}

		// Common tokens
		List<String> common = new ArrayList<String>(ipnameList);

		common.retainAll(suspectnameList);

		tokens.put("common", common);

		tokens.put("input", ipnameList);

		tokens.put("suspect", suspectnameList);

		return tokens;
	}
}
