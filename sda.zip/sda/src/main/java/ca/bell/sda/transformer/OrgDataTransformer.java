package ca.bell.sda.transformer;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import ca.bell.sda.config.AttributesConfig;
import ca.bell.sda.model.Request;
import ca.bell.sda.model.elk.Attribute;
import ca.bell.sda.model.elk.response.ResponseData;
import ca.bell.sda.process.OrgDataProcessor;
import ca.bell.sda.service.SourceSystemService;

@Component
public class OrgDataTransformer {
	private final String idKey = "id";
	private final String externalIdKey = "externalId";
	private final String rltdPartyKey = "relatedParty";
	private final String relatedIdKey = "relatedId";
	private final String extRefKey = "bellExternalReference";
	private final String srcSystemKey = "sourceSystem";
	private final String srcSystemIdKey = "sourceSystemId";
	private final String cpmSrcSystem = "cpm";
	private final String gkKey = "goldenKey";
	private final String contactMediumKey = "contactMedium";
	private final String contactAddressKey = "contactAddress";

	@Autowired
	private OrgDataProcessor orgDP;

	@Autowired
	private AttributesConfig attributesConfig;
	
	@Autowired
	private SourceSystemService service;

	public void tranformData(Request request, String serviceType, String idValue, ResponseData resData) {
		if (resData.getProfile() != null) {
			Map<String, Object> profile = resData.getProfile();
			if (serviceType!=null && !serviceType.equalsIgnoreCase("getAccountProfile")) {
				reducePayLoad(request, serviceType, profile);
			}
			transformRltdParty(profile);
			addExtRef(profile);
			transformContactMedium(profile);
			addPrefix(request, idValue, profile);// Always call this at last
		}
	}

	private void transformContactMedium(Map<String, Object> profile) {
		if(profile.containsKey(contactMediumKey)&&profile.get(contactMediumKey)!=null)
		{
			profile.put(contactAddressKey, profile.get(contactMediumKey));			
		}
		
	}

	private void addPrefix(Request request, String idValue, Map<String, Object> profile) {
		//Map<String, String> srcSysMap = attributesConfig.getDataAttributes().get(request.getReqId()).get("sourceSystem")
			//	.getKeyPairs();
		Map<String, String> srcSysMap=service.getSourceSystem();
		if (idValue != null&&profile.get(srcSystemKey)!=null) {
			String srcSystemValue = profile.get(srcSystemKey).toString().toLowerCase();
			if (!srcSystemValue.equalsIgnoreCase(cpmSrcSystem)) {
				String profSrcSys = profile.get(srcSystemKey).toString().toLowerCase();
				String conjSrcSystem = cpmSrcSystem + "_" + srcSysMap.get(profSrcSys).toLowerCase();
				profile.put(idKey, conjSrcSystem + "_" + idValue);
				profile.put(srcSystemKey, (cpmSrcSystem + "_" + profSrcSys).toUpperCase());
			}
			addExternalId(profile, idValue);
		}
	}

	public String getRequestValue(Request request) {
		List<Attribute> queryAttrbList = request.getQueryAttrbList();
		for (Attribute attribute : queryAttrbList) {
			if (attribute.getId().equalsIgnoreCase(idKey)) {
				return attribute.getValue().toString();
			}
		}
		return null;
	}

	private void addExternalId(Map<String, Object> profile, String idValue) { // Call always to add externalId
		profile.put(externalIdKey, idValue);
	}

	@SuppressWarnings("unchecked")
	private void transformRltdParty(Map<String, Object> profile) { // Call always to transform related party
		if (profile.containsKey(rltdPartyKey)) {
			Object rpObj = profile.get(rltdPartyKey);
			List<Map<String, String>> rltdPartyList = (List<Map<String, String>>) rpObj;
			List<Map<String, String>> newRltdPartyList = new ArrayList<>();
			Map<String, String> rp;
			for (Map<String, String> rltdParty : rltdPartyList) {
				rp = rltdParty;
				if (rltdParty.containsKey(relatedIdKey) && rltdParty.containsKey(srcSystemKey)) {
					rp.put(relatedIdKey, rltdParty.get(srcSystemKey).toLowerCase() + "_" + rltdParty.get(relatedIdKey));
				}
				newRltdPartyList.add(rp);
			}
			profile.put(rltdPartyKey, newRltdPartyList);
		}
	}

	private void reducePayLoad(Request request, String serviceType, Map<String, Object> profile) { // Call if profile is
																									// approved account
		if (profile.containsKey(gkKey) && profile.get(gkKey) != null) {
			Map<String, Object> newProfMap = new HashMap<String, Object>();
			Set<String> keySet = attributesConfig.getDataAttributes().get(request.getReqId()).get("lightPayLoad")
					.getKeys();
			orgDP.processDataMap(profile, newProfMap, keySet, true);
			profile.clear();
			profile.putAll(newProfMap);
		}
	}

	private void addExtRef(Map<String, Object> profile) { // Call if profile is approved account
		if (profile.containsKey(gkKey) && profile.get(gkKey) != null) {
			List<Map<String, Object>> extRefList = new ArrayList<>();
			Map<String, Object> extRef = new HashMap<>();
			extRef.put(externalIdKey, profile.get(gkKey));
			extRef.put(srcSystemIdKey, cpmSrcSystem);
			extRefList.add(extRef);
			profile.put(extRefKey, extRefList);
		}
	}
}
