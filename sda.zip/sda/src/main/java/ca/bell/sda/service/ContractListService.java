package ca.bell.sda.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ca.bell.sda.config.AppConfig;
import ca.bell.sda.constant.log.LogKey;
import ca.bell.sda.constant.webclient.StreamSource;
import ca.bell.sda.dao.SearchDAO;
import ca.bell.sda.model.Request;
import ca.bell.sda.model.Response;
import ca.bell.sda.model.elk.SearchQuery;
import ca.bell.sda.model.elk.response.ResponseData;
import ca.bell.sda.process.ContractListProcessor;

@Service
public class ContractListService extends CPMService {

	@Autowired
	private AppConfig appConfig;

	@Autowired
	private SearchDAO searchDAO;

	@Autowired
	private ContractListProcessor dataProcessor;

	public void getContractList(Request request, Response response) {
		SearchQuery searchQuery = getSearchQuery(request);
		searchQuery.setMinScore("0.1");
		searchQuery.setSize("10000");
		String[] indexes = appConfig.getIndexNames(request.getReqId());
		String url = indexes[0];
		request.logTime(LogKey.QUERY_BUILD_END);
		ResponseData resData = null;
		try {
			request.log(LogKey.QUERY, searchQuery);
			request.logTime(LogKey.ELK_START);
			Object elkData = searchDAO.querySource(request.getReqId(), StreamSource.INDEX, searchQuery, url,
					request.getQueryConfig().getFilterPath());
			request.logTime(LogKey.ELK_END);
			request.logTime(LogKey.DATA_CONV_START);
			resData = dataProcessor.processData(request, elkData);
			addSuccessLog(request);
		} catch (Exception e) {
			request.log(LogKey.REQ_LOG_EX_MSG, getClass().getName() + e.getMessage());
			addExceptionLog(request,e);
		}
		request.logTime(LogKey.DATA_CONV_END);
		response.setData(resData);
	}

}
