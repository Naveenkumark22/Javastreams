package ca.bell.sda.service;

import java.time.Instant;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import ca.bell.sda.config.AppConfig;
import ca.bell.sda.constant.log.LogKey;
import ca.bell.sda.constant.status.StatusTypes;
import ca.bell.sda.constant.webclient.StreamSource;
import ca.bell.sda.controller.InteractionController;
import ca.bell.sda.dao.SearchDAO;
import ca.bell.sda.elk.QueryBuilder;
import ca.bell.sda.model.CustomerTimeline;
import ca.bell.sda.model.Request;
import ca.bell.sda.model.Response;
import ca.bell.sda.model.elk.Attribute;
import ca.bell.sda.model.elk.SearchQuery;
import ca.bell.sda.model.elk.response.ResponseData;
import ca.bell.sda.process.GetCustomerManagementProcessor;
import ca.bell.sda.process.GetCustomerTimelineProcessor;
import ca.bell.sda.process.GetEomProcessor;
import ca.bell.sda.process.RequestProcessor;

@Service
public class GetCustomerTimeLineService extends CPMService {
	
	@Autowired
	private AppConfig appConfig;

	@Autowired
	private SearchDAO searchDAO;
	
	@Autowired
	private GetCustomerTimelineProcessor dataProcessor;
	
	@Autowired
	private GetEomProcessor eomProcessor;
	
	@Autowired
	private QueryBuilder queryBuilder;
	
	@Autowired
	private GetCustomerManagementProcessor customerDataProcessor;
	
	@Autowired
	private InteractionController interactionController;
	
	@Autowired
	private RequestProcessor processor;
	
	public List<CustomerTimeline> getCustomerTimeline(Request request, Response response, Map<String, Object> requestMap, String eomFlag) {
		Set<Object> getIds = getEomIds(request,requestMap.get("parent_acct"));
		Set<Object> eomIds = new HashSet<>();
		if (getIds == null || getIds.isEmpty()) {
			eomIds.add(requestMap.get("parent_acct"));
		} else {
			eomIds.addAll(getIds);
		}
		List<Attribute> attrbQueryList = new ArrayList<>();
		attrbQueryList.add(getAttrb(request, "eom_id", eomIds));
		String[] indexes = appConfig.getIndexNames(request.getReqId());
		String url = StringUtils.join(indexes, ",", 1, 6);		
		SearchQuery searchQuery = getSearchQuery(request);
		searchQuery.setMinScore("0.1");
		searchQuery.setSize("10000");
		searchQuery.setQuery(queryBuilder.createSearchQuery(attrbQueryList));
		request.logTime(LogKey.QUERY_BUILD_END);
		List<CustomerTimeline> eventList = null;
		try {			 
				Object elkData = searchDAO.querySource(request.getReqId(), StreamSource.INDEX, searchQuery, url,
						request.getQueryConfig().getFilterPath());
				request.logTime(LogKey.ELK_END);
				request.logTime(LogKey.DATA_CONV_START);
				eventList = dataProcessor.processData(request, elkData);			 
			//call interaction service
			 if (("eom".equalsIgnoreCase(eomFlag) && !eomIds.isEmpty()))
	    	  {
				 List<CustomerTimeline> eomInterationData= getEomInteractionData(eomIds);
				 if(eventList!=null && eomInterationData!=null && !eomInterationData.isEmpty()) {
				    eventList.addAll(eomInterationData);
				    return eventList;}
				 else if(eventList==null && eomInterationData!=null && !eomInterationData.isEmpty()) {
					return eomInterationData;
				 }
	    	  }
			 addSuccessLog(request);
		} catch (Exception e) {
			request.log(LogKey.REQ_LOG_EX_MSG, getClass().getName() + e.getMessage());
			addExceptionLog(request,e);
		}
		return eventList;
   }	
     private List<CustomerTimeline> getEomInteractionData(Set<Object> eomIds) throws Exception {  
    			Map<String, Object> orgRequestMap = new HashMap<>();
    			List<CustomerTimeline> eomIntData = null;
				List<Object> eomId= eomIds.stream().collect(Collectors.toList());
				orgRequestMap.put("eomId", eomId);
				orgRequestMap.put("sourceSystem", "eom");
				List<String> filter = new ArrayList<>();
				filter.add("complete");
				orgRequestMap.put("filter", filter);			 
				Response intResponse=interactionController.getInteractionForCustomerTimeline(new Request("bbm", "GetInteraction"), orgRequestMap);
				if(intResponse!=null&&intResponse.getData()!=null){				
					eomIntData=dataProcessor.groupIntData(intResponse);	
				}				
				return eomIntData;
			 }
      

	public Set<Object> getEomIds(Request request, Object inputEOMId) {
    	String[] index = appConfig.getIndexNames(request.getReqId());
		SearchQuery searchQuery = getSearchQuery(request);
		searchQuery.setMinScore("0.1");
		searchQuery.setSize("1000");
		searchQuery.setSourceFilter(appConfig.getAttributesConfig().getDataAttributes().get(request.getReqId()).get("eomIds").getKeys());
		request.logTime(LogKey.QUERY_BUILD_END);
		Set<Object> eomIds=null;
		try {
			Object elkData = searchDAO.querySource(request.getReqId(), StreamSource.INDEX, searchQuery, index[0],
					request.getQueryConfig().getFilterPath());
			request.logTime(LogKey.ELK_END);
			request.logTime(LogKey.DATA_CONV_START);
			eomIds=eomProcessor.processData(request, elkData);
			if(inputEOMId!=null&& eomIds==null|| eomIds.isEmpty())
			{
				searchQuery.setMinScore("0.1");
				searchQuery.setSize("1");
				List<Attribute> attrbQueryList = new ArrayList<>();
				attrbQueryList.add(getAttrb(request, "sourceSystem", "EOM"));
				attrbQueryList.add(getAttrb(request, "source_id", inputEOMId));
				searchQuery.setQuery(queryBuilder.createSearchQuery(attrbQueryList, request.getFilterAttrbList()));
				searchQuery.setSourceFilter(null);
				request.log(LogKey.QUERY, searchQuery);
				request.logTime(LogKey.ELK_START);			
				elkData=searchDAO.querySource(request.getReqId(), StreamSource.INDEX, searchQuery, index[6],
							request.getQueryConfig().getFilterPath());
				request.logTime(LogKey.ELK_END);
				request.logTime(LogKey.DATA_CONV_START);
				String eomSourceId = customerDataProcessor.processEomId(elkData);
				if(eomSourceId!=null)
				{
					eomIds=new HashSet<>();
					eomIds.add(eomSourceId);
				}				
			}
		} catch (Exception e) {
			request.log(LogKey.REQ_LOG_EX_MSG, getClass().getName() + e.getMessage());
			request.log(LogKey.REQ_LOG_EX, e);
		}
		return eomIds;
	}
	
}
