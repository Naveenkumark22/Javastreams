package ca.bell.sda.process;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import ca.bell.sda.config.AttributesConfig;
import ca.bell.sda.model.Request;
import ca.bell.sda.model.config.DataAttributes;
import ca.bell.sda.model.elk.response.ResponseData;

@Component
public class OrgDataProcessor extends ElasticDataProcessor implements DataProcessor {

	@Autowired
	private AttributesConfig attributesConfig;

	private final String childGKKey = "child_gk";
	private final String gkURLKey = "gkURL";
	private final String bellExternalReferenceKey="bellExternalReference";
	private final String typeKey = "type";
	private final String urlKey="url";
	
	@SuppressWarnings("unchecked")
	@Override
	public <T> ResponseData processData(Request request, T data) {

		Map<String, Object> dataMap = (Map<String, Object>) data;
		ResponseData resData = new ResponseData();
		if (getTotalValue(dataMap) > 0) {
			List<Map<String, Object>> profilesList = getProfileMapList(dataMap);
			Map<String, Object> profileMap = profilesList.get(0);
			Map<String, Object> profile = new HashMap<String, Object>();
			Map<String, Object> sourceMap = (Map<String, Object>) profileMap.get("_source");
			DataAttributes profileKeys = attributesConfig.getDataAttributes().get(request.getReqId()).get("profile");
			if (profileKeys.getKeys() != null) {
				Set<String> profKeySets = profileKeys.getKeys();
				processDataMap(sourceMap, profile, profKeySets, true);
			} else if (profileKeys.getKeyPairs() != null) { // Check for this block whether it is executed or not
				Map<String, String> profKeyPairs = profileKeys.getKeyPairs();
				processDataMap(sourceMap, profile, profKeyPairs, true);
			}
			resData.setProfile(profile);
		}
		return resData;
	}

	@SuppressWarnings("unchecked")
	public <T> ResponseData processData(Request request, T data, Map<String, Map<String, Object>> profilesMap) {
		Map<String, Object> dataMap = (Map<String, Object>) data;
		ResponseData resData = new ResponseData();
		if (getTotalValue(dataMap) > 0) {
			List<Map<String, Object>> profilesList = new ArrayList<>();
			List<Map<String, Object>> srcProfilesList = getProfileMapList(dataMap);
			for (Map<String, Object> profileMap : srcProfilesList) {
				Map<String, Object> profile = new HashMap<>();
				Map<String, Object> sourceMap = (Map<String, Object>) profileMap.get("_source");
				Set<String> profKeySets = attributesConfig.getDataAttributes().get(request.getReqId()).get("profile")
						.getKeys();
				processDataMap(sourceMap, profile, profKeySets, true);
				profilesMap.put(profile.get("id").toString(), profile);
				profilesList.add(profile);
			}
			resData.setProfiles(profilesList);
		}
		return resData;
	}

	@SuppressWarnings("unchecked")
	public Object processExtReference(Request request, Object data,ResponseData resData) {
		Map<String, Object> dataMap = (Map<String, Object>) data;
		List<Map<String, Object>> extRefList = new ArrayList<>();
		Map<String, Object> extRef;
		Map<String, String> extRefKeyPairs = attributesConfig.getDataAttributes().get(request.getReqId())
				.get("externalRef").getKeyPairs();
		if (getTotalValue(dataMap) > 0) {
			List<Map<String, Object>> profileList = getProfileMapList(dataMap);
			for (Map<String, Object> profileMap : profileList) {
				extRef = new HashMap<>();
				Map<String, Object> sourceMap = (Map<String, Object>) profileMap.get("_source");
				processDataMap(sourceMap, extRef, extRefKeyPairs);
				extRefList.add(extRef);
			}			
		}
		/** start of W2U -gkURL added under BellExternalRef **/
		if(resData!=null&&resData.getProfile()!=null)
		{
			List<Map<String, Object>> gkURLList=(List<Map<String, Object>>) resData.getProfile().get(gkURLKey);
			if(gkURLList!=null&&gkURLList.size()>0)
			{
				for (Map<String, Object> gkURLMap : gkURLList) {
					extRef = new HashMap<>();
					processDataMap(gkURLMap, extRef, extRefKeyPairs);
					if(extRef.size()>0)
					{
						extRef.put(typeKey,urlKey);
						extRefList.add(extRef);
					}
				}
			}
		}
		resData.getProfile().remove(gkURLKey);	
		/** End of W2U -gkURL added under BellExternalRef **/
		return extRefList;
	}

	@SuppressWarnings("unchecked")
	public void processExtReference(Request request, Object data, Map<String, Map<String, Object>> profilesMap) {
		Map<String, Object> dataMap = (Map<String, Object>) data;
		Map<String, List<Map<String, Object>>> extRefListMap = new HashMap<>();
		List<Map<String, Object>> extRefList = null;
		Map<String, Object> extRef = null;
		Map<String, String> extRefKeyPairs = attributesConfig.getDataAttributes().get(request.getReqId())
				.get("externalRef").getKeyPairs();		
		if (getTotalValue(dataMap) > 0) {
			List<Map<String, Object>> profileList = getProfileMapList(dataMap);
			for (Map<String, Object> profileMap : profileList) {
				extRef = new HashMap<String, Object>();
				Map<String, Object> sourceMap = (Map<String, Object>) profileMap.get("_source");
				processDataMap(sourceMap, extRef, extRefKeyPairs);
				String id = sourceMap.get("goldenKey").toString();
				if (extRefListMap.containsKey(id)) {
					extRefListMap.get(id).add(extRef);
				} else {
					extRefList = new ArrayList<>();
					extRefList.add(extRef);
					extRefListMap.put(id, extRefList);
					profilesMap.get(id).put(bellExternalReferenceKey, extRefList);
					
				}
				
			}
			
			
		}
		/** start of W2U -gkURL added under BellExternalRef **/
		 for (Entry<String, Map<String, Object>> set :
			 profilesMap.entrySet()) {
			 String id=set.getKey();
			 	List<Map<String, Object>> gkURLList=(List<Map<String, Object>>) profilesMap.get(id).get(gkURLKey);
				List<Map<String,Object>> bellExtList=(List<Map<String, Object>>) profilesMap.get(id).get(bellExternalReferenceKey);
				if(gkURLList!=null&&gkURLList.size()>0)
				{
					for (Map<String, Object> gkURLMap : gkURLList) {
						Map<String, Object> extRefMap = new HashMap<>();						
						processDataMap(gkURLMap, extRefMap, extRefKeyPairs);
						if(extRefMap.size()>0)
						{
							if(bellExtList==null)
							{
								bellExtList=new ArrayList<Map<String, Object>>();
							}
							extRefMap.put(typeKey,urlKey);
							bellExtList.add(extRefMap);
						}										
					}
					profilesMap.get(id).put(bellExternalReferenceKey,bellExtList);
					profilesMap.get(id).remove(gkURLKey);	
				}
		}
		/** End of W2U -gkURL added under BellExternalRef **/
		
	}

	@SuppressWarnings("unchecked")
	public Map<String, Object> processMainCA(Request request, Object data) {
		Map<String, Object> dataMap = (Map<String, Object>) data;
		Map<String, Object> mainCAMap = null;
		if (getTotalValue(dataMap) > 0) {
			mainCAMap = new HashMap<>();
			List<Map<String, Object>> profileList = getProfileMapList(dataMap);
			Map<String, Object> profileMap = profileList.get(0);
			Map<String, Object> sourceMap = (Map<String, Object>) profileMap.get("_source");
			Set<String> mainCAKeySet = attributesConfig.getDataAttributes().get(request.getReqId()).get("mainCA")
					.getKeys();
			processDataMap(sourceMap, mainCAMap, mainCAKeySet);
		}
		return mainCAMap;
	}

	@SuppressWarnings("unchecked")
	public void processMainCA(Request request, Object data, Map<String, Map<String, Object>> profilesMap) {
		Map<String, Object> dataMap = (Map<String, Object>) data;
		Map<String, Object> mainCAMap = null;
		if (getTotalValue(dataMap) > 0) {
			List<Map<String, Object>> profileList = getProfileMapList(dataMap);
			Set<String> mainCAKeySet = attributesConfig.getDataAttributes().get(request.getReqId()).get("mainCA")
					.getKeys();
			for (Map<String, Object> profileMap : profileList) {
				mainCAMap = new HashMap<>();
				Map<String, Object> sourceMap = (Map<String, Object>) profileMap.get("_source");
				String id = sourceMap.get("goldenKey").toString();
				processDataMap(sourceMap, mainCAMap, mainCAKeySet);
				profilesMap.get(id).putAll(mainCAMap);
			}
		}
	}

	@SuppressWarnings("unchecked")
	public List<Map<String, Object>> processHirerchyData(Request request, Map<String, Object> hrchyData) {
		List<Map<String, Object>> hrchyList = null;
		if (hrchyData != null) {
			Map<String, Object> dataMap = hrchyData;
			if (getTotalValue(dataMap) > 0) {
				hrchyList = new ArrayList<>();
				Map<String, Object> hrchyMap = null;
				List<Map<String, Object>> profileList = getProfileMapList(dataMap);
				Map<String, String> rpKeyPairs = attributesConfig.getDataAttributes().get(request.getReqId())
						.get("relatedParty").getKeyPairs();
				for (Map<String, Object> profileMap : profileList) {
					hrchyMap = new HashMap<>();
					Map<String, Object> sourceMap = (Map<String, Object>) profileMap.get("_source");
					processDataMap(sourceMap, hrchyMap, rpKeyPairs);
					hrchyList.add(hrchyMap);
				}
			}
		}
		return hrchyList;
	}

	@SuppressWarnings("unchecked")
	public void processHirerchyData(Request request, Map<String, Map<String, Object>> profilesMap,
			Map<String, Object> hrchyData) {
		if (hrchyData != null) {
			Map<String, Object> dataMap = hrchyData;
			if (getTotalValue(dataMap) > 0) {
				Map<String, List<Map<String, Object>>> hrchyListMap = new HashMap<>();
				List<Map<String, Object>> hrchyList = null;
				Map<String, Object> hrchyMap = null;

				Map<String, String> rpKeyPairs = attributesConfig.getDataAttributes().get(request.getReqId())
						.get("relatedParty").getKeyPairs();

				List<Map<String, Object>> profileList = getProfileMapList(dataMap);
				for (Map<String, Object> profileMap : profileList) {
					hrchyMap = new HashMap<>();
					Map<String, Object> sourceMap = (Map<String, Object>) profileMap.get("_source");
					processDataMap(sourceMap, hrchyMap, rpKeyPairs);
					String id = sourceMap.get(childGKKey).toString();
					if (hrchyListMap.containsKey(id)) {
						hrchyListMap.get(id).add(hrchyMap);
					} else {
						hrchyList = new ArrayList<>();
						hrchyList.add(hrchyMap);
						profilesMap.get(id).put("relatedParty", hrchyList);
					}
				}
			}
		}
	}

	@SuppressWarnings("unchecked")
	public void processBanProductDetail(Map<String, Object> profile, Object elkData) {
		Map<String, Object> dataMap = (Map<String, Object>) elkData;
		if (getTotalValue(dataMap) > 0) {
			List<Map<String, Object>> banProductList = new ArrayList<>();
			List<Map<String, Object>> profileList = getProfileMapList(dataMap);
			profileList.forEach(profileSrcMap -> {
				Map<String, Object> sourceMap = (Map<String, Object>) profileSrcMap.get("_source");
				if (sourceMap.containsKey("ban")) {
					List<Map<String, Object>> banList = (List<Map<String, Object>>) sourceMap.get("ban");
					if (banList != null && !banList.isEmpty()) {
						banProductList.addAll(banList);
					}
				}
			});
			profile.put("ban", banProductList);
		}

	}
	
	@SuppressWarnings("unchecked")
	public void processBanDetail(Map<String, Object> profile, Object elkData) {
		Map<String, Object> dataMap = (Map<String, Object>) elkData;
		if (getTotalValue(dataMap) > 0) {
			List<Map<String, Object>> banDetailList = new ArrayList<>();
			List<Map<String, Object>> profileList = getProfileMapList(dataMap);
			profileList.forEach(profileSrcMap -> {
				Map<String, Object> sourceMap = (Map<String, Object>) profileSrcMap.get("_source");
				if (sourceMap.containsKey("ban")) {
					List<Map<String, Object>> banList = (List<Map<String, Object>>) sourceMap.get("ban");
					if (banList != null && !banList.isEmpty()) {
						banList.get(0).put("banSourceSystem", sourceMap.get("sourceSystem"));
						banDetailList.addAll(banList);
						
					}
				}		
				
			});
			profile.put("ban", banDetailList);
		}
	}

	
	public <T> Map<String,String> processSourceData( T data) {

		Map<String, Object> dataMap = (Map<String, Object>) data;
		int total = getTotalValue(dataMap);
		Map<String, String> sourceSystemMap= new HashMap<>();		
		if (total > 0) {
			List<Map<String, Object>> profilesMap = getProfileMapList(dataMap);
			for (Map<String, Object> profMap : profilesMap) {
				Map<String, Object> sourceMap = (Map<String, Object>) profMap.get("_source");
				sourceSystemMap.put(sourceMap.get("name").toString(),sourceMap.get("value").toString());
			}
			
		}
		return sourceSystemMap;
	}
}
