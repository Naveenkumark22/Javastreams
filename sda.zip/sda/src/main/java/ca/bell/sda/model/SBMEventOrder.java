package ca.bell.sda.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
@JsonInclude(Include.NON_NULL)
public class SBMEventOrder {
	
	private Object interactionDate;
	private Object interactionType;
	private List<Map<String,Object>> relatedParty =new ArrayList<>();
	private List<ReferencedInteraction> referencedInteraction;
	private Object event_name;
	private Object parent_event_name;
	private Object id;
	private List<Map<String,Object>> characteristic= new ArrayList<>();
	public Object getInteractionDate() {
		return interactionDate;
	}
	public void setInteractionDate(Object interactionDate) {
		this.interactionDate = interactionDate;
	}
	public Object getInteractionType() {
		return interactionType;
	}
	public void setInteractionType(Object interactionType) {
		this.interactionType = interactionType;
	}
	public List<Map<String, Object>> getRelatedParty() {
		return relatedParty;
	}
	public void setRelatedParty(List<Map<String, Object>> relatedParty) {
		this.relatedParty = relatedParty;
	}
	public List<ReferencedInteraction> getReferencedInteraction() {
		return referencedInteraction;
	}
	public void setReferencedInteraction(List<ReferencedInteraction> referencedInteraction) {
		this.referencedInteraction = referencedInteraction;
	}
	public Object getEvent_name() {
		return event_name;
	}
	public void setEvent_name(Object event_name) {
		this.event_name = event_name;
	}
	public Object getParent_event_name() {
		return parent_event_name;
	}
	public void setParent_event_name(Object parent_event_name) {
		this.parent_event_name = parent_event_name;
	}
	public Object getId() {
		return id;
	}
	public void setId(Object id) {
		this.id = id;
	}
	public List<Map<String, Object>> getCharacteristic() {
		return characteristic;
	}
	public void setCharacteristic(List<Map<String, Object>> characteristic) {
		this.characteristic = characteristic;
	}
	
}
