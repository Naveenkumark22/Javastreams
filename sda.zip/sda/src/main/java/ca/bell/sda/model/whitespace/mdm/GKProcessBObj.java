package ca.bell.sda.model.whitespace.mdm;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author Kamalanathan Ranganathan
 */
public class GKProcessBObj {
	private String sourceSystem;

	private String sourceSystemID;

	private String score;

	private String suspectID;

	private String suspectName;

	private String description;

	private String token_freq = "";

	private String ml_flag = "";

	private String address_match_score = "";

	private String name_match_score = "";

	private String profileType = "";

	private String parent_duns = "";

	private String is_franchies = "";

	private String utl_parent_duns = "";

	private String customer_phone = "";

	private String customer_prime_contact = "";

	private String customer_url = "";

	private String input_phone = "";

	private String input_contact = "";

	private String input_url = "";
	
    private String keyStatus="";
	
	private String keySegment="";
	
	private String keyType="";

	private Map<String, String> stdAddress;

	@JsonProperty("sourceSystem")
	public String getSourceSystem() {

		return this.sourceSystem;
	}

	@JsonProperty("sourceSystemID")
	public String getSourceSystemID() {

		return this.sourceSystemID;
	}

	@JsonProperty("score")
	public String getScore() {

		return this.score;
	}

	@JsonProperty("suspectID")
	public String getSuspectID() {

		return this.suspectID;
	}

	@JsonProperty("suspectName")
	public String getSuspectName() {

		return this.suspectName;
	}

	@JsonProperty("description")
	public String getDescription() {

		return this.description;
	}

	@JsonProperty("token_freq")
	public String getToken_freq() {
		return token_freq;
	}

	@JsonProperty("ml_flag")
	public String getMl_flag() {
		return ml_flag;
	}

	@JsonProperty("address_match_score")
	public String getAddress_match_score() {
		return address_match_score;
	}

	@JsonProperty("stdAddress")
	public Map<String, String> getStdAddress() {
		return stdAddress;
	}

	@JsonProperty("profileType")
	public String getProfileType() {
		return profileType;
	}

	@JsonProperty("parent_duns")
	public String getParent_duns() {
		return parent_duns;
	}

	@JsonProperty("is_franchies")
	public String getIs_franchies() {
		return is_franchies;
	}

	@JsonProperty("utl_parent_duns")
	public String getUtl_parent_duns() {
		return utl_parent_duns;
	}

	@JsonProperty("customer_phone")
	public String getCustomer_phone() {
		return customer_phone;
	}

	@JsonProperty("customer_prime_contact")
	public String getCustomer_prime_contact() {
		return customer_prime_contact;
	}

	@JsonProperty("customer_url")
	public String getCustomer_url() {
		return customer_url;
	}

	@JsonProperty("input_phone")
	public String getInput_phone() {
		return input_phone;
	}

	@JsonProperty("input_contact")
	public String getInput_contact() {
		return input_contact;
	}

	@JsonProperty("input_url")
	public String getInput_url() {
		return input_url;
	}

	@JsonProperty("name_match_score")
	public String getName_match_score() {
		return name_match_score;
	}	
	@JsonProperty("keyStatus")
	public String getKeyStatus() {
		return keyStatus;
	}
	@JsonProperty("keySegment")
	public String getKeySegment() {
		return keySegment;
	}
	@JsonProperty("keyType")
	public String getKeyType() {
		return keyType;
	}
	
	
	public void setKeyStatus(String keyStatus) {
		this.keyStatus = keyStatus;
	}

	public void setKeySegment(String keySegment) {
		this.keySegment = keySegment;
	}

	public void setKeyType(String keyType) {
		this.keyType = keyType;
	}

	public void setName_match_score(String name_match_score) {
		this.name_match_score = name_match_score;
	}

	public void setDescription(String description) {

		this.description = description;
	}

	public void setSuspectName(String suspectName) {

		this.suspectName = suspectName;
	}

	public void setSuspectID(String suspectID) {

		this.suspectID = suspectID;
	}

	public void setScore(String score) {

		this.score = score;
	}

	public void setSourceSystemID(String sourceSystemID) {

		this.sourceSystemID = sourceSystemID;
	}

	public void setSourceSystem(String sourceSystem) {

		this.sourceSystem = sourceSystem;
	}

	public void setToken_freq(String token_freq) {
		this.token_freq = token_freq;
	}

	public void setMl_flag(String ml_flag) {
		this.ml_flag = ml_flag;
	}

	public void setAddress_match_score(String address_match_score) {
		this.address_match_score = address_match_score;
	}

	public void setStdAddress(Map<String, String> address) {

		if (address != null) {

			if (this.stdAddress == null)
				this.stdAddress = new HashMap<>();

			address.entrySet().stream().forEach(entity -> {
				this.stdAddress.put(entity.getKey(), entity.getValue());
			});

		}
	}

	@JsonProperty("record")

	public void setProfileType(String profileType) {
		this.profileType = profileType;
	}

	public void setParent_duns(String parent_duns) {
		this.parent_duns = parent_duns;
	}

	public void setIs_franchies(String is_franchies) {
		this.is_franchies = is_franchies;
	}

	public void setUtl_parent_duns(String utl_parent_duns) {
		this.utl_parent_duns = utl_parent_duns;
	}

	public void setCustomer_phone(String customer_phone) {
		this.customer_phone = customer_phone;
	}

	public void setCustomer_prime_contact(String customer_prime_contact) {
		this.customer_prime_contact = customer_prime_contact;
	}

	public void setCustomer_url(String customer_url) {
		this.customer_url = customer_url;
	}

	public void setInput_phone(String input_phone) {
		this.input_phone = input_phone;
	}

	public void setInput_contact(String input_contact) {
		this.input_contact = input_contact;
	}

	public void setInput_url(String input_url) {
		this.input_url = input_url;
	}

}
