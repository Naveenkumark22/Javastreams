package ca.bell.sda.process;

import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.stereotype.Component;

import ca.bell.sda.model.Request;

@Component
public class GetEomProcessor extends ElasticDataProcessor{
	
		
	@SuppressWarnings("unchecked")
	public <T> Set<Object> processData(Request request, T data) {
		
		Map<String, Object> dataMap = (Map<String, Object>) data;
		int total = getTotalValue(dataMap);
		Map<String, Object> sourceMap = null;
		Set<Object> listOfIds=null;
		List<Map<String, String>> bellIdList = null;
		if (total > 0) {
			List<Map<String, Object>> profilesMap = getProfileMapList(dataMap);
			for (Map<String, Object> profMap : profilesMap) {
				sourceMap = (Map<String, Object>) profMap.get("_source");
				bellIdList= (List<Map<String, String>>) sourceMap.get("bellExternalReference");
						
			}
			if(bellIdList!=null && !bellIdList.isEmpty()) {
			 listOfIds=new HashSet<>();
			  for(Map<String, String> ids:bellIdList) {
				  listOfIds.add(ids.get("externalId"));
				}
			}
		}	
		return listOfIds;
	}
}
