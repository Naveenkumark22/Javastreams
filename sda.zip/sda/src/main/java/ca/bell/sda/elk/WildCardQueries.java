package ca.bell.sda.elk;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;


@Component
public class WildCardQueries {

	public static Map<String, Object> getWildcardQuery(String attrb, Object value) {
		Map<String, Object> rootMap = new HashMap<>();
		Map<String, Object> wildcard = new HashMap<>();
		String[] wildcardValue=(String[]) value;
		String wildcardString="*"+wildcardValue[0]+"*";
		wildcard.put(attrb, wildcardString);
		rootMap.put("wildcard", wildcard);

		return rootMap;
	}

	public static Map<String, Object> getNestedTermsQuery(String attrb, String path, Object value,
			String boolCondition) {
		Map<String, Object> rootMap = new HashMap<>();
		Map<String, Object> nested = new HashMap<>();
		Map<String, Object> query = new HashMap<>();
		Map<String, List<Object>> bool = new HashMap<>();
		List<Object> termsList = new ArrayList<>();
		Map<String, Object> terms = new HashMap<>();
		Map<String, Object> termsQuery = new HashMap<>();

		terms.put(attrb, value);
		termsQuery.put("terms", terms);
		termsList.add(termsQuery);
		bool.put(boolCondition, termsList);
		query.put("bool", bool);
		nested.put("path", path);
		nested.put("query", query);
		rootMap.put("nested", nested);

		return rootMap;
	}

	public static Map<String, Object> getNestedTermsQuery(String attrb, String path, Object value, String boolCondition,
			String boostVal) {
		Map<String, Object> rootMap = new HashMap<>();
		Map<String, Object> nested = new HashMap<>();
		Map<String, Object> query = new HashMap<>();
		Map<String, List<Object>> bool = new HashMap<>();
		List<Object> termsList = new ArrayList<>();
		Map<String, Object> terms = new HashMap<>();
		Map<String, Object> termsQuery = new HashMap<>();

		terms.put(attrb, value);
		terms.put("boost", boostVal);
		termsQuery.put("terms", terms);
		termsList.add(termsQuery);
		bool.put(boolCondition, termsList);
		query.put("bool", bool);
		nested.put("path", path);
		nested.put("query", query);
		rootMap.put("nested", nested);

		return rootMap;
	}

	public static Map<String, Object> getMultiNestedWildcardQuery(String[] attrbArr, Object value, String boolCondition) {
		Map<String, Object> rootMap = new HashMap<>();
		rootMap = getNestedWildcard(attrbArr, 0, attrbArr[0], value, boolCondition);
		return rootMap;
	}

	public static Map<String, Object> getNestedWildcard(String[] attrbArr, int position, String path, Object value,
			String boolCondition) {
		if (position == attrbArr.length - 1) {
			return getWildcardQuery(path, value);
		} else {
			Map<String, Object> rootMap = new HashMap<>();
			Map<String, Object> nested = new HashMap<>();
			Map<String, Object> query = new HashMap<>();
			Map<String, List<Object>> bool = new HashMap<>();
			List<Object> objList = new ArrayList<>();
			nested.put("path", path);
			nested.put("query", query);
			query.put("bool", bool);
			bool.put("must", objList);
			position += 1;
			objList.add(getNestedWildcard(attrbArr, position, path + "." + attrbArr[position], value, boolCondition));
			if((path + "." + attrbArr[position]).equalsIgnoreCase("relatedParty.name"))
			{
				
				objList.add(getRelatedPartyRole());
			}
			rootMap.put("nested", nested);
			return rootMap;
		}

	}

	private static Map<String,Object> getRelatedPartyRole() {
			Map<String, Object> rootMap = new HashMap<>();
			Map<String, Object> match = new HashMap<>();
			match.put("relatedParty.role", "User");
			rootMap.put("match", match);
			return rootMap;
		}

}
