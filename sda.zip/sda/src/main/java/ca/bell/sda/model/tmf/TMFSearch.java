package ca.bell.sda.model.tmf;

import java.util.List;
import java.util.Set;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class TMFSearch {

	private String name;
	private String transactionId;

	@Valid
	@NotNull(message = "Atleast 1 filter group needed")
	private List<FilterGroup> filter;

	@JsonInclude(Include.NON_EMPTY)
	private Set<String> fields;

	@Min(0)
	private Integer offset;

	@Min(0)
	private Integer limit;
	
	@Min(0)
	private Integer from;

	@Min(0)
	private Integer size;
	
	private String sort;
	
	@Pattern(regexp = "and|or", flags = Pattern.Flag.CASE_INSENSITIVE, message= "Invalid Group Operator")
	private String groupOperator;

	public String getGroupOperator() {
		return groupOperator;
	}

	public void setGroupOperator(String groupOperator) {
		this.groupOperator = groupOperator;
	}

	public TMFSearch() {
		super();
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}

	public List<FilterGroup> getFilter() {
		return filter;
	}

	public void setFilter(List<FilterGroup> filter) {
		this.filter = filter;
	}

	public final Set<String> getFields() {
		return fields;
	}

	public final void setFields(Set<String> fields) {
		this.fields = fields;
	}

	public Integer getOffset() {
		return offset;
	}

	public void setOffset(Integer offset) {
		this.offset = offset;
	}

	public Integer getLimit() {
		return limit;
	}

	public void setLimit(Integer limit) {
		this.limit = limit;
	}

	public String getSort() {
		return sort;
	}

	public void setSort(String sort) {
		this.sort = sort;
	}

	public Integer getFrom() {
		return from;
	}

	public void setFrom(Integer from) {
		this.from = from;
	}

	public Integer getSize() {
		return size;
	}

	public void setSize(Integer size) {
		this.size = size;
	}
	
	

}
