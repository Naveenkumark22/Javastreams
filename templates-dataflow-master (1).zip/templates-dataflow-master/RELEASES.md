# Releases

## 2024-10-02 @ 14:52 - Release 93a2af28

<a name="release-93a2af28" />


mTLS support for all templates.

See merge request nbd/smartcore/templates-data-engineering/templates-dataflow!22

<details><summary>Full Description</summary>

# What changes are introduced in this MR?
1. mTLS support for all templates.
2. Apache Beam version upgrade to 2.59.0.
3. Refactoring changes.
4. Dataflow pipeline options segregation.
5. Added new helper class based on the usage.
6. Updated unit testcases.

## How was this tested?

[Describe how it was tested.  Either link to a successful pipeline, or indicate if you tested this change manually and how]

## MOP

[Method of Procedure (MOP) should be a bullet list of things needed to do to release and deploy this change]

## Steps for rollback

[Indicate the steps to rollback this change in case it does not work as expected.  Majority of the time, it should be "Rollback to main/master"]

</details>

## 2024-08-06 @ 12:05 - Release ce94853f

<a name="release-ce94853f" />


Fix for the BQ date format added

See merge request nbd/smartcore/templates-data-engineering/templates-dataflow!19

<details><summary>Full Description</summary>

# What changes are introduced in this MR?
Fix for the BQ date format added and tested in WNODI teams environment.

[Describe your change]

## How was this tested?

[Describe how it was tested.  Either link to a successful pipeline, or indicate if you tested this change manually and how]

## MOP

[Method of Procedure (MOP) should be a bullet list of things needed to do to release and deploy this change]

## Steps for rollback

[Indicate the steps to rollback this change in case it does not work as expected.  Majority of the time, it should be "Rollback to main/master"]

</details>

## 2024-08-02 @ 18:03 - Release 3b2e24bd

<a name="release-3b2e24bd" />


Revert "Merge branch 'nbd-88767-mtls-support-for-all-templates' into 'master'"

See merge request nbd/smartcore/templates-data-engineering/templates-dataflow!20

<details><summary>Full Description</summary>

# What changes are introduced in this MR?

[Describe your change]

## How was this tested?

[Describe how it was tested.  Either link to a successful pipeline, or indicate if you tested this change manually and how]

## MOP

[Method of Procedure (MOP) should be a bullet list of things needed to do to release and deploy this change]

## Steps for rollback

[Indicate the steps to rollback this change in case it does not work as expected.  Majority of the time, it should be "Rollback to main/master"]

</details>

## 2024-07-30 @ 19:35 - Release 160cff7f

<a name="release-160cff7f" />


Code Refactoring and mTLS feature added to all templates

See merge request nbd/smartcore/templates-data-engineering/templates-dataflow!16

<details><summary>Full Description</summary>

# What changes are introduced in this MR?
1. Added mTLS support to all Dataflow templates.
2. Moved all the common code to common project.
3. Split the PipelineOption into multiple Option files and used it as needed, which provides the Dataflow default pipeline option validations as per the defined option type.
4. Moved all constants to common project and extended in each project.
5. Added multiple Helper classes and moved common code in common project.
6. Updated test cases.

[Describe your change]

## How was this tested?
1. Tested (Basic and Kerberos auth flows) all flows and working as expected.
2. Tested mTLS flow in WNDOI team environment and working as expected.

[Describe how it was tested.  Either link to a successful pipeline, or indicate if you tested this change manually and how]

## MOP

[Method of Procedure (MOP) should be a bullet list of things needed to do to release and deploy this change]

## Steps for rollback

[Indicate the steps to rollback this change in case it does not work as expected.  Majority of the time, it should be "Rollback to main/master"]

</details>

## 2024-07-30 @ 13:09 - Release 636d3faf

<a name="release-636d3faf" />


Big Query flow Added DAY partition logic to EPOCH timestamp values.

See merge request nbd/smartcore/templates-data-engineering/templates-dataflow!18

<details><summary>Full Description</summary>

# What changes are introduced in this MR?
1. Added DAY partition logic to EPOCH timestamp values to partition on the incoming date-day instead of first day of month to Big Query flow.
2. Previous business case used to partition the data by first day of month for MONTH partition types.
3. Currently supports DAY and MONTH (default).
4. Future cases not added currently, need to update the logic based on the business needs.

## How was this tested?
1. Updated unit test based on the changes.
2. Tested in DirectRunner mode and validated the column values to be incoming day.

</details>

## 2024-07-15 @ 13:28 - Release 4c1c5724

<a name="release-4c1c5724" />


mTLS authentication integration feature

See merge request nbd/smartcore/templates-data-engineering/templates-dataflow!14

<details><summary>Full Description</summary>

# What changes are introduced in this MR?

Enabled and integrated mTLS authentication feature to KafkaAvroToBigQuery flow.
1. Updated flex-template parameters to accommodate the new feature along with the Kerberos auth.
2. Updated dataflow job options.
3. Updated terraform parameter and secrets keys parameters as well.
4. added conditional logic to differentiate both auth flows.
5. Updated README with all the new and required options in both the flows.

## Note
@eq36361 would be working on Build side validations, already brief him with all the criteria options.

## How was this tested?

Tested this in WNDOI teams environment both manually and over CI deployment. Team confirmed auth working fine as expected.

## MOP

[Method of Procedure (MOP) should be a bullet list of things needed to do to release and deploy this change]

## Steps for rollback

[Indicate the steps to rollback this change in case it does not work as expected.  Majority of the time, it should be "Rollback to main/master"]

</details>

## 2024-06-28 @ 19:26 - Release 632089ed

<a name="release-632089ed" />


Feature epoch micro-seconds to date conversion

See merge request nbd/smartcore/templates-data-engineering/templates-dataflow!12

<details><summary>Full Description</summary>

# What changes are introduced in this MR?

Feature epoch micro-seconds to date conversion, to accommodate epoch micro-seconds values for WNODI team data.

## How was this tested?

Added unit test cases to cover positive and negative cases.

## MOP

[Method of Procedure (MOP) should be a bullet list of things needed to do to release and deploy this change]

## Steps for rollback

[Indicate the steps to rollback this change in case it does not work as expected.  Majority of the time, it should be "Rollback to main/master"]

</details>
