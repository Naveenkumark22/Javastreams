# Overview

This project aims to create generic and reusable GCP Dataflow jobs. It achieves this by building and releasing Dataflow flex templates along with their corresponding container images. It takes advantage of common-modules v1.6.0 and up which changed the way the configuration for dataflow jobs are specified by requiring a URL to a specific flex template version in artifactory.

# Getting Started

## VSCode devcontainers
The project comes with a [VSCode devcontainer](https://code.visualstudio.com/docs/devcontainers/containers) [configuration](./.devcontainer/devcontainer.json) that can be used to create a dev environment with prerequisite tooling installed. It requires access to Unified Artifactory through an artifactory token. You can set the ARTIFACTORY_USERNAME and ARTIFACTORY_USER_TOKEN environment variables before running `code`. Or you can create a .devcontainer/devcontainer.env file with:

```sh
ARTIFACTORY_USERNAME=bob
ARTIFACTORY_USER_TOKEN=token
```

You can use this file to override any other environment variables (such as HTTP_PROXY) used in the post create provision.sh script.

### Create an Artifactory Token

1. Log into https://artifactory.int.bell.ca/ui/
2. Click on the user menu in the top right corner and click on "Edit Profile"
3. Click on "Generate an Identity Token"

## pre-commit

The project uses the [pre-commit tool](https://pre-commit.com/) which provides a framework for ensuring code quality by orchestrating the execution various other code tools. It is meant to be run as a [git hook](https://git-scm.com/docs/githooks). Use `pre-commit install` to install a script in your .git/hooks/ which will execute pre-commit automatically on `git commit ...` commands.

Any code commited that doesn't conform to the pre-commit configuration will fail within the gitlab pipeline executions since pre-commit is also run there.

To manually run pre-commit simply run `pre-commit`. 

To run a specific pre-commit hook defined in the [.pre-commit-config.yaml](./.pre-commit-config.yaml) run `pre-commit run HOOK_ID`.

To install the pre-commit tool see [installation](https://pre-commit.com/#installation).
Other possible install options:
- Most Linux package managers have a pre-commit package
- Brew has a pre-commit package
- winget has a pre-commit package

### Troubleshooting
#### Can't find go executable
When trying to run pre-commit there is the following error about a go executable:
```sh
$ pre-commit run -a
[INFO] Initializing environment for https://github.com/pre-commit/pre-commit-hooks.
[INFO] Initializing environment for https://github.com/gitleaks/gitleaks.
[INFO] Installing environment for https://github.com/pre-commit/pre-commit-hooks.
[INFO] Once installed this environment will be reused.
[INFO] This may take a few minutes...
[INFO] Installing environment for https://github.com/gitleaks/gitleaks.
[INFO] Once installed this environment will be reused.
[INFO] This may take a few minutes...
An unexpected error has occurred: CalledProcessError: command: ('go', 'get', './...')
return code: 1
expected return code: 0
stdout:
    Executable `go` not found
stderr: (none)
Check the log at /home/user/.cache/pre-commit/pre-commit.log
```

pre-commit version 3 and up support tools built with go as first class citizens. pre-commit will install a golang toolchain if one is not present. pre-commit version less than 3 required the system to already have golang toolchain installed if the user wanted to use tools built with golang. We use gitleaks in our pre-commit configuration and gitleaks is built with golang.

What version pre-commit am I running: `pre-commit -V`

Solution 1: Upgrade pre-commit
```sh
# Is pre-commit installed as an os package
sudo dpkg -S `which pre-commit`
# If it is uninstall it
sudo apt purge pre-commit
# else it must be installed with pip
# upgrade or install pre-commit with pip
pip3 install pre-commit
# this will be a "user" install so you will need to have $HOME/.local/bin/ in your path
```

Solution 2: Install golang toolchain `sudo apt install golang-1.19`

#### Virtualenv conflict
When trying to run pre-commit there is the following error about virtualenv

```sh
$ pre-commit run -a
[INFO] Initializing environment for https://github.com/pre-commit/pre-commit-hooks.
[INFO] Initializing environment for https://github.com/gitleaks/gitleaks.
[INFO] Installing environment for https://github.com/pre-commit/pre-commit-hooks.
[INFO] Once installed this environment will be reused.
[INFO] This may take a few minutes...
An unexpected error has occurred: CalledProcessError: command: ('/usr/bin/python3', '-mvirtualenv', '/home/user/.cache/pre-commit/repomjb9rr25/py_env-python3')
return code: 1
stdout:
    AttributeError: module 'virtualenv.create.via_global_ref.builtin.cpython.mac_os' has no attribute 'CPython2macOsFramework'
stderr: (none)
Check the log at /home/user/.cache/pre-commit/pre-commit.log
```

This seems to be due to pre-commit finding the virtualenv library installed.


Solution: Use python3's venv and uninstall virtualenv.

Ensure python3 venv is installed
```sh
sudo apt install python3-venv
```

Ensure virtualenv is uninstalled
```sh
pip3 uninstall virtualenv
```

# DataFlow
The code for the various dataflow jobs are located in ./df/.
See [dataflow](./df/README.md) README.md.


# Ephemeral Environments

This project utilizes ephemeral environments to create temporary infrastructure in GCP for testing out a snapshot of the code. Ephemeral environments are short-lived and used for testing features being developed. They are spun up and torn down in merge request pipelines. Each environment is assigned a unique name based on the git branch name to ensure resource isolation.

# Pipelines
There are two types of pipelines in use:
1. merge request pipelines
2. release pipeline

All pipelines utilize targeted building to optimize CI job execution by only running jobs that are affected by the changed code. For example if there is a modification to a single dataflow job source, only that specific dataflow job will be built and released, reducing unnecessary build and release steps.

## Merge Request Pipeline

The Merge Request pipeline is triggered on commits pushed to a branch with a merge request targeting master. It is used for building:
- development ephemeral environments (one per MR)
- snapshots of container images and flex templates (used by the development ephemeral environments)

### How does the targeted building work with ephemeral environments?
The ephemeral environments have optional `*_flex_template_url` variables for each deployable thing, for example `kafkatocloudstorage_flex_template_url`. These default to `null`. When they are `null` the terraform code for that job is left out. When code changes trigger something to be rebuilt, the merge request pipeline builds snapshots of just those changes storing them in snapshots part of artifactory and will set the corresponding `_flex_template_url` variable to point to the URL to the correct version for that snapshot. It does this by creating a `.auto.tfvars.json` artifact file for that variable in the environments/development-ephemeral/. The tf-plan stage will contain all the `.auto.tfvars.json` artifacts from the previous stage overriding the `null` values and enabling the terraform for those jobs.

## Release Pipeline
The Release pipeline is triggered after a merge to master. It will build the versioned releases of flex templates and container images.

# Secrets

Secrets are injected into each ephemeral development environment via Terraform variables, with the secret values being established as environment variables within the GitLab project.

The keytab secret is a unique case. A keytab file is created prior to executing the `terraform plan` command, using `ktutil`. This file is then passed to `terraform plan` as a base64 encoded variable value. However, `ktutil` does not generate idempotent keytab files. Even with identical inputs, it produces a unique file each time, which prompts Terraform to constantly update the secret. This is due to a timestamp that `ktutil` appends to the keytab file.

To circumvent this issue, we don't run `ktutil` directly. Instead, a Python script executes the `ktutil` command and subsequently overwrites the timestamp with a fixed value of `2024-01-01`. This approach ensures the idempotent generation of the keytab file.