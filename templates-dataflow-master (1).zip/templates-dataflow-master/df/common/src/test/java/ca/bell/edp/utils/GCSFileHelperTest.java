package ca.bell.edp.utils;

import org.hamcrest.MatcherAssert;
import org.hamcrest.core.Is;
import org.junit.Test;

public class GCSFileHelperTest {
    @Test
    public void testGetBatchFilePathAndName() {
        String filePrefix = "wnc_odf_que_daily_summary%2024-03-29 16:29";
        String val = GCSFileHelper.getBatchFilePathAndName(filePrefix);
        // Assert on the results.
        MatcherAssert.assertThat(val, Is.is("wnc_odf_que_daily_summary/2024/03/29/16/29/2024-03-29-16-29"));
    }

    @Test
    public void testGetBatchFilePathAndNameWithOnlyDatePrefix() {
        String filePrefix = "2024-03-29 16:29";
        String val = GCSFileHelper.getBatchFilePathAndName(filePrefix);
        // Assert on the results.
        MatcherAssert.assertThat(val, Is.is("2024/03/29/16/29/2024-03-29-16-29"));
    }
}
