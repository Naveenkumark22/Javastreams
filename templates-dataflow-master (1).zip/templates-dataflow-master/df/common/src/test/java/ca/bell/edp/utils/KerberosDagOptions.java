package ca.bell.edp.utils;

import ca.bell.edp.options.*;
import org.apache.beam.sdk.options.Description;
import org.apache.beam.sdk.options.PipelineOptions;
import org.apache.beam.sdk.options.Validation;

public interface KerberosDagOptions
        extends PipelineOptions, GcsOptions, KerberosOptions, KafkaOptions, TruststoreOptions, DagOptions {
    @Description("Secret Manager Project Id")
    @Validation.Required
    String getProjectIdForSecret();

    void setProjectIdForSecret(String value);

    @Description("Security Protocol, protocol used to communicate with brokers. Ex: SSL, SASL_SSL.")
    @Validation.Required
    String getSecurityProtocol();

    void setSecurityProtocol(String value);
}
