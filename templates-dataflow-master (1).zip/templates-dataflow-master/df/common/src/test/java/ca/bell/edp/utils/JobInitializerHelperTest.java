package ca.bell.edp.utils;

import org.apache.beam.sdk.testing.NeedsRunner;
import org.apache.beam.sdk.testing.TestPipeline;
import org.apache.beam.sdk.testing.TestPipelineOptions;
import org.apache.kafka.common.config.SslConfigs;
import org.junit.Assert;
import org.junit.Rule;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.rules.ExpectedException;

public class JobInitializerHelperTest {
    public interface TestJIOptions extends TestPipelineOptions, DagOptions {}

    private String dagType;

    @Rule
    public final TestPipeline p = TestPipeline.create().enableAbandonedNodeEnforcement(false);

    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @BeforeEach
    public void setUp() throws Exception {
        String[] optionsList =
                new String[] {"--runner=DirectRunner", "--project=mygcpproject", "--authorizationType=mtls"};
        System.setProperty("beamTestPipelineOptions", JsonUtils.asJsonStr(optionsList));
        dagType = "HELLOWORLD";
    }

    @Test
    @Category(NeedsRunner.class)
    public void testProcess() {
        p.getOptions().as(TestJIOptions.class).setDagType(dagType);
        p.run();
        Assertions.assertTrue(true);
    }

    @Test
    @Category(NeedsRunner.class)
    public void testOptions() {
        // Create an instance of your pipeline options
        TestJIOptions options = p.getOptions().as(TestJIOptions.class);
        options.setAuthorizationType("mtls");

        // Assert on the results.
        Assert.assertEquals("mtls", p.getOptions().as(TestJIOptions.class).getAuthorizationType());
    }

    @Test
    @Category(NeedsRunner.class)
    public void testInitializeOptionsNull() throws NullPointerException {
        // Create an instance of your pipeline options
        TestJIOptions options = p.getOptions().as(TestJIOptions.class);
        options.setAuthorizationType("mtls");
        JobInitializerHelper.initializeOptions(p.getOptions().as(DagOptions.class));

        // Assert on the results.
        Assertions.assertEquals(null, System.getProperty(SslConfigs.SSL_TRUSTSTORE_LOCATION_CONFIG));
    }
}
