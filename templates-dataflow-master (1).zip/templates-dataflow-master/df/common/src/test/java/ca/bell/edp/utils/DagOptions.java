package ca.bell.edp.utils;

import ca.bell.edp.options.*;
import org.apache.beam.sdk.options.Default;
import org.apache.beam.sdk.options.Description;
import org.apache.beam.sdk.options.PipelineOptions;
import org.apache.beam.sdk.options.Validation;

public interface DagOptions extends PipelineOptions, GcsOptions, MtlsOptions, TruststoreOptions {
    @Description("Dag options")
    @Default.String("HELLOWORLD")
    String getDagType();

    void setDagType(String dagType);

    @Description("Authorization type to connect to Kafka cluster, supported types: kerberos, mtls.")
    @Validation.Required
    String getAuthorizationType();

    void setAuthorizationType(String value);
}
