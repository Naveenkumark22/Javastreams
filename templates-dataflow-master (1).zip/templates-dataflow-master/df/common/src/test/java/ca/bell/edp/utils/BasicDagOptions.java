package ca.bell.edp.utils;

import ca.bell.edp.options.GcsOptions;
import ca.bell.edp.options.KafkaOptions;
import org.apache.beam.sdk.options.PipelineOptions;

public interface BasicDagOptions extends PipelineOptions, GcsOptions, KafkaOptions, DagOptions {}
