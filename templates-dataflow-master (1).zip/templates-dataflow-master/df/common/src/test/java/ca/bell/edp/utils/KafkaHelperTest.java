package ca.bell.edp.utils;

import static org.junit.jupiter.api.Assertions.*;

import ca.bell.edp.config.KafkaSerializationBuilder;
import org.apache.beam.sdk.options.PipelineOptions;
import org.apache.beam.sdk.options.PipelineOptionsFactory;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

public class KafkaHelperTest {

    private PipelineOptions mockOptions;

    @BeforeEach
    public void setUp() {
        mockOptions = Mockito.mock(PipelineOptions.class);
    }

    @Test
    public void testWithEmptyAuthorizationType() throws Exception {
        // Setup
        BasicDagOptions op = PipelineOptionsFactory.as(BasicDagOptions.class);
        op.setAuthorizationType("");
        op.setAutoOffsetReset("latest");
        op.setBootstrapServers("localhost:9092");
        op.setKafkaGroup("test-group");

        // Act
        KafkaSerializationBuilder result = KafkaHelper.serializationBuilder(op);

        // Assert
        assertNotNull(result);
    }

    @Test
    public void testWithKerberosAuthorization() throws Exception {
        // Setup
        KerberosDagOptions op = PipelineOptionsFactory.as(KerberosDagOptions.class);
        op.setAuthorizationType("kerberos");
        op.setAutoOffsetReset("latest");
        op.setBootstrapServers("localhost:9092");
        op.setKafkaGroup("test-group");
        op.setSecurityProtocol("SASL_PLAINTEXT");
        op.setPrincipal("user@EXAMPLE.COM");
        op.setProjectIdForSecret("project-id");
        op.setKeytabNameSecretId("keytab-id");
        op.setKeytabNameSecretVersion("1");
        op.setCertificateStoreBucket("bucket");
        op.setTrustStoreNameInGcs("truststore");
        op.setTrustStorePasswordSecretId("password-id");
        op.setTrustStorePasswordSecretVersion("1");
        op.setKrb5ConfNameSecretId("krb5-id");
        op.setKrb5ConfNameSecretVersion("1");

        // Act
        KafkaSerializationBuilder result = KafkaHelper.serializationBuilder(op);

        // Assert
        assertNotNull(result);
    }

    @Test
    public void testWithMTLSAuthorization() throws Exception {
        // Setup
        MtlsDagOptions op = PipelineOptionsFactory.as(MtlsDagOptions.class);
        op.setAuthorizationType("mtls");
        op.setAutoOffsetReset("latest");
        op.setBootstrapServers("localhost:9092");
        op.setKafkaGroup("test-group");
        op.setSecurityProtocol("SSL");
        op.setProjectIdForSecret("project-id");
        op.setCertificateStoreBucket("bucket");
        op.setTrustStoreNameInGcs("truststore");
        op.setTrustStorePasswordSecretId("password-id");
        op.setTrustStorePasswordSecretVersion("latest");
        op.setKeystoreSecretId("keystore-id");
        op.setKeystoreSecretVersion("latest");
        op.setKeystorePasswordSecretId("keystore-password-id");
        op.setKeystorePasswordSecretVersion("1");

        // Act
        KafkaSerializationBuilder result = KafkaHelper.serializationBuilder(op);

        // Assert
        assertNotNull(result);
    }

    @Test
    public void testWithNullOptions() {
        // Act & Assert
        assertThrows(Exception.class, () -> {
            KafkaHelper.serializationBuilder(null);
        });
    }

    @Test
    public void testWithInvalidAuthorizationType() throws Exception {
        // Setup
        DagOptions op = PipelineOptionsFactory.as(DagOptions.class);
        op.setAuthorizationType("invalid");

        // Act
        KafkaSerializationBuilder result = KafkaHelper.serializationBuilder(op);

        // Assert
        assertNull(result);
    }
}
