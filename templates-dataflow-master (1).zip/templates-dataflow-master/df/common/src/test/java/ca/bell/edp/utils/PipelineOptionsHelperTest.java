package ca.bell.edp.utils;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.HashMap;
import org.apache.beam.sdk.options.PipelineOptions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

public class PipelineOptionsHelperTest {

    private PipelineOptions mockOptions;

    @BeforeEach
    public void setUp() {
        mockOptions = Mockito.mock(PipelineOptions.class);
    }

    @Test
    public void testCreatePipelineOptions() {
        // Arrange
        String[] args = {"--option1=value1", "--option2=value2"};

        // Act
        MyPipelineOptions options = PipelineOptionsHelper.createPipelineOptions(MyPipelineOptions.class, args);

        // Assert
        assertNotNull(options);
        assertEquals("value1", options.getOption1());
        assertEquals("value2", options.getOption2());
    }

    @Test
    public void testGetValue() throws Exception {
        // Arrange
        String[] args = {"--option1=value1", "--option2=value2"};
        MyPipelineOptions options = PipelineOptionsHelper.createPipelineOptions(MyPipelineOptions.class, args);

        // Act
        Object result = PipelineOptionsHelper.getValue(options, "getOption1");

        // Assert
        assertEquals("value1", result);
    }

    @Test
    public void testSetValue() throws Exception {
        // Arrange
        String[] args = {"--option1=value1", "--option2=value2"};

        // Act
        MyPipelineOptions options = PipelineOptionsHelper.createPipelineOptions(MyPipelineOptions.class, args);
        PipelineOptionsHelper.setValue(options, "setNewValue", "newValue");

        // Assert
        assertEquals(PipelineOptionsHelper.getValue(options, "getNewValue").toString(), "newValue");
    }

    @Test
    public void testToKeyVal() {
        // Arrange
        String[] args = {"--key1=value1", "--key2=value2", "--key3"};

        // Act
        HashMap<String, String> result = PipelineOptionsHelper.toKeyVal(args);

        // Assert
        assertEquals(3, result.size());
        assertEquals("value1", result.get("key1"));
        assertEquals("value2", result.get("key2"));
        assertEquals("", result.get("key3")); // key3 has no value
    }

    // Define a mock PipelineOptions subclass for testing
    public interface MyPipelineOptions extends PipelineOptions {
        String getOption1();

        void setOption1(String value);

        String getOption2();

        void setOption2(String value);

        String getNewValue();

        void setNewValue(String value);
    }
}
