package ca.bell.edp.options;

import org.apache.beam.sdk.options.*;

/**
 * Interface which holds all mTLS related pipeline parameters values
 * this interface can be extended based on a need in the authentication flows
 */
public interface MtlsOptions extends PipelineOptions {
    @Description(
            "Keystore certificate secret id used to fetch keystore content from Secret Manager. Required only for mTLS based auth.")
    String getKeystoreSecretId();

    void setKeystoreSecretId(String value);

    @Description(
            "Keystore certificate secret id version used to fetch keystore content from Secret Manager. Required only for mTLS based auth.")
    String getKeystoreSecretVersion();

    void setKeystoreSecretVersion(String value);

    @Description(
            "Keystore certificate password secret id used to fetch keystore file password from Secret Manager. Required only for mTLS based auth.")
    String getKeystorePasswordSecretId();

    void setKeystorePasswordSecretId(String value);

    @Description(
            "Keystore password secret id version used to fetch keystore password from Secret Manager. Required only for mTLS based auth.")
    String getKeystorePasswordSecretVersion();

    void setKeystorePasswordSecretVersion(String value);
}
