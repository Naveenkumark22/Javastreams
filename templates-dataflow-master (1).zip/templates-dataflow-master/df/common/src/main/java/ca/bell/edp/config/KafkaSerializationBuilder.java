package ca.bell.edp.config;

import java.util.Map;
import org.apache.beam.sdk.transforms.SerializableFunction;
import org.apache.kafka.clients.consumer.Consumer;
import org.codehaus.plexus.util.StringUtils;

public class KafkaSerializationBuilder {
    private String kafkaGroup;
    private String autoOffsetReset;
    private String bootstrapServers;
    private String principal;
    private String securityProtocol;
    private String projectIdForSecret;
    private String keytabNameSecretId;
    private String keytabNameSecretVersion;
    private String trustStorePasswordSecretId;
    private String trustStoreNameInGcs;
    private String certificateStoreBucket;
    private String trustStorePasswordSecretVersion;
    private String krb5ConfNameSecretId;
    private String krb5ConfNameSecretVersion;
    private String authorizationType;
    private String keystoreSecretId;
    private String keystoreSecretVersion;
    private String keystorePasswordSecretId;
    private String keystorePasswordSecretVersion;

    public KafkaSerializationBuilder setKafkaGroup(String kafkaGroup) {
        this.kafkaGroup = kafkaGroup;
        return this;
    }

    public KafkaSerializationBuilder setAutoOffsetReset(String autoOffsetReset) {
        this.autoOffsetReset = autoOffsetReset;
        return this;
    }

    public KafkaSerializationBuilder setBootstrapServers(String bootstrapServers) {
        this.bootstrapServers = bootstrapServers;
        return this;
    }

    public KafkaSerializationBuilder setPrincipal(String principal) {
        this.principal = principal;
        return this;
    }

    public KafkaSerializationBuilder setSecurityProtocol(String securityProtocol) {
        this.securityProtocol = securityProtocol;
        return this;
    }

    public KafkaSerializationBuilder setProjectIdForSecret(String projectIdForSecret) {
        this.projectIdForSecret = projectIdForSecret;
        return this;
    }

    public KafkaSerializationBuilder setKeytabNameSecretId(String keytabNameSecretId) {
        this.keytabNameSecretId = keytabNameSecretId;
        return this;
    }

    public KafkaSerializationBuilder setKeytabNameSecretVersion(String keytabNameSecretVersion) {
        this.keytabNameSecretVersion = keytabNameSecretVersion;
        return this;
    }

    public KafkaSerializationBuilder setTrustStorePasswordSecretId(String trustStorePasswordSecretId) {
        this.trustStorePasswordSecretId = trustStorePasswordSecretId;
        return this;
    }

    public KafkaSerializationBuilder setTrustStoreNameInGcs(String trustStoreNameInGcs) {
        this.trustStoreNameInGcs = trustStoreNameInGcs;
        return this;
    }

    public KafkaSerializationBuilder setTrustStorePasswordSecretVersion(String trustStorePasswordSecretVersion) {
        this.trustStorePasswordSecretVersion = trustStorePasswordSecretVersion;
        return this;
    }

    public KafkaSerializationBuilder setCertificateStoreBucket(String certificateStoreBucket) {
        this.certificateStoreBucket = certificateStoreBucket;
        return this;
    }

    public KafkaSerializationBuilder setKrb5ConfNameSecretId(String krb5ConfNameSecretId) {
        this.krb5ConfNameSecretId = krb5ConfNameSecretId;
        return this;
    }

    public KafkaSerializationBuilder setKrb5ConfNameSecretVersion(String krb5ConfNameSecretVersion) {
        this.krb5ConfNameSecretVersion = krb5ConfNameSecretVersion;
        return this;
    }

    public KafkaSerializationBuilder setAuthorizationType(String authorizationType) {
        this.authorizationType = authorizationType;
        return this;
    }

    public KafkaSerializationBuilder setKeystoreSecretId(String keystoreSecretId) {
        this.keystoreSecretId = keystoreSecretId;
        return this;
    }

    public KafkaSerializationBuilder setKeystoreSecretVersion(String keystoreSecretVersion) {
        this.keystoreSecretVersion = keystoreSecretVersion;
        return this;
    }

    public KafkaSerializationBuilder setKeystorePasswordSecretId(String keystorePasswordSecretId) {
        this.keystorePasswordSecretId = keystorePasswordSecretId;
        return this;
    }

    public KafkaSerializationBuilder setKeystorePasswordSecretVersion(String keystorePasswordSecretVersion) {
        this.keystorePasswordSecretVersion = keystorePasswordSecretVersion;
        return this;
    }

    public SerializableFunction<Map<String, Object>, Consumer<byte[], byte[]>> createKafkaConsumer() {
        if (StringUtils.isEmpty(this.authorizationType)) {
            return new BasicConsumerFactoryFn(kafkaGroup, autoOffsetReset, securityProtocol, bootstrapServers);
        } else if (this.authorizationType.equalsIgnoreCase("kerberos")) {
            return new KerberosConsumerFactoryFn(
                    kafkaGroup,
                    autoOffsetReset,
                    principal,
                    securityProtocol,
                    bootstrapServers,
                    projectIdForSecret,
                    keytabNameSecretId,
                    keytabNameSecretVersion,
                    trustStorePasswordSecretId,
                    trustStoreNameInGcs,
                    certificateStoreBucket,
                    trustStorePasswordSecretVersion,
                    krb5ConfNameSecretId,
                    krb5ConfNameSecretVersion);
        } else if (this.authorizationType.equalsIgnoreCase("mtls")) {
            return new MtlsConsumerFactoryFn(
                    kafkaGroup,
                    autoOffsetReset,
                    securityProtocol,
                    bootstrapServers,
                    projectIdForSecret,
                    trustStorePasswordSecretId,
                    trustStoreNameInGcs,
                    certificateStoreBucket,
                    trustStorePasswordSecretVersion,
                    keystoreSecretId,
                    keystoreSecretVersion,
                    keystorePasswordSecretId,
                    keystorePasswordSecretVersion);
        }
        return null;
    }
}
