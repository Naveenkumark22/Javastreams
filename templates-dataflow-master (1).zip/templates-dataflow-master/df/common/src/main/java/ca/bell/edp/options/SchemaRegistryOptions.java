package ca.bell.edp.options;

import org.apache.beam.sdk.options.*;

/**
 * Interface which holds all SchemaRegistry related pipeline parameters values
 * this interface can be extended based on a need
 */
public interface SchemaRegistryOptions extends PipelineOptions {
    @Description("Schema Registry Url")
    @Validation.Required
    String getSchemaRegistryUrl();

    void setSchemaRegistryUrl(String value);

    @Description("Schema Registry Username")
    @Validation.Required
    String getSchemaRegistryUser();

    void setSchemaRegistryUser(String value);

    @Description("Schema Registry Password Secret Id")
    @Validation.Required
    String getSchemaRegistryPasswordSecretId();

    void setSchemaRegistryPasswordSecretId(String value);

    @Description("Secret version of the schema registry password from secret manager")
    @Validation.Required
    String getSchemaRegistryPasswordSecretVersion();

    void setSchemaRegistryPasswordSecretVersion(String value);
}
