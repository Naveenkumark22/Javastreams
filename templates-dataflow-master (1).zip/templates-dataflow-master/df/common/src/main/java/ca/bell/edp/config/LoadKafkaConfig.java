package ca.bell.edp.config;

import ca.bell.edp.constants.CommonConstants;
import ca.bell.edp.utils.CloudStorageHelper;
import ca.bell.edp.utils.PipelineOptionsHelper;
import ca.bell.edp.utils.SecretManagerHelper;
import com.google.api.client.util.Maps;
import com.google.api.client.util.Preconditions;
import io.confluent.kafka.schemaregistry.client.SchemaRegistryClientConfig;
import io.confluent.kafka.serializers.KafkaAvroSerializerConfig;
import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Map;
import java.util.Objects;
import org.apache.beam.sdk.options.PipelineOptions;
import org.apache.kafka.clients.CommonClientConfigs;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.common.config.SaslConfigs;
import org.apache.kafka.common.config.SslConfigs;
import org.apache.maven.shared.utils.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Kafka configuration class which used to fetch all the required certificates and credentials.
 * All the retrieved details will set to respective keys in the config map and System variables
 * All these keys will be used by Kafka Consumer, Schema Registry Client, Java Security
 *
 * @input {@link PipelineOptions}
 */
public class LoadKafkaConfig {
    private static final Logger LOG = LoggerFactory.getLogger(LoadKafkaConfig.class);

    public static Map<String, Object> config(PipelineOptions options) throws Exception {
        Path truststore, keytab, krb5Conf, keystore;
        String truststorePassword = "", schemaRegistryPassword = "", keystorePassword = "";

        // Deleting if there are any empty files to be safe side and download fresh files
        for (File file : Objects.requireNonNull(new File(CommonConstants.LOCAL_TEMP_FOLDER).listFiles())) {
            if (file.isFile() && file.length() == 0) {
                file.delete();
            }
        }

        try {
            schemaRegistryPassword = SecretManagerHelper.getValue(
                    (String) PipelineOptionsHelper.getValue(options, "getProjectIdForSecret"),
                    (String) PipelineOptionsHelper.getValue(options, "getSchemaRegistryPasswordSecretId"),
                    (String) PipelineOptionsHelper.getValue(options, "getSchemaRegistryPasswordSecretVersion"));
        } catch (Exception e) {
            LOG.error(
                    "Unable to download schema registry password: \n{}",
                    org.codehaus.plexus.util.ExceptionUtils.getFullStackTrace(e));
        }

        if (StringUtils.isEmpty(System.getProperty(SslConfigs.SSL_TRUSTSTORE_PASSWORD_CONFIG))) {
            try {
                truststorePassword = SecretManagerHelper.getValue(
                        (String) PipelineOptionsHelper.getValue(options, "getProjectIdForSecret"),
                        (String) PipelineOptionsHelper.getValue(options, "getTrustStorePasswordSecretId"),
                        (String) PipelineOptionsHelper.getValue(options, "getTrustStorePasswordSecretVersion"));
                System.setProperty(SslConfigs.SSL_TRUSTSTORE_PASSWORD_CONFIG, truststorePassword.trim());
                // Set below properties to avoid SSL: SunCertPathBuilderException exception
                System.setProperty(CommonConstants.JAVAX_NET_SSL_TRUSTSTORE_PASSWORD, truststorePassword.trim());
            } catch (Exception e) {
                LOG.error(
                        "Unable to download truststore password: \n{}",
                        org.codehaus.plexus.util.ExceptionUtils.getFullStackTrace(e));
            }
        }

        truststore = Paths.get(CommonConstants.LOCAL_TEMP_FOLDER
                + (String) PipelineOptionsHelper.getValue(options, "getTrustStoreNameInGcs"));
        if (!truststore.toFile().exists()
                | truststore.toFile().length() == 0
                | System.getProperty(SslConfigs.SSL_TRUSTSTORE_LOCATION_CONFIG) == null) {
            // Download the file only if the file doesn't exist.
            try {
                truststore = CloudStorageHelper.getFile(
                        (String) PipelineOptionsHelper.getValue(options, "getProjectIdForTruststore"),
                        (String) PipelineOptionsHelper.getValue(options, "getCertificateStoreBucket"),
                        (String) PipelineOptionsHelper.getValue(options, "getTrustStoreNameInGcs"),
                        CommonConstants.LOCAL_TEMP_FOLDER);
                System.setProperty(
                        SslConfigs.SSL_TRUSTSTORE_LOCATION_CONFIG,
                        truststore.toAbsolutePath().toString());
                // Set below properties to avoid SSL: SunCertPathBuilderException exception
                System.setProperty(
                        CommonConstants.JAVAX_NET_SSL_TRUSTSTORE,
                        truststore.toAbsolutePath().toString());
            } catch (Exception e) {
                LOG.error(
                        "Unable to download truststore file: \n{}",
                        org.codehaus.plexus.util.ExceptionUtils.getFullStackTrace(e));
            }
        }

        if (PipelineOptionsHelper.getValue(options, "getAuthorizationType")
                .toString()
                .equalsIgnoreCase("mtls")) {
            // MTLS auth flow
            keystore = Paths.get(CommonConstants.LOCAL_TEMP_FOLDER
                    + (String) PipelineOptionsHelper.getValue(options, "getKeystoreSecretId"));
            if (!keystore.toFile().exists()
                    | keystore.toFile().length() == 0
                    | System.getProperty(SslConfigs.SSL_KEYSTORE_LOCATION_CONFIG) == null) {
                try {
                    keystore = SecretManagerHelper.getValueAsFile(
                            (String) PipelineOptionsHelper.getValue(options, "getProjectIdForSecret"),
                            (String) PipelineOptionsHelper.getValue(options, "getKeystoreSecretId"),
                            (String) PipelineOptionsHelper.getValue(options, "getKeystoreSecretVersion"),
                            CommonConstants.LOCAL_TEMP_FOLDER);
                    System.setProperty(
                            SslConfigs.SSL_KEYSTORE_LOCATION_CONFIG,
                            keystore.toAbsolutePath().toString());
                } catch (Exception e) {
                    LOG.error(
                            "Unable to download keystore certificate: \n{}",
                            org.codehaus.plexus.util.ExceptionUtils.getFullStackTrace(e));
                }
            }

            keystorePassword = System.getProperty(SslConfigs.SSL_KEYSTORE_PASSWORD_CONFIG);
            if (StringUtils.isEmpty(keystorePassword)) {
                try {
                    keystorePassword = SecretManagerHelper.getValue(
                            (String) PipelineOptionsHelper.getValue(options, "getProjectIdForSecret"),
                            (String) PipelineOptionsHelper.getValue(options, "getKeystorePasswordSecretId"),
                            (String) PipelineOptionsHelper.getValue(options, "getKeystorePasswordSecretVersion"));
                    System.setProperty(SslConfigs.SSL_KEYSTORE_PASSWORD_CONFIG, keystorePassword.trim());
                } catch (Exception e) {
                    LOG.error(
                            "Unable to get keystore password: \n{}",
                            org.codehaus.plexus.util.ExceptionUtils.getFullStackTrace(e));
                }
            }
        } else if (PipelineOptionsHelper.getValue(options, "getAuthorizationType")
                .toString()
                .equalsIgnoreCase("kerberos")) {
            // Kerberos auth flow
            keytab = Paths.get(CommonConstants.LOCAL_TEMP_FOLDER
                    + (String) PipelineOptionsHelper.getValue(options, "getKeytabNameSecretId"));
            if (!keytab.toFile().exists()
                    | keytab.toFile().length() == 0
                    | System.getProperty(CommonConstants.KEYTAB_LOCATION_CONFIG) == null) {
                // Download the file only if the file doesn't exist.
                try {
                    keytab = SecretManagerHelper.getValueAsFile(
                            (String) PipelineOptionsHelper.getValue(options, "getProjectIdForSecret"),
                            (String) PipelineOptionsHelper.getValue(options, "getKeytabNameSecretId"),
                            (String) PipelineOptionsHelper.getValue(options, "getKeytabNameSecretVersion"),
                            CommonConstants.LOCAL_TEMP_FOLDER);
                    System.setProperty(
                            CommonConstants.KEYTAB_LOCATION_CONFIG,
                            keytab.toAbsolutePath().toString());
                } catch (Exception e) {
                    LOG.error(
                            "Unable to download keytab secret file: \n{}",
                            org.codehaus.plexus.util.ExceptionUtils.getFullStackTrace(e));
                }
            }

            Preconditions.checkNotNull(keytab);
            Preconditions.checkNotNull((String) PipelineOptionsHelper.getValue(options, "getPrincipal"));

            krb5Conf = Paths.get(CommonConstants.LOCAL_TEMP_FOLDER
                    + (String) PipelineOptionsHelper.getValue(options, "getKrb5ConfNameSecretId"));
            if (!krb5Conf.toFile().exists()
                    | krb5Conf.toFile().length() == 0
                    | System.getProperty(CommonConstants.JAVA_SECURITY_KRB5_CONFIG_KEY) == null) {
                // Download the file only if the file doesn't exist.
                try {
                    krb5Conf = SecretManagerHelper.getValueAsFile(
                            (String) PipelineOptionsHelper.getValue(options, "getProjectIdForSecret"),
                            (String) PipelineOptionsHelper.getValue(options, "getKrb5ConfNameSecretId"),
                            (String) PipelineOptionsHelper.getValue(options, "getKrb5ConfNameSecretVersion"),
                            CommonConstants.LOCAL_TEMP_FOLDER);
                    System.setProperty(
                            CommonConstants.JAVA_SECURITY_KRB5_CONFIG_KEY,
                            krb5Conf.toAbsolutePath().toString());
                } catch (Exception e) {
                    LOG.error(
                            "Unable to download KRB5 file: \n{}",
                            org.codehaus.plexus.util.ExceptionUtils.getFullStackTrace(e));
                }
            }
        }

        // Options coming from Constants
        Map<String, Object> config = Maps.newHashMap();
        config.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, CommonConstants.ENABLE_AUTO_COMMIT_CONFIG);
        config.put(SchemaRegistryClientConfig.BASIC_AUTH_CREDENTIALS_SOURCE, CommonConstants.BASIC_AUTH_TYPE);

        // Options coming from System Property
        config.put(
                SslConfigs.SSL_TRUSTSTORE_LOCATION_CONFIG,
                System.getProperty(SslConfigs.SSL_TRUSTSTORE_LOCATION_CONFIG));
        config.put(
                SslConfigs.SSL_TRUSTSTORE_PASSWORD_CONFIG,
                System.getProperty(SslConfigs.SSL_TRUSTSTORE_PASSWORD_CONFIG));
        config.put(SslConfigs.SSL_TRUSTSTORE_TYPE_CONFIG, "JKS");

        if (PipelineOptionsHelper.getValue(options, "getAuthorizationType")
                .toString()
                .equalsIgnoreCase("mtls")) {
            // SSL key store password cannot be specified with PEM format, only key password may be specified
            config.put(
                    SslConfigs.SSL_KEYSTORE_LOCATION_CONFIG,
                    System.getProperty(SslConfigs.SSL_KEYSTORE_LOCATION_CONFIG));
            config.put(
                    SslConfigs.SSL_KEYSTORE_PASSWORD_CONFIG,
                    System.getProperty(SslConfigs.SSL_KEYSTORE_PASSWORD_CONFIG));
            config.put(SslConfigs.SSL_KEYSTORE_TYPE_CONFIG, "JKS");
        } else if (PipelineOptionsHelper.getValue(options, "getAuthorizationType")
                .toString()
                .equalsIgnoreCase("kerberos")) {
            // Updating JAAS values like keytab, principal
            String JAAS_LOGIN_CONFIG = String.format(
                    CommonConstants.SASL_JAAS_CONFIG,
                    System.getProperty(CommonConstants.KEYTAB_LOCATION_CONFIG),
                    (String) PipelineOptionsHelper.getValue(options, "getPrincipal"));
            config.put(SaslConfigs.SASL_JAAS_CONFIG, JAAS_LOGIN_CONFIG);
            config.put(SaslConfigs.SASL_MECHANISM, CommonConstants.SASL_MECHANISM);
            config.put(SaslConfigs.SASL_KERBEROS_SERVICE_NAME, CommonConstants.SASL_KERBEROS_SERVICE_NAME_VALUE);
        }

        // Options coming from pipeline
        config.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, (String)
                PipelineOptionsHelper.getValue(options, "getAutoOffsetReset"));
        config.put(CommonClientConfigs.SECURITY_PROTOCOL_CONFIG, (String)
                PipelineOptionsHelper.getValue(options, "getSecurityProtocol"));
        config.put(
                CommonClientConfigs.GROUP_ID_CONFIG, (String) PipelineOptionsHelper.getValue(options, "getKafkaGroup"));
        config.put(CommonClientConfigs.BOOTSTRAP_SERVERS_CONFIG, (String)
                PipelineOptionsHelper.getValue(options, "getBootstrapServers"));
        config.put(KafkaAvroSerializerConfig.SCHEMA_REGISTRY_URL_CONFIG, (String)
                PipelineOptionsHelper.getValue(options, "getSchemaRegistryUrl"));
        config.put(
                SchemaRegistryClientConfig.SCHEMA_REGISTRY_USER_INFO_CONFIG,
                (String) PipelineOptionsHelper.getValue(options, "getSchemaRegistryUser") + ":"
                        + schemaRegistryPassword.trim());
        config.put(
                SchemaRegistryClientConfig.USER_INFO_CONFIG,
                (String) PipelineOptionsHelper.getValue(options, "getSchemaRegistryUser") + ":"
                        + schemaRegistryPassword.trim());
        config.put(CommonConstants.KAFKA_APPLICATION_ID, (String)
                PipelineOptionsHelper.getValue(options, "getKafkaGroup"));

        return config;
    }
}
