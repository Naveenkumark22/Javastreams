package ca.bell.edp.options;

import java.util.List;
import org.apache.beam.sdk.options.*;

/**
 * Interface which holds all kafka related pipeline parameters values
 * this interface can be extended based on a need in the authentication flows
 */
public interface KafkaOptions extends PipelineOptions {
    @Description("The Kafka topic name to consume from.")
    @Validation.Required
    List<String> getInputTopic();

    void setInputTopic(List<String> value);

    @Description(
            "Kafka common group id of all the input topics list with a valid ACL prefix. i.e all the topics must share the same group id.")
    @Validation.Required
    String getKafkaGroup();

    void setKafkaGroup(String value);

    @Description("Kafka Bootstrap Servers")
    @Validation.Required
    String getBootstrapServers();

    void setBootstrapServers(String value);

    @Description("AUTO_OFFSET_RESET_CONFIG true or false value")
    @Validation.Required
    String getAutoOffsetReset();

    void setAutoOffsetReset(String value);
}
