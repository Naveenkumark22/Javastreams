package ca.bell.edp.config;

import ca.bell.edp.constants.CommonConstants;
import ca.bell.edp.utils.CloudStorageHelper;
import ca.bell.edp.utils.SecretManagerHelper;
import io.confluent.kafka.schemaregistry.client.SchemaRegistryClientConfig;
import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Map;
import java.util.Objects;
import org.apache.beam.sdk.transforms.SerializableFunction;
import org.apache.kafka.clients.CommonClientConfigs;
import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.common.config.SslConfigs;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Kafka Consumer Factory class to build {@link KafkaConsumer} object and uses mTLS authentication to read messages.
 */
public class MtlsConsumerFactoryFn implements SerializableFunction<Map<String, Object>, Consumer<byte[], byte[]>> {
    private static final Logger LOG = LoggerFactory.getLogger(MtlsConsumerFactoryFn.class);

    private final String kafkaGroup;
    private final String autoOffsetReset;
    private final String bootstrapServers;
    private final String securityProtocol;
    private final String projectIdForSecret;
    private final String trustStorePasswordSecretId;
    private final String trustStoreNameInGcs;
    private final String certificateStoreBucket;
    private final String trustStorePasswordSecretVersion;
    private final String keystoreSecretId;
    private final String keystoreSecretVersion;
    private final String keystorePasswordSecretId;
    private final String keystorePasswordSecretVersion;

    public MtlsConsumerFactoryFn(
            String kafkaGroup,
            String autoOffsetReset,
            String securityProtocol,
            String bootstrapServers,
            String projectIdForSecret,
            String trustStorePasswordSecretId,
            String trustStoreNameInGcs,
            String certificateStoreBucket,
            String trustStorePasswordSecretVersion,
            String keystoreSecretId,
            String keystoreSecretVersion,
            String keystorePasswordSecretId,
            String keystorePasswordSecretVersion) {
        this.kafkaGroup = kafkaGroup;
        this.autoOffsetReset = autoOffsetReset;
        this.securityProtocol = securityProtocol;
        this.bootstrapServers = bootstrapServers;
        this.projectIdForSecret = projectIdForSecret;
        this.trustStorePasswordSecretId = trustStorePasswordSecretId;
        this.trustStoreNameInGcs = trustStoreNameInGcs;
        this.certificateStoreBucket = certificateStoreBucket;
        this.trustStorePasswordSecretVersion = trustStorePasswordSecretVersion;
        this.keystoreSecretId = keystoreSecretId;
        this.keystoreSecretVersion = keystoreSecretVersion;
        this.keystorePasswordSecretId = keystorePasswordSecretId;
        this.keystorePasswordSecretVersion = keystorePasswordSecretVersion;
    }

    /**
     * Note:
     * Doc:https://github.com/apache/beam/blob/master/sdks/java/io/kafka/src/main/java/org/apache/beam/sdk/io/kafka/KafkaIO.java
     * 1. 'ENABLE_AUTO_COMMIT_CONFIG' Enable committing record offset. Consumer
     * offset stored in Kafka when
     * {@code ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG = true};
     * 2. Since we set 'commitOffsetsInFinalize()' in
     * {@code ca.bell.edp.jobs.KafkaToCloudStorage}, 'ENABLE_AUTO_COMMIT_CONFIG' is
     * set to false. As per the documentation, we can use only one of them.
     */
    public Consumer<byte[], byte[]> apply(Map<String, Object> config) {
        Path truststore, keystore;
        String truststorePassword = "", keystorePassword = "";

        // Deleting if there are any empty files to be safe side and download fresh files
        for (File file : Objects.requireNonNull(new File(CommonConstants.LOCAL_TEMP_FOLDER).listFiles())) {
            if (file.isFile() && file.length() == 0) {
                file.delete();
            }
        }

        if (System.getProperty(SslConfigs.SSL_TRUSTSTORE_PASSWORD_CONFIG) == null) {
            try {
                truststorePassword = SecretManagerHelper.getValue(
                        this.projectIdForSecret, this.trustStorePasswordSecretId, this.trustStorePasswordSecretVersion);
                System.setProperty(SslConfigs.SSL_TRUSTSTORE_PASSWORD_CONFIG, truststorePassword.trim());
                // Set below properties to avoid SSL: SunCertPathBuilderException exception
                System.setProperty(CommonConstants.JAVAX_NET_SSL_TRUSTSTORE_PASSWORD, truststorePassword.trim());
            } catch (IOException e) {
                LOG.error(
                        "Unable to download truststore password: \n{}",
                        org.codehaus.plexus.util.ExceptionUtils.getFullStackTrace(e));
            }
        }

        truststore = Paths.get(CommonConstants.LOCAL_TEMP_FOLDER + this.trustStoreNameInGcs);
        if (!truststore.toFile().exists()
                | truststore.toFile().length() == 0
                | System.getProperty(SslConfigs.SSL_TRUSTSTORE_LOCATION_CONFIG) == null) {
            // Download the file only if the file doesn't exist.
            try {
                truststore = CloudStorageHelper.getFile(
                        this.projectIdForSecret,
                        this.certificateStoreBucket,
                        this.trustStoreNameInGcs,
                        CommonConstants.LOCAL_TEMP_FOLDER);
                System.setProperty(
                        SslConfigs.SSL_TRUSTSTORE_LOCATION_CONFIG,
                        truststore.toAbsolutePath().toString());
                // Set below properties to avoid SSL: SunCertPathBuilderException exception
                System.setProperty(
                        CommonConstants.JAVAX_NET_SSL_TRUSTSTORE,
                        truststore.toAbsolutePath().toString());
            } catch (IOException e) {
                LOG.error(
                        "Unable to download truststore file: \n{}",
                        org.codehaus.plexus.util.ExceptionUtils.getFullStackTrace(e));
            }
        }

        // MTLS auth flow
        keystore = Paths.get(CommonConstants.LOCAL_TEMP_FOLDER + this.keystoreSecretId);
        if (!keystore.toFile().exists()
                | keystore.toFile().length() == 0
                | System.getProperty(SslConfigs.SSL_KEYSTORE_LOCATION_CONFIG) == null) {
            try {
                keystore = SecretManagerHelper.getValueAsFile(
                        this.projectIdForSecret,
                        this.keystoreSecretId,
                        this.keystoreSecretVersion,
                        CommonConstants.LOCAL_TEMP_FOLDER);
                System.setProperty(
                        SslConfigs.SSL_KEYSTORE_LOCATION_CONFIG,
                        keystore.toAbsolutePath().toString());
            } catch (IOException e) {
                LOG.error(
                        "Unable to download keystore certificate: \n{}",
                        org.codehaus.plexus.util.ExceptionUtils.getFullStackTrace(e));
            }
        }

        keystorePassword = System.getProperty(SslConfigs.SSL_KEYSTORE_PASSWORD_CONFIG);
        if (keystorePassword.isEmpty()) {
            try {
                keystorePassword = SecretManagerHelper.getValue(
                        this.projectIdForSecret, this.keystorePasswordSecretId, this.keystorePasswordSecretVersion);
                System.setProperty(SslConfigs.SSL_KEYSTORE_PASSWORD_CONFIG, keystorePassword.trim());
            } catch (IOException e) {
                LOG.error(
                        "Unable to get keystore password: \n{}",
                        org.codehaus.plexus.util.ExceptionUtils.getFullStackTrace(e));
            }
        }

        // Options coming from Constants
        config.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, CommonConstants.ENABLE_AUTO_COMMIT_CONFIG);
        config.put(SchemaRegistryClientConfig.BASIC_AUTH_CREDENTIALS_SOURCE, CommonConstants.BASIC_AUTH_TYPE);

        // Options coming from System Property
        config.put(
                SslConfigs.SSL_TRUSTSTORE_LOCATION_CONFIG,
                System.getProperty(SslConfigs.SSL_TRUSTSTORE_LOCATION_CONFIG));
        config.put(
                SslConfigs.SSL_TRUSTSTORE_PASSWORD_CONFIG,
                System.getProperty(SslConfigs.SSL_TRUSTSTORE_PASSWORD_CONFIG));
        config.put(SslConfigs.SSL_TRUSTSTORE_TYPE_CONFIG, "JKS");

        // SSL key store password cannot be specified with PEM format, only key password may be specified
        config.put(
                SslConfigs.SSL_KEYSTORE_LOCATION_CONFIG, System.getProperty(SslConfigs.SSL_KEYSTORE_LOCATION_CONFIG));
        config.put(
                SslConfigs.SSL_KEYSTORE_PASSWORD_CONFIG, System.getProperty(SslConfigs.SSL_KEYSTORE_PASSWORD_CONFIG));
        config.put(SslConfigs.SSL_KEYSTORE_TYPE_CONFIG, "JKS");

        // Options coming from pipeline
        config.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, this.autoOffsetReset);
        config.put(CommonClientConfigs.SECURITY_PROTOCOL_CONFIG, this.securityProtocol);
        config.put(CommonClientConfigs.GROUP_ID_CONFIG, this.kafkaGroup);
        config.put(CommonClientConfigs.BOOTSTRAP_SERVERS_CONFIG, this.bootstrapServers);

        KafkaConsumer<byte[], byte[]> kafkaConsumerInstance = null;

        try {
            kafkaConsumerInstance = new KafkaConsumer<byte[], byte[]>(config);
        } catch (Exception e) {
            LOG.error(
                    "Error Creating mTLS Kafka Consumer Instance: \n{}",
                    org.codehaus.plexus.util.ExceptionUtils.getFullStackTrace(e));
        }

        return kafkaConsumerInstance;
    }
}
