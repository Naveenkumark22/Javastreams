package ca.bell.edp.options;

import org.apache.beam.sdk.options.*;

/**
 * Interface which holds all Kerberos related pipeline parameters values
 * this interface can be extended based on a need in the authentication flows
 */
public interface KerberosOptions extends PipelineOptions {
    @Description("Kerberos username, used to get active ticket. Example: fidappnpdaaccenture@BELL.CORP.BCE.CA")
    String getPrincipal();

    void setPrincipal(String value);

    @Description(
            "secret id of the keytab name configuration from secret manager. Required only for Kerberos based auth.")
    String getKeytabNameSecretId();

    void setKeytabNameSecretId(String value);

    @Description(
            "secret version of the keytab name configuration from secret manager. Required only for Kerberos based auth.")
    String getKeytabNameSecretVersion();

    void setKeytabNameSecretVersion(String value);

    @Description("secret id of the kerberos configuration from secret manager. Required only for Kerberos based auth.")
    String getKrb5ConfNameSecretId();

    void setKrb5ConfNameSecretId(String value);

    @Description(
            "secret version of the kerberos configuration from secret manager. Required only for Kerberos based auth.")
    String getKrb5ConfNameSecretVersion();

    void setKrb5ConfNameSecretVersion(String value);
}
