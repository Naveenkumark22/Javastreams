package ca.bell.edp.options;

import org.apache.beam.sdk.options.*;

/**
 * Interface which holds all BigQuery related pipeline parameters values
 * this interface can be extended based on a need
 */
public interface BigQueryOptions extends PipelineOptions {
    @Description("The BQ dataset project-name to where the output data required to sink")
    @Validation.Required
    String getBqProjectName();

    void setBqProjectName(String value);

    @Description("The BQ dataset name to where the output data required to sink.")
    @Validation.Required
    String getBqDataSetName();

    void setBqDataSetName(String value);

    @Description("Big Query window size used to sink processed data with given frequency.")
    @Default.Integer(5)
    @Validation.Required
    Integer getOutputWindowSizeBq();

    void setOutputWindowSizeBq(Integer value);

    @Description("The directory to output Error EDR from BQ Insert failures.")
    @Validation.Required
    String getBqFailedOutputDirectory();

    void setBqFailedOutputDirectory(String value);
}
