package ca.bell.edp.utils;

/**
 * Helper class to build the GCS directory structure path for each group of events to save.
 * Used in the Batch mode processing
 */
public class GCSFileHelper {
    /**
     * Build the GS file path with the timestamp-based order
     *
     * @param filePrefix string which concatenated with event type and record timestamp from the event json
     * @return File name with the complete path including a file extension
     */
    public static String getBatchFilePathAndName(String filePrefix) {
        String type = "";
        String ts = "";

        if (filePrefix.contains("%")) {
            // With prefix key and prefix dateTime Ex: 'prefixKey%prefixDateTime'
            String[] string_list = filePrefix.split("%", 2);
            type = string_list[0];
            ts = string_list[1];
            return String.format(
                    "%s/%s/%s/%s/%s/%s/%s",
                    type,
                    ts.substring(0, 4), // year
                    ts.substring(5, 7), // month
                    ts.substring(8, 10), // day
                    ts.substring(11, 13), // hour
                    ts.substring(14), // minutes
                    ts.replace(' ', '-').replace(':', '-'));
        } else {
            // With only prefixDateTime
            ts = filePrefix;
            return String.format(
                    "%s/%s/%s/%s/%s/%s",
                    ts.substring(0, 4), // year
                    ts.substring(5, 7), // month
                    ts.substring(8, 10), // day
                    ts.substring(11, 13), // hour
                    ts.substring(14), // minutes
                    ts.replace(' ', '-').replace(':', '-'));
        }
    }
}
