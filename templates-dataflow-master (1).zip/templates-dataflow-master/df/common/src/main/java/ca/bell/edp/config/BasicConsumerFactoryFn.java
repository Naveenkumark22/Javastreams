package ca.bell.edp.config;

import ca.bell.edp.constants.CommonConstants;
import java.util.Map;
import org.apache.beam.sdk.transforms.SerializableFunction;
import org.apache.kafka.clients.CommonClientConfigs;
import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Kafka Consumer Factory class to build {@link KafkaConsumer} object for and
 * this instance is basic and targeted to non-kerberos/non-mTLS environment.
 *
 */
public class BasicConsumerFactoryFn implements SerializableFunction<Map<String, Object>, Consumer<byte[], byte[]>> {
    private static final Logger LOG = LoggerFactory.getLogger(BasicConsumerFactoryFn.class);

    private final String autoOffsetReset;
    private final String kafkaGroup;
    private final String bootstrapServers;

    public BasicConsumerFactoryFn(
            String kafkaGroup, String autoOffsetReset, String securityProtocol, String bootstrapServers) {
        this.autoOffsetReset = autoOffsetReset;
        this.kafkaGroup = kafkaGroup;
        this.bootstrapServers = bootstrapServers;
    }

    /**
     * Note:
     * Doc:https://github.com/apache/beam/blob/master/sdks/java/io/kafka/src/main/java/org/apache/beam/sdk/io/kafka/KafkaIO.java
     * 1. 'ENABLE_AUTO_COMMIT_CONFIG' Enable committing record offset. Consumer
     * offset stored in Kafka when
     * {@code ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG = true};
     * 2. Since we set 'commitOffsetsInFinalize()' in
     * {@code ca.bell.edp.jobs.KafkaToCloudStorage}, 'ENABLE_AUTO_COMMIT_CONFIG' is
     * set to false. As per the documentation, we can use only one of them.
     */
    public Consumer<byte[], byte[]> apply(Map<String, Object> config) {
        // Options coming from Constants
        assert config != null;
        config.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, CommonConstants.ENABLE_AUTO_COMMIT_CONFIG);
        // Options coming from pipeline options
        config.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, autoOffsetReset);
        config.put(CommonClientConfigs.GROUP_ID_CONFIG, kafkaGroup);
        config.put(CommonClientConfigs.BOOTSTRAP_SERVERS_CONFIG, bootstrapServers);

        KafkaConsumer<byte[], byte[]> kafkaConsumerInstance = null;

        try {
            kafkaConsumerInstance = new KafkaConsumer<byte[], byte[]>(config);
        } catch (Exception e) {
            LOG.error(
                    "Error Creating Basic Kafka Consumer Instance: \n{}",
                    org.codehaus.plexus.util.ExceptionUtils.getFullStackTrace(e));
        }

        return kafkaConsumerInstance;
    }
}
