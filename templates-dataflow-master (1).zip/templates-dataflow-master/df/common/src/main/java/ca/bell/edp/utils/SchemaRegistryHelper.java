package ca.bell.edp.utils;

import io.confluent.kafka.schemaregistry.client.CachedSchemaRegistryClient;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Used to get the schema from the schema registry of a topic
 */
public class SchemaRegistryHelper {
    private static final Logger LOG = LoggerFactory.getLogger(SchemaRegistryHelper.class);

    /**
     * Used to get the schema from the schema registry of a topic
     *
     * @return String Schema
     */
    public static String getSchemaFromRegistry(String topicName, String schemaRegistryUrl, Map<String, Object> config) {
        String schema = "";
        CachedSchemaRegistryClient schemaRegistryClient =
                new CachedSchemaRegistryClient(schemaRegistryUrl, 100, config);
        try {
            // Retrieve the latest version of the schema for the subject
            schema = schemaRegistryClient
                    .getLatestSchemaMetadata(topicName + "-value")
                    .getSchema();
            LOG.info("Successfully retrieved schema: {}", schema);
        } catch (Exception e) {
            LOG.error("Error retrieving schema: {}", e.getMessage());
        }
        return schema;
    }
}
