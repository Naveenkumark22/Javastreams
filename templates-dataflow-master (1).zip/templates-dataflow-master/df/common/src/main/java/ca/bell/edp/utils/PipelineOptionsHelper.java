package ca.bell.edp.utils;

import java.lang.reflect.Method;
import java.util.HashMap;
import org.apache.beam.sdk.options.PipelineOptions;
import org.apache.beam.sdk.options.PipelineOptionsFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Helper class
 * This class is used to call the PipelineOptions custom methods at run time dynamically
 * Each template has it an own set of custom options
 * We can get and set the values to the same instance of options
 */
public class PipelineOptionsHelper {
    private static final Logger LOG = LoggerFactory.getLogger(PipelineOptionsHelper.class);

    @SuppressWarnings("unchecked")
    public static <T extends PipelineOptions> T createPipelineOptions(Class<T> optionsClass, String[] args) {
        PipelineOptionsFactory.register(optionsClass);
        return (T) PipelineOptionsFactory.fromArgs(args).withValidation().as(optionsClass);
    }

    public static Object getValue(PipelineOptions options, String optionName) throws Exception {
        Method method = options.getClass().getMethod(optionName);
        return method.invoke(options);
    }

    public static void setValue(PipelineOptions options, String optionName, Object value) throws Exception {
        Method method = options.getClass().getMethod(optionName, value.getClass());
        method.invoke(options, value);
    }

    public static HashMap<String, String> toKeyVal(String[] args) {
        HashMap<String, String> params = new HashMap<>();
        for (String arg : args) {
            String[] splitUsingSymbol = arg.split("=");
            String key = splitUsingSymbol[0].substring(2);
            String value = splitUsingSymbol.length > 1 ? splitUsingSymbol[1] : "";
            params.put(key, value);
        }
        return params;
    }
}
