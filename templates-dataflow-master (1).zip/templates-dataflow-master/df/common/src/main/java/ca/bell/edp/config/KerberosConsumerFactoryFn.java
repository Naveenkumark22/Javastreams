package ca.bell.edp.config;

import ca.bell.edp.constants.CommonConstants;
import ca.bell.edp.utils.CloudStorageHelper;
import ca.bell.edp.utils.SecretManagerHelper;
import com.google.api.client.util.Preconditions;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Map;
import java.util.Objects;
import org.apache.beam.sdk.transforms.SerializableFunction;
import org.apache.kafka.clients.CommonClientConfigs;
import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.common.config.SaslConfigs;
import org.apache.kafka.common.config.SslConfigs;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Kafka Consumer Factory class to build {@link KafkaConsumer} object and uses Kerberos authentication to read messages.
 */
public class KerberosConsumerFactoryFn implements SerializableFunction<Map<String, Object>, Consumer<byte[], byte[]>> {
    private static final Logger LOG = LoggerFactory.getLogger(KerberosConsumerFactoryFn.class);

    private final String kafkaGroup;
    private final String autoOffsetReset;
    private final String bootstrapServers;
    private final String principal;
    private final String securityProtocol;
    private final String projectIdForSecret;
    private final String keytabNameSecretId;
    private final String keytabNameSecretVersion;
    private final String trustStorePasswordSecretId;
    private final String trustStoreNameInGcs;
    private final String certificateStoreBucket;
    private final String trustStorePasswordSecretVersion;
    private final String krb5ConfNameSecretId;
    private final String krb5ConfNameSecretVersion;

    public KerberosConsumerFactoryFn(
            String kafkaGroup,
            String autoOffsetReset,
            String principal,
            String securityProtocol,
            String bootstrapServers,
            String projectIdForSecret,
            String keytabNameSecretId,
            String keytabNameSecretVersion,
            String trustStorePasswordSecretId,
            String trustStoreNameInGcs,
            String certificateStoreBucket,
            String trustStorePasswordSecretVersion,
            String krb5ConfNameSecretId,
            String krb5ConfNameSecretVersion) {
        this.kafkaGroup = kafkaGroup;
        this.autoOffsetReset = autoOffsetReset;
        this.principal = principal;
        this.securityProtocol = securityProtocol;
        this.bootstrapServers = bootstrapServers;
        this.projectIdForSecret = projectIdForSecret;
        this.keytabNameSecretId = keytabNameSecretId;
        this.keytabNameSecretVersion = keytabNameSecretVersion;
        this.trustStorePasswordSecretId = trustStorePasswordSecretId;
        this.trustStoreNameInGcs = trustStoreNameInGcs;
        this.certificateStoreBucket = certificateStoreBucket;
        this.trustStorePasswordSecretVersion = trustStorePasswordSecretVersion;
        this.krb5ConfNameSecretId = krb5ConfNameSecretId;
        this.krb5ConfNameSecretVersion = krb5ConfNameSecretVersion;
    }

    /**
     * Note:
     * Doc:https://github.com/apache/beam/blob/master/sdks/java/io/kafka/src/main/java/org/apache/beam/sdk/io/kafka/KafkaIO.java
     * 1. 'ENABLE_AUTO_COMMIT_CONFIG' Enable committing record offset. Consumer
     * offset stored in Kafka when
     * {@code ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG = true};
     * 2. Since we set 'commitOffsetsInFinalize()' in
     * {@code ca.bell.edp.jobs.KafkaToCloudStorage}, 'ENABLE_AUTO_COMMIT_CONFIG' is
     * set to false. As per the documentation, we can use only one of them.
     */
    public Consumer<byte[], byte[]> apply(Map<String, Object> config) {
        Path truststore, keytab, krb5Conf;

        // Deleting if there are any empty files to be safe side and download fresh files
        for (File file : Objects.requireNonNull(new File(CommonConstants.LOCAL_TEMP_FOLDER).listFiles())) {
            if (file.isFile() && file.length() == 0) {
                file.delete();
            }
        }

        keytab = Paths.get(CommonConstants.LOCAL_TEMP_FOLDER + this.keytabNameSecretId);
        if (Files.notExists(keytab)) {
            // Download the file only if the file doesn't exist.
            try {
                keytab = SecretManagerHelper.getValueAsFile(
                        projectIdForSecret,
                        keytabNameSecretId,
                        keytabNameSecretVersion,
                        CommonConstants.LOCAL_TEMP_FOLDER);
                System.setProperty(
                        CommonConstants.KEYTAB_LOCATION_CONFIG,
                        keytab.toAbsolutePath().toString());
            } catch (IOException e) {
                LOG.error(
                        "Unable to download keytab secret file: \n{}",
                        org.codehaus.plexus.util.ExceptionUtils.getFullStackTrace(e));
            }
        }

        Preconditions.checkNotNull(keytab);
        Preconditions.checkNotNull(principal);

        if (System.getProperty(SslConfigs.SSL_TRUSTSTORE_PASSWORD_CONFIG) == null) {
            try {
                String truststorePassword = SecretManagerHelper.getValue(
                        projectIdForSecret, trustStorePasswordSecretId, trustStorePasswordSecretVersion);
                System.setProperty(SslConfigs.SSL_TRUSTSTORE_PASSWORD_CONFIG, truststorePassword.trim());
            } catch (IOException e) {
                LOG.error(
                        "Unable to download truststore password: \n{}",
                        org.codehaus.plexus.util.ExceptionUtils.getFullStackTrace(e));
            }
        }

        truststore = Paths.get(CommonConstants.LOCAL_TEMP_FOLDER + trustStoreNameInGcs);
        if (Files.notExists(truststore)) {
            // Download the file only if the file doesn't exist.
            try {
                truststore = CloudStorageHelper.getFile(
                        projectIdForSecret,
                        certificateStoreBucket,
                        trustStoreNameInGcs,
                        CommonConstants.LOCAL_TEMP_FOLDER);
                System.setProperty(
                        SslConfigs.SSL_TRUSTSTORE_LOCATION_CONFIG,
                        truststore.toAbsolutePath().toString());
            } catch (IOException e) {
                LOG.error(
                        "Unable to download truststore file: \n{}",
                        org.codehaus.plexus.util.ExceptionUtils.getFullStackTrace(e));
            }
        }

        krb5Conf = Paths.get(CommonConstants.LOCAL_TEMP_FOLDER + krb5ConfNameSecretId);
        if (Files.notExists(krb5Conf)) {
            // Download the file only if the file doesn't exist.
            try {
                krb5Conf = SecretManagerHelper.getValueAsFile(
                        projectIdForSecret,
                        krb5ConfNameSecretId,
                        krb5ConfNameSecretVersion,
                        CommonConstants.LOCAL_TEMP_FOLDER);
                System.setProperty(
                        CommonConstants.JAVA_SECURITY_KRB5_CONFIG_KEY,
                        krb5Conf.toAbsolutePath().toString());
            } catch (IOException e) {
                LOG.error(
                        "Unable to download KRB5Conf file: \n{}",
                        org.codehaus.plexus.util.ExceptionUtils.getFullStackTrace(e));
            }
        }
        // Enable below line if you need to see the KRB5 auth logs.
        // System.setProperty(CommonConstants.SUN_SECURITY_KRB5_CONFIG_DEBUG_KEY, "true");

        // Updating JAAS values like keytab, principal
        String JAAS_LOGIN_CONFIG = String.format(
                CommonConstants.SASL_JAAS_CONFIG,
                System.getProperty(CommonConstants.KEYTAB_LOCATION_CONFIG),
                principal);

        // Options coming from Constants
        config.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, CommonConstants.ENABLE_AUTO_COMMIT_CONFIG);
        config.put(SaslConfigs.SASL_MECHANISM, CommonConstants.SASL_MECHANISM);
        config.put(SaslConfigs.SASL_KERBEROS_SERVICE_NAME, CommonConstants.SASL_KERBEROS_SERVICE_NAME_VALUE);
        // Options coming from System Property
        config.put(
                SslConfigs.SSL_TRUSTSTORE_LOCATION_CONFIG,
                System.getProperty(SslConfigs.SSL_TRUSTSTORE_LOCATION_CONFIG));
        config.put(
                SslConfigs.SSL_TRUSTSTORE_PASSWORD_CONFIG,
                System.getProperty(SslConfigs.SSL_TRUSTSTORE_PASSWORD_CONFIG));
        // Options coming from pipeline options
        config.put(CommonClientConfigs.SECURITY_PROTOCOL_CONFIG, securityProtocol);
        config.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, autoOffsetReset);
        config.put(CommonClientConfigs.GROUP_ID_CONFIG, kafkaGroup);
        config.put(CommonClientConfigs.BOOTSTRAP_SERVERS_CONFIG, bootstrapServers);
        // Options coming from System Property & pipeline options
        config.put(SaslConfigs.SASL_JAAS_CONFIG, JAAS_LOGIN_CONFIG);

        KafkaConsumer<byte[], byte[]> kafkaConsumerInstance = null;

        try {
            kafkaConsumerInstance = new KafkaConsumer<byte[], byte[]>(config);
        } catch (Exception e) {
            LOG.error(
                    "Error Creating Kerberos Kafka Consumer Instance: \n{}",
                    org.codehaus.plexus.util.ExceptionUtils.getFullStackTrace(e));
        }

        return kafkaConsumerInstance;
    }
}
