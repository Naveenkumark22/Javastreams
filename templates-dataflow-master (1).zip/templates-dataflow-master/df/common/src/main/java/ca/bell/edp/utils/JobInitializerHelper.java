package ca.bell.edp.utils;

import ca.bell.edp.constants.CommonConstants;
import java.io.File;
import java.nio.file.Path;
import java.util.Objects;
import org.apache.beam.sdk.options.PipelineOptions;
import org.apache.kafka.common.config.SslConfigs;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Helper class
 * to pre download the required certificates and credentials
 * which helps to build {@link org.apache.kafka.clients.consumer.KafkaConsumer},
 * this initializeOptions would be invoked in JvmInitializer -> beforeProcessing method
 * which auto triggered before every worker instantiation and load the required data.
 */
public class JobInitializerHelper {
    private static final Logger LOG = LoggerFactory.getLogger(JobInitializerHelper.class);

    public static void initializeOptions(PipelineOptions options) {
        LOG.debug("Initializing worker and loading job options.");
        try {
            String truststorePassword, keystorePassword;
            Path krb5Conf, truststore, keytab, keystore;
            // Deleting if there are any empty files to be safe side and download fresh
            // files
            for (File file : Objects.requireNonNull(new File(CommonConstants.LOCAL_TEMP_FOLDER).listFiles())) {
                if (file.isFile() && file.length() == 0) {
                    file.delete();
                }
            }

            truststorePassword = SecretManagerHelper.getValue(
                    (String) PipelineOptionsHelper.getValue(options, "getProjectIdForSecret"),
                    (String) PipelineOptionsHelper.getValue(options, "getTrustStorePasswordSecretId"),
                    (String) PipelineOptionsHelper.getValue(options, "getTrustStorePasswordSecretVersion"));
            truststore = CloudStorageHelper.getFile(
                    (String) PipelineOptionsHelper.getValue(options, "getProjectIdForTruststore"),
                    (String) PipelineOptionsHelper.getValue(options, "getCertificateStoreBucket"),
                    (String) PipelineOptionsHelper.getValue(options, "getTrustStoreNameInGcs"),
                    CommonConstants.LOCAL_TEMP_FOLDER);

            // Merging truststore certificate with default SSL certificates
            SslSocketFactoryHelper.addTrustStoreFrom(
                    "gs://"
                            + (String) PipelineOptionsHelper.getValue(options, "getCertificateStoreBucket") + "/"
                            + (String) PipelineOptionsHelper.getValue(options, "getTrustStoreNameInGcs"),
                    truststorePassword.trim().toCharArray());

            if (PipelineOptionsHelper.getValue(options, "getAuthorizationType")
                    .toString()
                    .equalsIgnoreCase("mtls")) {
                // MTLS auth flow to connect to Kafka cluster
                keystore = SecretManagerHelper.getValueAsFile(
                        (String) PipelineOptionsHelper.getValue(options, "getProjectIdForSecret"),
                        (String) PipelineOptionsHelper.getValue(options, "getKeystoreSecretId"),
                        (String) PipelineOptionsHelper.getValue(options, "getKeystoreSecretVersion"),
                        CommonConstants.LOCAL_TEMP_FOLDER);
                keystorePassword = SecretManagerHelper.getValue(
                        (String) PipelineOptionsHelper.getValue(options, "getProjectIdForSecret"),
                        (String) PipelineOptionsHelper.getValue(options, "getKeystorePasswordSecretId"),
                        (String) PipelineOptionsHelper.getValue(options, "getKeystorePasswordSecretVersion"));
                System.setProperty(
                        SslConfigs.SSL_KEYSTORE_LOCATION_CONFIG,
                        keystore.toAbsolutePath().toString());
                System.setProperty(SslConfigs.SSL_KEYSTORE_PASSWORD_CONFIG, keystorePassword.trim());
            } else if (PipelineOptionsHelper.getValue(options, "getAuthorizationType")
                    .toString()
                    .equalsIgnoreCase("kerberos")) {
                krb5Conf = SecretManagerHelper.getValueAsFile(
                        (String) PipelineOptionsHelper.getValue(options, "getProjectIdForSecret"),
                        (String) PipelineOptionsHelper.getValue(options, "getKrb5ConfNameSecretId"),
                        (String) PipelineOptionsHelper.getValue(options, "getKrb5ConfNameSecretVersion"),
                        CommonConstants.LOCAL_TEMP_FOLDER);
                keytab = SecretManagerHelper.getValueAsFile(
                        (String) PipelineOptionsHelper.getValue(options, "getProjectIdForSecret"),
                        (String) PipelineOptionsHelper.getValue(options, "getKeytabNameSecretId"),
                        (String) PipelineOptionsHelper.getValue(options, "getKeytabNameSecretVersion"),
                        CommonConstants.LOCAL_TEMP_FOLDER);
                System.setProperty(
                        CommonConstants.KEYTAB_LOCATION_CONFIG,
                        keytab.toAbsolutePath().toString());
                System.setProperty(
                        CommonConstants.JAVA_SECURITY_KRB5_CONFIG_KEY,
                        krb5Conf.toAbsolutePath().toString());
            }

            // Setting this with custom key, to reuse later while building Kafka Consumer
            System.setProperty(
                    SslConfigs.SSL_TRUSTSTORE_LOCATION_CONFIG,
                    truststore.toAbsolutePath().toString());
            System.setProperty(
                    CommonConstants.JAVAX_NET_SSL_TRUSTSTORE,
                    truststore.toAbsolutePath().toString());
            System.setProperty(SslConfigs.SSL_TRUSTSTORE_PASSWORD_CONFIG, truststorePassword.trim());
            System.setProperty(CommonConstants.JAVAX_NET_SSL_TRUSTSTORE_PASSWORD, truststorePassword.trim());

            // Enable below line if you need to see the KRB5 auth logs.
            // System.setProperty(CommonConstants.SUN_SECURITY_KRB5_CONFIG_DEBUG_KEY, "true");
            // System.setProperty(CommonConstants.JAVAX_NET_DEBUG_KEY, "ssl");
        } catch (Exception ex) {
            LOG.error(
                    "Unable to initialize/load job options: \n{}",
                    org.codehaus.plexus.util.ExceptionUtils.getFullStackTrace(ex));
        }
    }
}
