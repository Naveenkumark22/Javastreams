package ca.bell.edp.utils;

import com.google.cloud.storage.BlobId;
import com.google.cloud.storage.Storage;
import com.google.cloud.storage.StorageOptions;
import java.io.IOException;
import java.io.InputStream;
import java.io.PipedInputStream;
import java.io.PipedOutputStream;
import java.security.*;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.function.Function;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.X509TrustManager;
import nl.altindag.ssl.SSLFactory;
import nl.altindag.ssl.util.ProviderUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Class used to merge Custom truststore keys with default SSLContext keys.
 * Re instantiating HttpsURLConnection SSLSocketFactory with merged certificates
 * To avoid the certification issue while accessing Schema Registry
 */
public class SslSocketFactoryHelper {
    private static final Logger LOG = LoggerFactory.getLogger(SslSocketFactoryHelper.class);
    private static final String TRUST_MANAGER_FACTORY_ALGORITHM = "PKIX";
    private static final String SSL_CONTEXT_PROTOCOL = "TLSv1.2";
    private static final String KEYSTORE_TYPE = "PKCS12";
    private static final String CERTIFICATE_FACTORY_TYPE = "X.509";

    private static X509Certificate[] getAcceptedIssuers(boolean useDefaultTrustManager)
            throws KeyStoreException, NoSuchAlgorithmException {
        if (useDefaultTrustManager) {
            TrustManagerFactory trustManagerFactory = TrustManagerFactory.getInstance(TRUST_MANAGER_FACTORY_ALGORITHM);
            trustManagerFactory.init((KeyStore) null); // this will give us the default trust manager used by java
            return Arrays.stream(trustManagerFactory.getTrustManagers())
                    .filter(trustManager -> trustManager instanceof X509TrustManager)
                    .map(X509TrustManager.class::cast)
                    .map(X509TrustManager::getAcceptedIssuers)
                    .flatMap(Arrays::stream)
                    .toArray(X509Certificate[]::new);
        } else {
            return new X509Certificate[] {};
        }
    }

    private static KeyStore mergeTrustStoreIntoDefault(KeyStore trustStore) {
        try {
            KeyStore defaultStore = createTrustStore(true);
            for (Enumeration<String> aliasEnumeration = trustStore.aliases(); aliasEnumeration.hasMoreElements(); ) {
                String alias = aliasEnumeration.nextElement();
                Certificate cert = trustStore.getCertificate(alias);
                if (cert != null) { // assuming aliases don't overlap
                    defaultStore.setCertificateEntry(alias, cert);
                }
            }
            return defaultStore;
        } catch (KeyStoreException e) {
            throw new RuntimeException("unable to merge the provided keystore with the default one");
        }
    }

    private static KeyStore createTrustStore(boolean withDefaultTrustManagers) {
        try {
            KeyStore keyStore = KeyStore.getInstance(KEYSTORE_TYPE);
            keyStore.load(null, null);
            X509Certificate[] acceptedIssuers = getAcceptedIssuers(withDefaultTrustManagers);
            for (int i = 0; i < acceptedIssuers.length; i += 1) {
                keyStore.setCertificateEntry(Integer.toString(i), acceptedIssuers[i]);
            }
            LOG.info("created a keystore with {} already accepted issuer(s)", acceptedIssuers.length);
            return keyStore;
        } catch (NoSuchAlgorithmException | KeyStoreException | IOException | CertificateException e) {
            throw new RuntimeException("unable to create a trust store", e);
        }
    }

    private static KeyStore createTrustStoreWithCert(Certificate certificate, boolean withDefaultTrustManagers) {
        try {
            KeyStore keyStore = createTrustStore(withDefaultTrustManagers);
            keyStore.setCertificateEntry("downloaded", certificate);
            LOG.info("created a truststore and added the provided cert {}", certificate);
            return keyStore;
        } catch (KeyStoreException e) {
            throw new RuntimeException("unable add a certificate to a keystore", e);
        }
    }

    private static <T> T downloadFromCloudStorage(String location, Function<InputStream, T> streamHandler) {
        Storage storage = StorageOptions.getDefaultInstance().getService();
        try (PipedInputStream inputStream = new PipedInputStream();
                PipedOutputStream outputStream = new PipedOutputStream(inputStream)) {
            Thread downloadThread = new Thread(
                    () -> storage.downloadTo(BlobId.fromGsUtilUri(location), outputStream), "download thread");
            downloadThread.start();
            T t = streamHandler.apply(inputStream);
            downloadThread.join();
            return t;
        } catch (InterruptedException | IOException e) {
            throw new RuntimeException(String.format("download from %s failed", location));
        }
    }

    private static Certificate downloadCaCert(String caCertLocation) {
        LOG.info("downloading cacert from {}", caCertLocation);
        return downloadFromCloudStorage(caCertLocation, inputStream -> {
            try {
                return CertificateFactory.getInstance(CERTIFICATE_FACTORY_TYPE).generateCertificate(inputStream);
            } catch (CertificateException e) {
                throw new RuntimeException("error while generating a certificate", e);
            }
        });
    }

    private static KeyStore downloadTrustStore(String trustStoreLocation, char[] password) {
        LOG.info("downloading truststore from {}", trustStoreLocation);
        return downloadFromCloudStorage(trustStoreLocation, inputStream -> {
            try {
                KeyStore keyStore = KeyStore.getInstance(KEYSTORE_TYPE);
                keyStore.load(inputStream, password);
                return keyStore;
            } catch (KeyStoreException | IOException | NoSuchAlgorithmException | CertificateException e) {
                throw new RuntimeException("error when loading a keystore", e);
            }
        });
    }

    private static void initDefaultSslContext(KeyStore trustStore) {
        LOG.info("initializing a new default SSLContext with a truststore");
        try {
            TrustManagerFactory trustManagerFactory = TrustManagerFactory.getInstance(TRUST_MANAGER_FACTORY_ALGORITHM);
            trustManagerFactory.init(trustStore);
            SSLContext newDefaultSslContext = SSLContext.getInstance(SSL_CONTEXT_PROTOCOL);
            newDefaultSslContext.init(null, trustManagerFactory.getTrustManagers(), null);
            SSLContext.setDefault(newDefaultSslContext);
            HttpsURLConnection.setDefaultSSLSocketFactory(newDefaultSslContext.getSocketFactory());
        } catch (NoSuchAlgorithmException | KeyStoreException | KeyManagementException e) {
            throw new RuntimeException("error while initializing default SSLContext", e);
        }
    }

    public static void addCertFrom(String caCertLocation) {
        Certificate certificate = downloadCaCert(caCertLocation);
        KeyStore trustStore = createTrustStoreWithCert(certificate, true);
        initDefaultSslContext(trustStore);
    }

    public static void addTrustStoreFrom(String trustStoreLocation, char[] password) {
        KeyStore downloadedTrustStore = downloadTrustStore(trustStoreLocation, password);
        KeyStore mergedTrustStore = mergeTrustStoreIntoDefault(downloadedTrustStore);
        initDefaultSslContext(mergedTrustStore);
    }

    public static void addTrustStoreWithHakky(String trustStoreLocation, char[] password) {
        KeyStore downloadedTrustStore = downloadTrustStore(trustStoreLocation, password);
        SSLFactory sslFactory = SSLFactory.builder()
                .withDefaultTrustMaterial()
                .withSystemTrustMaterial()
                .withTrustMaterial(downloadedTrustStore)
                .build();
        Provider provider = ProviderUtils.create(sslFactory);
        Security.insertProviderAt(provider, 1);
        SSLContext.setDefault(sslFactory.getSslContext());
        HttpsURLConnection.setDefaultSSLSocketFactory(sslFactory.getSslContext().getSocketFactory());
    }
}
