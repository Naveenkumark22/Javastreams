package ca.bell.edp.options;

import org.apache.beam.sdk.options.*;

/**
 * Interface which holds all GCS related pipeline parameters values
 * this interface can be extended based on a need
 */
public interface GcsOptions extends PipelineOptions {
    @Description("Fixed window duration, in minutes")
    @Default.Integer(5)
    Integer getWindowSize();

    void setWindowSize(Integer value);

    @Description("Output GCS path to save files")
    @Validation.Required
    String getOutputPath();

    void setOutputPath(String value);

    @Description("Output file extension type to store in cloud storage")
    @Validation.Required
    String getOutputFileExtension();

    void setOutputFileExtension(String value);
}
