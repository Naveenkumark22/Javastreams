package ca.bell.edp.constants;

/**
 * Common constants class which holds all useful constants values,
 * these constants can be used in multiple template flows
 * A new common value can be added here and used across the flows
 */
public class CommonConstants {
    public static final String ENABLE_AUTO_COMMIT_CONFIG = "false";
    public static final String LOCAL_TEMP_FOLDER = "/tmp/";
    public static final String KEYTAB_LOCATION_CONFIG = "keytab.conf";
    public static final String BASIC_AUTH_TYPE = "USER_INFO";
    public static final String KAFKA_APPLICATION_ID = "application.id";
    public static final String SUN_SECURITY_KRB5_CONFIG_DEBUG_KEY = "sun.security.krb5.debug";
    public static final String JAVAX_NET_DEBUG_KEY = "javax.net.debug";
    public static final String JAVA_SECURITY_AUTH_LOGIN_CONFIG_KEY = "java.security.auth.login.config";
    public static final String JAVA_SECURITY_KRB5_CONFIG_KEY = "java.security.krb5.conf";
    public static final String JAVAX_NET_SSL_TRUSTSTORE = "javax.net.ssl.trustStore";
    public static final String JAVAX_NET_SSL_TRUSTSTORE_PASSWORD = "javax.net.ssl.trustStorePassword";
    public static final String JAVAX_NET_SSL_TRUSTSTORE_TYPE = "javax.net.ssl.trustStoreType";
    public static final String JAVAX_NET_SSL_KEYSTORE = "javax.net.ssl.keyStore";
    public static final String JAVAX_NET_SSL_KEYSTORE_PASSWORD = "javax.net.ssl.keyStorePassword";
    public static final String JAVAX_NET_SSL_KEYSTORE_TYPE = "javax.net.ssl.keyStoreType";
    public static final String SASL_MECHANISM = "GSSAPI";
    public static final String SASL_KERBEROS_SERVICE_NAME_VALUE = "kafka";
    public static final String SASL_JAAS_CONFIG =
            "com.sun.security.auth.module.Krb5LoginModule required useKeyTab=true doNotPrompt=true debug=false storeKey=true serviceName=\"kafka\" keyTab=\"%s\" principal=\"%s\";";
    public static final String INGESTED_ON = "ingested_on";
    public static final String GCS_FILE_EXTENSION = ".json";
}
