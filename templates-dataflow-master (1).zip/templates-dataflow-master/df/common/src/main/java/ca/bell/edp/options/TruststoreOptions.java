package ca.bell.edp.options;

import org.apache.beam.sdk.options.*;

/**
 * Interface which holds all truststore related pipeline parameters values
 * this interface can be extended based on a need in the authentication flows
 */
public interface TruststoreOptions extends PipelineOptions {
    @Description("GCS truststore file project id")
    String getProjectIdForTruststore();

    void setProjectIdForTruststore(String value);

    @Description("GCS Bucket Name where truststore config present.")
    String getCertificateStoreBucket();

    void setCertificateStoreBucket(String value);

    @Description("File name of the trust store configuration in Cloud Storage")
    String getTrustStoreNameInGcs();

    void setTrustStoreNameInGcs(String value);

    @Description("Secret id of the trust store password configuration from secret manager")
    String getTrustStorePasswordSecretId();

    void setTrustStorePasswordSecretId(String value);

    @Description("Secret version of the trust store password configuration from secret manager")
    String getTrustStorePasswordSecretVersion();

    void setTrustStorePasswordSecretVersion(String value);
}
