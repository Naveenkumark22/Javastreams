package ca.bell.edp.utils;

import com.google.cloud.secretmanager.v1.AccessSecretVersionResponse;
import com.google.cloud.secretmanager.v1.SecretManagerServiceClient;
import com.google.cloud.secretmanager.v1.SecretVersionName;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Helper class to get value from Secret Manager
 */
public class SecretManagerHelper {
    private static final Logger LOG = LoggerFactory.getLogger(SecretManagerHelper.class);

    /**
     * Fetches the value corresponding to the secret id and writes as file into /tmp folder of a file system
     *
     * @param projectId     project id of the Secret Manager resource
     * @param secretId      secret id of the values being looked into
     * @param secretVersion version of the secret being looked into
     * @param tempPath      local file system temp folder path, where all the required files get downloaded
     * @return File name with the complete path
     * @throws IOException - Exception received fetching the secret value and/or creating the File
     */
    public static Path getValueAsFile(String projectId, String secretId, String secretVersion, String tempPath)
            throws IOException {
        Path tmpFile = Paths.get(tempPath + secretId);

        if (Files.notExists(tmpFile)) {
            try (SecretManagerServiceClient client = SecretManagerServiceClient.create()) {
                Files.createFile(tmpFile);

                SecretVersionName secretVersionName = SecretVersionName.of(projectId, secretId, secretVersion);
                AccessSecretVersionResponse response = client.accessSecretVersion(secretVersionName);

                FileOutputStream etcFileOutputStream = new FileOutputStream(tmpFile.toFile());
                etcFileOutputStream.write(response.getPayload().getData().toByteArray());
                etcFileOutputStream.close();
            } catch (Exception e) {
                LOG.error("NBD-ERR201 - Unable to download secret file: ", e);
            }
        }
        return tmpFile;
    }

    /**
     * Fetches the value corresponding to the secret id.
     *
     * @param projectId     project id of the Secret Manager resource
     * @param secretId      secret id of the values being looked into
     * @param secretVersion version of the secret being looked into
     * @return Secret value in String format
     * @throws IOException - Exception received fetching the secret value
     */
    public static String getValue(String projectId, String secretId, String secretVersion) throws IOException {
        AccessSecretVersionResponse response = null;
        try (SecretManagerServiceClient client = SecretManagerServiceClient.create()) {
            SecretVersionName secretVersionName = SecretVersionName.of(projectId, secretId, secretVersion);
            response = client.accessSecretVersion(secretVersionName);
        } catch (Exception e) {
            LOG.error("NBD-ERR201 - Unable to download secret value: ", e);
        }
        assert response != null;
        return response.getPayload().getData().toStringUtf8();
    }
}
