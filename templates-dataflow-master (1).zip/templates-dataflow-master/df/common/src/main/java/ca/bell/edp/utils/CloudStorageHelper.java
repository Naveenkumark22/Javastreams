package ca.bell.edp.utils;

import com.google.cloud.storage.Blob;
import com.google.cloud.storage.Storage;
import com.google.cloud.storage.StorageOptions;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

/**
 * Helper class to download a file from GCS
 */
public class CloudStorageHelper {
    /**
     * Downloads the given file path of GCS and writes as file into /tmp folder of a file system.
     * bucketName - bucket name
     * fileName - file name
     *
     * @param projectId  project id of the GCS bucket
     * @param bucketName GCS bucket of the resource being looked into
     * @param fileName   file name to be created with the content
     * @param tempPath   local file system temp folder path, where all the required files get downloaded
     * @return File name with the complete path
     * @throws IOException - Exception received creating the File
     */
    public static Path getFile(String projectId, String bucketName, String fileName, String tempPath)
            throws IOException {
        Path tmpFile = Paths.get(tempPath + fileName);
        if (Files.notExists(tmpFile)) {
            Files.createFile(tmpFile);
            Storage storage =
                    StorageOptions.newBuilder().setProjectId(projectId).build().getService();
            Blob blob = storage.get(bucketName, fileName);
            FileOutputStream etcFileOutputStream = new FileOutputStream(tmpFile.toFile());
            etcFileOutputStream.write(blob.getContent());
            etcFileOutputStream.close();
        }
        return tmpFile;
    }
}
