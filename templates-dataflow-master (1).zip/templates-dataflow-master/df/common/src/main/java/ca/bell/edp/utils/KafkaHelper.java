package ca.bell.edp.utils;

import ca.bell.edp.config.KafkaSerializationBuilder;
import org.apache.beam.sdk.options.PipelineOptions;
import org.apache.maven.shared.utils.StringUtils;

public class KafkaHelper {
    /**
     * Method to build a Kafka serializable function
     *
     * @param options pipeline options
     * @return Instance of the Kafka serialization builder
     */
    public static KafkaSerializationBuilder serializationBuilder(PipelineOptions options) throws Exception {
        KafkaSerializationBuilder kafkaSerializationBuilder = null;
        if (StringUtils.isEmpty(
                PipelineOptionsHelper.getValue(options, "getAuthorizationType").toString())) {
            kafkaSerializationBuilder = (new KafkaSerializationBuilder())
                    .setAutoOffsetReset((String) PipelineOptionsHelper.getValue(options, "getAutoOffsetReset"))
                    .setBootstrapServers((String) PipelineOptionsHelper.getValue(options, "getBootstrapServers"))
                    .setKafkaGroup((String) PipelineOptionsHelper.getValue(options, "getKafkaGroup"))
                    .setAuthorizationType("");
        } else if (PipelineOptionsHelper.getValue(options, "getAuthorizationType")
                .toString()
                .equalsIgnoreCase("kerberos")) {
            kafkaSerializationBuilder = (new KafkaSerializationBuilder())
                    .setAutoOffsetReset((String) PipelineOptionsHelper.getValue(options, "getAutoOffsetReset"))
                    .setBootstrapServers((String) PipelineOptionsHelper.getValue(options, "getBootstrapServers"))
                    .setKafkaGroup((String) PipelineOptionsHelper.getValue(options, "getKafkaGroup"))
                    .setSecurityProtocol((String) PipelineOptionsHelper.getValue(options, "getSecurityProtocol"))
                    .setPrincipal((String) PipelineOptionsHelper.getValue(options, "getPrincipal"))
                    .setProjectIdForSecret((String) PipelineOptionsHelper.getValue(options, "getProjectIdForSecret"))
                    .setKeytabNameSecretId((String) PipelineOptionsHelper.getValue(options, "getKeytabNameSecretId"))
                    .setKeytabNameSecretVersion(
                            (String) PipelineOptionsHelper.getValue(options, "getKeytabNameSecretVersion"))
                    .setCertificateStoreBucket(
                            (String) PipelineOptionsHelper.getValue(options, "getCertificateStoreBucket"))
                    .setTrustStoreNameInGcs((String) PipelineOptionsHelper.getValue(options, "getTrustStoreNameInGcs"))
                    .setTrustStorePasswordSecretId(
                            (String) PipelineOptionsHelper.getValue(options, "getTrustStorePasswordSecretId"))
                    .setTrustStorePasswordSecretVersion(
                            (String) PipelineOptionsHelper.getValue(options, "getTrustStorePasswordSecretVersion"))
                    .setKrb5ConfNameSecretId(
                            (String) PipelineOptionsHelper.getValue(options, "getKrb5ConfNameSecretId"))
                    .setKrb5ConfNameSecretVersion(
                            (String) PipelineOptionsHelper.getValue(options, "getKrb5ConfNameSecretVersion"))
                    .setAuthorizationType((String) PipelineOptionsHelper.getValue(options, "getAuthorizationType"));
        } else if (PipelineOptionsHelper.getValue(options, "getAuthorizationType")
                .toString()
                .equalsIgnoreCase("mtls")) {
            kafkaSerializationBuilder = (new KafkaSerializationBuilder())
                    .setKafkaGroup((String) PipelineOptionsHelper.getValue(options, "getKafkaGroup"))
                    .setAutoOffsetReset((String) PipelineOptionsHelper.getValue(options, "getAutoOffsetReset"))
                    .setSecurityProtocol((String) PipelineOptionsHelper.getValue(options, "getSecurityProtocol"))
                    .setBootstrapServers((String) PipelineOptionsHelper.getValue(options, "getBootstrapServers"))
                    .setProjectIdForSecret((String) PipelineOptionsHelper.getValue(options, "getProjectIdForSecret"))
                    .setCertificateStoreBucket(
                            (String) PipelineOptionsHelper.getValue(options, "getCertificateStoreBucket"))
                    .setTrustStoreNameInGcs((String) PipelineOptionsHelper.getValue(options, "getTrustStoreNameInGcs"))
                    .setTrustStorePasswordSecretId(
                            (String) PipelineOptionsHelper.getValue(options, "getTrustStorePasswordSecretId"))
                    .setTrustStorePasswordSecretVersion(
                            (String) PipelineOptionsHelper.getValue(options, "getTrustStorePasswordSecretVersion"))
                    .setAuthorizationType((String) PipelineOptionsHelper.getValue(options, "getAuthorizationType"))
                    .setKeystoreSecretId((String) PipelineOptionsHelper.getValue(options, "getKeystoreSecretId"))
                    .setKeystoreSecretVersion(
                            (String) PipelineOptionsHelper.getValue(options, "getKeystoreSecretVersion"))
                    .setKeystorePasswordSecretId(
                            (String) PipelineOptionsHelper.getValue(options, "getKeystorePasswordSecretId"))
                    .setKeystorePasswordSecretVersion(
                            (String) PipelineOptionsHelper.getValue(options, "getKeystorePasswordSecretVersion"));
        }
        return kafkaSerializationBuilder;
    }
}
