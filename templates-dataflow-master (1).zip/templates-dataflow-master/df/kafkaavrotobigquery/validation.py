#!/usr/bin/env python3
#
# *kafkaavrotobigquery* job validation script
#
# This script checks that a given configuration for a deployment of a kafkaavrotobigquery job is valid.
# It is released next to the flex-template.json and used by common modules. It will be run on
# terraform plan by common-modules and will validate that the given terraform for a job is valid.
# It does not fail-fast and will return all the misconfigurations it finds. Common modules fails the
# terraform plan and displays all the misconfigurations in the error message.
#
# see common modules for more information:
# https://gitlab.int.bell.ca/nbd/dataplatform/gcp/datapltf-modules/datapltf-common-modules#dataflow-job-validation

import json
import sys
from typing import cast, Dict, Iterable, Literal, TextIO, Tuple, TypedDict


def main(stdin: TextIO, stdout: TextIO) -> int:
    job_parameters, flex_template = parse_script_input(stdin)
    errors = validate(job_parameters, flex_template)
    output_errors(errors, stdout)
    return 0


JsonEncodedString = str

FlexTemplate = Dict


class KafkaAvroToBigqueryParameters(TypedDict, total=False):
    """
    The kafvaavrotobigquery job parameters. These are what we put in custom_parameters = {}
    in terraform that get passed to the dataflow job.
    """

    # Kafka topics with comma separator as string to pull results from
    inputTopic: str
    kafkaGroup: str
    errorRecordWindowSizeGcs: str
    # autoOffsetReset
    # Kafka Bootstrap Server list
    bootstrapServers: str
    # Project name of your Secret Manager to fetch Kafka config details
    projectIdForSecret: str
    # Project name of your GCS Truststore file
    projectIdForTruststore: str
    # Kerberos username, used to get active ticket.
    principal: str
    # Security Protocol used by Kafka
    securityProtocol: str
    # certificateStoreBucket
    certificateStoreBucket: str
    # Secret id of keytab configuration in Secret Manager
    keytabNameSecretId: str
    # Secret version of keytab configuration in Secret Manager
    keytabNameSecretVersion: str
    # Secret id of krb5 configuration in Secret Manager
    krb5ConfNameSecretId: str
    # Secret version of krb5 configuration in Secret Manager
    krb5ConfNameSecretVersion: str
    # Secret id of TrustStore Password in Secret Manager
    trustStorePasswordSecretId: str
    # Secret version of TrustStore Password in Secret Manager
    trustStorePasswordSecretVersion: str
    # TrustStore Name file name in GCS
    trustStoreNameInGcs: str
    # SchemaRegistry Url
    schemaRegistryUrl: str
    # schemaRegistry User
    schemaRegistryUser: str
    # SchemaRegistry Password Secret Id
    schemaRegistryPasswordSecretId: str
    # Secret version of TrustStore Password in Secret Manager
    schemaRegistryPasswordSecretVersion: str
    # Big Query project name
    bqProjectName: str
    # Big Query dataset name
    bqDataSetName: str
    # Big Query window size
    outputWindowSizeBq: str
    bqFailedOutputDirectory: str
    unprocessedRecordsOutputDirectory: str
    # JSON config string used to add partition and clustering to result data
    partitionConfigJson: str


# The partitionConfigJson job parameter is a JSON encoded string consisting of a JSON object whose
# keys are table names and values are a config object.

# The decoded partitionConfigJson
PartitionConfig = Dict[str, "PartitionConfigValue"]


class PartitionConfigValue(TypedDict, total=False):
    """The table config object in partitionConfigJson."""

    cluster_attribute: str
    cluster_column: str
    cluster_value_type: str
    partition_attribute: str
    partition_column: str
    partition_days_subtract: str
    partition_delimiter: str
    partition_format: str
    partition_value_type: str


PartitionConfigValueKeys = Literal[
    "cluster_attribute",
    "cluster_column",
    "cluster_value_type",
    "partition_attribute",
    "partition_column",
    "partition_days_subtract",
    "partition_delimiter",
    "partition_format",
    "partition_value_type",
]


def validate(
    job_parameters: KafkaAvroToBigqueryParameters, flex_template: FlexTemplate
) -> Iterable[str]:
    """Entrypoint to validate job_parameters and flex_templates."""
    if "partitionConfigJson" not in job_parameters:
        yield "'partitionConfigJson' parameter not found in job parameters."
    else:
        for error in validate_partition_config_json_str(
            job_parameters["partitionConfigJson"]
        ):
            yield f"partitionConfigJson{error}"


def validate_partition_config_json_str(config_str: JsonEncodedString) -> Iterable[str]:
    """Validate the partitionConfigJson attribute which is a JSON encoded string."""
    try:
        yield from validate_partition_config_json(json.loads(config_str))
    except json.JSONDecodeError as err:
        yield f" contains invalid JSON: {str(err)}"


def validate_partition_config_json(config: PartitionConfig) -> Iterable[str]:
    for table_name, config_value in config.items():
        for error in validate_partition_config_value(config_value):
            yield f".{table_name}: {error}"


def validate_partition_config_value(value: PartitionConfigValue) -> Iterable[str]:
    """Validates the given PartitionConfigValue."""
    if "partition_attribute" not in value:
        yield "Missing required 'partition_attribute' attribute."
    else:
        if "partition_delimiter" in value:
            yield from validate_partition_config_value_delimiter(value)

    if "partition_value_type" not in value:
        yield 'Missing required \'partition_value_type\' which should be either "string" or "epoch" value.'
    else:
        if value["partition_value_type"] not in ["string", "epoch"]:
            yield 'Incorrect value for \'partition_value_type\'. It must be either "string" or "epoch" value.'
        else:
            if value["partition_value_type"] == "epoch" and "partition_format" in value:
                yield "When 'partition_value_type' is \"epoch\" then 'partition_format' should not be present."
    if "cluster_column" in value:
        if "cluster_value_type" not in value:
            yield "When using 'cluster_column' then 'cluster_value_type' must be \"epoch\", it's currently missing."
        elif value["cluster_value_type"] != "epoch":
            yield f"If using 'cluster_column' then 'cluster_value_type' must be \"epoch\", it's currently set to \"{value['cluster_value_type']}\"."
    if "cluster_attribute" in value:
        if "." not in value["cluster_attribute"]:
            yield f"'cluster_attribute' should be a dot separated path to an nested attribute, it's currently \"{value['cluster_attribute']}\""


def validate_partition_config_value_delimiter(
    value: PartitionConfigValue,
) -> Iterable[str]:
    """Validate rules that deal with the partition delimiter."""

    def _validate_delimiter(
        value: PartitionConfigValue, attribute: PartitionConfigValueKeys
    ) -> Iterable[str]:
        delimiter = value["partition_delimiter"]
        parts = value[attribute].split(delimiter)
        if len(parts) != 2:
            yield (
                "When 'partition_delimiter' is provided it must partition exactly two columns within "
                f"'{attribute}'. In other words, 'partition_delimiter' with value \"{delimiter}\", can appear only once in "
                f"'{attribute}' with value \"{value[attribute]}\"."
            )
        elif "" in parts:
            yield (
                f"'{attribute}' should have two values separated by {delimiter}, "
                f"the given value of {value[attribute]} has an empty value {parts!r}."
            )

    partition_delimiter = value["partition_delimiter"]
    if partition_delimiter not in value["partition_attribute"]:
        yield "When 'partition_delimiter' is provided it must be present in 'partition_attribute'."
    else:
        yield from _validate_delimiter(value, "partition_attribute")
    if "partition_format" not in value:
        yield "When 'partition_delimiter' is provided 'partition_format' attribute is required."
    else:
        if partition_delimiter not in value["partition_format"]:
            yield "When 'partition_delimiter' is provided it must be present in 'partition_format'."
        else:
            yield from _validate_delimiter(value, "partition_format")


class ScriptInput(TypedDict):
    """The input that will be fed on STDIN to the validation script we received on our STDIN."""

    job_parameters: JsonEncodedString
    flex_template: JsonEncodedString


def parse_script_input(
    stdin: TextIO,
) -> Tuple[KafkaAvroToBigqueryParameters, FlexTemplate]:
    """
    We get our validation inputs from the caller through STDIN.
    Parse the STDIN input stream and return the given job_parameters and flex_template.
    """
    script_input = cast(ScriptInput, json.load(stdin))
    if "flex_template" not in script_input:
        raise RuntimeError("'flex_template' attribute is required.")
    if "job_parameters" not in script_input:
        raise RuntimeError("'job_parameters' attribute is required.")
    return json.loads(script_input["job_parameters"]), json.loads(
        script_input["flex_template"]
    )


def output_errors(errors: Iterable[str], stdout: TextIO = sys.stdout):
    """
    The caller receives the errors through STDOUT as a JSON string.
    Format the errors in the way upstream is expecting and print to STDOUT.
    """
    json.dump(list(errors), stdout)


if __name__ == "__main__":
    try:
        sys.exit(main(sys.stdin, sys.stdout))
    except Exception:
        import traceback

        print(
            f"An unexpected error occured.\n{traceback.format_exc()}", file=sys.stderr
        )
        sys.exit(1)
