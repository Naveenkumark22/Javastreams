package ca.bell.edp.transformers;

import ca.bell.edp.utils.GenericRecordCoder;
import com.google.api.services.bigquery.model.TableRow;
import java.io.Serializable;
import java.util.List;
import java.util.Objects;
import org.apache.avro.Schema;
import org.apache.avro.SchemaBuilder;
import org.apache.avro.generic.GenericData;
import org.apache.avro.generic.GenericRecord;
import org.apache.beam.runners.dataflow.TestDataflowPipelineOptions;
import org.apache.beam.sdk.coders.StringUtf8Coder;
import org.apache.beam.sdk.extensions.avro.schemas.utils.AvroUtils;
import org.apache.beam.sdk.io.gcp.bigquery.BigQueryUtils;
import org.apache.beam.sdk.io.kafka.KafkaRecord;
import org.apache.beam.sdk.io.kafka.KafkaRecordCoder;
import org.apache.beam.sdk.io.kafka.KafkaTimestampType;
import org.apache.beam.sdk.options.PipelineOptionsFactory;
import org.apache.beam.sdk.testing.PAssert;
import org.apache.beam.sdk.testing.TestPipeline;
import org.apache.beam.sdk.testing.ValidatesRunner;
import org.apache.beam.sdk.transforms.Create;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.transforms.ParDo;
import org.apache.beam.sdk.transforms.SerializableFunction;
import org.apache.beam.sdk.values.*;
import org.junit.After;
import org.junit.ClassRule;
import org.junit.Rule;
import org.junit.experimental.categories.Category;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.rules.ExpectedException;
import org.junit.rules.TemporaryFolder;

public class DeriveColumnsParDoTest implements Serializable {
    public TestDataflowPipelineOptions options;

    @Rule
    public transient ExpectedException thrown = ExpectedException.none();

    @Rule
    public final transient TestPipeline pipeline = TestPipeline.create().enableAbandonedNodeEnforcement(false);

    @ClassRule
    public static TemporaryFolder tempFolder = new TemporaryFolder();

    @BeforeEach
    public void setUp() throws Exception {
        options = PipelineOptionsFactory.as(TestDataflowPipelineOptions.class);
    }

    @After
    public void cleanupTestEnvironment() {
        tempFolder.delete();
    }

    private TableRow getTableRecordWithNestedValues() {
        Schema avroSchema = SchemaBuilder.record("wnc_arc_que_ratedusages")
                .namespace("wnc_arc_que_ratedusages")
                .fields()
                .requiredString("startTime")
                .name("getSubscriberBalancesResponse")
                .type()
                .record("account")
                .fields()
                .name("account")
                .type()
                .record("nextBillCycleDate")
                .fields()
                .requiredString("nextBillCycleDate")
                .endRecord()
                .noDefault()
                .endRecord()
                .noDefault()
                .name("usageDetails")
                .type()
                .record("startTime")
                .fields()
                .requiredString("startTime")
                .endRecord()
                .noDefault()
                .endRecord();

        Schema nestedRecordSchema = SchemaBuilder.record("nextBillCycleDate")
                .fields()
                .requiredString("nextBillCycleDate")
                .endRecord();

        Schema accountRecordSchema = SchemaBuilder.record("account")
                .fields()
                .name("account")
                .type()
                .record("nextBillCycleDate")
                .fields()
                .requiredString("nextBillCycleDate")
                .endRecord()
                .noDefault()
                .endRecord();

        Schema startTimeRecordSchema = SchemaBuilder.record("startTime")
                .fields()
                .requiredString("startTime")
                .endRecord();

        GenericRecord nestedRecord = new GenericData.Record(nestedRecordSchema);
        nestedRecord.put("nextBillCycleDate", "1709302324000"); // Friday, March 1, 2024 2:12:04 PM

        GenericRecord accountRecord = new GenericData.Record(accountRecordSchema);
        accountRecord.put("account", nestedRecord);

        GenericRecord startTimeRecord = new GenericData.Record(startTimeRecordSchema);
        startTimeRecord.put("startTime", "1705509035256");

        GenericRecord record = new GenericData.Record(avroSchema);
        record.put("startTime", "1711733572082"); // Friday, Mar 29, 2024 17:32:52.082 GMT
        record.put("usageDetails", startTimeRecord);
        record.put("getSubscriberBalancesResponse", accountRecord);

        SerializableFunction<GenericRecord, Row> conversionFn =
                AvroUtils.getGenericRecordToRowFunction(AvroUtils.toBeamSchema(avroSchema));
        return BigQueryUtils.toTableRow(Objects.requireNonNull(conversionFn.apply(record)));
    }

    @Test
    @Category(ValidatesRunner.class)
    public void testRequiredRecords() {
        String jsonConfig =
                "{\"wnc_arc_que_ratedusages\":{\"partition_column\":\"month_skey\",\"partition_attribute\":\"getSubscriberBalancesResponse.account.nextBillCycleDate\",\"partition_value_type\":\"epoch\",\"partition_days_subtract\":\"1\",\"cluster_column\":\"reporting_date\",\"cluster_attribute\":\"usageDetails.startTime\",\"cluster_value_type\":\"epoch\"},\"wnc_odf_que_rated_ccrs_deduplicated\":{\"partition_column\":\"month_skey\",\"partition_attribute\":\"getSubscriberBalancesResponse.account.nextBillCycleDate\",\"partition_value_type\":\"epoch\",\"partition_days_subtract\":\"1\",\"cluster_column\":\"reporting_date\",\"cluster_attribute\":\"usageDetails.startTime\",\"cluster_value_type\":\"epoch\"},\"wnc_arc_que_billed_rated_usages\":{\"partition_column\":\"month_skey\",\"partition_attribute\":\"getSubscriberBalancesResponse.account.nextBillCycleDate\",\"partition_value_type\":\"epoch\",\"partition_days_subtract\":\"1\"},\"wnc_odf_que_billed_intake_reject_records\":{\"partition_column\":\"month_skey\",\"partition_attribute\":\"getSubscriberBalancesResponse.account.nextBillCycleDate\",\"partition_value_type\":\"epoch\",\"partition_days_subtract\":\"1\"},\"wnc_odf_que_intake_skipped_records\":{\"partition_column\":\"month_skey\",\"partition_attribute\":\"getSubscriberBalancesResponse.account.nextBillCycleDate\",\"partition_value_type\":\"epoch\",\"partition_days_subtract\":\"1\",\"cluster_column\":\"reporting_date\",\"cluster_attribute\":\"usageDetails.startTime\",\"cluster_value_type\":\"epoch\"},\"wnc_odf_que_intake_reject_records\":{\"partition_column\":\"month_skey\",\"partition_attribute\":\"getSubscriberBalancesResponse.account.nextBillCycleDate\",\"partition_value_type\":\"epoch\",\"partition_days_subtract\":\"1\",\"cluster_column\":\"reporting_date\",\"cluster_attribute\":\"usageDetails.startTime\",\"cluster_value_type\":\"epoch\"},\"wnc_odf_que_intake_late_usage_records\":{\"partition_column\":\"month_skey\",\"partition_attribute\":\"getSubscriberBalancesResponse.account.nextBillCycleDate\",\"partition_value_type\":\"epoch\",\"partition_days_subtract\":\"1\",\"cluster_column\":\"reporting_date\",\"cluster_attribute\":\"usageDetails.startTime\",\"cluster_value_type\":\"epoch\"},\"wnc_cgf_que_unrated_mapping\":{\"partition_column\":\"dt_skey\",\"partition_attribute\":\"startTime\",\"partition_value_type\":\"string\",\"partition_format\":\"yyyyMMddHHmmss\"},\"wnc_cgf_que_unrated_mapping_free_filter\":{\"partition_column\":\"dt_skey\",\"partition_attribute\":\"startTime\",\"partition_value_type\":\"string\",\"partition_format\":\"yyyyMMddHHmmss\"},\"wnc_cgf_que_unrated_mapping_error_records\":{\"partition_column\":\"dt_skey\",\"partition_attribute\":\"startTime\",\"partition_value_type\":\"epoch\"},\"wnc_odf_que_daily_summary\":{\"partition_column\":\"month_skey\",\"partition_attribute\":\"cycle_run_year|cycle_run_month\",\"partition_value_type\":\"string\",\"partition_format\":\"yyyy|MM\",\"partition_delimiter\":\"|\"},\"wnc_odf_que_au_aggr_record_type_1\":{\"partition_column\":\"month_skey\",\"partition_attribute\":\"cycle_run_year|cycle_run_month\",\"partition_value_type\":\"string\",\"partition_format\":\"yyyy|MM\",\"partition_delimiter\":\"|\"},\"wnc_odf_que_unique_reject_summary\":{\"partition_column\":\"month_skey\",\"partition_attribute\":\"cycle_run_year|cycle_run_month\",\"partition_value_type\":\"string\",\"partition_format\":\"yyyy|MM\",\"partition_delimiter\":\"|\"},\"wnc_odf_que_billed_daily_summary\":{\"partition_column\":\"month_skey\",\"partition_attribute\":\"cycle_run_year|cycle_run_month\",\"partition_value_type\":\"string\",\"partition_format\":\"yyyy|MM\",\"partition_delimiter\":\"|\"},\"wnc_odf_que_billed_unique_reject_summary\":{\"partition_column\":\"month_skey\",\"partition_attribute\":\"cycle_run_year|cycle_run_month\",\"partition_value_type\":\"string\",\"partition_format\":\"yyyy|MM\",\"partition_delimiter\":\"|\"},\"wnc_odf_que_billed_au_aggr_record_type_1\":{\"partition_column\":\"month_skey\",\"partition_attribute\":\"cycle_run_year|cycle_run_month\",\"partition_value_type\":\"string\",\"partition_format\":\"yyyy|MM\",\"partition_delimiter\":\"|\"},\"wnc_odf_que_partial_daily_summary\":{\"partition_column\":\"month_skey\",\"partition_attribute\":\"cycle_run_year|cycle_run_month\",\"partition_value_type\":\"string\",\"partition_format\":\"yyyy|MM\",\"partition_delimiter\":\"|\"},\"wnc_arc_que_billed_rerate_triggers\":{\"partition_column\":\"month_skey\",\"partition_attribute\":\"ImplBilledRerateReqRestOutput.baseOutput.arcCustDetail.cycleYear|ImplBilledRerateReqRestOutput.baseOutput.arcCustDetail.cycleMonth\",\"partition_value_type\":\"string\",\"partition_format\":\"yyyy|MM\",\"partition_delimiter\":\"|\"}}";

        options.as(TestOptions.class).setPartitionConfigJson(jsonConfig);

        Schema avroSchema = SchemaBuilder.record("testRecord")
                .namespace("test_table")
                .fields()
                .requiredInt("id")
                .requiredString("name")
                .requiredBoolean("isEngineer")
                .requiredDouble("height")
                .requiredDouble("weight")
                .requiredLong("salary")
                .requiredString("startTime")
                .name("address")
                .type()
                .record("addressRecord")
                .fields()
                .requiredString("street")
                .requiredString("city")
                .endRecord()
                .noDefault()
                .endRecord();

        Schema nestedRecordSchema = SchemaBuilder.record("addressRecord")
                .fields()
                .requiredString("street")
                .requiredString("city")
                .endRecord();

        GenericRecord nestedRecord = new GenericData.Record(nestedRecordSchema);
        nestedRecord.put("street", "123 Fake St.");
        nestedRecord.put("city", "Austin, TX");

        GenericRecord record = new GenericData.Record(avroSchema);
        record.put("id", 1);
        record.put("name", "Ryan McDowell");
        record.put("isEngineer", true);
        record.put("height", 72.44);
        record.put("weight", 233.35);
        record.put("salary", 1L);
        record.put("startTime", "1711733572082"); // Friday, Mar 29, 2024 17:32:52.082 GMT
        record.put("address", nestedRecord);

        KafkaRecord<String, GenericRecord> krecord = new KafkaRecord<String, GenericRecord>(
                "wnc_cgf_que_unrated_mapping_error_records",
                0,
                0,
                0,
                KafkaTimestampType.CREATE_TIME,
                null,
                "wnc_cgf_que_unrated_mapping_error_records",
                record);

        pipeline.getCoderRegistry().registerCoderForClass(GenericRecord.class, GenericRecordCoder.of());

        // Create an input PCollection.
        PCollection<KV<String, TableRow>> trecord = pipeline.apply(
                        "Load data",
                        Create.of(List.of(krecord))
                                .withCoder(KafkaRecordCoder.of(StringUtf8Coder.of(), GenericRecordCoder.of())))
                .apply("Kr to Kv", ParDo.of(new KRToKVParDo()));

        // Create an input PCollection.
        PCollectionTuple kVRecords = trecord.apply(
                "Bucketing Records",
                ParDo.of(new DeriveColumnsParDo(jsonConfig))
                        .withOutputTags(
                                DeriveColumnsParDo.REQUIRED_RECORDS_OUT,
                                TupleTagList.of(DeriveColumnsParDo.UNPROCESSED_RECORDS_OUT)));

        PCollection<KV<String, TableRow>> required_table_rows = kVRecords.get(DeriveColumnsParDo.REQUIRED_RECORDS_OUT);
        PCollection<String> pkrecord =
                required_table_rows.apply("Get Key", ParDo.of(new DoFn<KV<String, TableRow>, String>() {
                    @ProcessElement
                    public void processElement(@Element KV<String, TableRow> element, OutputReceiver<String> out) {
                        out.output(element.getKey());
                    }
                }));
        PCollection<String> vrecord =
                required_table_rows.apply("Get Value", ParDo.of(new DoFn<KV<String, TableRow>, String>() {
                    @ProcessElement
                    public void processElement(@Element KV<String, TableRow> element, OutputReceiver<String> out) {
                        out.output(String.valueOf(
                                Objects.requireNonNull(element.getValue()).get("dt_skey")));
                    }
                }));

        // Assert on the key results.
        PAssert.that(pkrecord).containsInAnyOrder("wnc_cgf_que_unrated_mapping_error_records");

        // Assert on the value results.
        PAssert.that(vrecord).containsInAnyOrder("2024-03-01");

        // Run the pipeline.
        pipeline.run().waitUntilFinish();
    }

    @Test
    @Category(ValidatesRunner.class)
    public void testUnprocessedRecords() {
        String jsonConfig =
                "{\"wnc_arc_que_ratedusages\":{\"partition_column\":\"month_skey\",\"partition_attribute\":\"getSubscriberBalancesResponse.account.nextBillCycleDate\",\"partition_value_type\":\"epoch\",\"partition_days_subtract\":\"1\",\"cluster_column\":\"reporting_date\",\"cluster_attribute\":\"usageDetails.startTime\",\"cluster_value_type\":\"epoch\"},\"wnc_odf_que_rated_ccrs_deduplicated\":{\"partition_column\":\"month_skey\",\"partition_attribute\":\"getSubscriberBalancesResponse.account.nextBillCycleDate\",\"partition_value_type\":\"epoch\",\"partition_days_subtract\":\"1\",\"cluster_column\":\"reporting_date\",\"cluster_attribute\":\"usageDetails.startTime\",\"cluster_value_type\":\"epoch\"},\"wnc_arc_que_billed_rated_usages\":{\"partition_column\":\"month_skey\",\"partition_attribute\":\"getSubscriberBalancesResponse.account.nextBillCycleDate\",\"partition_value_type\":\"epoch\",\"partition_days_subtract\":\"1\"},\"wnc_odf_que_billed_intake_reject_records\":{\"partition_column\":\"month_skey\",\"partition_attribute\":\"getSubscriberBalancesResponse.account.nextBillCycleDate\",\"partition_value_type\":\"epoch\",\"partition_days_subtract\":\"1\"},\"wnc_odf_que_intake_skipped_records\":{\"partition_column\":\"month_skey\",\"partition_attribute\":\"getSubscriberBalancesResponse.account.nextBillCycleDate\",\"partition_value_type\":\"epoch\",\"partition_days_subtract\":\"1\",\"cluster_column\":\"reporting_date\",\"cluster_attribute\":\"usageDetails.startTime\",\"cluster_value_type\":\"epoch\"},\"wnc_odf_que_intake_reject_records\":{\"partition_column\":\"month_skey\",\"partition_attribute\":\"getSubscriberBalancesResponse.account.nextBillCycleDate\",\"partition_value_type\":\"epoch\",\"partition_days_subtract\":\"1\",\"cluster_column\":\"reporting_date\",\"cluster_attribute\":\"usageDetails.startTime\",\"cluster_value_type\":\"epoch\"},\"wnc_odf_que_intake_late_usage_records\":{\"partition_column\":\"month_skey\",\"partition_attribute\":\"getSubscriberBalancesResponse.account.nextBillCycleDate\",\"partition_value_type\":\"epoch\",\"partition_days_subtract\":\"1\",\"cluster_column\":\"reporting_date\",\"cluster_attribute\":\"usageDetails.startTime\",\"cluster_value_type\":\"epoch\"},\"wnc_cgf_que_unrated_mapping\":{\"partition_column\":\"dt_skey\",\"partition_attribute\":\"startTime\",\"partition_value_type\":\"string\",\"partition_format\":\"yyyyMMddHHmmss\"},\"wnc_cgf_que_unrated_mapping_free_filter\":{\"partition_column\":\"dt_skey\",\"partition_attribute\":\"startTime\",\"partition_value_type\":\"string\",\"partition_format\":\"yyyyMMddHHmmss\"},\"wnc_cgf_que_unrated_mapping_error_records\":{\"partition_column\":\"dt_skey\",\"partition_attribute\":\"startTime\",\"partition_value_type\":\"string\",\"partition_format\":\"yyyyMMddHHmmss\"},\"wnc_odf_que_daily_summary\":{\"partition_column\":\"month_skey\",\"partition_attribute\":\"cycle_run_year|cycle_run_month\",\"partition_value_type\":\"string\",\"partition_format\":\"yyyy|MM\",\"partition_delimiter\":\"|\"},\"wnc_odf_que_au_aggr_record_type_1\":{\"partition_column\":\"month_skey\",\"partition_attribute\":\"cycle_run_year|cycle_run_month\",\"partition_value_type\":\"string\",\"partition_format\":\"yyyy|MM\",\"partition_delimiter\":\"|\"},\"wnc_odf_que_unique_reject_summary\":{\"partition_column\":\"month_skey\",\"partition_attribute\":\"cycle_run_year|cycle_run_month\",\"partition_value_type\":\"string\",\"partition_format\":\"yyyy|MM\",\"partition_delimiter\":\"|\"},\"wnc_odf_que_billed_daily_summary\":{\"partition_column\":\"month_skey\",\"partition_attribute\":\"cycle_run_year|cycle_run_month\",\"partition_value_type\":\"string\",\"partition_format\":\"yyyy|MM\",\"partition_delimiter\":\"|\"},\"wnc_odf_que_billed_unique_reject_summary\":{\"partition_column\":\"month_skey\",\"partition_attribute\":\"cycle_run_year|cycle_run_month\",\"partition_value_type\":\"string\",\"partition_format\":\"yyyy|MM\",\"partition_delimiter\":\"|\"},\"wnc_odf_que_billed_au_aggr_record_type_1\":{\"partition_column\":\"month_skey\",\"partition_attribute\":\"cycle_run_year|cycle_run_month\",\"partition_value_type\":\"string\",\"partition_format\":\"yyyy|MM\",\"partition_delimiter\":\"|\"},\"wnc_odf_que_partial_daily_summary\":{\"partition_column\":\"month_skey\",\"partition_attribute\":\"cycle_run_year|cycle_run_month\",\"partition_value_type\":\"string\",\"partition_format\":\"yyyy|MM\",\"partition_delimiter\":\"|\"},\"wnc_arc_que_billed_rerate_triggers\":{\"partition_column\":\"month_skey\",\"partition_attribute\":\"ImplBilledRerateReqRestOutput.baseOutput.arcCustDetail.cycleYear|ImplBilledRerateReqRestOutput.baseOutput.arcCustDetail.cycleMonth\",\"partition_value_type\":\"string\",\"partition_format\":\"yyyy|MM\",\"partition_delimiter\":\"|\"}}";

        options.as(TestOptions.class).setPartitionConfigJson(jsonConfig);

        Schema avroSchema = SchemaBuilder.record("testRecord")
                .namespace("test_table")
                .fields()
                .requiredInt("id")
                .requiredString("name")
                .requiredBoolean("isEngineer")
                .requiredDouble("height")
                .requiredDouble("weight")
                .requiredLong("salary")
                .requiredString("startTime")
                .name("address")
                .type()
                .record("addressRecord")
                .fields()
                .requiredString("street")
                .requiredString("city")
                .endRecord()
                .noDefault()
                .endRecord();

        Schema nestedRecordSchema = SchemaBuilder.record("addressRecord")
                .fields()
                .requiredString("street")
                .requiredString("city")
                .endRecord();

        GenericRecord nestedRecord = new GenericData.Record(nestedRecordSchema);
        nestedRecord.put("street", "123 Fake St.");
        nestedRecord.put("city", "Austin, TX");

        GenericRecord record = new GenericData.Record(avroSchema);
        record.put("id", 1);
        record.put("name", "Ryan McDowell");
        record.put("isEngineer", true);
        record.put("height", 72.44);
        record.put("weight", 233.35);
        record.put("salary", 1L);
        record.put("startTime", "1711733572"); // Friday, Mar 29, 2024 17:32:52 GMT
        record.put("address", nestedRecord);

        KafkaRecord<String, GenericRecord> krecord = new KafkaRecord<String, GenericRecord>(
                "wnc_cgf_que_unrated_mapping_error_records",
                0,
                0,
                0,
                KafkaTimestampType.CREATE_TIME,
                null,
                "wnc_cgf_que_unrated_mapping_error_records",
                record);

        pipeline.getCoderRegistry().registerCoderForClass(GenericRecord.class, GenericRecordCoder.of());

        // Create an input PCollection.
        PCollection<KV<String, TableRow>> trecord = pipeline.apply(
                        "Unprocessed Load data",
                        Create.of(List.of(krecord))
                                .withCoder(KafkaRecordCoder.of(StringUtf8Coder.of(), GenericRecordCoder.of())))
                .apply("Unprocessed Kr to Kv", ParDo.of(new KRToKVParDo()));

        // Create an input PCollection.
        PCollectionTuple kVRecords = trecord.apply(
                "Unprocessed Bucketing Records",
                ParDo.of(new DeriveColumnsParDo(jsonConfig))
                        .withOutputTags(
                                DeriveColumnsParDo.REQUIRED_RECORDS_OUT,
                                TupleTagList.of(DeriveColumnsParDo.UNPROCESSED_RECORDS_OUT)));

        PCollection<KV<String, TableRow>> not_required_table_rows =
                kVRecords.get(DeriveColumnsParDo.UNPROCESSED_RECORDS_OUT);
        PCollection<String> upkrecord =
                not_required_table_rows.apply("Unprocessed Get Key", ParDo.of(new DoFn<KV<String, TableRow>, String>() {
                    @ProcessElement
                    public void processElement(@Element KV<String, TableRow> element, OutputReceiver<String> out) {
                        out.output(element.getKey());
                    }
                }));
        PCollection<String> uvrecord = not_required_table_rows.apply(
                "Unprocessed Get Value", ParDo.of(new DoFn<KV<String, TableRow>, String>() {
                    @ProcessElement
                    public void processElement(@Element KV<String, TableRow> element, OutputReceiver<String> out) {
                        out.output(String.valueOf(
                                Objects.requireNonNull(element.getValue()).get("startTime")));
                    }
                }));

        PCollection<String> nullrecord = not_required_table_rows.apply(
                "Unprocessed Data without custom column", ParDo.of(new DoFn<KV<String, TableRow>, String>() {
                    @ProcessElement
                    public void processElement(@Element KV<String, TableRow> element, OutputReceiver<String> out) {
                        out.output(String.valueOf(
                                Objects.requireNonNull(element.getValue()).containsKey("dt_skey")));
                    }
                }));

        // Assert on the key results.
        PAssert.that(upkrecord).containsInAnyOrder("wnc_cgf_que_unrated_mapping_error_records");

        // Assert on the value results.
        PAssert.that(uvrecord).containsInAnyOrder("1711733572");
        PAssert.that(nullrecord).containsInAnyOrder(List.of("false"));

        // Run the pipeline.
        pipeline.run().waitUntilFinish();
    }
}
