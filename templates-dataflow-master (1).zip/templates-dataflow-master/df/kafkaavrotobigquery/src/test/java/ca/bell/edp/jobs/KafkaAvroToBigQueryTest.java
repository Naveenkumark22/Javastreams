package ca.bell.edp.jobs;

import java.io.Serializable;
import org.apache.beam.runners.dataflow.TestDataflowPipelineOptions;
import org.apache.beam.sdk.options.PipelineOptionsFactory;
import org.apache.beam.sdk.testing.TestPipeline;
import org.junit.After;
import org.junit.Assert;
import org.junit.ClassRule;
import org.junit.Rule;
import org.junit.jupiter.api.Test;
import org.junit.rules.ExpectedException;
import org.junit.rules.TemporaryFolder;

public class KafkaAvroToBigQueryTest implements Serializable {
    public TestDataflowPipelineOptions options;

    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @Rule
    public TestPipeline pipeline = TestPipeline.create();

    @ClassRule
    public static TemporaryFolder tempFolder = new TemporaryFolder();

    @org.junit.Before
    public void setUp() throws Exception {
        options = PipelineOptionsFactory.as(TestDataflowPipelineOptions.class);
    }

    @After
    public void cleanupTestEnvironment() {
        tempFolder.delete();
    }

    @Test
    public void testRunner() {
        Assert.assertEquals(
                "class org.apache.beam.runners.direct.DirectRunner",
                pipeline.getOptions().getRunner().toString());
    }
}
