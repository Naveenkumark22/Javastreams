package ca.bell.edp.transformers;

import ca.bell.edp.utils.EdrDate;
import ca.bell.edp.utils.GenericRecordCoder;
import com.google.api.services.bigquery.model.TableRow;
import java.util.List;
import java.util.Objects;
import org.apache.avro.Schema;
import org.apache.avro.SchemaBuilder;
import org.apache.avro.generic.GenericData;
import org.apache.avro.generic.GenericRecord;
import org.apache.beam.runners.dataflow.TestDataflowPipelineOptions;
import org.apache.beam.sdk.coders.StringUtf8Coder;
import org.apache.beam.sdk.io.kafka.KafkaRecord;
import org.apache.beam.sdk.io.kafka.KafkaRecordCoder;
import org.apache.beam.sdk.io.kafka.KafkaTimestampType;
import org.apache.beam.sdk.options.PipelineOptionsFactory;
import org.apache.beam.sdk.testing.PAssert;
import org.apache.beam.sdk.testing.TestPipeline;
import org.apache.beam.sdk.testing.ValidatesRunner;
import org.apache.beam.sdk.transforms.Create;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.transforms.ParDo;
import org.apache.beam.sdk.values.KV;
import org.apache.beam.sdk.values.PCollection;
import org.apache.beam.sdk.values.PCollectionTuple;
import org.apache.beam.sdk.values.TupleTagList;
import org.junit.After;
import org.junit.ClassRule;
import org.junit.Rule;
import org.junit.experimental.categories.Category;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.rules.ExpectedException;
import org.junit.rules.TemporaryFolder;

public class TableRowToKVParDoTest {
    public TestDataflowPipelineOptions options;

    @Rule
    public transient ExpectedException thrown = ExpectedException.none();

    @Rule
    public final transient TestPipeline pipeline = TestPipeline.create().enableAbandonedNodeEnforcement(false);

    @ClassRule
    public static TemporaryFolder tempFolder = new TemporaryFolder();

    @BeforeEach
    public void setUp() throws Exception {
        options = PipelineOptionsFactory.as(TestDataflowPipelineOptions.class);
    }

    @After
    public void cleanupTestEnvironment() {
        tempFolder.delete();
    }

    static class KeyEle extends DoFn<KV<String, String>, String> {
        private static final long serialVersionUID = 0;

        @ProcessElement
        public void processElement(ProcessContext c) {
            c.output(Objects.requireNonNull(c.element()).getKey());
        }
    }

    static class KeyVal extends DoFn<KV<String, String>, String> {
        private static final long serialVersionUID = 0;

        @ProcessElement
        public void processElement(ProcessContext c) {
            c.output(Objects.requireNonNull(c.element()).getValue());
        }
    }

    static class GetTableRow extends DoFn<KV<String, TableRow>, TableRow> {
        private static final long serialVersionUID = 0;

        @ProcessElement
        public void processElement(ProcessContext c) {
            c.output(Objects.requireNonNull(c.element()).getValue());
        }
    }

    @Test
    @Category(ValidatesRunner.class)
    public void testRequiredRecords() {
        // Create an input PCollection.
        String jsonConfig =
                "{\"wnc_arc_que_ratedusages\":{\"partition_column\":\"month_skey\",\"partition_attribute\":\"getSubscriberBalancesResponse.account.nextBillCycleDate\",\"partition_value_type\":\"epoch\",\"partition_days_subtract\":\"1\",\"cluster_column\":\"reporting_date\",\"cluster_attribute\":\"usageDetails.startTime\",\"cluster_value_type\":\"epoch\"},\"wnc_odf_que_rated_ccrs_deduplicated\":{\"partition_column\":\"month_skey\",\"partition_attribute\":\"getSubscriberBalancesResponse.account.nextBillCycleDate\",\"partition_value_type\":\"epoch\",\"partition_days_subtract\":\"1\",\"cluster_column\":\"reporting_date\",\"cluster_attribute\":\"usageDetails.startTime\",\"cluster_value_type\":\"epoch\"},\"wnc_arc_que_billed_rated_usages\":{\"partition_column\":\"month_skey\",\"partition_attribute\":\"getSubscriberBalancesResponse.account.nextBillCycleDate\",\"partition_value_type\":\"epoch\",\"partition_days_subtract\":\"1\"},\"wnc_odf_que_billed_intake_reject_records\":{\"partition_column\":\"month_skey\",\"partition_attribute\":\"getSubscriberBalancesResponse.account.nextBillCycleDate\",\"partition_value_type\":\"epoch\",\"partition_days_subtract\":\"1\"},\"wnc_odf_que_intake_skipped_records\":{\"partition_column\":\"month_skey\",\"partition_attribute\":\"getSubscriberBalancesResponse.account.nextBillCycleDate\",\"partition_value_type\":\"epoch\",\"partition_days_subtract\":\"1\",\"cluster_column\":\"reporting_date\",\"cluster_attribute\":\"usageDetails.startTime\",\"cluster_value_type\":\"epoch\"},\"wnc_odf_que_intake_reject_records\":{\"partition_column\":\"month_skey\",\"partition_attribute\":\"getSubscriberBalancesResponse.account.nextBillCycleDate\",\"partition_value_type\":\"epoch\",\"partition_days_subtract\":\"1\",\"cluster_column\":\"reporting_date\",\"cluster_attribute\":\"usageDetails.startTime\",\"cluster_value_type\":\"epoch\"},\"wnc_odf_que_intake_late_usage_records\":{\"partition_column\":\"month_skey\",\"partition_attribute\":\"getSubscriberBalancesResponse.account.nextBillCycleDate\",\"partition_value_type\":\"epoch\",\"partition_days_subtract\":\"1\",\"cluster_column\":\"reporting_date\",\"cluster_attribute\":\"usageDetails.startTime\",\"cluster_value_type\":\"epoch\"},\"wnc_cgf_que_unrated_mapping\":{\"partition_column\":\"dt_skey\",\"partition_attribute\":\"startTime\",\"partition_value_type\":\"string\",\"partition_format\":\"yyyyMMddHHmmss\"},\"wnc_cgf_que_unrated_mapping_free_filter\":{\"partition_column\":\"dt_skey\",\"partition_attribute\":\"startTime\",\"partition_value_type\":\"string\",\"partition_format\":\"yyyyMMddHHmmss\"},\"wnc_cgf_que_unrated_mapping_error_records\":{\"partition_column\":\"dt_skey\",\"partition_attribute\":\"startTime\",\"partition_value_type\":\"epoch\"},\"wnc_odf_que_daily_summary\":{\"partition_column\":\"month_skey\",\"partition_attribute\":\"cycle_run_year|cycle_run_month\",\"partition_value_type\":\"string\",\"partition_format\":\"yyyy|MM\",\"partition_delimiter\":\"|\"},\"wnc_odf_que_au_aggr_record_type_1\":{\"partition_column\":\"month_skey\",\"partition_attribute\":\"cycle_run_year|cycle_run_month\",\"partition_value_type\":\"string\",\"partition_format\":\"yyyy|MM\",\"partition_delimiter\":\"|\"},\"wnc_odf_que_unique_reject_summary\":{\"partition_column\":\"month_skey\",\"partition_attribute\":\"cycle_run_year|cycle_run_month\",\"partition_value_type\":\"string\",\"partition_format\":\"yyyy|MM\",\"partition_delimiter\":\"|\"},\"wnc_odf_que_billed_daily_summary\":{\"partition_column\":\"month_skey\",\"partition_attribute\":\"cycle_run_year|cycle_run_month\",\"partition_value_type\":\"string\",\"partition_format\":\"yyyy|MM\",\"partition_delimiter\":\"|\"},\"wnc_odf_que_billed_unique_reject_summary\":{\"partition_column\":\"month_skey\",\"partition_attribute\":\"cycle_run_year|cycle_run_month\",\"partition_value_type\":\"string\",\"partition_format\":\"yyyy|MM\",\"partition_delimiter\":\"|\"},\"wnc_odf_que_billed_au_aggr_record_type_1\":{\"partition_column\":\"month_skey\",\"partition_attribute\":\"cycle_run_year|cycle_run_month\",\"partition_value_type\":\"string\",\"partition_format\":\"yyyy|MM\",\"partition_delimiter\":\"|\"},\"wnc_odf_que_partial_daily_summary\":{\"partition_column\":\"month_skey\",\"partition_attribute\":\"cycle_run_year|cycle_run_month\",\"partition_value_type\":\"string\",\"partition_format\":\"yyyy|MM\",\"partition_delimiter\":\"|\"},\"wnc_arc_que_billed_rerate_triggers\":{\"partition_column\":\"month_skey\",\"partition_attribute\":\"ImplBilledRerateReqRestOutput.baseOutput.arcCustDetail.cycleYear|ImplBilledRerateReqRestOutput.baseOutput.arcCustDetail.cycleMonth\",\"partition_value_type\":\"string\",\"partition_format\":\"yyyy|MM\",\"partition_delimiter\":\"|\"}}";

        Schema avroSchema = SchemaBuilder.record("testRecord")
                .namespace("test_table")
                .fields()
                .requiredInt("id")
                .requiredString("name")
                .requiredBoolean("isEngineer")
                .requiredDouble("height")
                .requiredDouble("weight")
                .requiredLong("salary")
                .requiredString("startTime")
                .name("address")
                .type()
                .record("addressRecord")
                .fields()
                .requiredString("street")
                .requiredString("city")
                .endRecord()
                .noDefault()
                .endRecord();

        Schema nestedRecordSchema = SchemaBuilder.record("addressRecord")
                .fields()
                .requiredString("street")
                .requiredString("city")
                .endRecord();

        GenericRecord nestedRecord = new GenericData.Record(nestedRecordSchema);
        nestedRecord.put("street", "123 Fake St.");
        nestedRecord.put("city", "Austin, TX");

        GenericRecord record = new GenericData.Record(avroSchema);
        record.put("id", 1);
        record.put("name", "Ryan McDowell");
        record.put("isEngineer", true);
        record.put("height", 72.44);
        record.put("weight", 233.35);
        record.put("salary", 1L);
        record.put("startTime", "1711733572082"); // Friday, Mar 29, 2024 17:32:52.082 GMT
        record.put("address", nestedRecord);

        KafkaRecord<String, GenericRecord> krecord = new KafkaRecord<String, GenericRecord>(
                "wnc_cgf_que_unrated_mapping_error_records",
                0,
                0,
                0,
                KafkaTimestampType.CREATE_TIME,
                null,
                "wnc_cgf_que_unrated_mapping_error_records",
                record);

        pipeline.getCoderRegistry().registerCoderForClass(GenericRecord.class, GenericRecordCoder.of());

        // Create an input PCollection.
        PCollection<KV<String, TableRow>> trecord = pipeline.apply(
                        "Load test data",
                        Create.of(List.of(krecord))
                                .withCoder(KafkaRecordCoder.of(StringUtf8Coder.of(), GenericRecordCoder.of())))
                .apply("Kr to Kv parDo", ParDo.of(new KRToKVParDo()));

        options.as(TestOptions.class).setPartitionConfigJson(jsonConfig);

        // Create an input PCollection.
        PCollectionTuple kVRecords = trecord.apply(
                "Bucketing Records",
                ParDo.of(new DeriveColumnsParDo(jsonConfig))
                        .withOutputTags(
                                DeriveColumnsParDo.REQUIRED_RECORDS_OUT,
                                TupleTagList.of(DeriveColumnsParDo.UNPROCESSED_RECORDS_OUT)));

        PCollection<KV<String, TableRow>> required_table_rows = kVRecords.get(DeriveColumnsParDo.REQUIRED_RECORDS_OUT);
        PCollection<TableRow> required_table_rows2 =
                required_table_rows.apply("Get Table Row", ParDo.of(new TableRowToKVParDoTest.GetTableRow()));

        PCollection<KV<String, String>> trecord3 =
                required_table_rows2.apply("Kr to Kv of tableRow", ParDo.of(new TableRowToKVParDo()));

        PCollection<String> trecord4 = trecord3.apply("String key", ParDo.of(new TableRowToKVParDoTest.KeyEle()));
        PCollection<String> trecord5 = trecord3.apply("String val", ParDo.of(new TableRowToKVParDoTest.KeyVal()));

        // Assert on the key results.
        PAssert.that(trecord4).containsInAnyOrder("failed_data_" + EdrDate.getDate());

        // Note: value assertion not possible as ingested_on carrying seconds details.

        // Run the pipeline.
        pipeline.run().waitUntilFinish();
    }
}
