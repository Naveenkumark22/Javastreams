package ca.bell.edp.transformers;

import ca.bell.edp.utils.GenericRecordCoder;
import com.google.api.services.bigquery.model.TableRow;
import java.io.Serializable;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.Objects;
import org.apache.avro.Schema;
import org.apache.avro.SchemaBuilder;
import org.apache.avro.generic.GenericData.Record;
import org.apache.avro.generic.GenericRecord;
import org.apache.beam.runners.dataflow.TestDataflowPipelineOptions;
import org.apache.beam.sdk.coders.StringUtf8Coder;
import org.apache.beam.sdk.io.kafka.KafkaRecord;
import org.apache.beam.sdk.io.kafka.KafkaRecordCoder;
import org.apache.beam.sdk.io.kafka.KafkaTimestampType;
import org.apache.beam.sdk.options.PipelineOptionsFactory;
import org.apache.beam.sdk.testing.PAssert;
import org.apache.beam.sdk.testing.TestPipeline;
import org.apache.beam.sdk.testing.ValidatesRunner;
import org.apache.beam.sdk.transforms.Create;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.transforms.ParDo;
import org.apache.beam.sdk.values.KV;
import org.apache.beam.sdk.values.PCollection;
import org.junit.After;
import org.junit.ClassRule;
import org.junit.Rule;
import org.junit.experimental.categories.Category;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.rules.ExpectedException;
import org.junit.rules.TemporaryFolder;

public class KRToKVParDoTest implements Serializable {
    public TestDataflowPipelineOptions options;

    @Rule
    public transient ExpectedException thrown = ExpectedException.none();

    @Rule
    public final transient TestPipeline pipeline = TestPipeline.create().enableAbandonedNodeEnforcement(false);

    @ClassRule
    public static TemporaryFolder tempFolder = new TemporaryFolder();

    @BeforeEach
    public void setUp() throws Exception {
        options = PipelineOptionsFactory.as(TestDataflowPipelineOptions.class);
    }

    @After
    public void cleanupTestEnvironment() {
        tempFolder.delete();
    }

    @Test
    @Category(ValidatesRunner.class)
    public void testKrToKvParDo() {
        Schema avroSchema = SchemaBuilder.record("testRecord")
                .namespace("test_table")
                .fields()
                .requiredInt("id")
                .requiredString("name")
                .requiredBoolean("isEngineer")
                .requiredDouble("height")
                .requiredDouble("weight")
                .requiredLong("salary")
                .name("address")
                .type()
                .record("addressRecord")
                .fields()
                .requiredString("street")
                .requiredString("city")
                .endRecord()
                .noDefault()
                .endRecord();

        Schema nestedRecordSchema = SchemaBuilder.record("addressRecord")
                .fields()
                .requiredString("street")
                .requiredString("city")
                .endRecord();

        GenericRecord nestedRecord = new Record(nestedRecordSchema);
        nestedRecord.put("street", "123 Fake St.");
        nestedRecord.put("city", "Austin, TX");

        GenericRecord record = new Record(avroSchema);
        record.put("id", 1);
        record.put("name", "Ryan McDowell");
        record.put("isEngineer", true);
        record.put("height", 72.44);
        record.put("weight", 233.35);
        record.put("salary", 1L);
        record.put("address", nestedRecord);

        KafkaRecord<String, GenericRecord> krecord = new KafkaRecord<String, GenericRecord>(
                "test-topic", 0, 0, 0, KafkaTimestampType.CREATE_TIME, null, "test-topic", record);

        pipeline.getCoderRegistry().registerCoderForClass(GenericRecord.class, GenericRecordCoder.of());

        // Create an input PCollection.
        PCollection<KV<String, TableRow>> trecord = pipeline.apply(Create.of(Arrays.asList(krecord))
                        .withCoder(KafkaRecordCoder.of(StringUtf8Coder.of(), GenericRecordCoder.of())))
                .apply("Kr to Kv", ParDo.of(new KRToKVParDo()));

        PCollection<String> pkrecord = trecord.apply("Get key", ParDo.of(new DoFn<KV<String, TableRow>, String>() {
            @ProcessElement
            public void processElement(@Element KV<String, TableRow> element, OutputReceiver<String> out) {
                out.output(element.getKey());
            }
        }));
        PCollection<String> vrecord = trecord.apply("Get Value", ParDo.of(new DoFn<KV<String, TableRow>, String>() {
            @ProcessElement
            public void processElement(@Element KV<String, TableRow> element, OutputReceiver<String> out) {
                out.output(String.valueOf(element.getValue().get("name")));
            }
        }));

        PCollection<String> nrecord =
                trecord.apply("Get Nested Value", ParDo.of(new DoFn<KV<String, TableRow>, String>() {
                    @ProcessElement
                    public void processElement(@Element KV<String, TableRow> element, OutputReceiver<String> out) {
                        LinkedHashMap address = (LinkedHashMap)
                                Objects.requireNonNull(element.getValue()).get("address");
                        out.output(String.valueOf(address.get("street")));
                    }
                }));

        // Assert on the key results.
        PAssert.that(pkrecord).containsInAnyOrder("test-topic");

        // Assert on the value results.
        PAssert.that(vrecord).containsInAnyOrder("Ryan McDowell");

        // Assert on the nested value results.
        PAssert.that(nrecord).containsInAnyOrder("123 Fake St.");

        // Run the pipeline.
        pipeline.run().waitUntilFinish();
    }
}
