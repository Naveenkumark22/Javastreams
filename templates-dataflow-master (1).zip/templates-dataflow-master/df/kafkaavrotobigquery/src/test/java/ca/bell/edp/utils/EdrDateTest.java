package ca.bell.edp.utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.hamcrest.MatcherAssert;
import org.hamcrest.core.Is;
import org.hamcrest.core.IsInstanceOf;
import org.junit.After;
import org.junit.Rule;
import org.junit.Test;
import org.junit.jupiter.api.BeforeAll;
import org.junit.rules.ExpectedException;

public class EdrDateTest {
    Long dateEpoch = 0L;

    @Rule
    public final ExpectedException exception = ExpectedException.none();

    @BeforeAll
    public void setUp() throws Exception {
        dateEpoch = 0L;
    }

    @After
    public void tearDown() throws Exception {}

    @Test
    public void testToBqDate() throws ParseException {
        dateEpoch = 1705509035256L; // January 17, 2024 4:30:35
        String val = EdrDate.toBqDate(EdrDate.getDateFromEpoch(dateEpoch.toString(), 0));
        String dateInString = "2024-01-17";
        // Assert on the results.
        MatcherAssert.assertThat(dateInString, Is.is(val));
    }

    @Test
    public void testToMicroEpochBqDate() throws ParseException {
        dateEpoch = 1705509035256525L; // January 17, 2024 4:30:35, 16 digit length micro-seconds epoch format
        String val = EdrDate.toBqDate(EdrDate.getDateFromEpoch(dateEpoch.toString(), 0));
        String dateInString = "2024-01-17";
        // Assert on the results.
        MatcherAssert.assertThat(dateInString, Is.is(val));
    }

    @Test
    public void testDateWithMonthFirstDay() throws ParseException {
        dateEpoch = 1705509035256L; // January 17, 2024 4:30:35
        String val = EdrDate.dateWithFirstDayOfMonth(EdrDate.getDateFromEpoch(dateEpoch.toString(), 0));
        String dateInString = "2024-01-01";
        // Assert on the results.
        MatcherAssert.assertThat(dateInString, Is.is(val));
    }

    @Test
    public void testDateWithMonthFirstDayWithSeconds() throws ParseException {
        // Epoch without milliseconds
        dateEpoch = 1707766064L; // Monday, Feb 12, 2024 19:27:44 GMT
        String val = EdrDate.dateWithFirstDayOfMonth(EdrDate.getDateFromEpoch(dateEpoch.toString(), 0));
        String dateInString = "2024-02-01";
        // Assert on the results.
        MatcherAssert.assertThat(dateInString, Is.is(val));
    }

    @Test
    public void testNonEpoch() throws NumberFormatException {
        Throwable e = null;
        try {
            EdrDate.getDateFromEpoch("INVALID-VALUE", 0);
        } catch (Throwable ex) {
            e = ex;
        }
        MatcherAssert.assertThat(e, new IsInstanceOf(NumberFormatException.class));
    }

    @Test
    public void testGetDateFromEpoch() throws ParseException {
        dateEpoch = 1705509035256L; // January 17, 2024 4:30:35
        Date val = EdrDate.getDateFromEpoch(dateEpoch.toString(), 1);
        String dateInString = "11-01-2024";
        SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
        // Assert on the results.
        MatcherAssert.assertThat(formatter.parse(dateInString).getMonth(), Is.is(val.getMonth()));
        MatcherAssert.assertThat(16, Is.is(val.getDate()));
    }

    @Test
    public void testGetDateFromString() throws ParseException {
        dateEpoch = 20240111232227L;
        Date val = EdrDate.getDateFromString(dateEpoch.toString(), "yyyyMMddHHmmss");
        String dateInString = "11-01-2024";
        SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
        // Assert on the results.
        MatcherAssert.assertThat(formatter.parse(dateInString).getMonth(), Is.is(val.getMonth()));
    }

    @Test
    public void testGetCurrentTimestamp() {
        String val = EdrDate.getCurrentTimestamp();
        String fval = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
        // Assert on the results.
        MatcherAssert.assertThat(val, Is.is(fval.replace(' ', 'T')));
    }

    @Test
    public void testGetDate() {
        String val = EdrDate.getDate();
        String fval = new SimpleDateFormat("yyyy_MM_dd").format(new Date());
        // Assert on the results.
        MatcherAssert.assertThat(val, Is.is(fval));
    }

    @Test
    public void testGetDateTime() {
        String val = EdrDate.getDateTime();
        String fval = new SimpleDateFormat("yyyy-MM-dd HH:mm").format(new Date());
        // Assert on the results.
        MatcherAssert.assertThat(val, Is.is(fval));
    }
}
