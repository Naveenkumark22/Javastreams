package ca.bell.edp.utils;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Getter
public enum KafkaProperty {
    SCHEMA("SCHEMA");

    private final String name;
}
