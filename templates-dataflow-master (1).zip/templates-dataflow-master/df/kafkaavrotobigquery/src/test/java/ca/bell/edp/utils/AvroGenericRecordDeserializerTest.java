package ca.bell.edp.utils;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import com.google.common.collect.ImmutableMap;
import io.confluent.kafka.schemaregistry.client.MockSchemaRegistryClient;
import io.confluent.kafka.schemaregistry.client.SchemaRegistryClient;
import io.confluent.kafka.schemaregistry.client.rest.exceptions.RestClientException;
import io.confluent.kafka.serializers.KafkaAvroDeserializerConfig;
import io.confluent.kafka.serializers.KafkaAvroSerializer;
import io.confluent.kafka.serializers.KafkaAvroSerializerConfig;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Value;
import lombok.experimental.FieldNameConstants;
import org.apache.avro.Schema;
import org.apache.avro.generic.GenericData;
import org.apache.avro.generic.GenericRecord;
import org.apache.avro.generic.IndexedRecord;
import org.apache.avro.reflect.ReflectData;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class AvroGenericRecordDeserializerTest {
    private static final Logger LOG = LoggerFactory.getLogger(AvroGenericRecordDeserializerTest.class);
    private static final Schema GIVEN_SCHEMA = createSourceSchema();
    private static final Map<String, ?> GIVEN_CONFIGURATION_PROPERTIES =
            Map.of(KafkaProperty.SCHEMA.getName(), GIVEN_SCHEMA);
    private static final boolean GIVEN_KEY = true;

    private final AvroGenericRecordDeserializer deserializer = new AvroGenericRecordDeserializer();

    @BeforeEach
    public void configureDeserializer() {
        deserializer.configure(GIVEN_CONFIGURATION_PROPERTIES, GIVEN_KEY);
    }

    private Schema createUserSchema() {
        String userSchema = "{\"namespace\": \"example.avro\", \"type\": \"record\", " + "\"name\": \"User\","
                + "\"id\": 1,"
                + "\"fields\": [{\"name\": \"name\", \"type\": \"string\"}]}";
        Schema.Parser parser = new Schema.Parser();
        return parser.parse(userSchema);
    }

    private IndexedRecord createUserRecord() {
        Schema schema = createUserSchema();
        GenericRecord avroRecord = new GenericData.Record(schema);
        avroRecord.put("name", "testUser");
        return avroRecord;
    }

    private static SchemaRegistryClient getMockClient(final Schema schema$) {
        return new MockSchemaRegistryClient() {
            @Override
            public synchronized org.apache.avro.Schema getById(int id) {
                return schema$;
            }

            @Override
            public int getId(String subject, Schema schema) {
                return 1;
            }
        };
    }

    private static AvroGenericRecordDeserializer getDeserializer(final Schema schema$) {
        return new AvroGenericRecordDeserializer() {
            @Override
            public GenericRecord deserialize(String topic, byte[] bytes) {
                this.schemaRegistry = getMockClient(schema$);
                return super.deserialize(topic, bytes);
            }
        };
    }

    @Test
    public void testKafkaAvroSerializerWithPreRegistered() throws RestClientException, IOException {
        byte[] bytes;
        IndexedRecord avroRecord = createUserRecord();

        SchemaRegistryClient schemaRegistry = getMockClient(avroRecord.getSchema());
        Map configs = ImmutableMap.of(
                KafkaAvroDeserializerConfig.SCHEMA_REGISTRY_URL_CONFIG,
                "http://localhost:8080",
                KafkaAvroSerializerConfig.AUTO_REGISTER_SCHEMAS,
                false);

        KafkaAvroSerializer avroSerializer = new KafkaAvroSerializer(schemaRegistry, new HashMap(configs));
        avroSerializer.configure(configs, false);
        bytes = avroSerializer.serialize("test", avroRecord);
        assertEquals(avroRecord, getDeserializer(avroRecord.getSchema()).deserialize("test", bytes));
    }

    @Test
    public void testNullBytesShouldBeDeserializedToNull() {
        final String givenTopic = "test-topic";

        final GenericRecord actual = deserializer.deserialize(givenTopic, null);
        assertNull(actual);
    }

    private static Schema createSourceSchema() {
        return ReflectData.get().getSchema(TestSource.class);
    }

    @SuppressWarnings("SameParameterValue")
    private static GenericRecord createRecord(final Long id, final String name, final Boolean text) {
        final GenericRecord record = new GenericData.Record(GIVEN_SCHEMA);
        record.put(TestSource.Fields.id, id);
        record.put(TestSource.Fields.name, name);
        record.put(TestSource.Fields.isEngineer, text);
        return record;
    }

    @Value
    @AllArgsConstructor
    @Builder
    @FieldNameConstants
    private static class TestSource {
        Long id;
        String name;
        String isEngineer;
    }
}
