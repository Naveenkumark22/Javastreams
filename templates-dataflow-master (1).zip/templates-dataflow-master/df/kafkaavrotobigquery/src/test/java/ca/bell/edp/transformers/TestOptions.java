package ca.bell.edp.transformers;

import org.apache.beam.sdk.options.Description;
import org.apache.beam.sdk.options.PipelineOptions;
import org.apache.beam.sdk.options.Validation;

public interface TestOptions extends PipelineOptions {
    @Description("This JSON config string used to add partition and clustering column to the tableRow.")
    @Validation.Required
    String getPartitionConfigJson();

    void setPartitionConfigJson(String value);
}
