package ca.bell.edp.utils;

import org.apache.beam.sdk.io.Compression;
import org.apache.beam.sdk.testing.ValidatesRunner;
import org.apache.beam.sdk.transforms.windowing.GlobalWindow;
import org.apache.beam.sdk.transforms.windowing.PaneInfo;
import org.hamcrest.core.Is;
import org.junit.Assert;
import org.junit.experimental.categories.Category;
import org.junit.jupiter.api.Test;

public class FailedRowsFileFormatTest {
    @Test
    @Category(ValidatesRunner.class)
    public void testGetFilename() throws Exception {
        String filePrefix = "test";
        FailedRowsFileFormat fRFF = new FailedRowsFileFormat(filePrefix);
        Assert.assertThat(
                fRFF.getFilename(
                                GlobalWindow.INSTANCE, PaneInfo.ON_TIME_AND_ONLY_FIRING, 0, 0, Compression.UNCOMPRESSED)
                        .split("/")[0],
                Is.is("test"));
    }
}
