package ca.bell.edp.transformers;

import ca.bell.edp.utils.EdrDate;
import com.google.api.services.bigquery.model.TableRow;
import com.google.gson.Gson;
import java.io.IOException;
import java.util.Objects;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.values.KV;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class TableRowToKVParDo extends DoFn<TableRow, KV<String, String>> {
    private static final Logger LOG = LoggerFactory.getLogger(TableRowToKVParDo.class);

    @ProcessElement
    public void processElement(final ProcessContext context) throws IOException {
        try {
            Gson gson = new Gson();
            if (!Objects.requireNonNull(context.element()).isEmpty()
                    && !Objects.requireNonNull(context.element()).keySet().isEmpty()) {
                context.output(KV.of("failed_data_" + EdrDate.getDate(), gson.toJson(context.element())));
            }
        } catch (Exception e) {
            LOG.error(
                    "Error while converting TableRow Object to Json: \n{}",
                    org.codehaus.plexus.util.ExceptionUtils.getFullStackTrace(e));
        }
    }
}
