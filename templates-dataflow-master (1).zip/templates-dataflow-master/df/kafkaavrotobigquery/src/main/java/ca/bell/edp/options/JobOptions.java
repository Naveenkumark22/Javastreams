package ca.bell.edp.options;

import org.apache.beam.sdk.options.*;

public interface JobOptions
        extends PipelineOptions,
                StreamingOptions,
                KerberosOptions,
                MtlsOptions,
                KafkaOptions,
                BigQueryOptions,
                TruststoreOptions,
                SchemaRegistryOptions {
    @Description("Authorization type to connect to Kafka cluster, supported types: kerberos, mtls.")
    @Validation.Required
    String getAuthorizationType();

    void setAuthorizationType(String value);

    @Description("Secret Manager Project Id")
    @Validation.Required
    String getProjectIdForSecret();

    void setProjectIdForSecret(String value);

    @Description("Security Protocol, protocol used to communicate with brokers. Ex: SSL, SASL_SSL.")
    @Validation.Required
    String getSecurityProtocol();

    void setSecurityProtocol(String value);

    @Description("Fixed window duration, in minutes used to write error records to GCS.")
    @Default.Integer(5)
    Integer getErrorRecordWindowSizeGcs();

    void setErrorRecordWindowSizeGcs(Integer value);

    @Description("The directory to output Error EDR from BQ Insert failures.")
    @Validation.Required
    String getUnprocessedRecordsOutputDirectory();

    void setUnprocessedRecordsOutputDirectory(String value);

    @Description("This JSON config string used to add partition and clustering column to the tableRow.")
    @Validation.Required
    String getPartitionConfigJson();

    void setPartitionConfigJson(String value);
}
