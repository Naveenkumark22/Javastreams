package ca.bell.edp.utils;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.Date;
import java.util.concurrent.TimeUnit;
import org.apache.beam.repackaged.core.org.apache.commons.lang3.time.DateUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Helper class to format the timestamp values in events.
 */
public class EdrDate {
    private static final Logger LOG = LoggerFactory.getLogger(EdrDate.class);

    /**
     * Helper method to date to string date.
     *
     * @return date as value
     */
    public static String toBqDate(Date date) {
        DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        return formatter.format(date);
    }

    /**
     * Helper method to date to string date.
     *
     * @return date as value with day set to First Day of Month
     */
    public static String dateWithFirstDayOfMonth(Date date) {
        DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        date.setDate(1);
        return formatter.format(date);
    }

    /**
     * Helper method to provide epoch to date.
     *
     * @return date as value
     */
    public static Date getDateFromEpoch(String date, Integer subtractDays) throws NumberFormatException {
        Date localDate;

        if (date.length() == 16) {
            localDate = Date.from(Instant.ofEpochMilli(TimeUnit.MICROSECONDS.toMillis(Long.parseLong(date))));
        } else if (date.length() == 13) {
            localDate = Date.from(Instant.ofEpochMilli(Long.parseLong(date)));
        } else {
            localDate = Date.from(Instant.ofEpochSecond(Long.parseLong(date)));
        }

        if (subtractDays != 0) {
            localDate = DateUtils.addDays(localDate, -subtractDays);
        }
        return localDate;
    }

    /**
     * Helper method to provide string to date.
     *
     * @return date as value
     */
    public static Date getDateFromString(String date, String formatString) throws ParseException {
        SimpleDateFormat dateFormat = new SimpleDateFormat(formatString);
        return dateFormat.parse(date);
    }

    /**
     * Helper method to provide current timestamp value.
     *
     * @return current timestamp string value
     */
    public static String getCurrentTimestamp() {
        return new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss")
                .format(new java.util.Date())
                .replaceAll(" ", "T");
    }

    /**
     * Helper method to provide current timestamp value.
     *
     * @return current timestamp in date string value
     */
    public static String getDate() {
        return new java.text.SimpleDateFormat("yyyy_MM_dd").format(new java.util.Date());
    }

    /**
     * Helper method to provide current timestamp value.
     *
     * @return current timestamp in date-time string value till minute
     */
    public static String getDateTime() {
        return new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm").format(new java.util.Date());
    }
}
