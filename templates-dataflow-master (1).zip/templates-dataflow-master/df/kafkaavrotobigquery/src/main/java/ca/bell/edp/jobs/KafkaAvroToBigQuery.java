package ca.bell.edp.jobs;

import ca.bell.edp.config.LoadKafkaConfig;
import ca.bell.edp.constants.JobConstants;
import ca.bell.edp.options.JobOptions;
import ca.bell.edp.transformers.*;
import ca.bell.edp.utils.*;
import com.google.api.services.bigquery.model.TableRow;
import java.util.List;
import java.util.Map;
import org.apache.avro.generic.GenericRecord;
import org.apache.beam.sdk.Pipeline;
import org.apache.beam.sdk.PipelineResult;
import org.apache.beam.sdk.coders.NullableCoder;
import org.apache.beam.sdk.coders.StringUtf8Coder;
import org.apache.beam.sdk.io.FileIO;
import org.apache.beam.sdk.io.TextIO;
import org.apache.beam.sdk.io.gcp.bigquery.WriteResult;
import org.apache.beam.sdk.io.kafka.KafkaIO;
import org.apache.beam.sdk.io.kafka.KafkaRecord;
import org.apache.beam.sdk.io.kafka.KafkaRecordCoder;
import org.apache.beam.sdk.options.PipelineOptionsFactory;
import org.apache.beam.sdk.transforms.Contextful;
import org.apache.beam.sdk.transforms.ParDo;
import org.apache.beam.sdk.transforms.windowing.FixedWindows;
import org.apache.beam.sdk.transforms.windowing.Window;
import org.apache.beam.sdk.values.KV;
import org.apache.beam.sdk.values.PCollection;
import org.apache.beam.sdk.values.PCollectionTuple;
import org.apache.beam.sdk.values.TupleTagList;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.joda.time.Duration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Dataflow job with Kafka AVRO type data to BigQuery tables using SchemaRegistry
 * This is a generic pipeline flow with supports multiple kafka topics with SchemaRegistry integration
 */
public class KafkaAvroToBigQuery {
    private static final Logger LOG = LoggerFactory.getLogger(KafkaAvroToBigQuery.class);

    public static void main(String[] args) throws Exception {
        JobOptions options =
                PipelineOptionsFactory.fromArgs(args).withValidation().as(JobOptions.class);
        options.setStreaming(true);

        PipelineResult result = run(options);
    }

    /**
     * The pipeline run method containing the DAG.
     *
     * <p>
     * Steps:
     * 1. Prepare Kafka Configurations Object
     * 2. Register GenericRecordCoder
     * 3. Read messages from Kafka
     * 4. Convert KafkaRecord messages with a topic to TableRow with a topic as table_name
     * 5. Sink TableRow record to BigQuery dynamically
     * 6. Capture failed records
     * 7. Apply defined window duration
     * 8. Save the failed records to GCS to further analysis
     *
     * @param options pipeline options
     * @return pipeline result
     */
    public static PipelineResult run(JobOptions options) throws Exception {
        // Create the pipeline
        final Pipeline pipeline = Pipeline.create(options);

        // Load Kafka Consumer Config with preloaded credentials and secret
        Map<String, Object> config = LoadKafkaConfig.config(options);

        pipeline.getCoderRegistry().registerCoderForClass(GenericRecord.class, GenericRecordCoder.of());

        PCollection<KafkaRecord<String, GenericRecord>> messages = pipeline.apply(
                        "Read Messages",
                        KafkaIO.<String, GenericRecord>read()
                                .withBootstrapServers(options.getBootstrapServers())
                                .withReadCommitted()
                                .withTopics((List<String>) options.getInputTopic())
                                .withConsumerConfigUpdates(config)
                                .commitOffsetsInFinalize()
                                .withKeyDeserializer(StringDeserializer.class)
                                .withValueDeserializer(AvroGenericRecordDeserializer.class))
                .setCoder(KafkaRecordCoder.of(NullableCoder.of(StringUtf8Coder.of()), GenericRecordCoder.of()));

        // Bucketing records
        PCollectionTuple kVRecords = messages.apply("GenericRecord to BQ TableRow", ParDo.of(new KRToKVParDo()))
                .apply(
                        "Bucketing Records",
                        ParDo.of(new DeriveColumnsParDo(options.getPartitionConfigJson()))
                                .withOutputTags(
                                        DeriveColumnsParDo.REQUIRED_RECORDS_OUT,
                                        TupleTagList.of(DeriveColumnsParDo.UNPROCESSED_RECORDS_OUT)));

        // Write required records to BQ
        PCollection<KV<String, TableRow>> required_table_rows = kVRecords.get(DeriveColumnsParDo.REQUIRED_RECORDS_OUT);

        WriteResult writeResult = required_table_rows.apply(
                "BQ Write",
                new BigQueryDynamicWrite(
                        options.getBqProjectName(), options.getBqDataSetName(), options.getOutputWindowSizeBq()));

        // Write failed BQ records to GCS
        PCollection<KV<String, String>> failedInserts =
                writeResult.getFailedInserts().apply("Capturing Failed Records", ParDo.of(new TableRowToKVParDo()));

        failedInserts
                .apply(
                        "Apply Error window",
                        Window.<KV<String, String>>into(
                                FixedWindows.of(Duration.standardMinutes(options.getErrorRecordWindowSizeGcs()))))
                .apply(
                        "Write BQ Failed Rows To GCS",
                        FileIO.<String, KV<String, String>>writeDynamic()
                                .withDestinationCoder(StringUtf8Coder.of())
                                .by(key -> key != null ? key.getKey() : null)
                                .via(Contextful.fn(value -> value != null ? value.getValue() : null), TextIO.sink())
                                .to(options.getBqFailedOutputDirectory())
                                .withNaming(FailedRowsFileFormat::new));

        // Write unprocessed records to GCS
        PCollection<KV<String, String>> unprocessed_table_rows = kVRecords
                .get(DeriveColumnsParDo.UNPROCESSED_RECORDS_OUT)
                .apply("Capturing Unprocessed Records", ParDo.of(new TableRowToStringParDo()))
                .apply(
                        "Apply Unprocessed Window",
                        Window.<KV<String, String>>into(
                                FixedWindows.of(Duration.standardMinutes(options.getErrorRecordWindowSizeGcs()))));

        unprocessed_table_rows.apply(
                "Write Unprocessed Records to GCS",
                FileIO.<String, KV<String, String>>writeDynamic()
                        .withDestinationCoder(StringUtf8Coder.of())
                        .by(stringStringKV -> stringStringKV != null ? stringStringKV.getKey() : null)
                        .via(Contextful.fn(KV -> KV != null ? KV.getValue() : null), TextIO.sink())
                        .to(options.getUnprocessedRecordsOutputDirectory())
                        .withNaming(key -> {
                            assert key != null;
                            return FileIO.Write.defaultNaming(
                                    GCSFileHelper.getBatchFilePathAndName(key), JobConstants.GCS_FILE_EXTENSION);
                        }));

        // Execute the pipeline and return the result.
        return pipeline.run();
    }
}
