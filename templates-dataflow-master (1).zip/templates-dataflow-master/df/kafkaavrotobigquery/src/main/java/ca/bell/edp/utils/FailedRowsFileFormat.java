package ca.bell.edp.utils;

import ca.bell.edp.constants.JobConstants;
import org.apache.beam.sdk.io.Compression;
import org.apache.beam.sdk.io.FileIO;
import org.apache.beam.sdk.transforms.windowing.BoundedWindow;
import org.apache.beam.sdk.transforms.windowing.PaneInfo;
import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

/**
 * Support class to build the GCS directory structure path for each group of failed events to save to {@link com.google.api.services.bigquery.Bigquery}.
 *
 * @input string which concatenated with a window, shards, index, filePrefix (BQ table name)
 * @output File name with the complete path including a file extension
 */
public class FailedRowsFileFormat implements FileIO.Write.FileNaming {

    private static final DateTimeFormatter DATE_FORMAT = DateTimeFormat.forPattern("yyyy-MM-dd");
    private static final DateTimeFormatter TIME_FORMAT = DateTimeFormat.forPattern("HH:mm:ss");

    private final String filePrefix;

    public FailedRowsFileFormat(String prefix) {
        filePrefix = prefix;
    }

    /**
     * Create filename in specific format
     *
     * @return A string representing filename.
     */
    @Override
    public String getFilename(
            BoundedWindow window, PaneInfo pane, int numShards, int shardIndex, Compression compression) {
        return String.format(
                "%s/%s/%s/%s/%s/%s/failed-%s-of-%s%s",
                filePrefix,
                DATE_FORMAT.print(new DateTime()).substring(0, 4), // year
                DATE_FORMAT.print(new DateTime()).substring(5, 7), // month
                DATE_FORMAT.print(new DateTime()).substring(8, 10), // day
                TIME_FORMAT.print(new DateTime()).substring(0, 2), // hour
                TIME_FORMAT.print(new DateTime()).substring(3, 5), // minutes
                shardIndex,
                numShards,
                JobConstants.GCS_FILE_EXTENSION);
    }
}
