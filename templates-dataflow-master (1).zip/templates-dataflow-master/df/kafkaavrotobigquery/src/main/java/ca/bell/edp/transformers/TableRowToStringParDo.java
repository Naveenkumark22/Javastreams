package ca.bell.edp.transformers;

import ca.bell.edp.utils.EdrDate;
import com.google.api.services.bigquery.model.TableRow;
import com.google.gson.Gson;
import java.io.IOException;
import java.util.Objects;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.values.KV;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class TableRowToStringParDo extends DoFn<KV<String, TableRow>, KV<String, String>> {
    private static final Logger LOG = LoggerFactory.getLogger(TableRowToStringParDo.class);

    @ProcessElement
    public void processElement(@Element KV<String, TableRow> element, OutputReceiver<KV<String, String>> out)
            throws IOException {
        try {
            Gson gson = new Gson();
            if (!Objects.requireNonNull(element.getValue()).isEmpty()
                    && !Objects.requireNonNull(element).getValue().keySet().isEmpty()) {
                out.output(KV.of(
                        Objects.requireNonNull(element.getKey()) + "%" + EdrDate.getDateTime(),
                        gson.toJson(Objects.requireNonNull(element.getValue()))));
            }
        } catch (Exception e) {
            LOG.error(
                    "Error while converting TableRow Object to String: \n{}",
                    org.codehaus.plexus.util.ExceptionUtils.getFullStackTrace(e));
        }
    }
}
