package ca.bell.edp.constants;

public class JobConstants extends CommonConstants {}
