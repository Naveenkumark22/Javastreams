package ca.bell.edp.transformers;

import com.google.api.services.bigquery.model.TableRow;
import java.util.Objects;
import org.apache.beam.sdk.io.gcp.bigquery.BigQueryIO;
import org.apache.beam.sdk.io.gcp.bigquery.TableDestination;
import org.apache.beam.sdk.io.gcp.bigquery.WriteResult;
import org.apache.beam.sdk.transforms.PTransform;
import org.apache.beam.sdk.transforms.SerializableFunction;
import org.apache.beam.sdk.values.KV;
import org.apache.beam.sdk.values.PCollection;
import org.apache.beam.sdk.values.ValueInSingleWindow;
import org.checkerframework.checker.nullness.qual.NonNull;
import org.joda.time.Duration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Transformation ParDo class used to insert TableRow data in to BigQuery tables dynamically.
 * Where key is topic name as table name in BigQuery
 *
 * @input {@link KV}
 */
public class BigQueryDynamicWrite extends PTransform<@NonNull PCollection<KV<String, TableRow>>, @NonNull WriteResult> {
    public static final Logger LOG = LoggerFactory.getLogger(BigQueryDynamicWrite.class);
    private final String bigQueryProjectName;
    private final String bigQueryDatasetName;
    private final Integer outputWindowSizeBq;

    public BigQueryDynamicWrite(String bigQueryProjectName, String bigQueryDatasetName, Integer outputWindowSizeBq) {
        this.bigQueryProjectName = bigQueryProjectName;
        this.bigQueryDatasetName = bigQueryDatasetName;
        this.outputWindowSizeBq = outputWindowSizeBq;
    }

    @Override
    public @NonNull WriteResult expand(PCollection<KV<String, TableRow>> input) {
        return input.apply(
                "Write to BQ Tables",
                BigQueryIO.<KV<String, TableRow>>write()
                        .to((SerializableFunction<ValueInSingleWindow<KV<String, TableRow>>, TableDestination>)
                                value -> {
                                    assert value != null;
                                    String tableSpec = String.format(
                                            "%s:%s.%s",
                                            bigQueryProjectName,
                                            bigQueryDatasetName,
                                            Objects.requireNonNull(value.getValue())
                                                    .getKey());
                                    return new TableDestination(tableSpec, null);
                                })
                        .withFormatFunction(tableRow -> {
                            assert tableRow != null;
                            return tableRow.getValue();
                        })
                        .withClustering()
                        .ignoreUnknownValues()
                        .optimizedWrites()
                        .withMethod(BigQueryIO.Write.Method.FILE_LOADS)
                        .withTriggeringFrequency(Duration.standardMinutes(outputWindowSizeBq))
                        .withCreateDisposition(BigQueryIO.Write.CreateDisposition.CREATE_NEVER)
                        .withWriteDisposition(BigQueryIO.Write.WriteDisposition.WRITE_APPEND));
    }
}
