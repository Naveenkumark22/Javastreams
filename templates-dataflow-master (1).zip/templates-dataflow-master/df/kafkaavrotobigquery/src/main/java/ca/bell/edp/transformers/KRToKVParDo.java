package ca.bell.edp.transformers;

import com.google.api.services.bigquery.model.TableRow;
import java.io.IOException;
import java.util.Objects;
import org.apache.avro.Schema;
import org.apache.avro.generic.GenericRecord;
import org.apache.beam.sdk.extensions.avro.schemas.utils.AvroUtils;
import org.apache.beam.sdk.io.gcp.bigquery.BigQueryUtils;
import org.apache.beam.sdk.io.kafka.KafkaRecord;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.transforms.SerializableFunction;
import org.apache.beam.sdk.values.KV;
import org.apache.beam.sdk.values.Row;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Transformation ParDo class to build key as a topic and value as TableRow
 * data.
 * Converts {@link KafkaRecord} to {@link KV} record
 *
 * @input {@link KafkaRecord}
 * @output {@link KV}
 */
public class KRToKVParDo extends DoFn<KafkaRecord<String, GenericRecord>, KV<String, TableRow>> {
    private static final Logger LOG = LoggerFactory.getLogger(KRToKVParDo.class);

    @ProcessElement
    public void processElement(
            @Element KafkaRecord<String, GenericRecord> element, OutputReceiver<KV<String, TableRow>> out)
            throws IOException {
        try {
            assert element != null;
            assert element.getKV().getValue() != null;
            assert element.getKV().getValue().getSchema() != null;
            Schema avroSchema =
                    Objects.requireNonNull(element.getKV().getValue()).getSchema();
            SerializableFunction<GenericRecord, Row> conversionFn =
                    AvroUtils.getGenericRecordToRowFunction(AvroUtils.toBeamSchema(avroSchema));
            out.output(KV.of(
                    element.getTopic(),
                    BigQueryUtils.toTableRow(Objects.requireNonNull(
                            conversionFn.apply(element.getKV().getValue())))));
        } catch (Exception e) {
            LOG.error(
                    "Error while converting TableRow Object: \n Topic Name : {}\n {}",
                    Objects.requireNonNull(element).getTopic(),
                    org.codehaus.plexus.util.ExceptionUtils.getFullStackTrace(e));
        }
    }
}
