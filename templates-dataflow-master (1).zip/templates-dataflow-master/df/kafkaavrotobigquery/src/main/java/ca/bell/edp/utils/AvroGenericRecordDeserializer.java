package ca.bell.edp.utils;

import io.confluent.kafka.serializers.AbstractKafkaAvroDeserializer;
import io.confluent.kafka.serializers.KafkaAvroDeserializerConfig;
import java.util.Map;
import org.apache.avro.generic.GenericRecord;
import org.apache.kafka.common.serialization.Deserializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * This is a deserializer class responsible for deserializing GenericRecord
 *
 */
public class AvroGenericRecordDeserializer extends AbstractKafkaAvroDeserializer
        implements Deserializer<GenericRecord> {

    private static final Logger LOG = LoggerFactory.getLogger(AvroGenericRecordDeserializer.class);

    @Override
    public void configure(Map<String, ?> configs, boolean isKey) {
        configure(new KafkaAvroDeserializerConfig(configs));
    }

    @Override
    public GenericRecord deserialize(String s, byte[] bytes) {
        try {
            return (GenericRecord) this.deserialize(bytes);
        } catch (Exception e) {
            LOG.error(
                    "Error while deserializing GenericRecord Object: \n Topic: {}\n {}",
                    s,
                    org.codehaus.plexus.util.ExceptionUtils.getFullStackTrace(e));
        }
        return null;
    }

    @Override
    public void close() {}
}
