package ca.bell.edp.utils;

import ca.bell.edp.constants.JobConstants;
import com.google.api.services.bigquery.model.TableRow;
import com.google.gson.Gson;
import java.text.ParseException;
import java.util.List;
import java.util.Map;
import org.apache.beam.repackaged.core.org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * PartitionColumnUtil class used to add additional columns to incoming tableRow
 * Columns added based on the 'PartitionConfigJson' from pipeline options
 */
public class PartitionColumnUtil {
    private static final Logger LOG = LoggerFactory.getLogger(PartitionColumnUtil.class);

    /**
     * This method used to add partition, clustering & ingested_on columns to incoming tableRow using below params
     *
     * @return {@link TableRow}
     * @params {topic, jsonConfig, tableRow}
     */
    public static TableRow addPartitionAndClusterColumnAndValue(String topic, String jsonConfig, TableRow tableRow)
            throws ParseException {
        Map<String, Object> mapObj = new Gson().fromJson(jsonConfig, Map.class);
        if (mapObj.containsKey(topic)) {
            Map<String, String> configMap = (Map<String, String>) mapObj.get(topic);
            if (configMap.containsKey("partition_attribute")) {
                tableRow = addPartitionColumnAndValue(configMap, tableRow);
            }
            if (configMap.containsKey("cluster_attribute")) {
                tableRow = addClusteringColumnAndValue(configMap, tableRow);
            }
        }
        // Adding ingested_on column to the tableRow object, which is data ingested datetime column to BigQuery
        tableRow.set(JobConstants.INGESTED_ON, EdrDate.getCurrentTimestamp());
        return tableRow;
    }

    /**
     * This method used to add partition column to incoming tableRow using below params
     *
     * @return {@link TableRow}
     * @params {jsonMap, tableRow}
     */
    private static TableRow addPartitionColumnAndValue(Map<String, String> jsonMap, TableRow tableRow)
            throws ParseException {
        String partitionString = jsonMap.get("partition_attribute");
        String partitionValue = "";
        List<String> partitionValues = new java.util.ArrayList<>();
        if (jsonMap.containsKey("partition_delimiter")
                && partitionString.contains(jsonMap.get("partition_delimiter"))) {
            // With dynamic delimiter flow
            List<String> partitionAttributes =
                    List.of(StringUtils.splitByWholeSeparator(partitionString, jsonMap.get("partition_delimiter")));
            partitionAttributes.forEach(val -> partitionValues.add(getAttributeValue(val, tableRow)));
        } else {
            // With direct column reference flow
            partitionValue = getAttributeValue(jsonMap.get("partition_attribute"), tableRow);
        }

        // Converting retrieved values to right format as per the config
        if (jsonMap.get("partition_value_type").equals("epoch")) {
            // Epoch type dates flow
            if (jsonMap.containsKey("partition_type")
                    && jsonMap.get("partition_type").equalsIgnoreCase("day")) {
                // Partition type is DAY
                tableRow.set(
                        jsonMap.get("partition_column"),
                        EdrDate.toBqDate(EdrDate.getDateFromEpoch(
                                partitionValue,
                                jsonMap.containsKey("partition_days_subtract")
                                        ? Integer.parseInt(jsonMap.get("partition_days_subtract"))
                                        : 0)));
            } else {
                // Partition type is MONTH, setting the first day of month for MONTH partition
                tableRow.set(
                        jsonMap.get("partition_column"),
                        EdrDate.dateWithFirstDayOfMonth(EdrDate.getDateFromEpoch(
                                partitionValue,
                                jsonMap.containsKey("partition_days_subtract")
                                        ? Integer.parseInt(jsonMap.get("partition_days_subtract"))
                                        : 0)));
            }
        } else if (!partitionValues.isEmpty()
                && jsonMap.get("partition_format").contains(jsonMap.get("partition_delimiter"))) {
            tableRow.set(
                    jsonMap.get("partition_column"),
                    String.format("%s-%s-%s", partitionValues.get(0), partitionValues.get(1), "01"));
        } else if (jsonMap.get("partition_value_type").equals("string")
                && !jsonMap.containsKey("partition_delimiter")) {
            tableRow.set(
                    jsonMap.get("partition_column"),
                    EdrDate.toBqDate(EdrDate.getDateFromString(
                            tableRow.get(jsonMap.get("partition_attribute")).toString(),
                            jsonMap.get("partition_format"))));
        } else {
            tableRow.set(jsonMap.get("partition_column"), partitionValue);
        }
        return tableRow;
    }

    /**
     * This method used to add cluster column to incoming tableRow using below params
     *
     * @return {@link TableRow}
     * @params {jsonMap, tableRow}
     */
    private static TableRow addClusteringColumnAndValue(Map<String, String> jsonMap, TableRow tableRow)
            throws ParseException {
        // With direct column reference flow
        String value = getAttributeValue(jsonMap.get("cluster_attribute"), tableRow);
        if (jsonMap.get("cluster_value_type").equals("epoch")) {
            // Epoch type dates flow
            tableRow.set(jsonMap.get("cluster_column"), EdrDate.toBqDate(EdrDate.getDateFromEpoch(value, 0)));
        }
        return tableRow;
    }

    /**
     * This method used to retrieve values from tableRow,
     * This method retrieve data based on the BigQuery value & nested value reference
     *
     * Below are the sample values of params
     * attributePath: 'getSubscriberBalancesResponse.account.nextBillCycleDate'
     * tableRow: { "getSubscriberBalancesResponse": { "account": { "nextBillCycleDate": "date_value" } } }
     *
     * @return {@link String}
     * @params {attributePath, tableRow}
     */
    @SuppressWarnings("rawtypes")
    private static String getAttributeValue(String attributePath, TableRow tableRow) {
        if (attributePath.contains(".")) {
            // Fetches the data from the tableRow with a dotted reference nested column path flow
            Map localTableRow = tableRow;
            List<String> attributes = List.of(attributePath.split("\\."));
            for (int i = 0; i < attributes.size() - 1; i++) {
                localTableRow = (Map) localTableRow.get(attributes.get(i));
            }
            // Return value of last element from the list
            assert localTableRow != null;
            return localTableRow.get(attributes.get(attributes.size() - 1)).toString();
        } else {
            // Direct reference column flow
            return tableRow.get(attributePath).toString();
        }
    }
}
