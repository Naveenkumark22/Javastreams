package ca.bell.edp.transformers;

import ca.bell.edp.utils.PartitionColumnUtil;
import com.google.api.services.bigquery.model.TableRow;
import java.io.IOException;
import java.util.Objects;
import org.apache.beam.sdk.io.kafka.KafkaRecord;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.values.KV;
import org.apache.beam.sdk.values.TupleTag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * DeriveColumns ParDo class to build key as a topic and value as TableRow
 * data.
 * Converts {@link KafkaRecord} to {@link KV} record
 *
 * @input {@link KafkaRecord}
 * @output {@link KV}
 */
public class DeriveColumnsParDo extends DoFn<KV<String, TableRow>, KV<String, TableRow>> {
    private static final Logger LOG = LoggerFactory.getLogger(DeriveColumnsParDo.class);

    private final String partitionConfigJson;

    public static final TupleTag<KV<String, TableRow>> REQUIRED_RECORDS_OUT = new TupleTag<KV<String, TableRow>>() {};
    public static final TupleTag<KV<String, TableRow>> UNPROCESSED_RECORDS_OUT =
            new TupleTag<KV<String, TableRow>>() {};

    public DeriveColumnsParDo(String partitionConfigJson) {
        this.partitionConfigJson = partitionConfigJson;
    }

    @ProcessElement
    public void processElement(ProcessContext context) throws IOException {
        try {
            // Adding Partition, Clustering & ingested_on Columns based on the incoming topic name
            assert context.element() != null;
            TableRow tr = PartitionColumnUtil.addPartitionAndClusterColumnAndValue(
                    Objects.requireNonNull(context.element()).getKey(),
                    partitionConfigJson,
                    Objects.requireNonNull(
                                    Objects.requireNonNull(context.element()).getValue())
                            .clone());
            if (!tr.isEmpty()) {
                context.output(
                        REQUIRED_RECORDS_OUT,
                        KV.of(Objects.requireNonNull(context.element()).getKey(), tr));
            } else {
                // Here we capture all the AVRO objects, which are failed to parse or derive partition and clustering
                // column
                // All records moved to GCS for further troubleshooting
                // Which further avoids empty records ingestion to BQ and minimize the BQ errors
                context.output(UNPROCESSED_RECORDS_OUT, context.element());
            }
        } catch (Exception e) {
            // Here we capture all the AVRO objects, which are failed to parse or derive partition and clustering column
            // All records moved to GCS for further troubleshooting
            // Which further avoids empty records ingestion to BQ and minimize the BQ errors
            context.output(UNPROCESSED_RECORDS_OUT, context.element());
            LOG.warn(
                    "Error while adding partition column: \n Topic Name : {}\n {}",
                    Objects.requireNonNull(context.element()).getKey(),
                    org.codehaus.plexus.util.ExceptionUtils.getFullStackTrace(e));
        }
    }
}
