package ca.bell.edp.utils;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.concurrent.ConcurrentHashMap;
import org.apache.avro.Schema;
import org.apache.avro.generic.GenericRecord;
import org.apache.beam.sdk.coders.AtomicCoder;
import org.apache.beam.sdk.coders.StringUtf8Coder;
import org.apache.beam.sdk.extensions.avro.coders.AvroCoder;
import org.checkerframework.checker.nullness.qual.NonNull;

/**
 * This is a Coder class responsible integrating schema to GenericRecord
 */
public class GenericRecordCoder extends AtomicCoder<GenericRecord> {

    // Cache that holds AvroCoders for the encountered Avro records
    private static final ConcurrentHashMap<String, AvroCoder<GenericRecord>> codersCache = new ConcurrentHashMap<>();

    public static GenericRecordCoder of() {
        return new GenericRecordCoder();
    }

    @Override
    public void encode(GenericRecord record, @NonNull OutputStream outputStream) throws IOException {
        // Add base64-encoded schema to the output stream
        assert record != null;
        String schema = record.getSchema().toString();
        String schema64 = Base64.getEncoder().encodeToString(schema.getBytes());
        StringUtf8Coder.of().encode(schema64, outputStream);

        // Get AvroCoder associated with the schema
        AvroCoder<GenericRecord> coder = codersCache.computeIfAbsent(schema64, key -> AvroCoder.of(record.getSchema()));

        // Add encoded record to the output stream
        coder.encode(record, outputStream);
    }

    @Override
    public GenericRecord decode(@NonNull InputStream inputStream) throws IOException {
        // Fetch the base64-encoded schema
        String schema64 = StringUtf8Coder.of().decode(inputStream);

        // Get AvroCoder associated with the schema
        AvroCoder<GenericRecord> coder = codersCache.computeIfAbsent(
                schema64,
                key -> AvroCoder.of(new Schema.Parser()
                        .parse(new String(Base64.getDecoder().decode(schema64), StandardCharsets.UTF_8))));

        // Decode the Avro record
        return coder.decode(inputStream);
    }
}
