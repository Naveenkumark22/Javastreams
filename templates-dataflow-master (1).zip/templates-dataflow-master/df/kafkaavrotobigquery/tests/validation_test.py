"""
Example tests for the validation script.

Run it with this from repo root:
( cd test/df/pythonflow/ && python3 -munittest validation_test.py; )
"""

import json
import os
import unittest
from collections import defaultdict
from functools import wraps
from pathlib import Path
from typing import Any, Callable, cast, Dict, Iterable, TypeVar

from validation import (
    KafkaAvroToBigqueryParameters,
    PartitionConfigValue,
    validate,
    validate_partition_config_json,
    validate_partition_config_json_str,
    validate_partition_config_value,
)

MODULE_DIR = Path(__file__).parent


# Use Golden Master Testing to make performing changes such as to messages easier.
T = TypeVar("T", bound=Callable[..., Any])


class GoldenTestsDecorator:
    # a mapping of test name to how many expectations it has, this allows running
    # assert_errors multiple times per test
    golden_tests: Dict[str, int]

    def __init__(
        self, *, module_dir: Path = MODULE_DIR, overwrite_failed: bool = False
    ):
        self.golden_tests = defaultdict(lambda: 0)
        self.module_dir = module_dir
        self.expected_dir = self.module_dir / ".expected_validation_errors"
        self.overwrite_failed = overwrite_failed

    @property
    def extra_expectations(self):
        """Returns the files in self.expected_dir that don't have matching tests."""
        tests = set()
        for test_name, count in self.golden_tests.items():
            for n in range(1, count + 1):
                tests.add(f"{test_name}-{n}.json")
        return [p for p in self.expected_dir.glob("*.json") if p.name not in tests]

    def cleanup(self):
        """
        Remove files in self.expected_dir that don't have matching tests.
        Likely due to test function renaming.
        """
        for test in self.extra_expectations:
            print(f"Removing extra test {test.name}")
            test.unlink()

    def expected_path_for(self, name: str, n: int) -> Path:
        return self.expected_dir / f"{name}-{n}.json"

    def load_expected(self, name: str, n: int) -> Any:
        """Try to load a previously save expectation."""
        filepath = self.expected_path_for(name, n)
        if filepath.exists():
            with filepath.open("r") as fp:
                return json.load(fp)
        return None

    def save_expected(self, thing: Any, name: str, n: int):
        filepath = self.expected_path_for(name, n)
        with filepath.open("w") as fp:
            json.dump(thing, fp, indent=2)
        return filepath

    def assert_errors(
        self,
        errors: Iterable[str],
        name: str,
        failfn: Callable[[Any], None],
        msg: str | None = None,
    ):
        self.golden_tests[name] += 1

        if not self.expected_dir.exists():
            self.expected_dir.mkdir(parents=True, exist_ok=True)

        actual = list(errors)
        expected = self.load_expected(name, self.golden_tests[name])
        if expected is None:
            expected_file = self.save_expected(actual, name, self.golden_tests[name])
            msg = "\n".join(actual)
            failfn(f"Saved {expected_file}\nNo expectations for:\n{msg}")
        try:
            if msg:
                assert actual == expected, msg
            else:
                assert actual == expected
        except Exception as err:
            if self.overwrite_failed:
                self.save_expected(actual, name, self.golden_tests[name])
            raise err

    def __call__(self, fn: T) -> T:
        self.golden_tests[fn.__name__] = 0

        @wraps(fn)
        def wrapper(test_instance, *args, **kwargs):
            kwargs["assert_errors"] = lambda errors: self.assert_errors(
                errors, fn.__name__, test_instance.fail
            )
            return fn(test_instance, *args, **kwargs)

        return cast(T, wrapper)


def env_bool(name: str):
    return os.environ.get(name, "f").lower() in [
        "t",
        "true",
        "1",
    ]


golden_test = GoldenTestsDecorator(
    module_dir=MODULE_DIR, overwrite_failed=env_bool("TEST_OVERWRITE_FAILED")
)


def tearDownModule() -> None:
    golden_test.cleanup()


class ValidationTests(unittest.TestCase):
    """Test all the different expected validation errors."""

    @golden_test
    def test_validate_missing_partitionConfigJson(self, assert_errors):
        assert_errors(validate({}, {}))

    @golden_test
    def test_validate_partitionConfigJson_invalid_json(self, assert_errors):
        invalid_json = r"{BOGUS}"
        assert_errors(validate_partition_config_json_str(invalid_json))

    @golden_test
    def test_validate_partitionConfigJson_invalid_json_top_level(self, assert_errors):
        assert_errors(validate({"partitionConfigJson": "{BOGUS}"}, {}))

    @golden_test
    def test_validate_partitionConfigJson_missing_partition_attribute(
        self, assert_errors
    ):
        value: PartitionConfigValue = {"partition_delimiter": "|"}
        assert_errors(validate_partition_config_value(value))
        partition_config = {"table": value}
        assert_errors(validate_partition_config_json(partition_config))
        job_parameters: KafkaAvroToBigqueryParameters = {
            "partitionConfigJson": json.dumps(partition_config)
        }
        assert_errors(validate(job_parameters, {}))

    @golden_test
    def test_validate_partitionConfigJson_missing_partition_delimiter(
        self, assert_errors
    ):
        value: PartitionConfigValue = {
            "partition_attribute": "cycle_run_year,cycle_run_month",
            "partition_delimiter": "|",
        }
        assert_errors(validate_partition_config_value(value))
        value["partition_format"] = "yyyy,MM"
        assert_errors(validate_partition_config_value(value))

    @golden_test
    def test_validate_partitionConfigJson_too_many_partition_delimiters(
        self, assert_errors
    ):
        value: PartitionConfigValue = {
            "partition_attribute": "cycle_run_year|cycle_run_month|cycle_run_day|cycle_run_hour",
            "partition_delimiter": "|",
        }
        assert_errors(validate_partition_config_value(value))
        value["partition_format"] = "yyyy|MM|dd|HH"
        assert_errors(validate_partition_config_value(value))
        value["partition_format"] = "yyyy|"
        assert_errors(validate_partition_config_value(value))

    @golden_test
    def test_validate_partitionConfigJson_partition_value_type_wrong_type(
        self, assert_errors
    ):
        value: PartitionConfigValue = {
            "partition_attribute": "cycle_run_year|cycle_run_month",
            "partition_value_type": "number",
            "partition_format": "yyyy|MM",
            "partition_delimiter": "|",
        }
        assert_errors(validate_partition_config_value(value))

    @golden_test
    def test_validate_partitionConfigJson_epoch_partition_value_type_no_partition_format(
        self, assert_errors
    ):
        value: PartitionConfigValue = {
            "partition_attribute": "cycle_run_year|cycle_run_month",
            "partition_value_type": "epoch",
            "partition_format": "yyyy|MM",
            "partition_delimiter": "|",
        }
        assert_errors(validate_partition_config_value(value))

    @golden_test
    def test_validate_partitionConfigJson_cluster_column_exists_missing_cluster_value_type(
        self, assert_errors
    ):
        value: PartitionConfigValue = {
            "partition_column": "month_skey",
            "partition_attribute": "getSubscriberBalancesResponse.account.nextBillCycleDate",
            "partition_value_type": "epoch",
            "partition_days_subtract": "1",
            "cluster_column": "reporting_date",
            "cluster_attribute": "usageDetails.startTime",
        }
        assert_errors(validate_partition_config_value(value))

    @golden_test
    def test_validate_partitionConfigJson_cluster_column_exists_cluster_value_type_wrong_type(
        self, assert_errors
    ):
        value: PartitionConfigValue = {
            "partition_column": "month_skey",
            "partition_attribute": "getSubscriberBalancesResponse.account.nextBillCycleDate",
            "partition_value_type": "epoch",
            "partition_days_subtract": "1",
            "cluster_column": "reporting_date",
            "cluster_attribute": "usageDetails.startTime",
            "cluster_value_type": "string",
        }
        assert_errors(validate_partition_config_value(value))

    @golden_test
    def test_validate_partitionConfigJson_cluster_attribute_should_be_dot_separated_path(
        self, assert_errors
    ):
        value: PartitionConfigValue = {
            "partition_column": "month_skey",
            "partition_attribute": "getSubscriberBalancesResponse.account.nextBillCycleDate",
            "partition_value_type": "epoch",
            "partition_days_subtract": "1",
            "cluster_column": "reporting_date",
            "cluster_attribute": "simple_attribute_missing_dot",
            "cluster_value_type": "epoch",
        }
        assert_errors(validate_partition_config_value(value))


if __name__ == "__main__":
    unittest.main(verbosity=2)
