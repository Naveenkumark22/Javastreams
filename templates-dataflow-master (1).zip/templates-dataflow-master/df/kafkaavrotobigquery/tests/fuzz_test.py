# Fuzz Testing below requires hypothesis.
# We can generate tests for the happy path where all validations should return no errors
# and for the unhappy path where all values generated should trigger validation errors.
#
# For the happy path, we approach generating the various PartitionConfigValues as generating
# simpler subtypes and then define the partition config value as a union type like:
# partition_config_value = subtype_1 | subtype_2 | ... | subtype_n

import json
import unittest
from typing import List, Tuple

from validation import (
    KafkaAvroToBigqueryParameters,
    PartitionConfigValue,
    PartitionConfigValueKeys,
    validate,
)


try:
    import string

    from hypothesis import assume, given, settings, strategies as st

    words = st.text(string.ascii_letters, min_size=1)
    underscore_separated_words = st.lists(words, min_size=1).map(
        lambda ws: "_".join(ws)
    )
    columns = underscore_separated_words
    capitalized_letters = st.text(string.ascii_uppercase, min_size=1, max_size=1)
    lowercase_words = st.text(string.ascii_lowercase, min_size=1)
    capitalized_words = st.tuples(capitalized_letters, lowercase_words).map(
        lambda parts: "".join(parts)
    )
    camel_case_words = st.tuples(lowercase_words, capitalized_words).map(
        lambda parts: "".join(parts)
    )
    dot_separated_camel_case_words = st.lists(camel_case_words, min_size=2).map(
        lambda parts: ".".join(parts)
    )
    partition_config_values_type1 = st.fixed_dictionaries(
        {
            "partition_attribute": dot_separated_camel_case_words,
            "partition_column": columns,
            "partition_value_type": st.just("epoch"),
        }
    )

    @st.composite
    def _date_format_strs_fn(draw: st.DrawFn):
        desc = draw(
            st.fixed_dictionaries(
                {
                    "yyyy": st.booleans(),
                    "MM": st.booleans(),
                    "dd": st.booleans(),
                    "HH": st.booleans(),
                    "mm": st.booleans(),
                    "ss": st.booleans(),
                }
            )
        )
        date_format = "".join(
            dformat for dformat, should_include in desc.items() if should_include
        )
        assume(date_format != "")
        return date_format

    date_format_strs = _date_format_strs_fn()
    partition_config_values_type2 = st.fixed_dictionaries(
        {
            "partition_attribute": camel_case_words,
            "partition_column": columns,
            "partition_format": date_format_strs,
            "partition_value_type": st.just("string"),
        }
    )
    partition_config_values_type3 = st.fixed_dictionaries(
        {
            "cluster_attribute": dot_separated_camel_case_words,
            "cluster_column": columns,
            "cluster_value_type": st.just("epoch"),
            "partition_attribute": dot_separated_camel_case_words,
            "partition_column": columns,
            "partition_value_type": st.just("epoch"),
        }
    )
    delimiters = st.text(r":;,.|@^&!/\\", min_size=1, max_size=1)

    @st.composite
    def _partition_config_values_type4_fn(draw: st.DrawFn):
        delimiter = draw(delimiters)
        column_pair = draw(st.tuples(columns, columns))
        format_pair = draw(st.tuples(date_format_strs, date_format_strs))
        return {
            "partition_attribute": delimiter.join(column_pair),
            "partition_column": draw(columns),
            "partition_delimiter": delimiter,
            "partition_format": delimiter.join(format_pair),
            "partition_value_type": "string",
        }

    partition_config_values_type4 = _partition_config_values_type4_fn()
    table_names = underscore_separated_words
    # The union type of simpler subtypes
    partition_config_values = st.one_of(
        partition_config_values_type1,
        partition_config_values_type2,
        partition_config_values_type3,
        partition_config_values_type4,
    )
    partition_configs = st.dictionaries(
        keys=table_names, values=partition_config_values, min_size=1
    )
    partition_config_strs = partition_configs.map(lambda c: json.dumps(c))
    job_parameterss = st.fixed_dictionaries(
        {
            "partitionConfigJson": partition_config_strs,
        }
    )

    # Unhappy path tests consist of taking valid config values and making them invalid and checking that
    # validate() returns errors.
    def to_job_parameters(
        partition_config_value: PartitionConfigValue,
    ) -> KafkaAvroToBigqueryParameters:
        """
        To test the unhappy paths we want everything to be valid except the specific logic being tested in
        the given partition_config_value.
        """
        return {
            "partitionConfigJson": json.dumps({"test_table": partition_config_value})
        }

    Errors = List[str]

    @st.composite
    def _validate_unhappy_path_missing_attributes(draw: st.DrawFn):
        config: PartitionConfigValue = draw(partition_config_values)
        attribute_to_delete: PartitionConfigValueKeys = draw(
            st.sampled_from(["partition_attribute"])
        )
        del config[attribute_to_delete]
        errors: Errors = [
            f"partitionConfigJson.test_table: Missing required '{attribute_to_delete}' attribute."
        ]
        return to_job_parameters(config), errors

    validate_unhappy_path_missing_attributes = (
        _validate_unhappy_path_missing_attributes()
    )

    def json_parse_error(text: str) -> json.JSONDecodeError | None:
        try:
            json.loads(text)
            return None
        except json.JSONDecodeError as err:
            return err

    @st.composite
    def _validate_unhappy_path_invalid_jsons(draw: st.DrawFn):
        invalid_json = draw(st.text(string.printable, min_size=1))
        json_error = json_parse_error(invalid_json)
        assume(json_error is not None)
        job_parameters: KafkaAvroToBigqueryParameters = {
            "partitionConfigJson": invalid_json,
        }
        errors: Errors = [
            f"partitionConfigJson contains invalid JSON: {str(json_error)}"
        ]
        return job_parameters, errors

    validate_unhappy_path_invalid_jsons = _validate_unhappy_path_invalid_jsons()
    validate_unhappy_paths = st.one_of(
        validate_unhappy_path_missing_attributes, validate_unhappy_path_invalid_jsons
    )

    class FuzzTests(unittest.TestCase):
        @given(job_parameters=job_parameterss)
        @settings(max_examples=100, deadline=None)
        def test_validate_happy_path(
            self, job_parameters: KafkaAvroToBigqueryParameters
        ):
            """"""
            self.assertListEqual(
                [], list(validate(job_parameters=job_parameters, flex_template={}))
            )

        @given(data=validate_unhappy_paths)
        @settings(max_examples=100, deadline=None)
        def test_validate_unhappy_path(
            self, data: Tuple[KafkaAvroToBigqueryParameters, Errors]
        ):
            job_parameters, expected = data
            errors = list(validate(job_parameters=job_parameters, flex_template={}))
            self.assertGreater(len(errors), 0)
            self.assertListEqual(expected, errors)

except ImportError:
    pass
