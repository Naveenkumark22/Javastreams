import json
import unittest
from io import StringIO
from typing import Dict

from validation import (
    FlexTemplate,
    main,
    parse_script_input,
    PartitionConfigValue,
    ScriptInput,
)


class SupportTests(unittest.TestCase):
    """
    Tests for supporting non-validation code.
    """

    def test_parse_script_input(self) -> None:
        expected_job_parameters = {"a": "2"}
        expected_flex_template: FlexTemplate = {"metadata": {"parameters": []}}
        script_input: ScriptInput = {
            "job_parameters": json.dumps(expected_job_parameters),
            "flex_template": json.dumps(expected_flex_template),
        }
        fp = StringIO(json.dumps(script_input))
        jp, ft = parse_script_input(fp)
        assert jp == expected_job_parameters
        assert ft == expected_flex_template

    def test_parse_script_input_flex_template_is_required(self) -> None:
        script_input = {"job_parameters": json.dumps({})}
        fp = StringIO(json.dumps(script_input))
        with self.assertRaises(RuntimeError) as ctx:
            parse_script_input(fp)
        self.assertEqual("'flex_template' attribute is required.", str(ctx.exception))

    def test_parse_script_input_job_parameters_is_required(self) -> None:
        script_input = {"flex_template": json.dumps({})}
        fp = StringIO(json.dumps(script_input))
        with self.assertRaises(RuntimeError) as ctx:
            parse_script_input(fp)
        self.assertEqual("'job_parameters' attribute is required.", str(ctx.exception))

    def test_main_errors(self):
        expected_job_parameters: Dict = {}
        expected_flex_template: FlexTemplate = {"metadata": {"parameters": []}}
        script_input: ScriptInput = {
            "job_parameters": json.dumps(expected_job_parameters),
            "flex_template": json.dumps(expected_flex_template),
        }
        stdin = StringIO(json.dumps(script_input))
        stdout = StringIO()
        assert main(stdin, stdout) == 0
        stdout.seek(0)
        result = json.load(stdout)
        assert isinstance(result, list)
        assert len(result) > 0

    def test_main_no_errors(self):
        mytable_partition_config: PartitionConfigValue = {
            "partition_column": "month_skey",
            "partition_attribute": "getSubscriberBalancesResponse.account.nextBillCycleDate",
            "partition_value_type": "epoch",
            "partition_days_subtract": "1",
        }
        expected_job_parameters: Dict = {
            "partitionConfigJson": json.dumps({"mytable": mytable_partition_config})
        }
        expected_flex_template: FlexTemplate = {"metadata": {"parameters": []}}
        script_input: ScriptInput = {
            "job_parameters": json.dumps(expected_job_parameters),
            "flex_template": json.dumps(expected_flex_template),
        }
        stdin = StringIO(json.dumps(script_input))
        stdout = StringIO()
        assert main(stdin, stdout) == 0
        stdout.seek(0)
        result = json.load(stdout)
        assert isinstance(result, list)
        assert result == []
