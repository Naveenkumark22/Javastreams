import unittest
from pathlib import Path

from validation import validate, validate_partition_config_json_str

MODULE_DIR = Path(__file__).parent.parent


class DevelopmentEphemeralTests(unittest.TestCase):
    """
    Test against the partitionConfig.json used in development-ephemeral which
    should always pass and return no errors.

    Ensures any validation code changes doesn't fail a currently in-use configuration.
    """

    config_str: str

    @classmethod
    def setUpClass(cls) -> None:
        partition_config_path = (
            MODULE_DIR.parent.parent
            / "environments/development-ephemeral/partitionConfig.json"
        )
        with partition_config_path.open("r") as fp:
            cls.config_str = fp.read()

    def test_partitionConfig_json_validate_partition_config_json_str(self):
        self.assertEqual([], list(validate_partition_config_json_str(self.config_str)))

    def test_partitionConfig_json_validate(self):
        self.assertEqual(
            [], list(validate({"partitionConfigJson": self.config_str}, {}))
        )
