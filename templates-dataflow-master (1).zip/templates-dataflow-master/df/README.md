# Overview

This directory is where all the DataFlow code lives. Each subdirectory within is a java module representing a Dataflow job.

# Anatomy of a Dataflow Job Directory
- myjob/
  - pom.xml [see Maven section below](#maven)
  - flex-template.json
  - src/

## flex-template.json
Each dataflow job code base should have a flex-template.json file which will be consumed by the CI pipeline and modified to point to the container image built by that pipeline. This modified flex-template.json will then be uploaded to artifactory as a versioned release. These versioned flex templates can then be used to deploy one or more similar dataflow jobs, which differ only by their parameter configurations (see [metadata section](https://cloud.google.com/dataflow/docs/guides/templates/using-flex-templates#metadataparameters) of google docs). These versioned flex templates can also be deployed by other teams allowing them to solve similar problems without needing to code similar solutions.

Sample flex-template.json, currently the only part that will be modified by the CI pipeline is the image attribute.
```json
{
    "defaultEnvironment": {},
    "image": "TO BE REPLACED BY CI PIPELINE",
    "sdkInfo": {
        "language": "JAVA"
    },
    "metadata": {
        "name": "Sample Dataflow job",
        "description": "Dataflow job from google tutorial",
        "parameters": [
            {
                "name": "outputPath",
                "label": "GCS location to store results",
                "helpText": "GCS location to store results",
                "isOptional": false,
                "regexes": [
                    "^gs:\\/\\/.*$"
                ],
                "paramType": "TEXT"
            }
        ]
    }
}
```

### Changes from previous versions of common modules
Previously one needed to have two files in their df/ job
- metadata.json - defines the parameters for the job and has been replaced by flex-template.json
- config.yaml   - defines any standard/default values for the parameters defined in metadata.json

A flex-template.json would be built on every deployment using the metadata.json and the dataflow job would be created with parameter values that were a combination of what is defined in config.yaml and in the various parts of the terraform.

Since v1.6.0 of common modules, the dataflows configuration no longer does this and instead requires an artifactory URL to a versioned flex-template.json. All job parameters are handled in terraform. The equivalent of config.yaml, which are values that are unlikely to change between environments or that can be templated can be found in [default_dataflow_configs in terraform/](../terraform/locals.tf). The terraform/ directory gets versioned and released to be used in deploying environments. Values that change between environments can be set in environment specific terraform (ex: [development-ephemeral](../environments/development-ephemeral/main.tf))


# Maven

We are using Maven as build tool. There is a top level pom.xml which defines the common dependencies and configuration. Each subdirectory contains a child pom.xml which [inherits](https://maven.apache.org/pom.html#inheritance) from this top level pom.xml. The top level pom.xml also uses [aggregation](https://maven.apache.org/pom.html#inheritance) allowing running maven goals (ex: mvn test) on all modules.

# Formatting and Linting

We are using [Spotless](https://github.com/diffplug/spotless) multi-language code formatter and linter through it's [Maven Plugin](https://github.com/diffplug/spotless/tree/main/plugin-maven). There is a pre-commit hook setup to run spotless code formatting on `git commit` and within the gitlab pipeline executions, see [project README](../README.md#pre-commit) for more details.

It is configured to format the following types of files:
1. Java: using the [Palantir Java Formatter](https://github.com/palantir/palantir-java-format)
2. pom.xml: using [SortPom](https://github.com/Ekryd/sortpom)


There are two main maven goals for Spotless:
1. spotless:check - lint the code
2. spotless:apply - format the code

You can run a lint/format operation at a per module level or on all modules.

For all modules/DF code:
```sh
# lint
mvn -f df/pom.xml spotless:check
# or format
mvn -f df/pom.xml spotless:apply
```

For a specific module:
```sh
# lint
mvn -f df/kafkatocloudstorage/pom.xml spotless:check
# or format
mvn -f df/kafkatocloudstorage/pom.xml spotless:apply
```


The formatting configuration is located in the top level pom.xml and is inherited down to the children pom.xml.

## Configure Java Formatting
Within the build.plugins.plugin.groupId.configuration section for com.diffplug.spotless.

### Palantir Java Formatter
```xml
<java>
    <palantirJavaFormat>
        <version>${palantirJavaFormat.version}</version>
    </palantirJavaFormat>
</java>
```

### Google Java Formatter
Google Java Formatter has more than one formatting style.

#### Google Java Style
```xml
<java>
    <googleJavaFormat>
        <version>${googleJavaFormat.version}</version>
        <style>GOOGLE</style>
        <reflowLongStrings>true</reflowLongStrings>
        <formatJavadoc>false</formatJavadoc>
    </googleJavaFormat>
</java>
```

#### AOSP Java Style
```xml
<java>
    <googleJavaFormat>
        <version>${googleJavaFormat.version}</version>
        <style>AOSP</style>
        <reflowLongStrings>true</reflowLongStrings>
        <formatJavadoc>false</formatJavadoc>
    </googleJavaFormat>
</java>
```

## Configure POM Formatting
Within the build.plugins.plugin.groupId.configuration.pom section for com.diffplug.spotless.

There are quite a few configuration possibilities:
1. https://github.com/diffplug/spotless/tree/main/plugin-maven#maven-pom
2. https://github.com/diffplug/spotless/tree/main/plugin-maven#sortpom
3. https://github.com/Ekryd/sortpom/wiki/Parameters

