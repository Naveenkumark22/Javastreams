package ca.bell.edp.transformers;

import org.apache.beam.sdk.io.kafka.KafkaRecord;
import org.apache.beam.sdk.io.kafka.KafkaTimestampType;
import org.apache.beam.sdk.values.KV;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

public class KafkaRecordToValidAvroPayloadParDoTest {
    @Test
    public void testProcessElement() {
        // Mock KafkaRecord
        KafkaRecord<String, byte[]> mockRecord = new KafkaRecord<>(
                "testTopic",
                0,
                0,
                0,
                KafkaTimestampType.NO_TIMESTAMP_TYPE,
                null,
                KV.of("testKey", "abcdeValue".getBytes()));
        // Mock ProcessContext
        KafkaRecordToValidAvroPayloadParDo processDoFn = new KafkaRecordToValidAvroPayloadParDo();
        KafkaRecordToValidAvroPayloadParDo.ProcessContext mockContext =
                Mockito.mock(KafkaRecordToValidAvroPayloadParDo.ProcessContext.class);
        Mockito.when(mockContext.element()).thenReturn(mockRecord);

        processDoFn.processElement(mockContext);
        // Verify output, the first 5 bytes of value has been trimmed off
        Mockito.verify(mockContext).output(KV.of("testTopic", "Value".getBytes()));
    }
}
