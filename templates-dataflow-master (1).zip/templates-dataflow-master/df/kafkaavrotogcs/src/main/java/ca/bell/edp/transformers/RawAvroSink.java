package ca.bell.edp.transformers;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.Channels;
import java.nio.channels.WritableByteChannel;
import org.apache.avro.Schema;
import org.apache.avro.file.DataFileWriter;
import org.apache.avro.generic.GenericDatumWriter;
import org.apache.beam.sdk.io.FileIO;

public class RawAvroSink implements FileIO.Sink<byte[]> {

    private final Schema schema;
    private DataFileWriter<Object> dataFileWriter;

    public RawAvroSink(String schemaString) {
        this.schema = new Schema.Parser().parse(schemaString);
    }

    @Override
    public void open(WritableByteChannel channel) throws IOException {
        dataFileWriter = new DataFileWriter<>(new GenericDatumWriter<>(schema));
        dataFileWriter.create(schema, Channels.newOutputStream(channel));
    }

    @Override
    public void write(byte[] record) throws IOException {
        dataFileWriter.appendEncoded(ByteBuffer.wrap(record));
    }

    @Override
    public void flush() throws IOException {
        dataFileWriter.flush();
    }
}
