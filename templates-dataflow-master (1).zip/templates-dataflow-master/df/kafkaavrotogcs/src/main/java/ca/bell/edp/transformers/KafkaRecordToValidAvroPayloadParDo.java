package ca.bell.edp.transformers;

import org.apache.beam.sdk.io.kafka.KafkaRecord;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.values.KV;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Transformation ParDo class to build key as a topic and value as message data.
 *
 * @input {@link KafkaRecord}
 */
public class KafkaRecordToValidAvroPayloadParDo extends DoFn<KafkaRecord<String, byte[]>, KV<String, byte[]>> {
    private static final Logger LOG = LoggerFactory.getLogger(KafkaRecordToValidAvroPayloadParDo.class);

    @ProcessElement
    public void processElement(ProcessContext c) {
        try {
            KafkaRecord<String, byte[]> record = c.element();
            assert record != null;
            String topicName = record.getTopic();

            byte[] recordValue = record.getKV().getValue();

            // Confluent Avro prepend 5 extra bytes ahead of the Apache Avro payload to help identify the schema used to
            // encode the payload.
            // Trim the first 5 bytes to achieve a valid Apache Avro payload
            assert recordValue != null;
            byte[] trimmedBytesArray = new byte[recordValue.length - 5];
            System.arraycopy(recordValue, 5, trimmedBytesArray, 0, trimmedBytesArray.length);

            c.output(KV.of(topicName, trimmedBytesArray));
        } catch (Exception e) {
            LOG.error(
                    "Error while converting Kafka record to valid Avro record: \n{}",
                    org.codehaus.plexus.util.ExceptionUtils.getFullStackTrace(e));
        }
    }
}
