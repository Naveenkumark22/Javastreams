package ca.bell.edp.initializer;

import ca.bell.edp.options.JobOptions;
import ca.bell.edp.utils.JobInitializerHelper;
import com.google.auto.service.AutoService;
import org.apache.beam.sdk.harness.JvmInitializer;
import org.apache.beam.sdk.options.PipelineOptions;
import org.checkerframework.checker.nullness.qual.NonNull;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Class that sets the JVM initialization parameters.
 */
@AutoService(JvmInitializer.class)
public class JobInitializer implements JvmInitializer {
    private static final Logger LOG = LoggerFactory.getLogger(JobInitializer.class);

    /**
     * Method that sets the JVM initialization parameters.
     *
     * @param options pipeline options
     */
    @Override
    public void beforeProcessing(@NonNull PipelineOptions options) {
        try {
            JobInitializerHelper.initializeOptions(options.as(JobOptions.class));
        } catch (Exception ex) {
            LOG.error(
                    "JVM initialization failed : \n{}", org.codehaus.plexus.util.ExceptionUtils.getFullStackTrace(ex));
        }
    }
}
