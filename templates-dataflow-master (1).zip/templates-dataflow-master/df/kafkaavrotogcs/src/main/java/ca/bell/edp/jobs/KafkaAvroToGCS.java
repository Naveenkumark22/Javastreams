package ca.bell.edp.jobs;

import ca.bell.edp.config.LoadKafkaConfig;
import ca.bell.edp.options.JobOptions;
import ca.bell.edp.transformers.KafkaRecordToValidAvroPayloadParDo;
import ca.bell.edp.transformers.RawAvroSink;
import ca.bell.edp.utils.KafkaHelper;
import ca.bell.edp.utils.SchemaRegistryHelper;
import com.google.common.collect.ImmutableMap;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import org.apache.beam.sdk.Pipeline;
import org.apache.beam.sdk.PipelineResult;
import org.apache.beam.sdk.coders.StringUtf8Coder;
import org.apache.beam.sdk.io.FileIO;
import org.apache.beam.sdk.io.kafka.KafkaIO;
import org.apache.beam.sdk.io.kafka.KafkaRecord;
import org.apache.beam.sdk.options.PipelineOptionsFactory;
import org.apache.beam.sdk.transforms.Contextful;
import org.apache.beam.sdk.transforms.ParDo;
import org.apache.beam.sdk.transforms.windowing.FixedWindows;
import org.apache.beam.sdk.transforms.windowing.Window;
import org.apache.beam.sdk.values.KV;
import org.apache.beam.sdk.values.PCollection;
import org.apache.kafka.clients.CommonClientConfigs;
import org.apache.kafka.common.serialization.ByteArrayDeserializer;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.joda.time.Duration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Dataflow job with Kafka AVRO type data to Cloud Storage using SchemaRegistry
 * This is a generic pipeline flow with supports multiple kafka topics with SchemaRegistry integration
 */
public class KafkaAvroToGCS {
    private static final Logger LOG = LoggerFactory.getLogger(KafkaAvroToGCS.class);

    public static void main(String[] args) throws Exception {
        JobOptions options =
                PipelineOptionsFactory.fromArgs(args).withValidation().as(JobOptions.class);
        options.setStreaming(true);

        PipelineResult result = run(options);
    }

    /**
     * The pipeline run method containing the DAG.
     *
     * <p>
     * Steps:
     * 1. Prepare Kafka Configurations Object
     * 2. Read messages from Kafka in original byte format
     * 3. Map each message to a KV pair with a key as topicName and value as processed byte array
     * 4. Windowing the data of fixed duration
     * 5. Sink records to Cloud Storage dynamically through customized RawAvroSink
     *
     * @param options pipeline options
     * @return pipeline result
     */
    public static PipelineResult run(JobOptions options) throws Exception {
        // Create the pipeline
        final Pipeline pipeline = Pipeline.create(options);
        String outputFileExtension = options.getOutputFileExtension();
        String schemaRegistryUrl = options.getSchemaRegistryUrl();

        // Load Kafka Consumer Config with preloaded credentials and secrets
        Map<String, Object> config = LoadKafkaConfig.config(options);

        PCollection<KafkaRecord<String, byte[]>> messages = pipeline.apply(
                "Read Kafka Message",
                KafkaIO.<String, byte[]>read()
                        .withConsumerFactoryFn(
                                KafkaHelper.serializationBuilder(options).createKafkaConsumer())
                        .withConsumerConfigUpdates(ImmutableMap.<String, Object>builder()
                                .put(CommonClientConfigs.GROUP_ID_CONFIG, options.getKafkaGroup())
                                .build())
                        .withBootstrapServers(options.getBootstrapServers())
                        .withTopics((List<String>) options.getInputTopic())
                        .withReadCommitted()
                        .commitOffsetsInFinalize()
                        .withKeyDeserializer(StringDeserializer.class)
                        .withValueDeserializer(ByteArrayDeserializer.class));

        PCollection<KV<String, byte[]>> records = messages.apply(
                        "Map message", ParDo.of(new KafkaRecordToValidAvroPayloadParDo()))
                .apply(
                        "Apply window",
                        Window.<KV<String, byte[]>>into(
                                FixedWindows.of(Duration.standardMinutes(options.getWindowSize()))));
        records.apply(
                "WriteFileOutput",
                FileIO.<String, KV<String, byte[]>>writeDynamic()
                        .to(options.getOutputPath())
                        .by(KV::getKey)
                        .via(
                                Contextful.fn(KV::getValue),
                                Contextful.fn(key -> new RawAvroSink(
                                        SchemaRegistryHelper.getSchemaFromRegistry(key, schemaRegistryUrl, config))))
                        .withDestinationCoder(StringUtf8Coder.of())
                        .withTempDirectory(options.getTempLocation())
                        .withNaming(key -> FileIO.Write.defaultNaming(
                                String.format(
                                        "%s/dt_skey=%s/%s",
                                        key, LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")), key),
                                "." + outputFileExtension)));

        // Execute the pipeline and return the result.
        return pipeline.run();
    }
}
