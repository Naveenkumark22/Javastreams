package ca.bell.edp.options;

import org.apache.beam.sdk.options.*;

public interface JobOptions
        extends PipelineOptions,
                StreamingOptions,
                KerberosOptions,
                MtlsOptions,
                KafkaOptions,
                TruststoreOptions,
                SchemaRegistryOptions,
                GcsOptions {
    @Description("Authorization type to connect to Kafka cluster, supported types: kerberos, mtls.")
    @Validation.Required
    String getAuthorizationType();

    void setAuthorizationType(String value);

    @Description("Secret Manager Project Id")
    @Validation.Required
    String getProjectIdForSecret();

    void setProjectIdForSecret(String value);

    @Description("Security Protocol, protocol used to communicate with brokers. Ex: SSL, SASL_SSL.")
    @Validation.Required
    String getSecurityProtocol();

    void setSecurityProtocol(String value);
}
