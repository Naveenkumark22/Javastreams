package ca.bell.edp.transformers;

import static org.junit.Assert.*;

import ca.bell.edp.constants.JobConstants;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.junit.Test;

public class KafkaRecordToKVParDoTest {
    @Test
    public void testAddIngestOnTimestamp() {
        String jsonString = "{\"key\": \"value\"}";
        String dateTimeFormat = "yyyy-MM-dd HH:mm:ss";
        String result = KafkaRecordToKVParDo.addIngestOnTimestamp(jsonString, dateTimeFormat);
        // Parse the resulting JSON string
        JsonObject jsonObject = JsonParser.parseString(result).getAsJsonObject();
        // Check if the 'ingested_on' field exists
        assertTrue(jsonObject.has(JobConstants.INGESTED_ON));
        // Validate the format of the 'ingested_on' field
        try {
            SimpleDateFormat sdf = new SimpleDateFormat(dateTimeFormat);
            Date formattedTimestamp =
                    sdf.parse(jsonObject.get(JobConstants.INGESTED_ON).getAsString());
            assertNotNull(formattedTimestamp);
        } catch (Exception e) {
            fail("Error parsing the timestamp: " + e.getMessage());
        }
    }
}
