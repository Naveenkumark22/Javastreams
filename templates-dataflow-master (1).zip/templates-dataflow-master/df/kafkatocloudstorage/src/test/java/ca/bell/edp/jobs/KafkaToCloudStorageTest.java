package ca.bell.edp.jobs;

class KafkaToCloudStorageTest {}
