package ca.bell.edp.transformers;

import ca.bell.edp.constants.JobConstants;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonSyntaxException;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.apache.beam.sdk.io.kafka.KafkaRecord;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.values.KV;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Transformation ParDo class to build key as a topic and value as message data.
 *
 * @input {@link KafkaRecord}
 */
public class KafkaRecordToKVParDo extends DoFn<KafkaRecord<String, String>, KV<String, String>> {
    private static final Logger LOG = LoggerFactory.getLogger(KafkaRecordToKVParDo.class);

    @ProcessElement
    public void processElement(ProcessContext c) {
        KafkaRecord<String, String> record = c.element();
        try {
            // Choose a format that BigQuery can detect https://cloud.google.com/bigquery/docs/schema-detect
            // With the current format, it will show as 2024-03-19 13:11:35 UTC as an example in BigQuery
            assert record != null;
            c.output(
                    KV.of(record.getTopic(), addIngestOnTimestamp(record.getKV().getValue(), "yyyy-MM-dd HH:mm:ss")));
        } catch (JsonSyntaxException jse) {
            LOG.error(
                    "Error while parsing record: Invalid json syntax \n{}",
                    org.codehaus.plexus.util.ExceptionUtils.getFullStackTrace(jse));
        }
    }

    public static String addIngestOnTimestamp(String jsonString, String dateTimeFormat) throws JsonSyntaxException {
        JsonObject jsonObject = null;
        try {
            // Parse the JSON string
            jsonObject = JsonParser.parseString(jsonString).getAsJsonObject();

            // Add ingested_on timestamp field with current timestamp formatted as per the specified format
            SimpleDateFormat sdf = new SimpleDateFormat(dateTimeFormat);
            String formattedTimestamp = sdf.format(new Date());
            jsonObject.addProperty(JobConstants.INGESTED_ON, formattedTimestamp);
        } catch (JsonSyntaxException jse) {
            throw jse;
        } catch (Exception e) {
            LOG.error(
                    "Error while adding ingested on timestamp: \n{}",
                    org.codehaus.plexus.util.ExceptionUtils.getFullStackTrace(e));
        }
        // Convert back to JSON string
        return jsonObject == null ? "" : jsonObject.toString();
    }
}
