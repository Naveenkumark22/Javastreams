import concurrent.futures
import configparser
import logging
import os
import time
from pathlib import Path

from confluent_kafka import Producer


# Setup logging configuration
logging.basicConfig(level=logging.INFO)

configParser = configparser.RawConfigParser()
configFilePath = r"config.ini"
configParser.read(configFilePath)

# Kafka broker details
bootstrap_servers = configParser.get("kafka-config", "bootstrap_servers")
security_protocol = configParser.get("kafka-config", "security_protocol")
sasl_mechanism = configParser.get("kafka-config", "sasl_mechanism")
kerberos_service_name = configParser.get("kafka-config", "kerberos_service_name")
kerberos_principal = configParser.get("kafka-config", "kerberos_principal")
root_path = Path(__file__).parents[0]
# Path to keytab file
keytab_file = configParser.get("kafka-config", "keytab_file")
keytab_path = f"{root_path}/{keytab_file}"
# Kafka topic
topic = configParser.get("kafka-config", "topic")

cacert_file = configParser.get("kafka-config", "cacert_file")
cacert_path = f"{root_path}/{cacert_file}"

# variables that can be tuned to improve kafka producer throughput

# Determines how long the program will run, each iteration runs 20s currently when testing on a GCP e2 medium VM with 62MB source data
num_interations = int(configParser.get("param", "num_interations"))
# Number of threads to be used
num_threads = int(configParser.get("param", "num_threads"))
# Number of tasks to be executed concurrently
num_tasks = int(configParser.get("param", "num_tasks"))
# Location of file with sample data; large file improves throughput
data_file_path = f"{root_path}/sample-data/source-data.jsonl"

# Create Kafka producer configuration with Kerberos authentication and keytab
producer_config = {
    "bootstrap.servers": bootstrap_servers,
    "security.protocol": security_protocol,
    "sasl.mechanism": sasl_mechanism,
    "sasl.kerberos.service.name": kerberos_service_name,
    "ssl.ca.location": cacert_path,
    "sasl.kerberos.principal": kerberos_principal,
    "sasl.kerberos.keytab": keytab_path,
    # parameters set to improve throughput
    "batch.size": str(512 * 1024),
    "compression.type": "snappy",
    "linger.ms": "80",
}
# Create Kafka producer
producer = Producer(producer_config)


def get_message_size_mb(message):
    return len(message) / (1024 * 1024)


def send_messages_with_throughput(lines, target_throughput_mb):
    start_time = time.time()
    for i in range(num_interations):
        total_sent_mb = 0
        for line in lines:
            message = line.strip()
            message = message.encode("utf-8")
            message_size_mb = get_message_size_mb(message)
            total_sent_mb += message_size_mb
            # Asynchronously produce a message.
            producer.produce(topic, message)

        producer.flush()
        elapsed_time = time.time() - start_time
        current_throughput_mb = total_sent_mb / elapsed_time
        logging.info(
            f"Sent {total_sent_mb} MB data in {elapsed_time} seconds. Current throughput is {current_throughput_mb} MB/s"
        )

        # Calculate remaining time to sleep to achieve target throughput
        remaining_time = (total_sent_mb / target_throughput_mb) - elapsed_time
        # Sleep if needed to control throughput
        if remaining_time > 0:
            logging.info(f"Sleeping for {remaining_time} seconds...")
            time.sleep(remaining_time)


if __name__ == "__main__":
    start_time = time.time()

    with open(data_file_path, "r") as file:
        file_size = os.path.getsize(data_file_path)
        file_size_mb = file_size / (1024 * 1024)
        logging.info(f"Sample data file size is {file_size_mb} MB")
        lines = file.readlines()

        # Create a thread pool to leverage parallel processing
        pool = concurrent.futures.ThreadPoolExecutor(max_workers=num_threads)
        for i in range(num_tasks):
            pool.submit(send_messages_with_throughput(lines, 200))
        pool.shutdown(wait=True)

    total_elapsed_time = time.time() - start_time
    overall_throughput = num_tasks * file_size_mb * num_interations / total_elapsed_time
    logging.info(
        f"Final Results: total_elapsed_time is {total_elapsed_time}, overall throughput is {overall_throughput}"
    )
