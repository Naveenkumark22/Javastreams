#!/usr/bin/env bash

echo 'Starting customization'
_DEVCONTAINER_ENV_FILE=".devcontainer/devcontainer.env"
if [[ -f $_DEVCONTAINER_ENV_FILE ]]
then source "$_DEVCONTAINER_ENV_FILE"
fi
export ARTIFACTORY_HOST="${ARTIFACTORY_HOST:-https://artifactory.int.bell.ca}"
export HTTP_PROXY="${HTTP_PROXY:-http://10.78.128.143:80}"
export HTTPS_PROXY="${HTTPS_PROXY:-$HTTP_PROXY}"
export http_proxy="${http_proxy:-$HTTP_PROXY}"
export https_proxy="${https_proxy:-$HTTP_PROXY}"
export NO_PROXY="${NO_PROXY:-*.gitlab.int.bell.ca,*.googleapis.com,172.16.0.2,172.16.1.2,172.16.2.2,*.metadata.google.internal,*.local}"
export no_proxy="${no_proxy:-$NO_PROXY}"

echo "Acquire::http::proxy \"$HTTP_PROXY\";
Acquire::https::proxy \"$HTTPS_PROXY\";" > /etc/apt/apt.conf.d/00proxy
apt-get update
DEBIAN_FRONTEND=noninteractive apt-get install -y krb5-user python3-dev=3.11.* libsasl2-modules-gssapi-mit=2.1.* libsasl2-dev=2.1.* && \
apt-get clean && \
apt-get install -y python3-confluent-kafka=1.7.*

GLAB_VERSION='1.36.0'
GLAB_ARCHIVE="glab_${GLAB_VERSION}_Linux_x86_64.deb"
wget "https://gitlab.com/gitlab-org/cli/-/releases/v${GLAB_VERSION}/downloads/${GLAB_ARCHIVE}" \
    -O "/tmp/${GLAB_ARCHIVE}"
wget "https://gitlab.com/gitlab-org/cli/-/releases/v${GLAB_VERSION}/downloads/checksums.txt" \
    -O "/tmp/checksums.txt"
(
    set -ex 
    cd /tmp/
    grep "${GLAB_ARCHIVE}" checksums.txt | sha256sum -c
)
dpkg -i "/tmp/${GLAB_ARCHIVE}"
sudo -H -i -u vscode \
    PIP_EXTRA_INDEX_URL="https://${ARTIFACTORY_USERNAME}:${ARTIFACTORY_USER_TOKEN}@${ARTIFACTORY_HOST}/artifactory/api/pypi/ndpaadp-python-release/simple" \
    pipx install "release-operations"
echo 'Done customization'