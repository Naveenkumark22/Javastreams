Add a description of your merge request here. Merge requests without an adequate description will not be reviewed until one is added.

## General Checklist

- [ ] Workflow name(s) corresponds easily to GitLab project name
- [ ] CI / CD Pipeline is repeatable
- [ ] Retention for Processed, Raw and Archived data has been discussed and set
- [ ] No JARs and no binary blobs in the repository, ensure .gitignore has `Build/target/*` & `Build/log/*`
- [ ] Latest MR checklist is used in `develop` branch : [NBD_MR_CHKLIST](https://w0569nbdutil01.bell.corp.bce.ca/NetworkBigDataCoE/CommonProject/blob/master/gitTemplt/.gitlab/merge_request_templates/NBD_MR_CHKLIST.md)

## Data Lineage Checklist

- [ ] Data Dictionary is updated prior to any deployment, [Data Dictionary](https://confluence.wnst.int.bell.ca/display/NBD/Table+Dictionary)
- [ ] Source Owner, Data Provider & user information documented

## Alarming Checklist

- [ ] If Oozie workflow, uses [FOX](https://confluence.wnst.int.bell.ca/display/NBD/FOX+-+Usage+Examples+for+Oozie+Workflows) to raise alarms when appropriate
- [ ] Alarms priority has been declared after consultations with architect and end user
- [ ] Developer email has been specified as the alarm recipient (for dev and preprod)

## Security Checklist

- [ ] No passwords are stored, either in plaintext or in a masked form, in any source files
- [ ] No sensitive data appears in logs

## Code Quality Checklist

- [ ] All exceptions have been handled / logged (no try blocks without catch blocks or with empty catch blocks must be present)
- [ ] Code is modular
- [ ] Resource allocation (e.g. memory, CPU & no. of executors in Spark) discussed and reviewed
- [ ] Single workflow.xml and coordinator.xml files under your Oozie directory
- [ ] Specify YARN pool correctly: root.high or root.medium or root.low
- [ ] Proper partitioning for the tables has been discussed and implemented
- [ ] No data/file dumping on any nodes (including edge nodes), use direct transfer instead (e.g. pipe to external ssh)
