#!/usr/bin/env python3

import json
import sys
from typing import IO


def deep_merge(*objs: dict):
    result = {}
    for obj in objs:
        for key, value in obj.items():
            if (
                key in result
                and isinstance(result[key], dict)
                and isinstance(value, dict)
            ):
                result[key] = deep_merge(result[key], value)
            else:
                result[key] = value
    return result


def main(stdin: IO) -> int:
    query = json.load(stdin)
    if "objects" not in query:
        raise RuntimeError(
            f"query must contain 'objects' key which is a json encoded list of objects to merge together."
        )
    objects = json.loads(query["objects"])
    if not isinstance(objects, list):
        raise RuntimeError(
            f"query.objects value must be a jsonencoded array of objects to merge together, received:\n{objects!r}"
        )
    merged = deep_merge(*objects)
    print(json.dumps({"merged": json.dumps(merged)}))
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main(sys.stdin))
    except Exception as err:
        print(f"An unexpected error occured:\n{err}", file=sys.stderr)
        sys.exit(1)
