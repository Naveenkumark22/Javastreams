#!/usr/bin/env bash

# Helper script to run spotless apply in a way that will fail the pre-commit
# if it actually performed changes.

fail() {
    echo -e "[FAILED] $*"
    exit 1
}

attention() {
    echo -e "[ATTENTION] $*"
}

# Run spotless operation using maven.
# Print errors on non-zero exit and silence otherwise.
# The linting operation spotless:check returns it's changes as errors so
# displaying just the errors should provide less output and be cleaner.
# Won't silently fail due to missing pom.xml.
# Can pass in other mvn cli options like alternate settings.xml.
#
# $1 - spotless operation, ex: check|apply
# $2+ - mvn args
spotless() {
    local op="$1"
    shift
    local mvn_args=() pom_xml_path='pom.xml'
    while (( "$#" ))
    do case $1 in
            -f|--file) shift; pom_xml_path="$1"; shift;;
            *) mvn_args+=("$1"); shift;;
       esac
    done

    if ! [[ -f $pom_xml_path ]]
    then fail "$pom_xml_path does not exist"
    fi

    if ! OUTPUT="$(mvn --batch-mode -f "$pom_xml_path" "${mvn_args[@]}" "spotless:$op" 2>&1)"
    then echo "$OUTPUT" | grep '\[ERROR\]'
         return 1
    fi
}

# Returns 0 if the given string is a command on the PATH otherwise non-zero.
# A command can be:
# - an executable on the PATH
# - a bash alias
# - a bash function
#
# $1 - a potential command on the PATH
command-exists() {
    command -v "$1" > /dev/null
}

# Spotless formatter returns success if:
# 1- it successfully formatted code
# 2- it did nothing
# pre-commit framework needs a success only if there is nothing to do.
# Therefore apply changes only if needed and return failure.
main() {
    if ! command-exists mvn
    then echo
         attention "mvn command not found, please install maven and try again."
         return 1
    fi
    if ! spotless check "$@"
    then spotless apply "$@"
         echo
         attention \
            "Code failed linting check!\n- If you are a developer, the code has been" \
            "formatted correctly and you can simply git add any unstaged files and" \
            "rerun your git commit.\n- If you are a pipeline, someone will need to" \
            "run the pre-commit command and commit & push all newly formatted" \
            "files in order to fix this pipeline failure. See README for more details."
         return 1
    fi
}

main "$@"